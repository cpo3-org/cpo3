NAME          markshare_4_0
ROWS
 E R0
 E R1
 E R2
 E R3
 N R4
COLUMNS
    X0        R4                            1
    X0        R0                            1
    X1        R4                            1
    X1        R1                            1
    X2        R4                            1
    X2        R2                            1
    X3        R4                            1
    X3        R3                            1
    X4        R3                            2
    X4        R2                            46
    X4        R1                            93
    X4        R0                            17
    X5        R3                            77
    X5        R2                            63
    X5        R1                            44
    X5        R0                            75
    X6        R3                            73
    X6        R2                            13
    X6        R1                            79
    X6        R0                            9
    X7        R3                            59
    X7        R2                            97
    X7        R1                            12
    X7        R0                            87
    X8        R3                            43
    X8        R2                            14
    X8        R1                            8
    X8        R0                            58
    X9        R3                            64
    X9        R2                            45
    X9        R1                            95
    X9        R0                            79
    X10       R3                            75
    X10       R2                            32
    X10       R1                            2
    X10       R0                            69
    X11       R3                            6
    X11       R2                            96
    X11       R1                            15
    X11       R0                            37
    X12       R3                            5
    X12       R2                            36
    X12       R1                            38
    X12       R0                            88
    X13       R3                            78
    X13       R2                            40
    X13       R1                            15
    X13       R0                            75
    X14       R3                            71
    X14       R2                            10
    X14       R1                            53
    X14       R0                            45
    X15       R3                            12
    X15       R2                            96
    X15       R1                            88
    X15       R0                            35
    X16       R3                            30
    X16       R2                            99
    X16       R1                            43
    X16       R0                            73
    X17       R3                            7
    X17       R2                            58
    X17       R1                            26
    X17       R0                            26
    X18       R3                            69
    X18       R2                            87
    X18       R1                            31
    X18       R0                            39
    X19       R3                            36
    X19       R2                            15
    X19       R1                            77
    X19       R0                            78
    X20       R3                            73
    X20       R2                            91
    X20       R1                            10
    X20       R0                            85
    X21       R3                            19
    X21       R2                            65
    X21       R1                            77
    X21       R0                            58
    X22       R3                            15
    X22       R2                            6
    X22       R1                            71
    X22       R0                            72
    X23       R3                            16
    X23       R2                            96
    X23       R1                            22
    X23       R0                            8
    X24       R3                            84
    X24       R2                            97
    X24       R1                            76
    X24       R0                            46
    X25       R3                            55
    X25       R2                            79
    X25       R1                            41
    X25       R0                            11
    X26       R3                            32
    X26       R2                            81
    X26       R1                            65
    X26       R0                            55
    X27       R3                            53
    X27       R2                            57
    X27       R1                            93
    X27       R0                            39
    X28       R3                            43
    X28       R2                            28
    X28       R1                            50
    X28       R0                            57
    X29       R3                            21
    X29       R2                            97
    X29       R1                            69
    X29       R0                            96
    X30       R3                            73
    X30       R2                            58
    X30       R1                            44
    X30       R0                            87
    X31       R2                            44
    X31       R1                            61
    X31       R0                            16
    X32       R3                            59
    X32       R2                            37
    X32       R1                            58
    X32       R0                            27
    X33       R3                            48
    X33       R2                            93
    X33       R1                            63
    X33       R0                            26
RHS
    RHS       R0                            786
    RHS       R1                            759
    RHS       R2                            888
    RHS       R3                            649
BOUNDS
 UP BND       X4                            1
 UP BND       X5                            1
 UP BND       X6                            1
 UP BND       X7                            1
 UP BND       X8                            1
 UP BND       X9                            1
 UP BND       X10                           1
 UP BND       X11                           1
 UP BND       X12                           1
 UP BND       X13                           1
 UP BND       X14                           1
 UP BND       X15                           1
 UP BND       X16                           1
 UP BND       X17                           1
 UP BND       X18                           1
 UP BND       X19                           1
 UP BND       X20                           1
 UP BND       X21                           1
 UP BND       X22                           1
 UP BND       X23                           1
 UP BND       X24                           1
 UP BND       X25                           1
 UP BND       X26                           1
 UP BND       X27                           1
 UP BND       X28                           1
 UP BND       X29                           1
 UP BND       X30                           1
 UP BND       X31                           1
 UP BND       X32                           1
 UP BND       X33                           1
ENDATA
