NAME          neos-4954672-berkel
ROWS
 E R0
 E R1
 E R2
 E R3
 E R4
 E R5
 E R6
 E R7
 E R8
 E R9
 E R10
 E R11
 E R12
 E R13
 E R14
 E R15
 E R16
 E R17
 E R18
 E R19
 E R20
 E R21
 E R22
 E R23
 E R24
 E R25
 E R26
 E R27
 E R28
 E R29
 E R30
 E R31
 E R32
 E R33
 E R34
 E R35
 E R36
 E R37
 E R38
 E R39
 E R40
 E R41
 E R42
 E R43
 E R44
 E R45
 E R46
 E R47
 E R48
 E R49
 E R50
 E R51
 E R52
 E R53
 E R54
 E R55
 E R56
 E R57
 E R58
 E R59
 E R60
 E R61
 E R62
 E R63
 E R64
 E R65
 E R66
 E R67
 E R68
 E R69
 E R70
 E R71
 E R72
 E R73
 E R74
 E R75
 E R76
 E R77
 E R78
 E R79
 E R80
 E R81
 E R82
 E R83
 E R84
 E R85
 E R86
 E R87
 E R88
 E R89
 E R90
 E R91
 E R92
 E R93
 E R94
 E R95
 E R96
 E R97
 E R98
 E R99
 E R100
 E R101
 E R102
 E R103
 E R104
 E R105
 E R106
 E R107
 E R108
 E R109
 E R110
 E R111
 E R112
 E R113
 E R114
 E R115
 E R116
 E R117
 E R118
 E R119
 E R120
 E R121
 E R122
 E R123
 E R124
 E R125
 E R126
 E R127
 E R128
 E R129
 E R130
 E R131
 E R132
 E R133
 E R134
 E R135
 E R136
 E R137
 E R138
 E R139
 E R140
 E R141
 E R142
 E R143
 E R144
 E R145
 E R146
 E R147
 E R148
 E R149
 E R150
 E R151
 E R152
 E R153
 E R154
 E R155
 E R156
 E R157
 E R158
 E R159
 E R160
 E R161
 E R162
 E R163
 E R164
 E R165
 E R166
 E R167
 E R168
 E R169
 E R170
 E R171
 E R172
 E R173
 E R174
 E R175
 E R176
 E R177
 E R178
 E R179
 E R180
 E R181
 E R182
 E R183
 E R184
 E R185
 E R186
 E R187
 E R188
 E R189
 E R190
 E R191
 E R192
 E R193
 E R194
 E R195
 E R196
 E R197
 E R198
 E R199
 E R200
 E R201
 E R202
 E R203
 E R204
 E R205
 E R206
 E R207
 E R208
 E R209
 E R210
 E R211
 E R212
 E R213
 E R214
 E R215
 E R216
 E R217
 E R218
 E R219
 E R220
 E R221
 E R222
 E R223
 E R224
 E R225
 E R226
 E R227
 E R228
 E R229
 E R230
 E R231
 E R232
 E R233
 E R234
 E R235
 E R236
 E R237
 E R238
 E R239
 E R240
 E R241
 E R242
 E R243
 E R244
 E R245
 E R246
 E R247
 E R248
 E R249
 E R250
 E R251
 E R252
 E R253
 E R254
 E R255
 E R256
 E R257
 E R258
 E R259
 E R260
 E R261
 E R262
 E R263
 E R264
 E R265
 E R266
 E R267
 E R268
 E R269
 E R270
 E R271
 E R272
 E R273
 E R274
 E R275
 E R276
 E R277
 E R278
 E R279
 E R280
 E R281
 E R282
 E R283
 E R284
 E R285
 E R286
 E R287
 E R288
 E R289
 E R290
 E R291
 E R292
 E R293
 E R294
 E R295
 E R296
 E R297
 E R298
 E R299
 E R300
 E R301
 E R302
 E R303
 E R304
 E R305
 E R306
 E R307
 E R308
 E R309
 E R310
 E R311
 E R312
 E R313
 E R314
 E R315
 E R316
 E R317
 E R318
 E R319
 E R320
 E R321
 E R322
 E R323
 E R324
 E R325
 E R326
 E R327
 E R328
 E R329
 E R330
 E R331
 E R332
 E R333
 E R334
 E R335
 E R336
 E R337
 E R338
 E R339
 E R340
 E R341
 E R342
 E R343
 E R344
 E R345
 E R346
 E R347
 E R348
 E R349
 E R350
 E R351
 E R352
 E R353
 E R354
 E R355
 E R356
 E R357
 E R358
 E R359
 E R360
 E R361
 E R362
 E R363
 E R364
 E R365
 E R366
 E R367
 E R368
 E R369
 E R370
 E R371
 E R372
 E R373
 E R374
 E R375
 E R376
 E R377
 E R378
 E R379
 E R380
 E R381
 E R382
 E R383
 E R384
 E R385
 E R386
 E R387
 E R388
 E R389
 E R390
 E R391
 E R392
 E R393
 E R394
 E R395
 E R396
 E R397
 E R398
 E R399
 E R400
 E R401
 E R402
 E R403
 E R404
 E R405
 E R406
 E R407
 E R408
 E R409
 E R410
 E R411
 E R412
 E R413
 E R414
 E R415
 E R416
 E R417
 E R418
 E R419
 E R420
 E R421
 E R422
 E R423
 E R424
 E R425
 E R426
 E R427
 E R428
 E R429
 E R430
 E R431
 E R432
 E R433
 E R434
 E R435
 E R436
 E R437
 E R438
 E R439
 E R440
 E R441
 E R442
 E R443
 E R444
 E R445
 E R446
 E R447
 E R448
 E R449
 E R450
 E R451
 E R452
 E R453
 E R454
 E R455
 E R456
 E R457
 E R458
 E R459
 E R460
 E R461
 E R462
 E R463
 E R464
 E R465
 E R466
 E R467
 E R468
 E R469
 E R470
 E R471
 E R472
 E R473
 E R474
 E R475
 E R476
 E R477
 E R478
 E R479
 E R480
 E R481
 E R482
 E R483
 E R484
 E R485
 E R486
 E R487
 E R488
 E R489
 E R490
 E R491
 E R492
 E R493
 E R494
 E R495
 E R496
 E R497
 E R498
 E R499
 E R500
 E R501
 E R502
 E R503
 E R504
 E R505
 E R506
 E R507
 E R508
 E R509
 E R510
 E R511
 E R512
 E R513
 E R514
 E R515
 E R516
 E R517
 E R518
 E R519
 E R520
 E R521
 E R522
 E R523
 E R524
 L R525
 L R526
 L R527
 L R528
 L R529
 L R530
 L R531
 L R532
 L R533
 L R534
 L R535
 L R536
 L R537
 L R538
 L R539
 L R540
 L R541
 L R542
 L R543
 L R544
 L R545
 L R546
 L R547
 L R548
 L R549
 L R550
 L R551
 L R552
 L R553
 L R554
 L R555
 L R556
 L R557
 L R558
 L R559
 L R560
 L R561
 L R562
 L R563
 L R564
 L R565
 L R566
 L R567
 L R568
 L R569
 L R570
 L R571
 L R572
 L R573
 L R574
 L R575
 L R576
 L R577
 L R578
 L R579
 L R580
 L R581
 L R582
 L R583
 L R584
 L R585
 L R586
 L R587
 L R588
 L R589
 L R590
 L R591
 L R592
 L R593
 L R594
 L R595
 L R596
 L R597
 L R598
 L R599
 L R600
 L R601
 L R602
 L R603
 L R604
 L R605
 L R606
 L R607
 L R608
 L R609
 L R610
 L R611
 L R612
 L R613
 L R614
 L R615
 L R616
 L R617
 L R618
 L R619
 L R620
 L R621
 L R622
 L R623
 L R624
 L R625
 L R626
 L R627
 L R628
 L R629
 L R630
 L R631
 L R632
 L R633
 L R634
 L R635
 L R636
 L R637
 L R638
 L R639
 L R640
 L R641
 L R642
 L R643
 L R644
 L R645
 L R646
 L R647
 L R648
 L R649
 L R650
 L R651
 L R652
 L R653
 L R654
 L R655
 L R656
 L R657
 L R658
 L R659
 L R660
 L R661
 L R662
 L R663
 L R664
 L R665
 L R666
 L R667
 L R668
 L R669
 L R670
 L R671
 L R672
 L R673
 L R674
 L R675
 L R676
 L R677
 L R678
 L R679
 L R680
 L R681
 L R682
 L R683
 L R684
 L R685
 L R686
 L R687
 L R688
 L R689
 L R690
 L R691
 L R692
 L R693
 L R694
 L R695
 L R696
 L R697
 L R698
 L R699
 L R700
 L R701
 L R702
 L R703
 L R704
 L R705
 L R706
 L R707
 L R708
 L R709
 L R710
 L R711
 L R712
 L R713
 L R714
 L R715
 L R716
 L R717
 L R718
 L R719
 L R720
 L R721
 L R722
 L R723
 L R724
 L R725
 L R726
 L R727
 L R728
 L R729
 L R730
 L R731
 L R732
 L R733
 L R734
 L R735
 L R736
 L R737
 L R738
 L R739
 L R740
 L R741
 L R742
 L R743
 L R744
 L R745
 L R746
 L R747
 L R748
 L R749
 L R750
 L R751
 L R752
 L R753
 L R754
 L R755
 L R756
 L R757
 L R758
 L R759
 L R760
 L R761
 L R762
 L R763
 L R764
 L R765
 L R766
 L R767
 L R768
 L R769
 L R770
 L R771
 L R772
 L R773
 L R774
 L R775
 L R776
 L R777
 L R778
 L R779
 L R780
 L R781
 L R782
 L R783
 L R784
 L R785
 L R786
 L R787
 L R788
 L R789
 L R790
 L R791
 L R792
 L R793
 L R794
 L R795
 L R796
 L R797
 L R798
 L R799
 L R800
 L R801
 L R802
 L R803
 L R804
 L R805
 L R806
 L R807
 L R808
 L R809
 L R810
 L R811
 L R812
 L R813
 L R814
 L R815
 L R816
 L R817
 L R818
 L R819
 L R820
 L R821
 L R822
 L R823
 L R824
 L R825
 L R826
 L R827
 L R828
 L R829
 L R830
 L R831
 L R832
 L R833
 L R834
 L R835
 L R836
 L R837
 L R838
 L R839
 L R840
 L R841
 L R842
 L R843
 L R844
 L R845
 L R846
 L R847
 L R848
 L R849
 L R850
 L R851
 L R852
 L R853
 L R854
 L R855
 L R856
 L R857
 L R858
 L R859
 L R860
 L R861
 L R862
 L R863
 L R864
 L R865
 L R866
 L R867
 L R868
 L R869
 L R870
 L R871
 L R872
 L R873
 L R874
 L R875
 L R876
 L R877
 L R878
 L R879
 L R880
 L R881
 L R882
 L R883
 L R884
 L R885
 L R886
 L R887
 L R888
 L R889
 L R890
 L R891
 L R892
 L R893
 L R894
 L R895
 L R896
 L R897
 L R898
 L R899
 L R900
 L R901
 L R902
 L R903
 L R904
 L R905
 L R906
 L R907
 L R908
 L R909
 L R910
 L R911
 L R912
 L R913
 L R914
 L R915
 L R916
 L R917
 L R918
 L R919
 L R920
 L R921
 L R922
 L R923
 L R924
 L R925
 L R926
 L R927
 L R928
 L R929
 L R930
 L R931
 L R932
 L R933
 L R934
 L R935
 L R936
 L R937
 L R938
 L R939
 L R940
 L R941
 L R942
 L R943
 L R944
 L R945
 L R946
 L R947
 L R948
 L R949
 L R950
 L R951
 L R952
 L R953
 L R954
 L R955
 L R956
 L R957
 L R958
 L R959
 L R960
 L R961
 L R962
 L R963
 L R964
 L R965
 L R966
 L R967
 L R968
 L R969
 L R970
 L R971
 L R972
 L R973
 L R974
 L R975
 L R976
 L R977
 L R978
 L R979
 L R980
 L R981
 L R982
 L R983
 L R984
 L R985
 L R986
 L R987
 L R988
 L R989
 L R990
 L R991
 L R992
 L R993
 L R994
 L R995
 L R996
 L R997
 L R998
 L R999
 L R1000
 L R1001
 L R1002
 L R1003
 L R1004
 L R1005
 L R1006
 L R1007
 L R1008
 L R1009
 L R1010
 L R1011
 L R1012
 L R1013
 L R1014
 L R1015
 L R1016
 L R1017
 L R1018
 L R1019
 L R1020
 L R1021
 L R1022
 L R1023
 L R1024
 L R1025
 L R1026
 L R1027
 L R1028
 L R1029
 L R1030
 L R1031
 L R1032
 L R1033
 L R1034
 L R1035
 L R1036
 L R1037
 L R1038
 L R1039
 L R1040
 L R1041
 L R1042
 L R1043
 L R1044
 L R1045
 L R1046
 L R1047
 L R1048
 L R1049
 L R1050
 L R1051
 L R1052
 L R1053
 L R1054
 L R1055
 L R1056
 L R1057
 L R1058
 L R1059
 L R1060
 L R1061
 L R1062
 L R1063
 L R1064
 L R1065
 L R1066
 L R1067
 L R1068
 L R1069
 L R1070
 L R1071
 L R1072
 L R1073
 L R1074
 L R1075
 L R1076
 L R1077
 L R1078
 L R1079
 L R1080
 L R1081
 L R1082
 L R1083
 L R1084
 L R1085
 L R1086
 L R1087
 L R1088
 L R1089
 L R1090
 L R1091
 L R1092
 L R1093
 L R1094
 L R1095
 L R1096
 L R1097
 L R1098
 L R1099
 L R1100
 L R1101
 L R1102
 L R1103
 L R1104
 L R1105
 L R1106
 L R1107
 L R1108
 L R1109
 L R1110
 L R1111
 L R1112
 L R1113
 L R1114
 L R1115
 L R1116
 L R1117
 L R1118
 L R1119
 L R1120
 L R1121
 L R1122
 L R1123
 L R1124
 L R1125
 L R1126
 L R1127
 L R1128
 L R1129
 L R1130
 L R1131
 L R1132
 L R1133
 L R1134
 L R1135
 L R1136
 L R1137
 L R1138
 L R1139
 L R1140
 L R1141
 L R1142
 L R1143
 L R1144
 L R1145
 L R1146
 L R1147
 L R1148
 L R1149
 L R1150
 L R1151
 L R1152
 L R1153
 L R1154
 L R1155
 L R1156
 L R1157
 L R1158
 L R1159
 L R1160
 L R1161
 L R1162
 L R1163
 L R1164
 L R1165
 L R1166
 L R1167
 L R1168
 L R1169
 L R1170
 L R1171
 L R1172
 L R1173
 L R1174
 L R1175
 L R1176
 L R1177
 L R1178
 L R1179
 L R1180
 L R1181
 L R1182
 L R1183
 L R1184
 L R1185
 L R1186
 L R1187
 L R1188
 L R1189
 L R1190
 L R1191
 L R1192
 L R1193
 L R1194
 L R1195
 L R1196
 L R1197
 L R1198
 L R1199
 L R1200
 L R1201
 L R1202
 L R1203
 L R1204
 L R1205
 L R1206
 L R1207
 L R1208
 L R1209
 L R1210
 L R1211
 L R1212
 L R1213
 L R1214
 L R1215
 L R1216
 L R1217
 L R1218
 L R1219
 L R1220
 L R1221
 L R1222
 L R1223
 L R1224
 L R1225
 L R1226
 L R1227
 L R1228
 L R1229
 L R1230
 L R1231
 L R1232
 L R1233
 L R1234
 L R1235
 L R1236
 L R1237
 L R1238
 L R1239
 L R1240
 L R1241
 L R1242
 L R1243
 L R1244
 L R1245
 L R1246
 L R1247
 L R1248
 L R1249
 L R1250
 L R1251
 L R1252
 L R1253
 L R1254
 L R1255
 L R1256
 L R1257
 L R1258
 L R1259
 L R1260
 L R1261
 L R1262
 L R1263
 L R1264
 L R1265
 L R1266
 L R1267
 L R1268
 L R1269
 L R1270
 L R1271
 L R1272
 L R1273
 L R1274
 L R1275
 L R1276
 L R1277
 L R1278
 L R1279
 L R1280
 L R1281
 L R1282
 L R1283
 L R1284
 L R1285
 L R1286
 L R1287
 L R1288
 L R1289
 L R1290
 L R1291
 L R1292
 L R1293
 L R1294
 L R1295
 L R1296
 L R1297
 L R1298
 L R1299
 L R1300
 L R1301
 L R1302
 L R1303
 L R1304
 L R1305
 L R1306
 L R1307
 L R1308
 L R1309
 L R1310
 L R1311
 L R1312
 L R1313
 L R1314
 L R1315
 L R1316
 L R1317
 L R1318
 L R1319
 L R1320
 L R1321
 L R1322
 L R1323
 L R1324
 L R1325
 L R1326
 L R1327
 L R1328
 L R1329
 L R1330
 L R1331
 L R1332
 L R1333
 L R1334
 L R1335
 L R1336
 L R1337
 L R1338
 L R1339
 L R1340
 L R1341
 L R1342
 L R1343
 L R1344
 L R1345
 L R1346
 L R1347
 L R1348
 L R1349
 L R1350
 L R1351
 L R1352
 L R1353
 L R1354
 L R1355
 L R1356
 L R1357
 L R1358
 L R1359
 L R1360
 L R1361
 L R1362
 L R1363
 L R1364
 L R1365
 L R1366
 L R1367
 L R1368
 L R1369
 L R1370
 L R1371
 L R1372
 L R1373
 L R1374
 L R1375
 L R1376
 L R1377
 L R1378
 L R1379
 L R1380
 L R1381
 L R1382
 L R1383
 L R1384
 L R1385
 L R1386
 L R1387
 L R1388
 L R1389
 L R1390
 L R1391
 L R1392
 L R1393
 L R1394
 L R1395
 L R1396
 L R1397
 L R1398
 L R1399
 L R1400
 L R1401
 L R1402
 L R1403
 L R1404
 L R1405
 L R1406
 L R1407
 L R1408
 L R1409
 L R1410
 L R1411
 L R1412
 L R1413
 L R1414
 L R1415
 L R1416
 L R1417
 L R1418
 L R1419
 L R1420
 L R1421
 L R1422
 L R1423
 L R1424
 L R1425
 L R1426
 L R1427
 L R1428
 L R1429
 L R1430
 L R1431
 L R1432
 L R1433
 L R1434
 L R1435
 L R1436
 L R1437
 L R1438
 L R1439
 L R1440
 L R1441
 L R1442
 L R1443
 L R1444
 L R1445
 L R1446
 L R1447
 L R1448
 L R1449
 L R1450
 L R1451
 L R1452
 L R1453
 L R1454
 L R1455
 L R1456
 L R1457
 L R1458
 L R1459
 L R1460
 L R1461
 L R1462
 L R1463
 L R1464
 L R1465
 L R1466
 L R1467
 L R1468
 L R1469
 L R1470
 L R1471
 L R1472
 L R1473
 L R1474
 L R1475
 L R1476
 L R1477
 L R1478
 L R1479
 L R1480
 L R1481
 L R1482
 L R1483
 L R1484
 L R1485
 L R1486
 L R1487
 L R1488
 L R1489
 L R1490
 L R1491
 L R1492
 L R1493
 L R1494
 L R1495
 L R1496
 L R1497
 L R1498
 L R1499
 L R1500
 L R1501
 L R1502
 L R1503
 L R1504
 L R1505
 L R1506
 L R1507
 L R1508
 L R1509
 L R1510
 L R1511
 L R1512
 L R1513
 L R1514
 L R1515
 L R1516
 L R1517
 L R1518
 L R1519
 L R1520
 L R1521
 L R1522
 L R1523
 L R1524
 L R1525
 L R1526
 L R1527
 L R1528
 L R1529
 L R1530
 L R1531
 L R1532
 L R1533
 L R1534
 L R1535
 L R1536
 L R1537
 L R1538
 L R1539
 L R1540
 L R1541
 L R1542
 L R1543
 L R1544
 L R1545
 L R1546
 L R1547
 L R1548
 L R1549
 L R1550
 L R1551
 L R1552
 L R1553
 L R1554
 L R1555
 L R1556
 L R1557
 L R1558
 L R1559
 L R1560
 L R1561
 L R1562
 L R1563
 L R1564
 L R1565
 L R1566
 L R1567
 L R1568
 L R1569
 L R1570
 L R1571
 L R1572
 L R1573
 L R1574
 L R1575
 L R1576
 L R1577
 L R1578
 L R1579
 L R1580
 L R1581
 L R1582
 L R1583
 L R1584
 L R1585
 L R1586
 L R1587
 L R1588
 L R1589
 L R1590
 L R1591
 L R1592
 L R1593
 L R1594
 L R1595
 L R1596
 L R1597
 L R1598
 L R1599
 L R1600
 L R1601
 L R1602
 L R1603
 L R1604
 L R1605
 L R1606
 L R1607
 L R1608
 L R1609
 L R1610
 L R1611
 L R1612
 L R1613
 L R1614
 L R1615
 L R1616
 L R1617
 L R1618
 L R1619
 L R1620
 L R1621
 L R1622
 L R1623
 L R1624
 L R1625
 L R1626
 L R1627
 L R1628
 L R1629
 L R1630
 L R1631
 L R1632
 L R1633
 L R1634
 L R1635
 L R1636
 L R1637
 L R1638
 L R1639
 L R1640
 L R1641
 L R1642
 L R1643
 L R1644
 L R1645
 L R1646
 L R1647
 L R1648
 L R1649
 L R1650
 L R1651
 L R1652
 L R1653
 L R1654
 L R1655
 L R1656
 L R1657
 L R1658
 L R1659
 L R1660
 L R1661
 L R1662
 L R1663
 L R1664
 L R1665
 L R1666
 L R1667
 L R1668
 L R1669
 L R1670
 L R1671
 L R1672
 L R1673
 L R1674
 L R1675
 L R1676
 L R1677
 L R1678
 L R1679
 L R1680
 L R1681
 L R1682
 L R1683
 L R1684
 L R1685
 L R1686
 L R1687
 L R1688
 L R1689
 L R1690
 L R1691
 L R1692
 L R1693
 L R1694
 L R1695
 L R1696
 L R1697
 L R1698
 L R1699
 L R1700
 L R1701
 L R1702
 L R1703
 L R1704
 L R1705
 L R1706
 L R1707
 L R1708
 L R1709
 L R1710
 L R1711
 L R1712
 L R1713
 L R1714
 L R1715
 L R1716
 L R1717
 L R1718
 L R1719
 L R1720
 L R1721
 L R1722
 L R1723
 L R1724
 L R1725
 L R1726
 L R1727
 L R1728
 L R1729
 L R1730
 L R1731
 L R1732
 L R1733
 L R1734
 L R1735
 L R1736
 L R1737
 L R1738
 L R1739
 L R1740
 L R1741
 L R1742
 L R1743
 L R1744
 L R1745
 L R1746
 L R1747
 L R1748
 L R1749
 L R1750
 L R1751
 L R1752
 L R1753
 L R1754
 L R1755
 L R1756
 L R1757
 L R1758
 L R1759
 L R1760
 L R1761
 L R1762
 L R1763
 L R1764
 L R1765
 L R1766
 L R1767
 L R1768
 L R1769
 L R1770
 L R1771
 L R1772
 L R1773
 L R1774
 L R1775
 L R1776
 L R1777
 L R1778
 L R1779
 L R1780
 L R1781
 L R1782
 L R1783
 L R1784
 L R1785
 L R1786
 L R1787
 L R1788
 L R1789
 L R1790
 L R1791
 L R1792
 L R1793
 L R1794
 L R1795
 L R1796
 L R1797
 L R1798
 L R1799
 L R1800
 L R1801
 L R1802
 L R1803
 L R1804
 L R1805
 L R1806
 L R1807
 L R1808
 L R1809
 L R1810
 L R1811
 L R1812
 L R1813
 L R1814
 L R1815
 L R1816
 L R1817
 L R1818
 L R1819
 L R1820
 L R1821
 L R1822
 L R1823
 L R1824
 L R1825
 L R1826
 L R1827
 L R1828
 L R1829
 L R1830
 L R1831
 L R1832
 L R1833
 L R1834
 L R1835
 L R1836
 L R1837
 L R1838
 L R1839
 L R1840
 L R1841
 L R1842
 L R1843
 L R1844
 L R1845
 L R1846
 L R1847
 N R1848
COLUMNS
    X0        R0                            -1
    X0        R126                          -1
    X0        R127                          -1
    X0        R128                          -1
    X0        R504                          -1
    X0        R525                          1
    X0        R546                          100
    X0        R924                          100
    X0        R1302                         100
    X0        R1323                         100
    X0        R1344                         100
    X0        R1407                         100
    X0        R1470                         100
    X0        R1596                         100
    X0        R1722                         100
    X0        R1764                         100
    X1        R0                            -1
    X1        R127                          -1
    X1        R128                          -1
    X1        R504                          -1
    X1        R525                          1
    X1        R547                          100
    X1        R925                          100
    X1        R1303                         100
    X1        R1324                         100
    X1        R1345                         100
    X1        R1408                         100
    X1        R1471                         100
    X1        R1597                         100
    X1        R1723                         100
    X1        R1765                         100
    X2        R0                            -1
    X2        R128                          -1
    X2        R504                          -1
    X2        R525                          1
    X2        R548                          100
    X2        R926                          100
    X2        R1304                         100
    X2        R1325                         100
    X2        R1346                         100
    X2        R1409                         100
    X2        R1472                         100
    X2        R1598                         100
    X2        R1724                         100
    X2        R1766                         100
    X3        R18                           -1
    X3        R180                          -1
    X3        R186                          -1
    X3        R192                          -1
    X3        R507                          -1
    X3        R528                          1
    X3        R549                          100
    X3        R927                          100
    X3        R1305                         100
    X3        R1326                         100
    X3        R1347                         100
    X3        R1410                         100
    X3        R1473                         100
    X3        R1599                         100
    X3        R1725                         100
    X3        R1767                         100
    X4        R18                           -1
    X4        R186                          -1
    X4        R192                          -1
    X4        R507                          -1
    X4        R528                          1
    X4        R550                          100
    X4        R928                          100
    X4        R1306                         100
    X4        R1327                         100
    X4        R1348                         100
    X4        R1411                         100
    X4        R1474                         100
    X4        R1600                         100
    X4        R1726                         100
    X4        R1768                         100
    X5        R18                           -1
    X5        R192                          -1
    X5        R507                          -1
    X5        R528                          1
    X5        R551                          100
    X5        R929                          100
    X5        R1307                         100
    X5        R1328                         100
    X5        R1349                         100
    X5        R1412                         100
    X5        R1475                         100
    X5        R1601                         100
    X5        R1727                         100
    X5        R1769                         100
    X6        R19                           -1
    X6        R181                          -1
    X6        R187                          -1
    X6        R193                          -1
    X6        R508                          -1
    X6        R529                          1
    X6        R552                          100
    X6        R930                          100
    X6        R1308                         100
    X6        R1329                         100
    X6        R1350                         100
    X6        R1413                         100
    X6        R1476                         100
    X6        R1602                         100
    X6        R1728                         100
    X6        R1770                         100
    X7        R19                           -1
    X7        R187                          -1
    X7        R193                          -1
    X7        R508                          -1
    X7        R529                          1
    X7        R553                          100
    X7        R931                          100
    X7        R1309                         100
    X7        R1330                         100
    X7        R1351                         100
    X7        R1414                         100
    X7        R1477                         100
    X7        R1603                         100
    X7        R1729                         100
    X7        R1771                         100
    X8        R19                           -1
    X8        R193                          -1
    X8        R508                          -1
    X8        R529                          1
    X8        R554                          100
    X8        R932                          100
    X8        R1310                         100
    X8        R1331                         100
    X8        R1352                         100
    X8        R1415                         100
    X8        R1478                         100
    X8        R1604                         100
    X8        R1730                         100
    X8        R1772                         100
    X9        R20                           -1
    X9        R182                          -1
    X9        R188                          -1
    X9        R194                          -1
    X9        R509                          -1
    X9        R530                          1
    X9        R555                          100
    X9        R933                          100
    X9        R1311                         100
    X9        R1332                         100
    X9        R1353                         100
    X9        R1416                         100
    X9        R1479                         100
    X9        R1605                         100
    X9        R1731                         100
    X9        R1773                         100
    X10       R20                           -1
    X10       R188                          -1
    X10       R194                          -1
    X10       R509                          -1
    X10       R530                          1
    X10       R556                          100
    X10       R934                          100
    X10       R1312                         100
    X10       R1333                         100
    X10       R1354                         100
    X10       R1417                         100
    X10       R1480                         100
    X10       R1606                         100
    X10       R1732                         100
    X10       R1774                         100
    X11       R20                           -1
    X11       R194                          -1
    X11       R509                          -1
    X11       R530                          1
    X11       R557                          100
    X11       R935                          100
    X11       R1313                         100
    X11       R1334                         100
    X11       R1355                         100
    X11       R1418                         100
    X11       R1481                         100
    X11       R1607                         100
    X11       R1733                         100
    X11       R1775                         100
    X12       R21                           -1
    X12       R183                          -1
    X12       R189                          -1
    X12       R195                          -1
    X12       R510                          -1
    X12       R531                          1
    X12       R558                          100
    X12       R936                          100
    X12       R1314                         100
    X12       R1335                         100
    X12       R1356                         100
    X12       R1419                         100
    X12       R1482                         100
    X12       R1608                         100
    X12       R1734                         100
    X12       R1776                         100
    X13       R21                           -1
    X13       R189                          -1
    X13       R195                          -1
    X13       R510                          -1
    X13       R531                          1
    X13       R559                          100
    X13       R937                          100
    X13       R1315                         100
    X13       R1336                         100
    X13       R1357                         100
    X13       R1420                         100
    X13       R1483                         100
    X13       R1609                         100
    X13       R1735                         100
    X13       R1777                         100
    X14       R21                           -1
    X14       R195                          -1
    X14       R510                          -1
    X14       R531                          1
    X14       R560                          100
    X14       R938                          100
    X14       R1316                         100
    X14       R1337                         100
    X14       R1358                         100
    X14       R1421                         100
    X14       R1484                         100
    X14       R1610                         100
    X14       R1736                         100
    X14       R1778                         100
    X15       R22                           -1
    X15       R184                          -1
    X15       R190                          -1
    X15       R196                          -1
    X15       R511                          -1
    X15       R532                          1
    X15       R561                          100
    X15       R939                          100
    X15       R1317                         100
    X15       R1338                         100
    X15       R1359                         100
    X15       R1422                         100
    X15       R1485                         100
    X15       R1611                         100
    X15       R1737                         100
    X15       R1779                         100
    X16       R22                           -1
    X16       R190                          -1
    X16       R196                          -1
    X16       R511                          -1
    X16       R532                          1
    X16       R562                          100
    X16       R940                          100
    X16       R1318                         100
    X16       R1339                         100
    X16       R1360                         100
    X16       R1423                         100
    X16       R1486                         100
    X16       R1612                         100
    X16       R1738                         100
    X16       R1780                         100
    X17       R22                           -1
    X17       R196                          -1
    X17       R511                          -1
    X17       R532                          1
    X17       R563                          100
    X17       R941                          100
    X17       R1319                         100
    X17       R1340                         100
    X17       R1361                         100
    X17       R1424                         100
    X17       R1487                         100
    X17       R1613                         100
    X17       R1739                         100
    X17       R1781                         100
    X18       R23                           -1
    X18       R185                          -1
    X18       R191                          -1
    X18       R197                          -1
    X18       R512                          -1
    X18       R533                          1
    X18       R564                          100
    X18       R942                          100
    X18       R1320                         100
    X18       R1341                         100
    X18       R1362                         100
    X18       R1425                         100
    X18       R1488                         100
    X18       R1614                         100
    X18       R1740                         100
    X18       R1782                         100
    X19       R23                           -1
    X19       R191                          -1
    X19       R197                          -1
    X19       R512                          -1
    X19       R533                          1
    X19       R565                          100
    X19       R943                          100
    X19       R1321                         100
    X19       R1342                         100
    X19       R1363                         100
    X19       R1426                         100
    X19       R1489                         100
    X19       R1615                         100
    X19       R1741                         100
    X19       R1783                         100
    X20       R23                           -1
    X20       R197                          -1
    X20       R512                          -1
    X20       R533                          1
    X20       R566                          100
    X20       R944                          100
    X20       R1322                         100
    X20       R1343                         100
    X20       R1364                         100
    X20       R1427                         100
    X20       R1490                         100
    X20       R1616                         100
    X20       R1742                         100
    X20       R1784                         100
    X21       R1                            -1
    X21       R129                          -1
    X21       R130                          -1
    X21       R131                          -1
    X21       R504                          -1
    X21       R525                          1
    X21       R567                          100
    X21       R945                          100
    X21       R1302                         100
    X21       R1323                         100
    X21       R1344                         100
    X21       R1407                         100
    X21       R1491                         100
    X21       R1617                         100
    X21       R1722                         100
    X21       R1764                         100
    X22       R1                            -1
    X22       R130                          -1
    X22       R131                          -1
    X22       R504                          -1
    X22       R525                          1
    X22       R568                          100
    X22       R946                          100
    X22       R1303                         100
    X22       R1324                         100
    X22       R1345                         100
    X22       R1408                         100
    X22       R1492                         100
    X22       R1618                         100
    X22       R1723                         100
    X22       R1765                         100
    X23       R1                            -1
    X23       R131                          -1
    X23       R504                          -1
    X23       R525                          1
    X23       R569                          100
    X23       R947                          100
    X23       R1304                         100
    X23       R1325                         100
    X23       R1346                         100
    X23       R1409                         100
    X23       R1493                         100
    X23       R1619                         100
    X23       R1724                         100
    X23       R1766                         100
    X24       R24                           -1
    X24       R198                          -1
    X24       R204                          -1
    X24       R210                          -1
    X24       R507                          -1
    X24       R528                          1
    X24       R570                          100
    X24       R948                          100
    X24       R1305                         100
    X24       R1326                         100
    X24       R1347                         100
    X24       R1410                         100
    X24       R1494                         100
    X24       R1620                         100
    X24       R1725                         100
    X24       R1767                         100
    X25       R24                           -1
    X25       R204                          -1
    X25       R210                          -1
    X25       R507                          -1
    X25       R528                          1
    X25       R571                          100
    X25       R949                          100
    X25       R1306                         100
    X25       R1327                         100
    X25       R1348                         100
    X25       R1411                         100
    X25       R1495                         100
    X25       R1621                         100
    X25       R1726                         100
    X25       R1768                         100
    X26       R24                           -1
    X26       R210                          -1
    X26       R507                          -1
    X26       R528                          1
    X26       R572                          100
    X26       R950                          100
    X26       R1307                         100
    X26       R1328                         100
    X26       R1349                         100
    X26       R1412                         100
    X26       R1496                         100
    X26       R1622                         100
    X26       R1727                         100
    X26       R1769                         100
    X27       R25                           -1
    X27       R199                          -1
    X27       R205                          -1
    X27       R211                          -1
    X27       R508                          -1
    X27       R529                          1
    X27       R573                          100
    X27       R951                          100
    X27       R1308                         100
    X27       R1329                         100
    X27       R1350                         100
    X27       R1413                         100
    X27       R1497                         100
    X27       R1623                         100
    X27       R1728                         100
    X27       R1770                         100
    X28       R25                           -1
    X28       R205                          -1
    X28       R211                          -1
    X28       R508                          -1
    X28       R529                          1
    X28       R574                          100
    X28       R952                          100
    X28       R1309                         100
    X28       R1330                         100
    X28       R1351                         100
    X28       R1414                         100
    X28       R1498                         100
    X28       R1624                         100
    X28       R1729                         100
    X28       R1771                         100
    X29       R25                           -1
    X29       R211                          -1
    X29       R508                          -1
    X29       R529                          1
    X29       R575                          100
    X29       R953                          100
    X29       R1310                         100
    X29       R1331                         100
    X29       R1352                         100
    X29       R1415                         100
    X29       R1499                         100
    X29       R1625                         100
    X29       R1730                         100
    X29       R1772                         100
    X30       R26                           -1
    X30       R200                          -1
    X30       R206                          -1
    X30       R212                          -1
    X30       R509                          -1
    X30       R530                          1
    X30       R576                          100
    X30       R954                          100
    X30       R1311                         100
    X30       R1332                         100
    X30       R1353                         100
    X30       R1416                         100
    X30       R1500                         100
    X30       R1626                         100
    X30       R1731                         100
    X30       R1773                         100
    X31       R26                           -1
    X31       R206                          -1
    X31       R212                          -1
    X31       R509                          -1
    X31       R530                          1
    X31       R577                          100
    X31       R955                          100
    X31       R1312                         100
    X31       R1333                         100
    X31       R1354                         100
    X31       R1417                         100
    X31       R1501                         100
    X31       R1627                         100
    X31       R1732                         100
    X31       R1774                         100
    X32       R26                           -1
    X32       R212                          -1
    X32       R509                          -1
    X32       R530                          1
    X32       R578                          100
    X32       R956                          100
    X32       R1313                         100
    X32       R1334                         100
    X32       R1355                         100
    X32       R1418                         100
    X32       R1502                         100
    X32       R1628                         100
    X32       R1733                         100
    X32       R1775                         100
    X33       R27                           -1
    X33       R201                          -1
    X33       R207                          -1
    X33       R213                          -1
    X33       R510                          -1
    X33       R531                          1
    X33       R579                          100
    X33       R957                          100
    X33       R1314                         100
    X33       R1335                         100
    X33       R1356                         100
    X33       R1419                         100
    X33       R1503                         100
    X33       R1629                         100
    X33       R1734                         100
    X33       R1776                         100
    X34       R27                           -1
    X34       R207                          -1
    X34       R213                          -1
    X34       R510                          -1
    X34       R531                          1
    X34       R580                          100
    X34       R958                          100
    X34       R1315                         100
    X34       R1336                         100
    X34       R1357                         100
    X34       R1420                         100
    X34       R1504                         100
    X34       R1630                         100
    X34       R1735                         100
    X34       R1777                         100
    X35       R27                           -1
    X35       R213                          -1
    X35       R510                          -1
    X35       R531                          1
    X35       R581                          100
    X35       R959                          100
    X35       R1316                         100
    X35       R1337                         100
    X35       R1358                         100
    X35       R1421                         100
    X35       R1505                         100
    X35       R1631                         100
    X35       R1736                         100
    X35       R1778                         100
    X36       R28                           -1
    X36       R202                          -1
    X36       R208                          -1
    X36       R214                          -1
    X36       R511                          -1
    X36       R532                          1
    X36       R582                          100
    X36       R960                          100
    X36       R1317                         100
    X36       R1338                         100
    X36       R1359                         100
    X36       R1422                         100
    X36       R1506                         100
    X36       R1632                         100
    X36       R1737                         100
    X36       R1779                         100
    X37       R28                           -1
    X37       R208                          -1
    X37       R214                          -1
    X37       R511                          -1
    X37       R532                          1
    X37       R583                          100
    X37       R961                          100
    X37       R1318                         100
    X37       R1339                         100
    X37       R1360                         100
    X37       R1423                         100
    X37       R1507                         100
    X37       R1633                         100
    X37       R1738                         100
    X37       R1780                         100
    X38       R28                           -1
    X38       R214                          -1
    X38       R511                          -1
    X38       R532                          1
    X38       R584                          100
    X38       R962                          100
    X38       R1319                         100
    X38       R1340                         100
    X38       R1361                         100
    X38       R1424                         100
    X38       R1508                         100
    X38       R1634                         100
    X38       R1739                         100
    X38       R1781                         100
    X39       R29                           -1
    X39       R203                          -1
    X39       R209                          -1
    X39       R215                          -1
    X39       R512                          -1
    X39       R533                          1
    X39       R585                          100
    X39       R963                          100
    X39       R1320                         100
    X39       R1341                         100
    X39       R1362                         100
    X39       R1425                         100
    X39       R1509                         100
    X39       R1635                         100
    X39       R1740                         100
    X39       R1782                         100
    X40       R29                           -1
    X40       R209                          -1
    X40       R215                          -1
    X40       R512                          -1
    X40       R533                          1
    X40       R586                          100
    X40       R964                          100
    X40       R1321                         100
    X40       R1342                         100
    X40       R1363                         100
    X40       R1426                         100
    X40       R1510                         100
    X40       R1636                         100
    X40       R1741                         100
    X40       R1783                         100
    X41       R29                           -1
    X41       R215                          -1
    X41       R512                          -1
    X41       R533                          1
    X41       R587                          100
    X41       R965                          100
    X41       R1322                         100
    X41       R1343                         100
    X41       R1364                         100
    X41       R1427                         100
    X41       R1511                         100
    X41       R1637                         100
    X41       R1742                         100
    X41       R1784                         100
    X42       R2                            -1
    X42       R132                          -1
    X42       R133                          -1
    X42       R134                          -1
    X42       R504                          -1
    X42       R525                          1
    X42       R588                          100
    X42       R966                          100
    X42       R1302                         100
    X42       R1323                         100
    X42       R1365                         100
    X42       R1428                         100
    X42       R1512                         100
    X42       R1638                         100
    X42       R1722                         100
    X42       R1764                         100
    X43       R2                            -1
    X43       R133                          -1
    X43       R134                          -1
    X43       R504                          -1
    X43       R525                          1
    X43       R589                          100
    X43       R967                          100
    X43       R1303                         100
    X43       R1324                         100
    X43       R1366                         100
    X43       R1429                         100
    X43       R1513                         100
    X43       R1639                         100
    X43       R1723                         100
    X43       R1765                         100
    X44       R2                            -1
    X44       R134                          -1
    X44       R504                          -1
    X44       R525                          1
    X44       R590                          100
    X44       R968                          100
    X44       R1304                         100
    X44       R1325                         100
    X44       R1367                         100
    X44       R1430                         100
    X44       R1514                         100
    X44       R1640                         100
    X44       R1724                         100
    X44       R1766                         100
    X45       R30                           -1
    X45       R216                          -1
    X45       R222                          -1
    X45       R228                          -1
    X45       R507                          -1
    X45       R528                          1
    X45       R591                          100
    X45       R969                          100
    X45       R1305                         100
    X45       R1326                         100
    X45       R1368                         100
    X45       R1431                         100
    X45       R1515                         100
    X45       R1641                         100
    X45       R1725                         100
    X45       R1767                         100
    X46       R30                           -1
    X46       R222                          -1
    X46       R228                          -1
    X46       R507                          -1
    X46       R528                          1
    X46       R592                          100
    X46       R970                          100
    X46       R1306                         100
    X46       R1327                         100
    X46       R1369                         100
    X46       R1432                         100
    X46       R1516                         100
    X46       R1642                         100
    X46       R1726                         100
    X46       R1768                         100
    X47       R30                           -1
    X47       R228                          -1
    X47       R507                          -1
    X47       R528                          1
    X47       R593                          100
    X47       R971                          100
    X47       R1307                         100
    X47       R1328                         100
    X47       R1370                         100
    X47       R1433                         100
    X47       R1517                         100
    X47       R1643                         100
    X47       R1727                         100
    X47       R1769                         100
    X48       R31                           -1
    X48       R217                          -1
    X48       R223                          -1
    X48       R229                          -1
    X48       R508                          -1
    X48       R529                          1
    X48       R594                          100
    X48       R972                          100
    X48       R1308                         100
    X48       R1329                         100
    X48       R1371                         100
    X48       R1434                         100
    X48       R1518                         100
    X48       R1644                         100
    X48       R1728                         100
    X48       R1770                         100
    X49       R31                           -1
    X49       R223                          -1
    X49       R229                          -1
    X49       R508                          -1
    X49       R529                          1
    X49       R595                          100
    X49       R973                          100
    X49       R1309                         100
    X49       R1330                         100
    X49       R1372                         100
    X49       R1435                         100
    X49       R1519                         100
    X49       R1645                         100
    X49       R1729                         100
    X49       R1771                         100
    X50       R31                           -1
    X50       R229                          -1
    X50       R508                          -1
    X50       R529                          1
    X50       R596                          100
    X50       R974                          100
    X50       R1310                         100
    X50       R1331                         100
    X50       R1373                         100
    X50       R1436                         100
    X50       R1520                         100
    X50       R1646                         100
    X50       R1730                         100
    X50       R1772                         100
    X51       R32                           -1
    X51       R218                          -1
    X51       R224                          -1
    X51       R230                          -1
    X51       R509                          -1
    X51       R530                          1
    X51       R597                          100
    X51       R975                          100
    X51       R1311                         100
    X51       R1332                         100
    X51       R1374                         100
    X51       R1437                         100
    X51       R1521                         100
    X51       R1647                         100
    X51       R1731                         100
    X51       R1773                         100
    X52       R32                           -1
    X52       R224                          -1
    X52       R230                          -1
    X52       R509                          -1
    X52       R530                          1
    X52       R598                          100
    X52       R976                          100
    X52       R1312                         100
    X52       R1333                         100
    X52       R1375                         100
    X52       R1438                         100
    X52       R1522                         100
    X52       R1648                         100
    X52       R1732                         100
    X52       R1774                         100
    X53       R32                           -1
    X53       R230                          -1
    X53       R509                          -1
    X53       R530                          1
    X53       R599                          100
    X53       R977                          100
    X53       R1313                         100
    X53       R1334                         100
    X53       R1376                         100
    X53       R1439                         100
    X53       R1523                         100
    X53       R1649                         100
    X53       R1733                         100
    X53       R1775                         100
    X54       R33                           -1
    X54       R219                          -1
    X54       R225                          -1
    X54       R231                          -1
    X54       R510                          -1
    X54       R531                          1
    X54       R600                          100
    X54       R978                          100
    X54       R1314                         100
    X54       R1335                         100
    X54       R1377                         100
    X54       R1440                         100
    X54       R1524                         100
    X54       R1650                         100
    X54       R1734                         100
    X54       R1776                         100
    X55       R33                           -1
    X55       R225                          -1
    X55       R231                          -1
    X55       R510                          -1
    X55       R531                          1
    X55       R601                          100
    X55       R979                          100
    X55       R1315                         100
    X55       R1336                         100
    X55       R1378                         100
    X55       R1441                         100
    X55       R1525                         100
    X55       R1651                         100
    X55       R1735                         100
    X55       R1777                         100
    X56       R33                           -1
    X56       R231                          -1
    X56       R510                          -1
    X56       R531                          1
    X56       R602                          100
    X56       R980                          100
    X56       R1316                         100
    X56       R1337                         100
    X56       R1379                         100
    X56       R1442                         100
    X56       R1526                         100
    X56       R1652                         100
    X56       R1736                         100
    X56       R1778                         100
    X57       R34                           -1
    X57       R220                          -1
    X57       R226                          -1
    X57       R232                          -1
    X57       R511                          -1
    X57       R532                          1
    X57       R603                          100
    X57       R981                          100
    X57       R1317                         100
    X57       R1338                         100
    X57       R1380                         100
    X57       R1443                         100
    X57       R1527                         100
    X57       R1653                         100
    X57       R1737                         100
    X57       R1779                         100
    X58       R34                           -1
    X58       R226                          -1
    X58       R232                          -1
    X58       R511                          -1
    X58       R532                          1
    X58       R604                          100
    X58       R982                          100
    X58       R1318                         100
    X58       R1339                         100
    X58       R1381                         100
    X58       R1444                         100
    X58       R1528                         100
    X58       R1654                         100
    X58       R1738                         100
    X58       R1780                         100
    X59       R34                           -1
    X59       R232                          -1
    X59       R511                          -1
    X59       R532                          1
    X59       R605                          100
    X59       R983                          100
    X59       R1319                         100
    X59       R1340                         100
    X59       R1382                         100
    X59       R1445                         100
    X59       R1529                         100
    X59       R1655                         100
    X59       R1739                         100
    X59       R1781                         100
    X60       R35                           -1
    X60       R221                          -1
    X60       R227                          -1
    X60       R233                          -1
    X60       R512                          -1
    X60       R533                          1
    X60       R606                          100
    X60       R984                          100
    X60       R1320                         100
    X60       R1341                         100
    X60       R1383                         100
    X60       R1446                         100
    X60       R1530                         100
    X60       R1656                         100
    X60       R1740                         100
    X60       R1782                         100
    X61       R35                           -1
    X61       R227                          -1
    X61       R233                          -1
    X61       R512                          -1
    X61       R533                          1
    X61       R607                          100
    X61       R985                          100
    X61       R1321                         100
    X61       R1342                         100
    X61       R1384                         100
    X61       R1447                         100
    X61       R1531                         100
    X61       R1657                         100
    X61       R1741                         100
    X61       R1783                         100
    X62       R35                           -1
    X62       R233                          -1
    X62       R512                          -1
    X62       R533                          1
    X62       R608                          100
    X62       R986                          100
    X62       R1322                         100
    X62       R1343                         100
    X62       R1385                         100
    X62       R1448                         100
    X62       R1532                         100
    X62       R1658                         100
    X62       R1742                         100
    X62       R1784                         100
    X63       R3                            -1
    X63       R135                          -1
    X63       R136                          -1
    X63       R137                          -1
    X63       R504                          -1
    X63       R525                          1
    X63       R609                          100
    X63       R987                          100
    X63       R1302                         100
    X63       R1323                         100
    X63       R1365                         100
    X63       R1428                         100
    X63       R1533                         100
    X63       R1659                         100
    X63       R1722                         100
    X63       R1764                         100
    X64       R3                            -1
    X64       R136                          -1
    X64       R137                          -1
    X64       R504                          -1
    X64       R525                          1
    X64       R610                          100
    X64       R988                          100
    X64       R1303                         100
    X64       R1324                         100
    X64       R1366                         100
    X64       R1429                         100
    X64       R1534                         100
    X64       R1660                         100
    X64       R1723                         100
    X64       R1765                         100
    X65       R3                            -1
    X65       R137                          -1
    X65       R504                          -1
    X65       R525                          1
    X65       R611                          100
    X65       R989                          100
    X65       R1304                         100
    X65       R1325                         100
    X65       R1367                         100
    X65       R1430                         100
    X65       R1535                         100
    X65       R1661                         100
    X65       R1724                         100
    X65       R1766                         100
    X66       R36                           -1
    X66       R234                          -1
    X66       R240                          -1
    X66       R246                          -1
    X66       R507                          -1
    X66       R528                          1
    X66       R612                          100
    X66       R990                          100
    X66       R1305                         100
    X66       R1326                         100
    X66       R1368                         100
    X66       R1431                         100
    X66       R1536                         100
    X66       R1662                         100
    X66       R1725                         100
    X66       R1767                         100
    X67       R36                           -1
    X67       R240                          -1
    X67       R246                          -1
    X67       R507                          -1
    X67       R528                          1
    X67       R613                          100
    X67       R991                          100
    X67       R1306                         100
    X67       R1327                         100
    X67       R1369                         100
    X67       R1432                         100
    X67       R1537                         100
    X67       R1663                         100
    X67       R1726                         100
    X67       R1768                         100
    X68       R36                           -1
    X68       R246                          -1
    X68       R507                          -1
    X68       R528                          1
    X68       R614                          100
    X68       R992                          100
    X68       R1307                         100
    X68       R1328                         100
    X68       R1370                         100
    X68       R1433                         100
    X68       R1538                         100
    X68       R1664                         100
    X68       R1727                         100
    X68       R1769                         100
    X69       R37                           -1
    X69       R235                          -1
    X69       R241                          -1
    X69       R247                          -1
    X69       R508                          -1
    X69       R529                          1
    X69       R615                          100
    X69       R993                          100
    X69       R1308                         100
    X69       R1329                         100
    X69       R1371                         100
    X69       R1434                         100
    X69       R1539                         100
    X69       R1665                         100
    X69       R1728                         100
    X69       R1770                         100
    X70       R37                           -1
    X70       R241                          -1
    X70       R247                          -1
    X70       R508                          -1
    X70       R529                          1
    X70       R616                          100
    X70       R994                          100
    X70       R1309                         100
    X70       R1330                         100
    X70       R1372                         100
    X70       R1435                         100
    X70       R1540                         100
    X70       R1666                         100
    X70       R1729                         100
    X70       R1771                         100
    X71       R37                           -1
    X71       R247                          -1
    X71       R508                          -1
    X71       R529                          1
    X71       R617                          100
    X71       R995                          100
    X71       R1310                         100
    X71       R1331                         100
    X71       R1373                         100
    X71       R1436                         100
    X71       R1541                         100
    X71       R1667                         100
    X71       R1730                         100
    X71       R1772                         100
    X72       R38                           -1
    X72       R236                          -1
    X72       R242                          -1
    X72       R248                          -1
    X72       R509                          -1
    X72       R530                          1
    X72       R618                          100
    X72       R996                          100
    X72       R1311                         100
    X72       R1332                         100
    X72       R1374                         100
    X72       R1437                         100
    X72       R1542                         100
    X72       R1668                         100
    X72       R1731                         100
    X72       R1773                         100
    X73       R38                           -1
    X73       R242                          -1
    X73       R248                          -1
    X73       R509                          -1
    X73       R530                          1
    X73       R619                          100
    X73       R997                          100
    X73       R1312                         100
    X73       R1333                         100
    X73       R1375                         100
    X73       R1438                         100
    X73       R1543                         100
    X73       R1669                         100
    X73       R1732                         100
    X73       R1774                         100
    X74       R38                           -1
    X74       R248                          -1
    X74       R509                          -1
    X74       R530                          1
    X74       R620                          100
    X74       R998                          100
    X74       R1313                         100
    X74       R1334                         100
    X74       R1376                         100
    X74       R1439                         100
    X74       R1544                         100
    X74       R1670                         100
    X74       R1733                         100
    X74       R1775                         100
    X75       R39                           -1
    X75       R237                          -1
    X75       R243                          -1
    X75       R249                          -1
    X75       R510                          -1
    X75       R531                          1
    X75       R621                          100
    X75       R999                          100
    X75       R1314                         100
    X75       R1335                         100
    X75       R1377                         100
    X75       R1440                         100
    X75       R1545                         100
    X75       R1671                         100
    X75       R1734                         100
    X75       R1776                         100
    X76       R39                           -1
    X76       R243                          -1
    X76       R249                          -1
    X76       R510                          -1
    X76       R531                          1
    X76       R622                          100
    X76       R1000                         100
    X76       R1315                         100
    X76       R1336                         100
    X76       R1378                         100
    X76       R1441                         100
    X76       R1546                         100
    X76       R1672                         100
    X76       R1735                         100
    X76       R1777                         100
    X77       R39                           -1
    X77       R249                          -1
    X77       R510                          -1
    X77       R531                          1
    X77       R623                          100
    X77       R1001                         100
    X77       R1316                         100
    X77       R1337                         100
    X77       R1379                         100
    X77       R1442                         100
    X77       R1547                         100
    X77       R1673                         100
    X77       R1736                         100
    X77       R1778                         100
    X78       R40                           -1
    X78       R238                          -1
    X78       R244                          -1
    X78       R250                          -1
    X78       R511                          -1
    X78       R532                          1
    X78       R624                          100
    X78       R1002                         100
    X78       R1317                         100
    X78       R1338                         100
    X78       R1380                         100
    X78       R1443                         100
    X78       R1548                         100
    X78       R1674                         100
    X78       R1737                         100
    X78       R1779                         100
    X79       R40                           -1
    X79       R244                          -1
    X79       R250                          -1
    X79       R511                          -1
    X79       R532                          1
    X79       R625                          100
    X79       R1003                         100
    X79       R1318                         100
    X79       R1339                         100
    X79       R1381                         100
    X79       R1444                         100
    X79       R1549                         100
    X79       R1675                         100
    X79       R1738                         100
    X79       R1780                         100
    X80       R40                           -1
    X80       R250                          -1
    X80       R511                          -1
    X80       R532                          1
    X80       R626                          100
    X80       R1004                         100
    X80       R1319                         100
    X80       R1340                         100
    X80       R1382                         100
    X80       R1445                         100
    X80       R1550                         100
    X80       R1676                         100
    X80       R1739                         100
    X80       R1781                         100
    X81       R41                           -1
    X81       R239                          -1
    X81       R245                          -1
    X81       R251                          -1
    X81       R512                          -1
    X81       R533                          1
    X81       R627                          100
    X81       R1005                         100
    X81       R1320                         100
    X81       R1341                         100
    X81       R1383                         100
    X81       R1446                         100
    X81       R1551                         100
    X81       R1677                         100
    X81       R1740                         100
    X81       R1782                         100
    X82       R41                           -1
    X82       R245                          -1
    X82       R251                          -1
    X82       R512                          -1
    X82       R533                          1
    X82       R628                          100
    X82       R1006                         100
    X82       R1321                         100
    X82       R1342                         100
    X82       R1384                         100
    X82       R1447                         100
    X82       R1552                         100
    X82       R1678                         100
    X82       R1741                         100
    X82       R1783                         100
    X83       R41                           -1
    X83       R251                          -1
    X83       R512                          -1
    X83       R533                          1
    X83       R629                          100
    X83       R1007                         100
    X83       R1322                         100
    X83       R1343                         100
    X83       R1385                         100
    X83       R1448                         100
    X83       R1553                         100
    X83       R1679                         100
    X83       R1742                         100
    X83       R1784                         100
    X84       R4                            -1
    X84       R138                          -1
    X84       R139                          -1
    X84       R140                          -1
    X84       R504                          -1
    X84       R525                          1
    X84       R630                          100
    X84       R1008                         100
    X84       R1302                         100
    X84       R1323                         100
    X84       R1386                         100
    X84       R1449                         100
    X84       R1554                         100
    X84       R1680                         100
    X84       R1722                         100
    X84       R1764                         100
    X85       R4                            -1
    X85       R139                          -1
    X85       R140                          -1
    X85       R504                          -1
    X85       R525                          1
    X85       R631                          100
    X85       R1009                         100
    X85       R1303                         100
    X85       R1324                         100
    X85       R1387                         100
    X85       R1450                         100
    X85       R1555                         100
    X85       R1681                         100
    X85       R1723                         100
    X85       R1765                         100
    X86       R4                            -1
    X86       R140                          -1
    X86       R504                          -1
    X86       R525                          1
    X86       R632                          100
    X86       R1010                         100
    X86       R1304                         100
    X86       R1325                         100
    X86       R1388                         100
    X86       R1451                         100
    X86       R1556                         100
    X86       R1682                         100
    X86       R1724                         100
    X86       R1766                         100
    X87       R42                           -1
    X87       R252                          -1
    X87       R258                          -1
    X87       R264                          -1
    X87       R507                          -1
    X87       R528                          1
    X87       R633                          100
    X87       R1011                         100
    X87       R1305                         100
    X87       R1326                         100
    X87       R1389                         100
    X87       R1452                         100
    X87       R1557                         100
    X87       R1683                         100
    X87       R1725                         100
    X87       R1767                         100
    X88       R42                           -1
    X88       R258                          -1
    X88       R264                          -1
    X88       R507                          -1
    X88       R528                          1
    X88       R634                          100
    X88       R1012                         100
    X88       R1306                         100
    X88       R1327                         100
    X88       R1390                         100
    X88       R1453                         100
    X88       R1558                         100
    X88       R1684                         100
    X88       R1726                         100
    X88       R1768                         100
    X89       R42                           -1
    X89       R264                          -1
    X89       R507                          -1
    X89       R528                          1
    X89       R635                          100
    X89       R1013                         100
    X89       R1307                         100
    X89       R1328                         100
    X89       R1391                         100
    X89       R1454                         100
    X89       R1559                         100
    X89       R1685                         100
    X89       R1727                         100
    X89       R1769                         100
    X90       R43                           -1
    X90       R253                          -1
    X90       R259                          -1
    X90       R265                          -1
    X90       R508                          -1
    X90       R529                          1
    X90       R636                          100
    X90       R1014                         100
    X90       R1308                         100
    X90       R1329                         100
    X90       R1392                         100
    X90       R1455                         100
    X90       R1560                         100
    X90       R1686                         100
    X90       R1728                         100
    X90       R1770                         100
    X91       R43                           -1
    X91       R259                          -1
    X91       R265                          -1
    X91       R508                          -1
    X91       R529                          1
    X91       R637                          100
    X91       R1015                         100
    X91       R1309                         100
    X91       R1330                         100
    X91       R1393                         100
    X91       R1456                         100
    X91       R1561                         100
    X91       R1687                         100
    X91       R1729                         100
    X91       R1771                         100
    X92       R43                           -1
    X92       R265                          -1
    X92       R508                          -1
    X92       R529                          1
    X92       R638                          100
    X92       R1016                         100
    X92       R1310                         100
    X92       R1331                         100
    X92       R1394                         100
    X92       R1457                         100
    X92       R1562                         100
    X92       R1688                         100
    X92       R1730                         100
    X92       R1772                         100
    X93       R44                           -1
    X93       R254                          -1
    X93       R260                          -1
    X93       R266                          -1
    X93       R509                          -1
    X93       R530                          1
    X93       R639                          100
    X93       R1017                         100
    X93       R1311                         100
    X93       R1332                         100
    X93       R1395                         100
    X93       R1458                         100
    X93       R1563                         100
    X93       R1689                         100
    X93       R1731                         100
    X93       R1773                         100
    X94       R44                           -1
    X94       R260                          -1
    X94       R266                          -1
    X94       R509                          -1
    X94       R530                          1
    X94       R640                          100
    X94       R1018                         100
    X94       R1312                         100
    X94       R1333                         100
    X94       R1396                         100
    X94       R1459                         100
    X94       R1564                         100
    X94       R1690                         100
    X94       R1732                         100
    X94       R1774                         100
    X95       R44                           -1
    X95       R266                          -1
    X95       R509                          -1
    X95       R530                          1
    X95       R641                          100
    X95       R1019                         100
    X95       R1313                         100
    X95       R1334                         100
    X95       R1397                         100
    X95       R1460                         100
    X95       R1565                         100
    X95       R1691                         100
    X95       R1733                         100
    X95       R1775                         100
    X96       R45                           -1
    X96       R255                          -1
    X96       R261                          -1
    X96       R267                          -1
    X96       R510                          -1
    X96       R531                          1
    X96       R642                          100
    X96       R1020                         100
    X96       R1314                         100
    X96       R1335                         100
    X96       R1398                         100
    X96       R1461                         100
    X96       R1566                         100
    X96       R1692                         100
    X96       R1734                         100
    X96       R1776                         100
    X97       R45                           -1
    X97       R261                          -1
    X97       R267                          -1
    X97       R510                          -1
    X97       R531                          1
    X97       R643                          100
    X97       R1021                         100
    X97       R1315                         100
    X97       R1336                         100
    X97       R1399                         100
    X97       R1462                         100
    X97       R1567                         100
    X97       R1693                         100
    X97       R1735                         100
    X97       R1777                         100
    X98       R45                           -1
    X98       R267                          -1
    X98       R510                          -1
    X98       R531                          1
    X98       R644                          100
    X98       R1022                         100
    X98       R1316                         100
    X98       R1337                         100
    X98       R1400                         100
    X98       R1463                         100
    X98       R1568                         100
    X98       R1694                         100
    X98       R1736                         100
    X98       R1778                         100
    X99       R46                           -1
    X99       R256                          -1
    X99       R262                          -1
    X99       R268                          -1
    X99       R511                          -1
    X99       R532                          1
    X99       R645                          100
    X99       R1023                         100
    X99       R1317                         100
    X99       R1338                         100
    X99       R1401                         100
    X99       R1464                         100
    X99       R1569                         100
    X99       R1695                         100
    X99       R1737                         100
    X99       R1779                         100
    X100      R46                           -1
    X100      R262                          -1
    X100      R268                          -1
    X100      R511                          -1
    X100      R532                          1
    X100      R646                          100
    X100      R1024                         100
    X100      R1318                         100
    X100      R1339                         100
    X100      R1402                         100
    X100      R1465                         100
    X100      R1570                         100
    X100      R1696                         100
    X100      R1738                         100
    X100      R1780                         100
    X101      R46                           -1
    X101      R268                          -1
    X101      R511                          -1
    X101      R532                          1
    X101      R647                          100
    X101      R1025                         100
    X101      R1319                         100
    X101      R1340                         100
    X101      R1403                         100
    X101      R1466                         100
    X101      R1571                         100
    X101      R1697                         100
    X101      R1739                         100
    X101      R1781                         100
    X102      R47                           -1
    X102      R257                          -1
    X102      R263                          -1
    X102      R269                          -1
    X102      R512                          -1
    X102      R533                          1
    X102      R648                          100
    X102      R1026                         100
    X102      R1320                         100
    X102      R1341                         100
    X102      R1404                         100
    X102      R1467                         100
    X102      R1572                         100
    X102      R1698                         100
    X102      R1740                         100
    X102      R1782                         100
    X103      R47                           -1
    X103      R263                          -1
    X103      R269                          -1
    X103      R512                          -1
    X103      R533                          1
    X103      R649                          100
    X103      R1027                         100
    X103      R1321                         100
    X103      R1342                         100
    X103      R1405                         100
    X103      R1468                         100
    X103      R1573                         100
    X103      R1699                         100
    X103      R1741                         100
    X103      R1783                         100
    X104      R47                           -1
    X104      R269                          -1
    X104      R512                          -1
    X104      R533                          1
    X104      R650                          100
    X104      R1028                         100
    X104      R1322                         100
    X104      R1343                         100
    X104      R1406                         100
    X104      R1469                         100
    X104      R1574                         100
    X104      R1700                         100
    X104      R1742                         100
    X104      R1784                         100
    X105      R5                            -1
    X105      R141                          -1
    X105      R142                          -1
    X105      R143                          -1
    X105      R504                          -1
    X105      R525                          1
    X105      R651                          100
    X105      R1029                         100
    X105      R1302                         100
    X105      R1323                         100
    X105      R1386                         100
    X105      R1449                         100
    X105      R1575                         100
    X105      R1701                         100
    X105      R1722                         100
    X105      R1764                         100
    X106      R5                            -1
    X106      R142                          -1
    X106      R143                          -1
    X106      R504                          -1
    X106      R525                          1
    X106      R652                          100
    X106      R1030                         100
    X106      R1303                         100
    X106      R1324                         100
    X106      R1387                         100
    X106      R1450                         100
    X106      R1576                         100
    X106      R1702                         100
    X106      R1723                         100
    X106      R1765                         100
    X107      R5                            -1
    X107      R143                          -1
    X107      R504                          -1
    X107      R525                          1
    X107      R653                          100
    X107      R1031                         100
    X107      R1304                         100
    X107      R1325                         100
    X107      R1388                         100
    X107      R1451                         100
    X107      R1577                         100
    X107      R1703                         100
    X107      R1724                         100
    X107      R1766                         100
    X108      R48                           -1
    X108      R270                          -1
    X108      R276                          -1
    X108      R282                          -1
    X108      R507                          -1
    X108      R528                          1
    X108      R654                          100
    X108      R1032                         100
    X108      R1305                         100
    X108      R1326                         100
    X108      R1389                         100
    X108      R1452                         100
    X108      R1578                         100
    X108      R1704                         100
    X108      R1725                         100
    X108      R1767                         100
    X109      R48                           -1
    X109      R276                          -1
    X109      R282                          -1
    X109      R507                          -1
    X109      R528                          1
    X109      R655                          100
    X109      R1033                         100
    X109      R1306                         100
    X109      R1327                         100
    X109      R1390                         100
    X109      R1453                         100
    X109      R1579                         100
    X109      R1705                         100
    X109      R1726                         100
    X109      R1768                         100
    X110      R48                           -1
    X110      R282                          -1
    X110      R507                          -1
    X110      R528                          1
    X110      R656                          100
    X110      R1034                         100
    X110      R1307                         100
    X110      R1328                         100
    X110      R1391                         100
    X110      R1454                         100
    X110      R1580                         100
    X110      R1706                         100
    X110      R1727                         100
    X110      R1769                         100
    X111      R49                           -1
    X111      R271                          -1
    X111      R277                          -1
    X111      R283                          -1
    X111      R508                          -1
    X111      R529                          1
    X111      R657                          100
    X111      R1035                         100
    X111      R1308                         100
    X111      R1329                         100
    X111      R1392                         100
    X111      R1455                         100
    X111      R1581                         100
    X111      R1707                         100
    X111      R1728                         100
    X111      R1770                         100
    X112      R49                           -1
    X112      R277                          -1
    X112      R283                          -1
    X112      R508                          -1
    X112      R529                          1
    X112      R658                          100
    X112      R1036                         100
    X112      R1309                         100
    X112      R1330                         100
    X112      R1393                         100
    X112      R1456                         100
    X112      R1582                         100
    X112      R1708                         100
    X112      R1729                         100
    X112      R1771                         100
    X113      R49                           -1
    X113      R283                          -1
    X113      R508                          -1
    X113      R529                          1
    X113      R659                          100
    X113      R1037                         100
    X113      R1310                         100
    X113      R1331                         100
    X113      R1394                         100
    X113      R1457                         100
    X113      R1583                         100
    X113      R1709                         100
    X113      R1730                         100
    X113      R1772                         100
    X114      R50                           -1
    X114      R272                          -1
    X114      R278                          -1
    X114      R284                          -1
    X114      R509                          -1
    X114      R530                          1
    X114      R660                          100
    X114      R1038                         100
    X114      R1311                         100
    X114      R1332                         100
    X114      R1395                         100
    X114      R1458                         100
    X114      R1584                         100
    X114      R1710                         100
    X114      R1731                         100
    X114      R1773                         100
    X115      R50                           -1
    X115      R278                          -1
    X115      R284                          -1
    X115      R509                          -1
    X115      R530                          1
    X115      R661                          100
    X115      R1039                         100
    X115      R1312                         100
    X115      R1333                         100
    X115      R1396                         100
    X115      R1459                         100
    X115      R1585                         100
    X115      R1711                         100
    X115      R1732                         100
    X115      R1774                         100
    X116      R50                           -1
    X116      R284                          -1
    X116      R509                          -1
    X116      R530                          1
    X116      R662                          100
    X116      R1040                         100
    X116      R1313                         100
    X116      R1334                         100
    X116      R1397                         100
    X116      R1460                         100
    X116      R1586                         100
    X116      R1712                         100
    X116      R1733                         100
    X116      R1775                         100
    X117      R51                           -1
    X117      R273                          -1
    X117      R279                          -1
    X117      R285                          -1
    X117      R510                          -1
    X117      R531                          1
    X117      R663                          100
    X117      R1041                         100
    X117      R1314                         100
    X117      R1335                         100
    X117      R1398                         100
    X117      R1461                         100
    X117      R1587                         100
    X117      R1713                         100
    X117      R1734                         100
    X117      R1776                         100
    X118      R51                           -1
    X118      R279                          -1
    X118      R285                          -1
    X118      R510                          -1
    X118      R531                          1
    X118      R664                          100
    X118      R1042                         100
    X118      R1315                         100
    X118      R1336                         100
    X118      R1399                         100
    X118      R1462                         100
    X118      R1588                         100
    X118      R1714                         100
    X118      R1735                         100
    X118      R1777                         100
    X119      R51                           -1
    X119      R285                          -1
    X119      R510                          -1
    X119      R531                          1
    X119      R665                          100
    X119      R1043                         100
    X119      R1316                         100
    X119      R1337                         100
    X119      R1400                         100
    X119      R1463                         100
    X119      R1589                         100
    X119      R1715                         100
    X119      R1736                         100
    X119      R1778                         100
    X120      R52                           -1
    X120      R274                          -1
    X120      R280                          -1
    X120      R286                          -1
    X120      R511                          -1
    X120      R532                          1
    X120      R666                          100
    X120      R1044                         100
    X120      R1317                         100
    X120      R1338                         100
    X120      R1401                         100
    X120      R1464                         100
    X120      R1590                         100
    X120      R1716                         100
    X120      R1737                         100
    X120      R1779                         100
    X121      R52                           -1
    X121      R280                          -1
    X121      R286                          -1
    X121      R511                          -1
    X121      R532                          1
    X121      R667                          100
    X121      R1045                         100
    X121      R1318                         100
    X121      R1339                         100
    X121      R1402                         100
    X121      R1465                         100
    X121      R1591                         100
    X121      R1717                         100
    X121      R1738                         100
    X121      R1780                         100
    X122      R52                           -1
    X122      R286                          -1
    X122      R511                          -1
    X122      R532                          1
    X122      R668                          100
    X122      R1046                         100
    X122      R1319                         100
    X122      R1340                         100
    X122      R1403                         100
    X122      R1466                         100
    X122      R1592                         100
    X122      R1718                         100
    X122      R1739                         100
    X122      R1781                         100
    X123      R53                           -1
    X123      R275                          -1
    X123      R281                          -1
    X123      R287                          -1
    X123      R512                          -1
    X123      R533                          1
    X123      R669                          100
    X123      R1047                         100
    X123      R1320                         100
    X123      R1341                         100
    X123      R1404                         100
    X123      R1467                         100
    X123      R1593                         100
    X123      R1719                         100
    X123      R1740                         100
    X123      R1782                         100
    X124      R53                           -1
    X124      R281                          -1
    X124      R287                          -1
    X124      R512                          -1
    X124      R533                          1
    X124      R670                          100
    X124      R1048                         100
    X124      R1321                         100
    X124      R1342                         100
    X124      R1405                         100
    X124      R1468                         100
    X124      R1594                         100
    X124      R1720                         100
    X124      R1741                         100
    X124      R1783                         100
    X125      R53                           -1
    X125      R287                          -1
    X125      R512                          -1
    X125      R533                          1
    X125      R671                          100
    X125      R1049                         100
    X125      R1322                         100
    X125      R1343                         100
    X125      R1406                         100
    X125      R1469                         100
    X125      R1595                         100
    X125      R1721                         100
    X125      R1742                         100
    X125      R1784                         100
    X126      R6                            -1
    X126      R144                          -1
    X126      R145                          -1
    X126      R146                          -1
    X126      R505                          -1
    X126      R526                          1
    X126      R672                          30
    X126      R1050                         30
    X126      R1302                         30
    X126      R1323                         30
    X126      R1344                         30
    X126      R1407                         30
    X126      R1470                         30
    X126      R1596                         30
    X126      R1722                         30
    X126      R1764                         30
    X127      R6                            -1
    X127      R145                          -1
    X127      R146                          -1
    X127      R505                          -1
    X127      R526                          1
    X127      R673                          30
    X127      R1051                         30
    X127      R1303                         30
    X127      R1324                         30
    X127      R1345                         30
    X127      R1408                         30
    X127      R1471                         30
    X127      R1597                         30
    X127      R1723                         30
    X127      R1765                         30
    X128      R6                            -1
    X128      R146                          -1
    X128      R505                          -1
    X128      R526                          1
    X128      R674                          30
    X128      R1052                         30
    X128      R1304                         30
    X128      R1325                         30
    X128      R1346                         30
    X128      R1409                         30
    X128      R1472                         30
    X128      R1598                         30
    X128      R1724                         30
    X128      R1766                         30
    X129      R54                           -1
    X129      R288                          -1
    X129      R294                          -1
    X129      R300                          -1
    X129      R513                          -1
    X129      R534                          1
    X129      R675                          30
    X129      R1053                         30
    X129      R1305                         30
    X129      R1326                         30
    X129      R1347                         30
    X129      R1410                         30
    X129      R1473                         30
    X129      R1599                         30
    X129      R1725                         30
    X129      R1767                         30
    X130      R54                           -1
    X130      R294                          -1
    X130      R300                          -1
    X130      R513                          -1
    X130      R534                          1
    X130      R676                          30
    X130      R1054                         30
    X130      R1306                         30
    X130      R1327                         30
    X130      R1348                         30
    X130      R1411                         30
    X130      R1474                         30
    X130      R1600                         30
    X130      R1726                         30
    X130      R1768                         30
    X131      R54                           -1
    X131      R300                          -1
    X131      R513                          -1
    X131      R534                          1
    X131      R677                          30
    X131      R1055                         30
    X131      R1307                         30
    X131      R1328                         30
    X131      R1349                         30
    X131      R1412                         30
    X131      R1475                         30
    X131      R1601                         30
    X131      R1727                         30
    X131      R1769                         30
    X132      R55                           -1
    X132      R289                          -1
    X132      R295                          -1
    X132      R301                          -1
    X132      R514                          -1
    X132      R535                          1
    X132      R678                          30
    X132      R1056                         30
    X132      R1308                         30
    X132      R1329                         30
    X132      R1350                         30
    X132      R1413                         30
    X132      R1476                         30
    X132      R1602                         30
    X132      R1728                         30
    X132      R1770                         30
    X133      R55                           -1
    X133      R295                          -1
    X133      R301                          -1
    X133      R514                          -1
    X133      R535                          1
    X133      R679                          30
    X133      R1057                         30
    X133      R1309                         30
    X133      R1330                         30
    X133      R1351                         30
    X133      R1414                         30
    X133      R1477                         30
    X133      R1603                         30
    X133      R1729                         30
    X133      R1771                         30
    X134      R55                           -1
    X134      R301                          -1
    X134      R514                          -1
    X134      R535                          1
    X134      R680                          30
    X134      R1058                         30
    X134      R1310                         30
    X134      R1331                         30
    X134      R1352                         30
    X134      R1415                         30
    X134      R1478                         30
    X134      R1604                         30
    X134      R1730                         30
    X134      R1772                         30
    X135      R56                           -1
    X135      R290                          -1
    X135      R296                          -1
    X135      R302                          -1
    X135      R515                          -1
    X135      R536                          1
    X135      R681                          30
    X135      R1059                         30
    X135      R1311                         30
    X135      R1332                         30
    X135      R1353                         30
    X135      R1416                         30
    X135      R1479                         30
    X135      R1605                         30
    X135      R1731                         30
    X135      R1773                         30
    X136      R56                           -1
    X136      R296                          -1
    X136      R302                          -1
    X136      R515                          -1
    X136      R536                          1
    X136      R682                          30
    X136      R1060                         30
    X136      R1312                         30
    X136      R1333                         30
    X136      R1354                         30
    X136      R1417                         30
    X136      R1480                         30
    X136      R1606                         30
    X136      R1732                         30
    X136      R1774                         30
    X137      R56                           -1
    X137      R302                          -1
    X137      R515                          -1
    X137      R536                          1
    X137      R683                          30
    X137      R1061                         30
    X137      R1313                         30
    X137      R1334                         30
    X137      R1355                         30
    X137      R1418                         30
    X137      R1481                         30
    X137      R1607                         30
    X137      R1733                         30
    X137      R1775                         30
    X138      R57                           -1
    X138      R291                          -1
    X138      R297                          -1
    X138      R303                          -1
    X138      R516                          -1
    X138      R537                          1
    X138      R684                          30
    X138      R1062                         30
    X138      R1314                         30
    X138      R1335                         30
    X138      R1356                         30
    X138      R1419                         30
    X138      R1482                         30
    X138      R1608                         30
    X138      R1734                         30
    X138      R1776                         30
    X139      R57                           -1
    X139      R297                          -1
    X139      R303                          -1
    X139      R516                          -1
    X139      R537                          1
    X139      R685                          30
    X139      R1063                         30
    X139      R1315                         30
    X139      R1336                         30
    X139      R1357                         30
    X139      R1420                         30
    X139      R1483                         30
    X139      R1609                         30
    X139      R1735                         30
    X139      R1777                         30
    X140      R57                           -1
    X140      R303                          -1
    X140      R516                          -1
    X140      R537                          1
    X140      R686                          30
    X140      R1064                         30
    X140      R1316                         30
    X140      R1337                         30
    X140      R1358                         30
    X140      R1421                         30
    X140      R1484                         30
    X140      R1610                         30
    X140      R1736                         30
    X140      R1778                         30
    X141      R58                           -1
    X141      R292                          -1
    X141      R298                          -1
    X141      R304                          -1
    X141      R517                          -1
    X141      R538                          1
    X141      R687                          30
    X141      R1065                         30
    X141      R1317                         30
    X141      R1338                         30
    X141      R1359                         30
    X141      R1422                         30
    X141      R1485                         30
    X141      R1611                         30
    X141      R1737                         30
    X141      R1779                         30
    X142      R58                           -1
    X142      R298                          -1
    X142      R304                          -1
    X142      R517                          -1
    X142      R538                          1
    X142      R688                          30
    X142      R1066                         30
    X142      R1318                         30
    X142      R1339                         30
    X142      R1360                         30
    X142      R1423                         30
    X142      R1486                         30
    X142      R1612                         30
    X142      R1738                         30
    X142      R1780                         30
    X143      R58                           -1
    X143      R304                          -1
    X143      R517                          -1
    X143      R538                          1
    X143      R689                          30
    X143      R1067                         30
    X143      R1319                         30
    X143      R1340                         30
    X143      R1361                         30
    X143      R1424                         30
    X143      R1487                         30
    X143      R1613                         30
    X143      R1739                         30
    X143      R1781                         30
    X144      R59                           -1
    X144      R293                          -1
    X144      R299                          -1
    X144      R305                          -1
    X144      R518                          -1
    X144      R539                          1
    X144      R690                          30
    X144      R1068                         30
    X144      R1320                         30
    X144      R1341                         30
    X144      R1362                         30
    X144      R1425                         30
    X144      R1488                         30
    X144      R1614                         30
    X144      R1740                         30
    X144      R1782                         30
    X145      R59                           -1
    X145      R299                          -1
    X145      R305                          -1
    X145      R518                          -1
    X145      R539                          1
    X145      R691                          30
    X145      R1069                         30
    X145      R1321                         30
    X145      R1342                         30
    X145      R1363                         30
    X145      R1426                         30
    X145      R1489                         30
    X145      R1615                         30
    X145      R1741                         30
    X145      R1783                         30
    X146      R59                           -1
    X146      R305                          -1
    X146      R518                          -1
    X146      R539                          1
    X146      R692                          30
    X146      R1070                         30
    X146      R1322                         30
    X146      R1343                         30
    X146      R1364                         30
    X146      R1427                         30
    X146      R1490                         30
    X146      R1616                         30
    X146      R1742                         30
    X146      R1784                         30
    X147      R7                            -1
    X147      R147                          -1
    X147      R148                          -1
    X147      R149                          -1
    X147      R505                          -1
    X147      R526                          1
    X147      R693                          30
    X147      R1071                         30
    X147      R1302                         30
    X147      R1323                         30
    X147      R1344                         30
    X147      R1407                         30
    X147      R1491                         30
    X147      R1617                         30
    X147      R1722                         30
    X147      R1764                         30
    X148      R7                            -1
    X148      R148                          -1
    X148      R149                          -1
    X148      R505                          -1
    X148      R526                          1
    X148      R694                          30
    X148      R1072                         30
    X148      R1303                         30
    X148      R1324                         30
    X148      R1345                         30
    X148      R1408                         30
    X148      R1492                         30
    X148      R1618                         30
    X148      R1723                         30
    X148      R1765                         30
    X149      R7                            -1
    X149      R149                          -1
    X149      R505                          -1
    X149      R526                          1
    X149      R695                          30
    X149      R1073                         30
    X149      R1304                         30
    X149      R1325                         30
    X149      R1346                         30
    X149      R1409                         30
    X149      R1493                         30
    X149      R1619                         30
    X149      R1724                         30
    X149      R1766                         30
    X150      R60                           -1
    X150      R306                          -1
    X150      R312                          -1
    X150      R318                          -1
    X150      R513                          -1
    X150      R534                          1
    X150      R696                          30
    X150      R1074                         30
    X150      R1305                         30
    X150      R1326                         30
    X150      R1347                         30
    X150      R1410                         30
    X150      R1494                         30
    X150      R1620                         30
    X150      R1725                         30
    X150      R1767                         30
    X151      R60                           -1
    X151      R312                          -1
    X151      R318                          -1
    X151      R513                          -1
    X151      R534                          1
    X151      R697                          30
    X151      R1075                         30
    X151      R1306                         30
    X151      R1327                         30
    X151      R1348                         30
    X151      R1411                         30
    X151      R1495                         30
    X151      R1621                         30
    X151      R1726                         30
    X151      R1768                         30
    X152      R60                           -1
    X152      R318                          -1
    X152      R513                          -1
    X152      R534                          1
    X152      R698                          30
    X152      R1076                         30
    X152      R1307                         30
    X152      R1328                         30
    X152      R1349                         30
    X152      R1412                         30
    X152      R1496                         30
    X152      R1622                         30
    X152      R1727                         30
    X152      R1769                         30
    X153      R61                           -1
    X153      R307                          -1
    X153      R313                          -1
    X153      R319                          -1
    X153      R514                          -1
    X153      R535                          1
    X153      R699                          30
    X153      R1077                         30
    X153      R1308                         30
    X153      R1329                         30
    X153      R1350                         30
    X153      R1413                         30
    X153      R1497                         30
    X153      R1623                         30
    X153      R1728                         30
    X153      R1770                         30
    X154      R61                           -1
    X154      R313                          -1
    X154      R319                          -1
    X154      R514                          -1
    X154      R535                          1
    X154      R700                          30
    X154      R1078                         30
    X154      R1309                         30
    X154      R1330                         30
    X154      R1351                         30
    X154      R1414                         30
    X154      R1498                         30
    X154      R1624                         30
    X154      R1729                         30
    X154      R1771                         30
    X155      R61                           -1
    X155      R319                          -1
    X155      R514                          -1
    X155      R535                          1
    X155      R701                          30
    X155      R1079                         30
    X155      R1310                         30
    X155      R1331                         30
    X155      R1352                         30
    X155      R1415                         30
    X155      R1499                         30
    X155      R1625                         30
    X155      R1730                         30
    X155      R1772                         30
    X156      R62                           -1
    X156      R308                          -1
    X156      R314                          -1
    X156      R320                          -1
    X156      R515                          -1
    X156      R536                          1
    X156      R702                          30
    X156      R1080                         30
    X156      R1311                         30
    X156      R1332                         30
    X156      R1353                         30
    X156      R1416                         30
    X156      R1500                         30
    X156      R1626                         30
    X156      R1731                         30
    X156      R1773                         30
    X157      R62                           -1
    X157      R314                          -1
    X157      R320                          -1
    X157      R515                          -1
    X157      R536                          1
    X157      R703                          30
    X157      R1081                         30
    X157      R1312                         30
    X157      R1333                         30
    X157      R1354                         30
    X157      R1417                         30
    X157      R1501                         30
    X157      R1627                         30
    X157      R1732                         30
    X157      R1774                         30
    X158      R62                           -1
    X158      R320                          -1
    X158      R515                          -1
    X158      R536                          1
    X158      R704                          30
    X158      R1082                         30
    X158      R1313                         30
    X158      R1334                         30
    X158      R1355                         30
    X158      R1418                         30
    X158      R1502                         30
    X158      R1628                         30
    X158      R1733                         30
    X158      R1775                         30
    X159      R63                           -1
    X159      R309                          -1
    X159      R315                          -1
    X159      R321                          -1
    X159      R516                          -1
    X159      R537                          1
    X159      R705                          30
    X159      R1083                         30
    X159      R1314                         30
    X159      R1335                         30
    X159      R1356                         30
    X159      R1419                         30
    X159      R1503                         30
    X159      R1629                         30
    X159      R1734                         30
    X159      R1776                         30
    X160      R63                           -1
    X160      R315                          -1
    X160      R321                          -1
    X160      R516                          -1
    X160      R537                          1
    X160      R706                          30
    X160      R1084                         30
    X160      R1315                         30
    X160      R1336                         30
    X160      R1357                         30
    X160      R1420                         30
    X160      R1504                         30
    X160      R1630                         30
    X160      R1735                         30
    X160      R1777                         30
    X161      R63                           -1
    X161      R321                          -1
    X161      R516                          -1
    X161      R537                          1
    X161      R707                          30
    X161      R1085                         30
    X161      R1316                         30
    X161      R1337                         30
    X161      R1358                         30
    X161      R1421                         30
    X161      R1505                         30
    X161      R1631                         30
    X161      R1736                         30
    X161      R1778                         30
    X162      R64                           -1
    X162      R310                          -1
    X162      R316                          -1
    X162      R322                          -1
    X162      R517                          -1
    X162      R538                          1
    X162      R708                          30
    X162      R1086                         30
    X162      R1317                         30
    X162      R1338                         30
    X162      R1359                         30
    X162      R1422                         30
    X162      R1506                         30
    X162      R1632                         30
    X162      R1737                         30
    X162      R1779                         30
    X163      R64                           -1
    X163      R316                          -1
    X163      R322                          -1
    X163      R517                          -1
    X163      R538                          1
    X163      R709                          30
    X163      R1087                         30
    X163      R1318                         30
    X163      R1339                         30
    X163      R1360                         30
    X163      R1423                         30
    X163      R1507                         30
    X163      R1633                         30
    X163      R1738                         30
    X163      R1780                         30
    X164      R64                           -1
    X164      R322                          -1
    X164      R517                          -1
    X164      R538                          1
    X164      R710                          30
    X164      R1088                         30
    X164      R1319                         30
    X164      R1340                         30
    X164      R1361                         30
    X164      R1424                         30
    X164      R1508                         30
    X164      R1634                         30
    X164      R1739                         30
    X164      R1781                         30
    X165      R65                           -1
    X165      R311                          -1
    X165      R317                          -1
    X165      R323                          -1
    X165      R518                          -1
    X165      R539                          1
    X165      R711                          30
    X165      R1089                         30
    X165      R1320                         30
    X165      R1341                         30
    X165      R1362                         30
    X165      R1425                         30
    X165      R1509                         30
    X165      R1635                         30
    X165      R1740                         30
    X165      R1782                         30
    X166      R65                           -1
    X166      R317                          -1
    X166      R323                          -1
    X166      R518                          -1
    X166      R539                          1
    X166      R712                          30
    X166      R1090                         30
    X166      R1321                         30
    X166      R1342                         30
    X166      R1363                         30
    X166      R1426                         30
    X166      R1510                         30
    X166      R1636                         30
    X166      R1741                         30
    X166      R1783                         30
    X167      R65                           -1
    X167      R323                          -1
    X167      R518                          -1
    X167      R539                          1
    X167      R713                          30
    X167      R1091                         30
    X167      R1322                         30
    X167      R1343                         30
    X167      R1364                         30
    X167      R1427                         30
    X167      R1511                         30
    X167      R1637                         30
    X167      R1742                         30
    X167      R1784                         30
    X168      R8                            -1
    X168      R150                          -1
    X168      R151                          -1
    X168      R152                          -1
    X168      R505                          -1
    X168      R526                          1
    X168      R714                          30
    X168      R1092                         30
    X168      R1302                         30
    X168      R1323                         30
    X168      R1365                         30
    X168      R1428                         30
    X168      R1512                         30
    X168      R1638                         30
    X168      R1722                         30
    X168      R1764                         30
    X169      R8                            -1
    X169      R151                          -1
    X169      R152                          -1
    X169      R505                          -1
    X169      R526                          1
    X169      R715                          30
    X169      R1093                         30
    X169      R1303                         30
    X169      R1324                         30
    X169      R1366                         30
    X169      R1429                         30
    X169      R1513                         30
    X169      R1639                         30
    X169      R1723                         30
    X169      R1765                         30
    X170      R8                            -1
    X170      R152                          -1
    X170      R505                          -1
    X170      R526                          1
    X170      R716                          30
    X170      R1094                         30
    X170      R1304                         30
    X170      R1325                         30
    X170      R1367                         30
    X170      R1430                         30
    X170      R1514                         30
    X170      R1640                         30
    X170      R1724                         30
    X170      R1766                         30
    X171      R66                           -1
    X171      R324                          -1
    X171      R330                          -1
    X171      R336                          -1
    X171      R513                          -1
    X171      R534                          1
    X171      R717                          30
    X171      R1095                         30
    X171      R1305                         30
    X171      R1326                         30
    X171      R1368                         30
    X171      R1431                         30
    X171      R1515                         30
    X171      R1641                         30
    X171      R1725                         30
    X171      R1767                         30
    X172      R66                           -1
    X172      R330                          -1
    X172      R336                          -1
    X172      R513                          -1
    X172      R534                          1
    X172      R718                          30
    X172      R1096                         30
    X172      R1306                         30
    X172      R1327                         30
    X172      R1369                         30
    X172      R1432                         30
    X172      R1516                         30
    X172      R1642                         30
    X172      R1726                         30
    X172      R1768                         30
    X173      R66                           -1
    X173      R336                          -1
    X173      R513                          -1
    X173      R534                          1
    X173      R719                          30
    X173      R1097                         30
    X173      R1307                         30
    X173      R1328                         30
    X173      R1370                         30
    X173      R1433                         30
    X173      R1517                         30
    X173      R1643                         30
    X173      R1727                         30
    X173      R1769                         30
    X174      R67                           -1
    X174      R325                          -1
    X174      R331                          -1
    X174      R337                          -1
    X174      R514                          -1
    X174      R535                          1
    X174      R720                          30
    X174      R1098                         30
    X174      R1308                         30
    X174      R1329                         30
    X174      R1371                         30
    X174      R1434                         30
    X174      R1518                         30
    X174      R1644                         30
    X174      R1728                         30
    X174      R1770                         30
    X175      R67                           -1
    X175      R331                          -1
    X175      R337                          -1
    X175      R514                          -1
    X175      R535                          1
    X175      R721                          30
    X175      R1099                         30
    X175      R1309                         30
    X175      R1330                         30
    X175      R1372                         30
    X175      R1435                         30
    X175      R1519                         30
    X175      R1645                         30
    X175      R1729                         30
    X175      R1771                         30
    X176      R67                           -1
    X176      R337                          -1
    X176      R514                          -1
    X176      R535                          1
    X176      R722                          30
    X176      R1100                         30
    X176      R1310                         30
    X176      R1331                         30
    X176      R1373                         30
    X176      R1436                         30
    X176      R1520                         30
    X176      R1646                         30
    X176      R1730                         30
    X176      R1772                         30
    X177      R68                           -1
    X177      R326                          -1
    X177      R332                          -1
    X177      R338                          -1
    X177      R515                          -1
    X177      R536                          1
    X177      R723                          30
    X177      R1101                         30
    X177      R1311                         30
    X177      R1332                         30
    X177      R1374                         30
    X177      R1437                         30
    X177      R1521                         30
    X177      R1647                         30
    X177      R1731                         30
    X177      R1773                         30
    X178      R68                           -1
    X178      R332                          -1
    X178      R338                          -1
    X178      R515                          -1
    X178      R536                          1
    X178      R724                          30
    X178      R1102                         30
    X178      R1312                         30
    X178      R1333                         30
    X178      R1375                         30
    X178      R1438                         30
    X178      R1522                         30
    X178      R1648                         30
    X178      R1732                         30
    X178      R1774                         30
    X179      R68                           -1
    X179      R338                          -1
    X179      R515                          -1
    X179      R536                          1
    X179      R725                          30
    X179      R1103                         30
    X179      R1313                         30
    X179      R1334                         30
    X179      R1376                         30
    X179      R1439                         30
    X179      R1523                         30
    X179      R1649                         30
    X179      R1733                         30
    X179      R1775                         30
    X180      R69                           -1
    X180      R327                          -1
    X180      R333                          -1
    X180      R339                          -1
    X180      R516                          -1
    X180      R537                          1
    X180      R726                          30
    X180      R1104                         30
    X180      R1314                         30
    X180      R1335                         30
    X180      R1377                         30
    X180      R1440                         30
    X180      R1524                         30
    X180      R1650                         30
    X180      R1734                         30
    X180      R1776                         30
    X181      R69                           -1
    X181      R333                          -1
    X181      R339                          -1
    X181      R516                          -1
    X181      R537                          1
    X181      R727                          30
    X181      R1105                         30
    X181      R1315                         30
    X181      R1336                         30
    X181      R1378                         30
    X181      R1441                         30
    X181      R1525                         30
    X181      R1651                         30
    X181      R1735                         30
    X181      R1777                         30
    X182      R69                           -1
    X182      R339                          -1
    X182      R516                          -1
    X182      R537                          1
    X182      R728                          30
    X182      R1106                         30
    X182      R1316                         30
    X182      R1337                         30
    X182      R1379                         30
    X182      R1442                         30
    X182      R1526                         30
    X182      R1652                         30
    X182      R1736                         30
    X182      R1778                         30
    X183      R70                           -1
    X183      R328                          -1
    X183      R334                          -1
    X183      R340                          -1
    X183      R517                          -1
    X183      R538                          1
    X183      R729                          30
    X183      R1107                         30
    X183      R1317                         30
    X183      R1338                         30
    X183      R1380                         30
    X183      R1443                         30
    X183      R1527                         30
    X183      R1653                         30
    X183      R1737                         30
    X183      R1779                         30
    X184      R70                           -1
    X184      R334                          -1
    X184      R340                          -1
    X184      R517                          -1
    X184      R538                          1
    X184      R730                          30
    X184      R1108                         30
    X184      R1318                         30
    X184      R1339                         30
    X184      R1381                         30
    X184      R1444                         30
    X184      R1528                         30
    X184      R1654                         30
    X184      R1738                         30
    X184      R1780                         30
    X185      R70                           -1
    X185      R340                          -1
    X185      R517                          -1
    X185      R538                          1
    X185      R731                          30
    X185      R1109                         30
    X185      R1319                         30
    X185      R1340                         30
    X185      R1382                         30
    X185      R1445                         30
    X185      R1529                         30
    X185      R1655                         30
    X185      R1739                         30
    X185      R1781                         30
    X186      R71                           -1
    X186      R329                          -1
    X186      R335                          -1
    X186      R341                          -1
    X186      R518                          -1
    X186      R539                          1
    X186      R732                          30
    X186      R1110                         30
    X186      R1320                         30
    X186      R1341                         30
    X186      R1383                         30
    X186      R1446                         30
    X186      R1530                         30
    X186      R1656                         30
    X186      R1740                         30
    X186      R1782                         30
    X187      R71                           -1
    X187      R335                          -1
    X187      R341                          -1
    X187      R518                          -1
    X187      R539                          1
    X187      R733                          30
    X187      R1111                         30
    X187      R1321                         30
    X187      R1342                         30
    X187      R1384                         30
    X187      R1447                         30
    X187      R1531                         30
    X187      R1657                         30
    X187      R1741                         30
    X187      R1783                         30
    X188      R71                           -1
    X188      R341                          -1
    X188      R518                          -1
    X188      R539                          1
    X188      R734                          30
    X188      R1112                         30
    X188      R1322                         30
    X188      R1343                         30
    X188      R1385                         30
    X188      R1448                         30
    X188      R1532                         30
    X188      R1658                         30
    X188      R1742                         30
    X188      R1784                         30
    X189      R9                            -1
    X189      R153                          -1
    X189      R154                          -1
    X189      R155                          -1
    X189      R505                          -1
    X189      R526                          1
    X189      R735                          30
    X189      R1113                         30
    X189      R1302                         30
    X189      R1323                         30
    X189      R1365                         30
    X189      R1428                         30
    X189      R1533                         30
    X189      R1659                         30
    X189      R1722                         30
    X189      R1764                         30
    X190      R9                            -1
    X190      R154                          -1
    X190      R155                          -1
    X190      R505                          -1
    X190      R526                          1
    X190      R736                          30
    X190      R1114                         30
    X190      R1303                         30
    X190      R1324                         30
    X190      R1366                         30
    X190      R1429                         30
    X190      R1534                         30
    X190      R1660                         30
    X190      R1723                         30
    X190      R1765                         30
    X191      R9                            -1
    X191      R155                          -1
    X191      R505                          -1
    X191      R526                          1
    X191      R737                          30
    X191      R1115                         30
    X191      R1304                         30
    X191      R1325                         30
    X191      R1367                         30
    X191      R1430                         30
    X191      R1535                         30
    X191      R1661                         30
    X191      R1724                         30
    X191      R1766                         30
    X192      R72                           -1
    X192      R342                          -1
    X192      R348                          -1
    X192      R354                          -1
    X192      R513                          -1
    X192      R534                          1
    X192      R738                          30
    X192      R1116                         30
    X192      R1305                         30
    X192      R1326                         30
    X192      R1368                         30
    X192      R1431                         30
    X192      R1536                         30
    X192      R1662                         30
    X192      R1725                         30
    X192      R1767                         30
    X193      R72                           -1
    X193      R348                          -1
    X193      R354                          -1
    X193      R513                          -1
    X193      R534                          1
    X193      R739                          30
    X193      R1117                         30
    X193      R1306                         30
    X193      R1327                         30
    X193      R1369                         30
    X193      R1432                         30
    X193      R1537                         30
    X193      R1663                         30
    X193      R1726                         30
    X193      R1768                         30
    X194      R72                           -1
    X194      R354                          -1
    X194      R513                          -1
    X194      R534                          1
    X194      R740                          30
    X194      R1118                         30
    X194      R1307                         30
    X194      R1328                         30
    X194      R1370                         30
    X194      R1433                         30
    X194      R1538                         30
    X194      R1664                         30
    X194      R1727                         30
    X194      R1769                         30
    X195      R73                           -1
    X195      R343                          -1
    X195      R349                          -1
    X195      R355                          -1
    X195      R514                          -1
    X195      R535                          1
    X195      R741                          30
    X195      R1119                         30
    X195      R1308                         30
    X195      R1329                         30
    X195      R1371                         30
    X195      R1434                         30
    X195      R1539                         30
    X195      R1665                         30
    X195      R1728                         30
    X195      R1770                         30
    X196      R73                           -1
    X196      R349                          -1
    X196      R355                          -1
    X196      R514                          -1
    X196      R535                          1
    X196      R742                          30
    X196      R1120                         30
    X196      R1309                         30
    X196      R1330                         30
    X196      R1372                         30
    X196      R1435                         30
    X196      R1540                         30
    X196      R1666                         30
    X196      R1729                         30
    X196      R1771                         30
    X197      R73                           -1
    X197      R355                          -1
    X197      R514                          -1
    X197      R535                          1
    X197      R743                          30
    X197      R1121                         30
    X197      R1310                         30
    X197      R1331                         30
    X197      R1373                         30
    X197      R1436                         30
    X197      R1541                         30
    X197      R1667                         30
    X197      R1730                         30
    X197      R1772                         30
    X198      R74                           -1
    X198      R344                          -1
    X198      R350                          -1
    X198      R356                          -1
    X198      R515                          -1
    X198      R536                          1
    X198      R744                          30
    X198      R1122                         30
    X198      R1311                         30
    X198      R1332                         30
    X198      R1374                         30
    X198      R1437                         30
    X198      R1542                         30
    X198      R1668                         30
    X198      R1731                         30
    X198      R1773                         30
    X199      R74                           -1
    X199      R350                          -1
    X199      R356                          -1
    X199      R515                          -1
    X199      R536                          1
    X199      R745                          30
    X199      R1123                         30
    X199      R1312                         30
    X199      R1333                         30
    X199      R1375                         30
    X199      R1438                         30
    X199      R1543                         30
    X199      R1669                         30
    X199      R1732                         30
    X199      R1774                         30
    X200      R74                           -1
    X200      R356                          -1
    X200      R515                          -1
    X200      R536                          1
    X200      R746                          30
    X200      R1124                         30
    X200      R1313                         30
    X200      R1334                         30
    X200      R1376                         30
    X200      R1439                         30
    X200      R1544                         30
    X200      R1670                         30
    X200      R1733                         30
    X200      R1775                         30
    X201      R75                           -1
    X201      R345                          -1
    X201      R351                          -1
    X201      R357                          -1
    X201      R516                          -1
    X201      R537                          1
    X201      R747                          30
    X201      R1125                         30
    X201      R1314                         30
    X201      R1335                         30
    X201      R1377                         30
    X201      R1440                         30
    X201      R1545                         30
    X201      R1671                         30
    X201      R1734                         30
    X201      R1776                         30
    X202      R75                           -1
    X202      R351                          -1
    X202      R357                          -1
    X202      R516                          -1
    X202      R537                          1
    X202      R748                          30
    X202      R1126                         30
    X202      R1315                         30
    X202      R1336                         30
    X202      R1378                         30
    X202      R1441                         30
    X202      R1546                         30
    X202      R1672                         30
    X202      R1735                         30
    X202      R1777                         30
    X203      R75                           -1
    X203      R357                          -1
    X203      R516                          -1
    X203      R537                          1
    X203      R749                          30
    X203      R1127                         30
    X203      R1316                         30
    X203      R1337                         30
    X203      R1379                         30
    X203      R1442                         30
    X203      R1547                         30
    X203      R1673                         30
    X203      R1736                         30
    X203      R1778                         30
    X204      R76                           -1
    X204      R346                          -1
    X204      R352                          -1
    X204      R358                          -1
    X204      R517                          -1
    X204      R538                          1
    X204      R750                          30
    X204      R1128                         30
    X204      R1317                         30
    X204      R1338                         30
    X204      R1380                         30
    X204      R1443                         30
    X204      R1548                         30
    X204      R1674                         30
    X204      R1737                         30
    X204      R1779                         30
    X205      R76                           -1
    X205      R352                          -1
    X205      R358                          -1
    X205      R517                          -1
    X205      R538                          1
    X205      R751                          30
    X205      R1129                         30
    X205      R1318                         30
    X205      R1339                         30
    X205      R1381                         30
    X205      R1444                         30
    X205      R1549                         30
    X205      R1675                         30
    X205      R1738                         30
    X205      R1780                         30
    X206      R76                           -1
    X206      R358                          -1
    X206      R517                          -1
    X206      R538                          1
    X206      R752                          30
    X206      R1130                         30
    X206      R1319                         30
    X206      R1340                         30
    X206      R1382                         30
    X206      R1445                         30
    X206      R1550                         30
    X206      R1676                         30
    X206      R1739                         30
    X206      R1781                         30
    X207      R77                           -1
    X207      R347                          -1
    X207      R353                          -1
    X207      R359                          -1
    X207      R518                          -1
    X207      R539                          1
    X207      R753                          30
    X207      R1131                         30
    X207      R1320                         30
    X207      R1341                         30
    X207      R1383                         30
    X207      R1446                         30
    X207      R1551                         30
    X207      R1677                         30
    X207      R1740                         30
    X207      R1782                         30
    X208      R77                           -1
    X208      R353                          -1
    X208      R359                          -1
    X208      R518                          -1
    X208      R539                          1
    X208      R754                          30
    X208      R1132                         30
    X208      R1321                         30
    X208      R1342                         30
    X208      R1384                         30
    X208      R1447                         30
    X208      R1552                         30
    X208      R1678                         30
    X208      R1741                         30
    X208      R1783                         30
    X209      R77                           -1
    X209      R359                          -1
    X209      R518                          -1
    X209      R539                          1
    X209      R755                          30
    X209      R1133                         30
    X209      R1322                         30
    X209      R1343                         30
    X209      R1385                         30
    X209      R1448                         30
    X209      R1553                         30
    X209      R1679                         30
    X209      R1742                         30
    X209      R1784                         30
    X210      R10                           -1
    X210      R156                          -1
    X210      R157                          -1
    X210      R158                          -1
    X210      R505                          -1
    X210      R526                          1
    X210      R756                          30
    X210      R1134                         30
    X210      R1302                         30
    X210      R1323                         30
    X210      R1386                         30
    X210      R1449                         30
    X210      R1554                         30
    X210      R1680                         30
    X210      R1722                         30
    X210      R1764                         30
    X211      R10                           -1
    X211      R157                          -1
    X211      R158                          -1
    X211      R505                          -1
    X211      R526                          1
    X211      R757                          30
    X211      R1135                         30
    X211      R1303                         30
    X211      R1324                         30
    X211      R1387                         30
    X211      R1450                         30
    X211      R1555                         30
    X211      R1681                         30
    X211      R1723                         30
    X211      R1765                         30
    X212      R10                           -1
    X212      R158                          -1
    X212      R505                          -1
    X212      R526                          1
    X212      R758                          30
    X212      R1136                         30
    X212      R1304                         30
    X212      R1325                         30
    X212      R1388                         30
    X212      R1451                         30
    X212      R1556                         30
    X212      R1682                         30
    X212      R1724                         30
    X212      R1766                         30
    X213      R78                           -1
    X213      R360                          -1
    X213      R366                          -1
    X213      R372                          -1
    X213      R513                          -1
    X213      R534                          1
    X213      R759                          30
    X213      R1137                         30
    X213      R1305                         30
    X213      R1326                         30
    X213      R1389                         30
    X213      R1452                         30
    X213      R1557                         30
    X213      R1683                         30
    X213      R1725                         30
    X213      R1767                         30
    X214      R78                           -1
    X214      R366                          -1
    X214      R372                          -1
    X214      R513                          -1
    X214      R534                          1
    X214      R760                          30
    X214      R1138                         30
    X214      R1306                         30
    X214      R1327                         30
    X214      R1390                         30
    X214      R1453                         30
    X214      R1558                         30
    X214      R1684                         30
    X214      R1726                         30
    X214      R1768                         30
    X215      R78                           -1
    X215      R372                          -1
    X215      R513                          -1
    X215      R534                          1
    X215      R761                          30
    X215      R1139                         30
    X215      R1307                         30
    X215      R1328                         30
    X215      R1391                         30
    X215      R1454                         30
    X215      R1559                         30
    X215      R1685                         30
    X215      R1727                         30
    X215      R1769                         30
    X216      R79                           -1
    X216      R361                          -1
    X216      R367                          -1
    X216      R373                          -1
    X216      R514                          -1
    X216      R535                          1
    X216      R762                          30
    X216      R1140                         30
    X216      R1308                         30
    X216      R1329                         30
    X216      R1392                         30
    X216      R1455                         30
    X216      R1560                         30
    X216      R1686                         30
    X216      R1728                         30
    X216      R1770                         30
    X217      R79                           -1
    X217      R367                          -1
    X217      R373                          -1
    X217      R514                          -1
    X217      R535                          1
    X217      R763                          30
    X217      R1141                         30
    X217      R1309                         30
    X217      R1330                         30
    X217      R1393                         30
    X217      R1456                         30
    X217      R1561                         30
    X217      R1687                         30
    X217      R1729                         30
    X217      R1771                         30
    X218      R79                           -1
    X218      R373                          -1
    X218      R514                          -1
    X218      R535                          1
    X218      R764                          30
    X218      R1142                         30
    X218      R1310                         30
    X218      R1331                         30
    X218      R1394                         30
    X218      R1457                         30
    X218      R1562                         30
    X218      R1688                         30
    X218      R1730                         30
    X218      R1772                         30
    X219      R80                           -1
    X219      R362                          -1
    X219      R368                          -1
    X219      R374                          -1
    X219      R515                          -1
    X219      R536                          1
    X219      R765                          30
    X219      R1143                         30
    X219      R1311                         30
    X219      R1332                         30
    X219      R1395                         30
    X219      R1458                         30
    X219      R1563                         30
    X219      R1689                         30
    X219      R1731                         30
    X219      R1773                         30
    X220      R80                           -1
    X220      R368                          -1
    X220      R374                          -1
    X220      R515                          -1
    X220      R536                          1
    X220      R766                          30
    X220      R1144                         30
    X220      R1312                         30
    X220      R1333                         30
    X220      R1396                         30
    X220      R1459                         30
    X220      R1564                         30
    X220      R1690                         30
    X220      R1732                         30
    X220      R1774                         30
    X221      R80                           -1
    X221      R374                          -1
    X221      R515                          -1
    X221      R536                          1
    X221      R767                          30
    X221      R1145                         30
    X221      R1313                         30
    X221      R1334                         30
    X221      R1397                         30
    X221      R1460                         30
    X221      R1565                         30
    X221      R1691                         30
    X221      R1733                         30
    X221      R1775                         30
    X222      R81                           -1
    X222      R363                          -1
    X222      R369                          -1
    X222      R375                          -1
    X222      R516                          -1
    X222      R537                          1
    X222      R768                          30
    X222      R1146                         30
    X222      R1314                         30
    X222      R1335                         30
    X222      R1398                         30
    X222      R1461                         30
    X222      R1566                         30
    X222      R1692                         30
    X222      R1734                         30
    X222      R1776                         30
    X223      R81                           -1
    X223      R369                          -1
    X223      R375                          -1
    X223      R516                          -1
    X223      R537                          1
    X223      R769                          30
    X223      R1147                         30
    X223      R1315                         30
    X223      R1336                         30
    X223      R1399                         30
    X223      R1462                         30
    X223      R1567                         30
    X223      R1693                         30
    X223      R1735                         30
    X223      R1777                         30
    X224      R81                           -1
    X224      R375                          -1
    X224      R516                          -1
    X224      R537                          1
    X224      R770                          30
    X224      R1148                         30
    X224      R1316                         30
    X224      R1337                         30
    X224      R1400                         30
    X224      R1463                         30
    X224      R1568                         30
    X224      R1694                         30
    X224      R1736                         30
    X224      R1778                         30
    X225      R82                           -1
    X225      R364                          -1
    X225      R370                          -1
    X225      R376                          -1
    X225      R517                          -1
    X225      R538                          1
    X225      R771                          30
    X225      R1149                         30
    X225      R1317                         30
    X225      R1338                         30
    X225      R1401                         30
    X225      R1464                         30
    X225      R1569                         30
    X225      R1695                         30
    X225      R1737                         30
    X225      R1779                         30
    X226      R82                           -1
    X226      R370                          -1
    X226      R376                          -1
    X226      R517                          -1
    X226      R538                          1
    X226      R772                          30
    X226      R1150                         30
    X226      R1318                         30
    X226      R1339                         30
    X226      R1402                         30
    X226      R1465                         30
    X226      R1570                         30
    X226      R1696                         30
    X226      R1738                         30
    X226      R1780                         30
    X227      R82                           -1
    X227      R376                          -1
    X227      R517                          -1
    X227      R538                          1
    X227      R773                          30
    X227      R1151                         30
    X227      R1319                         30
    X227      R1340                         30
    X227      R1403                         30
    X227      R1466                         30
    X227      R1571                         30
    X227      R1697                         30
    X227      R1739                         30
    X227      R1781                         30
    X228      R83                           -1
    X228      R365                          -1
    X228      R371                          -1
    X228      R377                          -1
    X228      R518                          -1
    X228      R539                          1
    X228      R774                          30
    X228      R1152                         30
    X228      R1320                         30
    X228      R1341                         30
    X228      R1404                         30
    X228      R1467                         30
    X228      R1572                         30
    X228      R1698                         30
    X228      R1740                         30
    X228      R1782                         30
    X229      R83                           -1
    X229      R371                          -1
    X229      R377                          -1
    X229      R518                          -1
    X229      R539                          1
    X229      R775                          30
    X229      R1153                         30
    X229      R1321                         30
    X229      R1342                         30
    X229      R1405                         30
    X229      R1468                         30
    X229      R1573                         30
    X229      R1699                         30
    X229      R1741                         30
    X229      R1783                         30
    X230      R83                           -1
    X230      R377                          -1
    X230      R518                          -1
    X230      R539                          1
    X230      R776                          30
    X230      R1154                         30
    X230      R1322                         30
    X230      R1343                         30
    X230      R1406                         30
    X230      R1469                         30
    X230      R1574                         30
    X230      R1700                         30
    X230      R1742                         30
    X230      R1784                         30
    X231      R11                           -1
    X231      R159                          -1
    X231      R160                          -1
    X231      R161                          -1
    X231      R505                          -1
    X231      R526                          1
    X231      R777                          30
    X231      R1155                         30
    X231      R1302                         30
    X231      R1323                         30
    X231      R1386                         30
    X231      R1449                         30
    X231      R1575                         30
    X231      R1701                         30
    X231      R1722                         30
    X231      R1764                         30
    X232      R11                           -1
    X232      R160                          -1
    X232      R161                          -1
    X232      R505                          -1
    X232      R526                          1
    X232      R778                          30
    X232      R1156                         30
    X232      R1303                         30
    X232      R1324                         30
    X232      R1387                         30
    X232      R1450                         30
    X232      R1576                         30
    X232      R1702                         30
    X232      R1723                         30
    X232      R1765                         30
    X233      R11                           -1
    X233      R161                          -1
    X233      R505                          -1
    X233      R526                          1
    X233      R779                          30
    X233      R1157                         30
    X233      R1304                         30
    X233      R1325                         30
    X233      R1388                         30
    X233      R1451                         30
    X233      R1577                         30
    X233      R1703                         30
    X233      R1724                         30
    X233      R1766                         30
    X234      R84                           -1
    X234      R378                          -1
    X234      R384                          -1
    X234      R390                          -1
    X234      R513                          -1
    X234      R534                          1
    X234      R780                          30
    X234      R1158                         30
    X234      R1305                         30
    X234      R1326                         30
    X234      R1389                         30
    X234      R1452                         30
    X234      R1578                         30
    X234      R1704                         30
    X234      R1725                         30
    X234      R1767                         30
    X235      R84                           -1
    X235      R384                          -1
    X235      R390                          -1
    X235      R513                          -1
    X235      R534                          1
    X235      R781                          30
    X235      R1159                         30
    X235      R1306                         30
    X235      R1327                         30
    X235      R1390                         30
    X235      R1453                         30
    X235      R1579                         30
    X235      R1705                         30
    X235      R1726                         30
    X235      R1768                         30
    X236      R84                           -1
    X236      R390                          -1
    X236      R513                          -1
    X236      R534                          1
    X236      R782                          30
    X236      R1160                         30
    X236      R1307                         30
    X236      R1328                         30
    X236      R1391                         30
    X236      R1454                         30
    X236      R1580                         30
    X236      R1706                         30
    X236      R1727                         30
    X236      R1769                         30
    X237      R85                           -1
    X237      R379                          -1
    X237      R385                          -1
    X237      R391                          -1
    X237      R514                          -1
    X237      R535                          1
    X237      R783                          30
    X237      R1161                         30
    X237      R1308                         30
    X237      R1329                         30
    X237      R1392                         30
    X237      R1455                         30
    X237      R1581                         30
    X237      R1707                         30
    X237      R1728                         30
    X237      R1770                         30
    X238      R85                           -1
    X238      R385                          -1
    X238      R391                          -1
    X238      R514                          -1
    X238      R535                          1
    X238      R784                          30
    X238      R1162                         30
    X238      R1309                         30
    X238      R1330                         30
    X238      R1393                         30
    X238      R1456                         30
    X238      R1582                         30
    X238      R1708                         30
    X238      R1729                         30
    X238      R1771                         30
    X239      R85                           -1
    X239      R391                          -1
    X239      R514                          -1
    X239      R535                          1
    X239      R785                          30
    X239      R1163                         30
    X239      R1310                         30
    X239      R1331                         30
    X239      R1394                         30
    X239      R1457                         30
    X239      R1583                         30
    X239      R1709                         30
    X239      R1730                         30
    X239      R1772                         30
    X240      R86                           -1
    X240      R380                          -1
    X240      R386                          -1
    X240      R392                          -1
    X240      R515                          -1
    X240      R536                          1
    X240      R786                          30
    X240      R1164                         30
    X240      R1311                         30
    X240      R1332                         30
    X240      R1395                         30
    X240      R1458                         30
    X240      R1584                         30
    X240      R1710                         30
    X240      R1731                         30
    X240      R1773                         30
    X241      R86                           -1
    X241      R386                          -1
    X241      R392                          -1
    X241      R515                          -1
    X241      R536                          1
    X241      R787                          30
    X241      R1165                         30
    X241      R1312                         30
    X241      R1333                         30
    X241      R1396                         30
    X241      R1459                         30
    X241      R1585                         30
    X241      R1711                         30
    X241      R1732                         30
    X241      R1774                         30
    X242      R86                           -1
    X242      R392                          -1
    X242      R515                          -1
    X242      R536                          1
    X242      R788                          30
    X242      R1166                         30
    X242      R1313                         30
    X242      R1334                         30
    X242      R1397                         30
    X242      R1460                         30
    X242      R1586                         30
    X242      R1712                         30
    X242      R1733                         30
    X242      R1775                         30
    X243      R87                           -1
    X243      R381                          -1
    X243      R387                          -1
    X243      R393                          -1
    X243      R516                          -1
    X243      R537                          1
    X243      R789                          30
    X243      R1167                         30
    X243      R1314                         30
    X243      R1335                         30
    X243      R1398                         30
    X243      R1461                         30
    X243      R1587                         30
    X243      R1713                         30
    X243      R1734                         30
    X243      R1776                         30
    X244      R87                           -1
    X244      R387                          -1
    X244      R393                          -1
    X244      R516                          -1
    X244      R537                          1
    X244      R790                          30
    X244      R1168                         30
    X244      R1315                         30
    X244      R1336                         30
    X244      R1399                         30
    X244      R1462                         30
    X244      R1588                         30
    X244      R1714                         30
    X244      R1735                         30
    X244      R1777                         30
    X245      R87                           -1
    X245      R393                          -1
    X245      R516                          -1
    X245      R537                          1
    X245      R791                          30
    X245      R1169                         30
    X245      R1316                         30
    X245      R1337                         30
    X245      R1400                         30
    X245      R1463                         30
    X245      R1589                         30
    X245      R1715                         30
    X245      R1736                         30
    X245      R1778                         30
    X246      R88                           -1
    X246      R382                          -1
    X246      R388                          -1
    X246      R394                          -1
    X246      R517                          -1
    X246      R538                          1
    X246      R792                          30
    X246      R1170                         30
    X246      R1317                         30
    X246      R1338                         30
    X246      R1401                         30
    X246      R1464                         30
    X246      R1590                         30
    X246      R1716                         30
    X246      R1737                         30
    X246      R1779                         30
    X247      R88                           -1
    X247      R388                          -1
    X247      R394                          -1
    X247      R517                          -1
    X247      R538                          1
    X247      R793                          30
    X247      R1171                         30
    X247      R1318                         30
    X247      R1339                         30
    X247      R1402                         30
    X247      R1465                         30
    X247      R1591                         30
    X247      R1717                         30
    X247      R1738                         30
    X247      R1780                         30
    X248      R88                           -1
    X248      R394                          -1
    X248      R517                          -1
    X248      R538                          1
    X248      R794                          30
    X248      R1172                         30
    X248      R1319                         30
    X248      R1340                         30
    X248      R1403                         30
    X248      R1466                         30
    X248      R1592                         30
    X248      R1718                         30
    X248      R1739                         30
    X248      R1781                         30
    X249      R89                           -1
    X249      R383                          -1
    X249      R389                          -1
    X249      R395                          -1
    X249      R518                          -1
    X249      R539                          1
    X249      R795                          30
    X249      R1173                         30
    X249      R1320                         30
    X249      R1341                         30
    X249      R1404                         30
    X249      R1467                         30
    X249      R1593                         30
    X249      R1719                         30
    X249      R1740                         30
    X249      R1782                         30
    X250      R89                           -1
    X250      R389                          -1
    X250      R395                          -1
    X250      R518                          -1
    X250      R539                          1
    X250      R796                          30
    X250      R1174                         30
    X250      R1321                         30
    X250      R1342                         30
    X250      R1405                         30
    X250      R1468                         30
    X250      R1594                         30
    X250      R1720                         30
    X250      R1741                         30
    X250      R1783                         30
    X251      R89                           -1
    X251      R395                          -1
    X251      R518                          -1
    X251      R539                          1
    X251      R797                          30
    X251      R1175                         30
    X251      R1322                         30
    X251      R1343                         30
    X251      R1406                         30
    X251      R1469                         30
    X251      R1595                         30
    X251      R1721                         30
    X251      R1742                         30
    X251      R1784                         30
    X252      R12                           -1
    X252      R162                          -1
    X252      R163                          -1
    X252      R164                          -1
    X252      R506                          -1
    X252      R527                          1
    X252      R798                          50
    X252      R1176                         50
    X252      R1302                         50
    X252      R1323                         50
    X252      R1344                         50
    X252      R1407                         50
    X252      R1470                         50
    X252      R1596                         50
    X252      R1743                         50
    X252      R1785                         50
    X253      R12                           -1
    X253      R163                          -1
    X253      R164                          -1
    X253      R506                          -1
    X253      R527                          1
    X253      R799                          50
    X253      R1177                         50
    X253      R1303                         50
    X253      R1324                         50
    X253      R1345                         50
    X253      R1408                         50
    X253      R1471                         50
    X253      R1597                         50
    X253      R1744                         50
    X253      R1786                         50
    X254      R12                           -1
    X254      R164                          -1
    X254      R506                          -1
    X254      R527                          1
    X254      R800                          50
    X254      R1178                         50
    X254      R1304                         50
    X254      R1325                         50
    X254      R1346                         50
    X254      R1409                         50
    X254      R1472                         50
    X254      R1598                         50
    X254      R1745                         50
    X254      R1787                         50
    X255      R90                           -1
    X255      R396                          -1
    X255      R402                          -1
    X255      R408                          -1
    X255      R519                          -1
    X255      R540                          1
    X255      R801                          50
    X255      R1179                         50
    X255      R1305                         50
    X255      R1326                         50
    X255      R1347                         50
    X255      R1410                         50
    X255      R1473                         50
    X255      R1599                         50
    X255      R1746                         50
    X255      R1788                         50
    X256      R90                           -1
    X256      R402                          -1
    X256      R408                          -1
    X256      R519                          -1
    X256      R540                          1
    X256      R802                          50
    X256      R1180                         50
    X256      R1306                         50
    X256      R1327                         50
    X256      R1348                         50
    X256      R1411                         50
    X256      R1474                         50
    X256      R1600                         50
    X256      R1747                         50
    X256      R1789                         50
    X257      R90                           -1
    X257      R408                          -1
    X257      R519                          -1
    X257      R540                          1
    X257      R803                          50
    X257      R1181                         50
    X257      R1307                         50
    X257      R1328                         50
    X257      R1349                         50
    X257      R1412                         50
    X257      R1475                         50
    X257      R1601                         50
    X257      R1748                         50
    X257      R1790                         50
    X258      R91                           -1
    X258      R397                          -1
    X258      R403                          -1
    X258      R409                          -1
    X258      R520                          -1
    X258      R541                          1
    X258      R804                          50
    X258      R1182                         50
    X258      R1308                         50
    X258      R1329                         50
    X258      R1350                         50
    X258      R1413                         50
    X258      R1476                         50
    X258      R1602                         50
    X258      R1749                         50
    X258      R1791                         50
    X259      R91                           -1
    X259      R403                          -1
    X259      R409                          -1
    X259      R520                          -1
    X259      R541                          1
    X259      R805                          50
    X259      R1183                         50
    X259      R1309                         50
    X259      R1330                         50
    X259      R1351                         50
    X259      R1414                         50
    X259      R1477                         50
    X259      R1603                         50
    X259      R1750                         50
    X259      R1792                         50
    X260      R91                           -1
    X260      R409                          -1
    X260      R520                          -1
    X260      R541                          1
    X260      R806                          50
    X260      R1184                         50
    X260      R1310                         50
    X260      R1331                         50
    X260      R1352                         50
    X260      R1415                         50
    X260      R1478                         50
    X260      R1604                         50
    X260      R1751                         50
    X260      R1793                         50
    X261      R92                           -1
    X261      R398                          -1
    X261      R404                          -1
    X261      R410                          -1
    X261      R521                          -1
    X261      R542                          1
    X261      R807                          50
    X261      R1185                         50
    X261      R1311                         50
    X261      R1332                         50
    X261      R1353                         50
    X261      R1416                         50
    X261      R1479                         50
    X261      R1605                         50
    X261      R1752                         50
    X261      R1794                         50
    X262      R92                           -1
    X262      R404                          -1
    X262      R410                          -1
    X262      R521                          -1
    X262      R542                          1
    X262      R808                          50
    X262      R1186                         50
    X262      R1312                         50
    X262      R1333                         50
    X262      R1354                         50
    X262      R1417                         50
    X262      R1480                         50
    X262      R1606                         50
    X262      R1753                         50
    X262      R1795                         50
    X263      R92                           -1
    X263      R410                          -1
    X263      R521                          -1
    X263      R542                          1
    X263      R809                          50
    X263      R1187                         50
    X263      R1313                         50
    X263      R1334                         50
    X263      R1355                         50
    X263      R1418                         50
    X263      R1481                         50
    X263      R1607                         50
    X263      R1754                         50
    X263      R1796                         50
    X264      R93                           -1
    X264      R399                          -1
    X264      R405                          -1
    X264      R411                          -1
    X264      R522                          -1
    X264      R543                          1
    X264      R810                          50
    X264      R1188                         50
    X264      R1314                         50
    X264      R1335                         50
    X264      R1356                         50
    X264      R1419                         50
    X264      R1482                         50
    X264      R1608                         50
    X264      R1755                         50
    X264      R1797                         50
    X265      R93                           -1
    X265      R405                          -1
    X265      R411                          -1
    X265      R522                          -1
    X265      R543                          1
    X265      R811                          50
    X265      R1189                         50
    X265      R1315                         50
    X265      R1336                         50
    X265      R1357                         50
    X265      R1420                         50
    X265      R1483                         50
    X265      R1609                         50
    X265      R1756                         50
    X265      R1798                         50
    X266      R93                           -1
    X266      R411                          -1
    X266      R522                          -1
    X266      R543                          1
    X266      R812                          50
    X266      R1190                         50
    X266      R1316                         50
    X266      R1337                         50
    X266      R1358                         50
    X266      R1421                         50
    X266      R1484                         50
    X266      R1610                         50
    X266      R1757                         50
    X266      R1799                         50
    X267      R94                           -1
    X267      R400                          -1
    X267      R406                          -1
    X267      R412                          -1
    X267      R523                          -1
    X267      R544                          1
    X267      R813                          50
    X267      R1191                         50
    X267      R1317                         50
    X267      R1338                         50
    X267      R1359                         50
    X267      R1422                         50
    X267      R1485                         50
    X267      R1611                         50
    X267      R1758                         50
    X267      R1800                         50
    X268      R94                           -1
    X268      R406                          -1
    X268      R412                          -1
    X268      R523                          -1
    X268      R544                          1
    X268      R814                          50
    X268      R1192                         50
    X268      R1318                         50
    X268      R1339                         50
    X268      R1360                         50
    X268      R1423                         50
    X268      R1486                         50
    X268      R1612                         50
    X268      R1759                         50
    X268      R1801                         50
    X269      R94                           -1
    X269      R412                          -1
    X269      R523                          -1
    X269      R544                          1
    X269      R815                          50
    X269      R1193                         50
    X269      R1319                         50
    X269      R1340                         50
    X269      R1361                         50
    X269      R1424                         50
    X269      R1487                         50
    X269      R1613                         50
    X269      R1760                         50
    X269      R1802                         50
    X270      R95                           -1
    X270      R401                          -1
    X270      R407                          -1
    X270      R413                          -1
    X270      R524                          -1
    X270      R545                          1
    X270      R816                          50
    X270      R1194                         50
    X270      R1320                         50
    X270      R1341                         50
    X270      R1362                         50
    X270      R1425                         50
    X270      R1488                         50
    X270      R1614                         50
    X270      R1761                         50
    X270      R1803                         50
    X271      R95                           -1
    X271      R407                          -1
    X271      R413                          -1
    X271      R524                          -1
    X271      R545                          1
    X271      R817                          50
    X271      R1195                         50
    X271      R1321                         50
    X271      R1342                         50
    X271      R1363                         50
    X271      R1426                         50
    X271      R1489                         50
    X271      R1615                         50
    X271      R1762                         50
    X271      R1804                         50
    X272      R95                           -1
    X272      R413                          -1
    X272      R524                          -1
    X272      R545                          1
    X272      R818                          50
    X272      R1196                         50
    X272      R1322                         50
    X272      R1343                         50
    X272      R1364                         50
    X272      R1427                         50
    X272      R1490                         50
    X272      R1616                         50
    X272      R1763                         50
    X272      R1805                         50
    X273      R13                           -1
    X273      R165                          -1
    X273      R166                          -1
    X273      R167                          -1
    X273      R506                          -1
    X273      R527                          1
    X273      R819                          50
    X273      R1197                         50
    X273      R1302                         50
    X273      R1323                         50
    X273      R1344                         50
    X273      R1407                         50
    X273      R1491                         50
    X273      R1617                         50
    X273      R1743                         50
    X273      R1785                         50
    X274      R13                           -1
    X274      R166                          -1
    X274      R167                          -1
    X274      R506                          -1
    X274      R527                          1
    X274      R820                          50
    X274      R1198                         50
    X274      R1303                         50
    X274      R1324                         50
    X274      R1345                         50
    X274      R1408                         50
    X274      R1492                         50
    X274      R1618                         50
    X274      R1744                         50
    X274      R1786                         50
    X275      R13                           -1
    X275      R167                          -1
    X275      R506                          -1
    X275      R527                          1
    X275      R821                          50
    X275      R1199                         50
    X275      R1304                         50
    X275      R1325                         50
    X275      R1346                         50
    X275      R1409                         50
    X275      R1493                         50
    X275      R1619                         50
    X275      R1745                         50
    X275      R1787                         50
    X276      R96                           -1
    X276      R414                          -1
    X276      R420                          -1
    X276      R426                          -1
    X276      R519                          -1
    X276      R540                          1
    X276      R822                          50
    X276      R1200                         50
    X276      R1305                         50
    X276      R1326                         50
    X276      R1347                         50
    X276      R1410                         50
    X276      R1494                         50
    X276      R1620                         50
    X276      R1746                         50
    X276      R1788                         50
    X277      R96                           -1
    X277      R420                          -1
    X277      R426                          -1
    X277      R519                          -1
    X277      R540                          1
    X277      R823                          50
    X277      R1201                         50
    X277      R1306                         50
    X277      R1327                         50
    X277      R1348                         50
    X277      R1411                         50
    X277      R1495                         50
    X277      R1621                         50
    X277      R1747                         50
    X277      R1789                         50
    X278      R96                           -1
    X278      R426                          -1
    X278      R519                          -1
    X278      R540                          1
    X278      R824                          50
    X278      R1202                         50
    X278      R1307                         50
    X278      R1328                         50
    X278      R1349                         50
    X278      R1412                         50
    X278      R1496                         50
    X278      R1622                         50
    X278      R1748                         50
    X278      R1790                         50
    X279      R97                           -1
    X279      R415                          -1
    X279      R421                          -1
    X279      R427                          -1
    X279      R520                          -1
    X279      R541                          1
    X279      R825                          50
    X279      R1203                         50
    X279      R1308                         50
    X279      R1329                         50
    X279      R1350                         50
    X279      R1413                         50
    X279      R1497                         50
    X279      R1623                         50
    X279      R1749                         50
    X279      R1791                         50
    X280      R97                           -1
    X280      R421                          -1
    X280      R427                          -1
    X280      R520                          -1
    X280      R541                          1
    X280      R826                          50
    X280      R1204                         50
    X280      R1309                         50
    X280      R1330                         50
    X280      R1351                         50
    X280      R1414                         50
    X280      R1498                         50
    X280      R1624                         50
    X280      R1750                         50
    X280      R1792                         50
    X281      R97                           -1
    X281      R427                          -1
    X281      R520                          -1
    X281      R541                          1
    X281      R827                          50
    X281      R1205                         50
    X281      R1310                         50
    X281      R1331                         50
    X281      R1352                         50
    X281      R1415                         50
    X281      R1499                         50
    X281      R1625                         50
    X281      R1751                         50
    X281      R1793                         50
    X282      R98                           -1
    X282      R416                          -1
    X282      R422                          -1
    X282      R428                          -1
    X282      R521                          -1
    X282      R542                          1
    X282      R828                          50
    X282      R1206                         50
    X282      R1311                         50
    X282      R1332                         50
    X282      R1353                         50
    X282      R1416                         50
    X282      R1500                         50
    X282      R1626                         50
    X282      R1752                         50
    X282      R1794                         50
    X283      R98                           -1
    X283      R422                          -1
    X283      R428                          -1
    X283      R521                          -1
    X283      R542                          1
    X283      R829                          50
    X283      R1207                         50
    X283      R1312                         50
    X283      R1333                         50
    X283      R1354                         50
    X283      R1417                         50
    X283      R1501                         50
    X283      R1627                         50
    X283      R1753                         50
    X283      R1795                         50
    X284      R98                           -1
    X284      R428                          -1
    X284      R521                          -1
    X284      R542                          1
    X284      R830                          50
    X284      R1208                         50
    X284      R1313                         50
    X284      R1334                         50
    X284      R1355                         50
    X284      R1418                         50
    X284      R1502                         50
    X284      R1628                         50
    X284      R1754                         50
    X284      R1796                         50
    X285      R99                           -1
    X285      R417                          -1
    X285      R423                          -1
    X285      R429                          -1
    X285      R522                          -1
    X285      R543                          1
    X285      R831                          50
    X285      R1209                         50
    X285      R1314                         50
    X285      R1335                         50
    X285      R1356                         50
    X285      R1419                         50
    X285      R1503                         50
    X285      R1629                         50
    X285      R1755                         50
    X285      R1797                         50
    X286      R99                           -1
    X286      R423                          -1
    X286      R429                          -1
    X286      R522                          -1
    X286      R543                          1
    X286      R832                          50
    X286      R1210                         50
    X286      R1315                         50
    X286      R1336                         50
    X286      R1357                         50
    X286      R1420                         50
    X286      R1504                         50
    X286      R1630                         50
    X286      R1756                         50
    X286      R1798                         50
    X287      R99                           -1
    X287      R429                          -1
    X287      R522                          -1
    X287      R543                          1
    X287      R833                          50
    X287      R1211                         50
    X287      R1316                         50
    X287      R1337                         50
    X287      R1358                         50
    X287      R1421                         50
    X287      R1505                         50
    X287      R1631                         50
    X287      R1757                         50
    X287      R1799                         50
    X288      R100                          -1
    X288      R418                          -1
    X288      R424                          -1
    X288      R430                          -1
    X288      R523                          -1
    X288      R544                          1
    X288      R834                          50
    X288      R1212                         50
    X288      R1317                         50
    X288      R1338                         50
    X288      R1359                         50
    X288      R1422                         50
    X288      R1506                         50
    X288      R1632                         50
    X288      R1758                         50
    X288      R1800                         50
    X289      R100                          -1
    X289      R424                          -1
    X289      R430                          -1
    X289      R523                          -1
    X289      R544                          1
    X289      R835                          50
    X289      R1213                         50
    X289      R1318                         50
    X289      R1339                         50
    X289      R1360                         50
    X289      R1423                         50
    X289      R1507                         50
    X289      R1633                         50
    X289      R1759                         50
    X289      R1801                         50
    X290      R100                          -1
    X290      R430                          -1
    X290      R523                          -1
    X290      R544                          1
    X290      R836                          50
    X290      R1214                         50
    X290      R1319                         50
    X290      R1340                         50
    X290      R1361                         50
    X290      R1424                         50
    X290      R1508                         50
    X290      R1634                         50
    X290      R1760                         50
    X290      R1802                         50
    X291      R101                          -1
    X291      R419                          -1
    X291      R425                          -1
    X291      R431                          -1
    X291      R524                          -1
    X291      R545                          1
    X291      R837                          50
    X291      R1215                         50
    X291      R1320                         50
    X291      R1341                         50
    X291      R1362                         50
    X291      R1425                         50
    X291      R1509                         50
    X291      R1635                         50
    X291      R1761                         50
    X291      R1803                         50
    X292      R101                          -1
    X292      R425                          -1
    X292      R431                          -1
    X292      R524                          -1
    X292      R545                          1
    X292      R838                          50
    X292      R1216                         50
    X292      R1321                         50
    X292      R1342                         50
    X292      R1363                         50
    X292      R1426                         50
    X292      R1510                         50
    X292      R1636                         50
    X292      R1762                         50
    X292      R1804                         50
    X293      R101                          -1
    X293      R431                          -1
    X293      R524                          -1
    X293      R545                          1
    X293      R839                          50
    X293      R1217                         50
    X293      R1322                         50
    X293      R1343                         50
    X293      R1364                         50
    X293      R1427                         50
    X293      R1511                         50
    X293      R1637                         50
    X293      R1763                         50
    X293      R1805                         50
    X294      R14                           -1
    X294      R168                          -1
    X294      R169                          -1
    X294      R170                          -1
    X294      R506                          -1
    X294      R527                          1
    X294      R840                          50
    X294      R1218                         50
    X294      R1302                         50
    X294      R1323                         50
    X294      R1365                         50
    X294      R1428                         50
    X294      R1512                         50
    X294      R1638                         50
    X294      R1743                         50
    X294      R1785                         50
    X295      R14                           -1
    X295      R169                          -1
    X295      R170                          -1
    X295      R506                          -1
    X295      R527                          1
    X295      R841                          50
    X295      R1219                         50
    X295      R1303                         50
    X295      R1324                         50
    X295      R1366                         50
    X295      R1429                         50
    X295      R1513                         50
    X295      R1639                         50
    X295      R1744                         50
    X295      R1786                         50
    X296      R14                           -1
    X296      R170                          -1
    X296      R506                          -1
    X296      R527                          1
    X296      R842                          50
    X296      R1220                         50
    X296      R1304                         50
    X296      R1325                         50
    X296      R1367                         50
    X296      R1430                         50
    X296      R1514                         50
    X296      R1640                         50
    X296      R1745                         50
    X296      R1787                         50
    X297      R102                          -1
    X297      R432                          -1
    X297      R438                          -1
    X297      R444                          -1
    X297      R519                          -1
    X297      R540                          1
    X297      R843                          50
    X297      R1221                         50
    X297      R1305                         50
    X297      R1326                         50
    X297      R1368                         50
    X297      R1431                         50
    X297      R1515                         50
    X297      R1641                         50
    X297      R1746                         50
    X297      R1788                         50
    X298      R102                          -1
    X298      R438                          -1
    X298      R444                          -1
    X298      R519                          -1
    X298      R540                          1
    X298      R844                          50
    X298      R1222                         50
    X298      R1306                         50
    X298      R1327                         50
    X298      R1369                         50
    X298      R1432                         50
    X298      R1516                         50
    X298      R1642                         50
    X298      R1747                         50
    X298      R1789                         50
    X299      R102                          -1
    X299      R444                          -1
    X299      R519                          -1
    X299      R540                          1
    X299      R845                          50
    X299      R1223                         50
    X299      R1307                         50
    X299      R1328                         50
    X299      R1370                         50
    X299      R1433                         50
    X299      R1517                         50
    X299      R1643                         50
    X299      R1748                         50
    X299      R1790                         50
    X300      R103                          -1
    X300      R433                          -1
    X300      R439                          -1
    X300      R445                          -1
    X300      R520                          -1
    X300      R541                          1
    X300      R846                          50
    X300      R1224                         50
    X300      R1308                         50
    X300      R1329                         50
    X300      R1371                         50
    X300      R1434                         50
    X300      R1518                         50
    X300      R1644                         50
    X300      R1749                         50
    X300      R1791                         50
    X301      R103                          -1
    X301      R439                          -1
    X301      R445                          -1
    X301      R520                          -1
    X301      R541                          1
    X301      R847                          50
    X301      R1225                         50
    X301      R1309                         50
    X301      R1330                         50
    X301      R1372                         50
    X301      R1435                         50
    X301      R1519                         50
    X301      R1645                         50
    X301      R1750                         50
    X301      R1792                         50
    X302      R103                          -1
    X302      R445                          -1
    X302      R520                          -1
    X302      R541                          1
    X302      R848                          50
    X302      R1226                         50
    X302      R1310                         50
    X302      R1331                         50
    X302      R1373                         50
    X302      R1436                         50
    X302      R1520                         50
    X302      R1646                         50
    X302      R1751                         50
    X302      R1793                         50
    X303      R104                          -1
    X303      R434                          -1
    X303      R440                          -1
    X303      R446                          -1
    X303      R521                          -1
    X303      R542                          1
    X303      R849                          50
    X303      R1227                         50
    X303      R1311                         50
    X303      R1332                         50
    X303      R1374                         50
    X303      R1437                         50
    X303      R1521                         50
    X303      R1647                         50
    X303      R1752                         50
    X303      R1794                         50
    X304      R104                          -1
    X304      R440                          -1
    X304      R446                          -1
    X304      R521                          -1
    X304      R542                          1
    X304      R850                          50
    X304      R1228                         50
    X304      R1312                         50
    X304      R1333                         50
    X304      R1375                         50
    X304      R1438                         50
    X304      R1522                         50
    X304      R1648                         50
    X304      R1753                         50
    X304      R1795                         50
    X305      R104                          -1
    X305      R446                          -1
    X305      R521                          -1
    X305      R542                          1
    X305      R851                          50
    X305      R1229                         50
    X305      R1313                         50
    X305      R1334                         50
    X305      R1376                         50
    X305      R1439                         50
    X305      R1523                         50
    X305      R1649                         50
    X305      R1754                         50
    X305      R1796                         50
    X306      R105                          -1
    X306      R435                          -1
    X306      R441                          -1
    X306      R447                          -1
    X306      R522                          -1
    X306      R543                          1
    X306      R852                          50
    X306      R1230                         50
    X306      R1314                         50
    X306      R1335                         50
    X306      R1377                         50
    X306      R1440                         50
    X306      R1524                         50
    X306      R1650                         50
    X306      R1755                         50
    X306      R1797                         50
    X307      R105                          -1
    X307      R441                          -1
    X307      R447                          -1
    X307      R522                          -1
    X307      R543                          1
    X307      R853                          50
    X307      R1231                         50
    X307      R1315                         50
    X307      R1336                         50
    X307      R1378                         50
    X307      R1441                         50
    X307      R1525                         50
    X307      R1651                         50
    X307      R1756                         50
    X307      R1798                         50
    X308      R105                          -1
    X308      R447                          -1
    X308      R522                          -1
    X308      R543                          1
    X308      R854                          50
    X308      R1232                         50
    X308      R1316                         50
    X308      R1337                         50
    X308      R1379                         50
    X308      R1442                         50
    X308      R1526                         50
    X308      R1652                         50
    X308      R1757                         50
    X308      R1799                         50
    X309      R106                          -1
    X309      R436                          -1
    X309      R442                          -1
    X309      R448                          -1
    X309      R523                          -1
    X309      R544                          1
    X309      R855                          50
    X309      R1233                         50
    X309      R1317                         50
    X309      R1338                         50
    X309      R1380                         50
    X309      R1443                         50
    X309      R1527                         50
    X309      R1653                         50
    X309      R1758                         50
    X309      R1800                         50
    X310      R106                          -1
    X310      R442                          -1
    X310      R448                          -1
    X310      R523                          -1
    X310      R544                          1
    X310      R856                          50
    X310      R1234                         50
    X310      R1318                         50
    X310      R1339                         50
    X310      R1381                         50
    X310      R1444                         50
    X310      R1528                         50
    X310      R1654                         50
    X310      R1759                         50
    X310      R1801                         50
    X311      R106                          -1
    X311      R448                          -1
    X311      R523                          -1
    X311      R544                          1
    X311      R857                          50
    X311      R1235                         50
    X311      R1319                         50
    X311      R1340                         50
    X311      R1382                         50
    X311      R1445                         50
    X311      R1529                         50
    X311      R1655                         50
    X311      R1760                         50
    X311      R1802                         50
    X312      R107                          -1
    X312      R437                          -1
    X312      R443                          -1
    X312      R449                          -1
    X312      R524                          -1
    X312      R545                          1
    X312      R858                          50
    X312      R1236                         50
    X312      R1320                         50
    X312      R1341                         50
    X312      R1383                         50
    X312      R1446                         50
    X312      R1530                         50
    X312      R1656                         50
    X312      R1761                         50
    X312      R1803                         50
    X313      R107                          -1
    X313      R443                          -1
    X313      R449                          -1
    X313      R524                          -1
    X313      R545                          1
    X313      R859                          50
    X313      R1237                         50
    X313      R1321                         50
    X313      R1342                         50
    X313      R1384                         50
    X313      R1447                         50
    X313      R1531                         50
    X313      R1657                         50
    X313      R1762                         50
    X313      R1804                         50
    X314      R107                          -1
    X314      R449                          -1
    X314      R524                          -1
    X314      R545                          1
    X314      R860                          50
    X314      R1238                         50
    X314      R1322                         50
    X314      R1343                         50
    X314      R1385                         50
    X314      R1448                         50
    X314      R1532                         50
    X314      R1658                         50
    X314      R1763                         50
    X314      R1805                         50
    X315      R15                           -1
    X315      R171                          -1
    X315      R172                          -1
    X315      R173                          -1
    X315      R506                          -1
    X315      R527                          1
    X315      R861                          50
    X315      R1239                         50
    X315      R1302                         50
    X315      R1323                         50
    X315      R1365                         50
    X315      R1428                         50
    X315      R1533                         50
    X315      R1659                         50
    X315      R1743                         50
    X315      R1785                         50
    X316      R15                           -1
    X316      R172                          -1
    X316      R173                          -1
    X316      R506                          -1
    X316      R527                          1
    X316      R862                          50
    X316      R1240                         50
    X316      R1303                         50
    X316      R1324                         50
    X316      R1366                         50
    X316      R1429                         50
    X316      R1534                         50
    X316      R1660                         50
    X316      R1744                         50
    X316      R1786                         50
    X317      R15                           -1
    X317      R173                          -1
    X317      R506                          -1
    X317      R527                          1
    X317      R863                          50
    X317      R1241                         50
    X317      R1304                         50
    X317      R1325                         50
    X317      R1367                         50
    X317      R1430                         50
    X317      R1535                         50
    X317      R1661                         50
    X317      R1745                         50
    X317      R1787                         50
    X318      R108                          -1
    X318      R450                          -1
    X318      R456                          -1
    X318      R462                          -1
    X318      R519                          -1
    X318      R540                          1
    X318      R864                          50
    X318      R1242                         50
    X318      R1305                         50
    X318      R1326                         50
    X318      R1368                         50
    X318      R1431                         50
    X318      R1536                         50
    X318      R1662                         50
    X318      R1746                         50
    X318      R1788                         50
    X319      R108                          -1
    X319      R456                          -1
    X319      R462                          -1
    X319      R519                          -1
    X319      R540                          1
    X319      R865                          50
    X319      R1243                         50
    X319      R1306                         50
    X319      R1327                         50
    X319      R1369                         50
    X319      R1432                         50
    X319      R1537                         50
    X319      R1663                         50
    X319      R1747                         50
    X319      R1789                         50
    X320      R108                          -1
    X320      R462                          -1
    X320      R519                          -1
    X320      R540                          1
    X320      R866                          50
    X320      R1244                         50
    X320      R1307                         50
    X320      R1328                         50
    X320      R1370                         50
    X320      R1433                         50
    X320      R1538                         50
    X320      R1664                         50
    X320      R1748                         50
    X320      R1790                         50
    X321      R109                          -1
    X321      R451                          -1
    X321      R457                          -1
    X321      R463                          -1
    X321      R520                          -1
    X321      R541                          1
    X321      R867                          50
    X321      R1245                         50
    X321      R1308                         50
    X321      R1329                         50
    X321      R1371                         50
    X321      R1434                         50
    X321      R1539                         50
    X321      R1665                         50
    X321      R1749                         50
    X321      R1791                         50
    X322      R109                          -1
    X322      R457                          -1
    X322      R463                          -1
    X322      R520                          -1
    X322      R541                          1
    X322      R868                          50
    X322      R1246                         50
    X322      R1309                         50
    X322      R1330                         50
    X322      R1372                         50
    X322      R1435                         50
    X322      R1540                         50
    X322      R1666                         50
    X322      R1750                         50
    X322      R1792                         50
    X323      R109                          -1
    X323      R463                          -1
    X323      R520                          -1
    X323      R541                          1
    X323      R869                          50
    X323      R1247                         50
    X323      R1310                         50
    X323      R1331                         50
    X323      R1373                         50
    X323      R1436                         50
    X323      R1541                         50
    X323      R1667                         50
    X323      R1751                         50
    X323      R1793                         50
    X324      R110                          -1
    X324      R452                          -1
    X324      R458                          -1
    X324      R464                          -1
    X324      R521                          -1
    X324      R542                          1
    X324      R870                          50
    X324      R1248                         50
    X324      R1311                         50
    X324      R1332                         50
    X324      R1374                         50
    X324      R1437                         50
    X324      R1542                         50
    X324      R1668                         50
    X324      R1752                         50
    X324      R1794                         50
    X325      R110                          -1
    X325      R458                          -1
    X325      R464                          -1
    X325      R521                          -1
    X325      R542                          1
    X325      R871                          50
    X325      R1249                         50
    X325      R1312                         50
    X325      R1333                         50
    X325      R1375                         50
    X325      R1438                         50
    X325      R1543                         50
    X325      R1669                         50
    X325      R1753                         50
    X325      R1795                         50
    X326      R110                          -1
    X326      R464                          -1
    X326      R521                          -1
    X326      R542                          1
    X326      R872                          50
    X326      R1250                         50
    X326      R1313                         50
    X326      R1334                         50
    X326      R1376                         50
    X326      R1439                         50
    X326      R1544                         50
    X326      R1670                         50
    X326      R1754                         50
    X326      R1796                         50
    X327      R111                          -1
    X327      R453                          -1
    X327      R459                          -1
    X327      R465                          -1
    X327      R522                          -1
    X327      R543                          1
    X327      R873                          50
    X327      R1251                         50
    X327      R1314                         50
    X327      R1335                         50
    X327      R1377                         50
    X327      R1440                         50
    X327      R1545                         50
    X327      R1671                         50
    X327      R1755                         50
    X327      R1797                         50
    X328      R111                          -1
    X328      R459                          -1
    X328      R465                          -1
    X328      R522                          -1
    X328      R543                          1
    X328      R874                          50
    X328      R1252                         50
    X328      R1315                         50
    X328      R1336                         50
    X328      R1378                         50
    X328      R1441                         50
    X328      R1546                         50
    X328      R1672                         50
    X328      R1756                         50
    X328      R1798                         50
    X329      R111                          -1
    X329      R465                          -1
    X329      R522                          -1
    X329      R543                          1
    X329      R875                          50
    X329      R1253                         50
    X329      R1316                         50
    X329      R1337                         50
    X329      R1379                         50
    X329      R1442                         50
    X329      R1547                         50
    X329      R1673                         50
    X329      R1757                         50
    X329      R1799                         50
    X330      R112                          -1
    X330      R454                          -1
    X330      R460                          -1
    X330      R466                          -1
    X330      R523                          -1
    X330      R544                          1
    X330      R876                          50
    X330      R1254                         50
    X330      R1317                         50
    X330      R1338                         50
    X330      R1380                         50
    X330      R1443                         50
    X330      R1548                         50
    X330      R1674                         50
    X330      R1758                         50
    X330      R1800                         50
    X331      R112                          -1
    X331      R460                          -1
    X331      R466                          -1
    X331      R523                          -1
    X331      R544                          1
    X331      R877                          50
    X331      R1255                         50
    X331      R1318                         50
    X331      R1339                         50
    X331      R1381                         50
    X331      R1444                         50
    X331      R1549                         50
    X331      R1675                         50
    X331      R1759                         50
    X331      R1801                         50
    X332      R112                          -1
    X332      R466                          -1
    X332      R523                          -1
    X332      R544                          1
    X332      R878                          50
    X332      R1256                         50
    X332      R1319                         50
    X332      R1340                         50
    X332      R1382                         50
    X332      R1445                         50
    X332      R1550                         50
    X332      R1676                         50
    X332      R1760                         50
    X332      R1802                         50
    X333      R113                          -1
    X333      R455                          -1
    X333      R461                          -1
    X333      R467                          -1
    X333      R524                          -1
    X333      R545                          1
    X333      R879                          50
    X333      R1257                         50
    X333      R1320                         50
    X333      R1341                         50
    X333      R1383                         50
    X333      R1446                         50
    X333      R1551                         50
    X333      R1677                         50
    X333      R1761                         50
    X333      R1803                         50
    X334      R113                          -1
    X334      R461                          -1
    X334      R467                          -1
    X334      R524                          -1
    X334      R545                          1
    X334      R880                          50
    X334      R1258                         50
    X334      R1321                         50
    X334      R1342                         50
    X334      R1384                         50
    X334      R1447                         50
    X334      R1552                         50
    X334      R1678                         50
    X334      R1762                         50
    X334      R1804                         50
    X335      R113                          -1
    X335      R467                          -1
    X335      R524                          -1
    X335      R545                          1
    X335      R881                          50
    X335      R1259                         50
    X335      R1322                         50
    X335      R1343                         50
    X335      R1385                         50
    X335      R1448                         50
    X335      R1553                         50
    X335      R1679                         50
    X335      R1763                         50
    X335      R1805                         50
    X336      R16                           -1
    X336      R174                          -1
    X336      R175                          -1
    X336      R176                          -1
    X336      R506                          -1
    X336      R527                          1
    X336      R882                          50
    X336      R1260                         50
    X336      R1302                         50
    X336      R1323                         50
    X336      R1386                         50
    X336      R1449                         50
    X336      R1554                         50
    X336      R1680                         50
    X336      R1743                         50
    X336      R1785                         50
    X337      R16                           -1
    X337      R175                          -1
    X337      R176                          -1
    X337      R506                          -1
    X337      R527                          1
    X337      R883                          50
    X337      R1261                         50
    X337      R1303                         50
    X337      R1324                         50
    X337      R1387                         50
    X337      R1450                         50
    X337      R1555                         50
    X337      R1681                         50
    X337      R1744                         50
    X337      R1786                         50
    X338      R16                           -1
    X338      R176                          -1
    X338      R506                          -1
    X338      R527                          1
    X338      R884                          50
    X338      R1262                         50
    X338      R1304                         50
    X338      R1325                         50
    X338      R1388                         50
    X338      R1451                         50
    X338      R1556                         50
    X338      R1682                         50
    X338      R1745                         50
    X338      R1787                         50
    X339      R114                          -1
    X339      R468                          -1
    X339      R474                          -1
    X339      R480                          -1
    X339      R519                          -1
    X339      R540                          1
    X339      R885                          50
    X339      R1263                         50
    X339      R1305                         50
    X339      R1326                         50
    X339      R1389                         50
    X339      R1452                         50
    X339      R1557                         50
    X339      R1683                         50
    X339      R1746                         50
    X339      R1788                         50
    X340      R114                          -1
    X340      R474                          -1
    X340      R480                          -1
    X340      R519                          -1
    X340      R540                          1
    X340      R886                          50
    X340      R1264                         50
    X340      R1306                         50
    X340      R1327                         50
    X340      R1390                         50
    X340      R1453                         50
    X340      R1558                         50
    X340      R1684                         50
    X340      R1747                         50
    X340      R1789                         50
    X341      R114                          -1
    X341      R480                          -1
    X341      R519                          -1
    X341      R540                          1
    X341      R887                          50
    X341      R1265                         50
    X341      R1307                         50
    X341      R1328                         50
    X341      R1391                         50
    X341      R1454                         50
    X341      R1559                         50
    X341      R1685                         50
    X341      R1748                         50
    X341      R1790                         50
    X342      R115                          -1
    X342      R469                          -1
    X342      R475                          -1
    X342      R481                          -1
    X342      R520                          -1
    X342      R541                          1
    X342      R888                          50
    X342      R1266                         50
    X342      R1308                         50
    X342      R1329                         50
    X342      R1392                         50
    X342      R1455                         50
    X342      R1560                         50
    X342      R1686                         50
    X342      R1749                         50
    X342      R1791                         50
    X343      R115                          -1
    X343      R475                          -1
    X343      R481                          -1
    X343      R520                          -1
    X343      R541                          1
    X343      R889                          50
    X343      R1267                         50
    X343      R1309                         50
    X343      R1330                         50
    X343      R1393                         50
    X343      R1456                         50
    X343      R1561                         50
    X343      R1687                         50
    X343      R1750                         50
    X343      R1792                         50
    X344      R115                          -1
    X344      R481                          -1
    X344      R520                          -1
    X344      R541                          1
    X344      R890                          50
    X344      R1268                         50
    X344      R1310                         50
    X344      R1331                         50
    X344      R1394                         50
    X344      R1457                         50
    X344      R1562                         50
    X344      R1688                         50
    X344      R1751                         50
    X344      R1793                         50
    X345      R116                          -1
    X345      R470                          -1
    X345      R476                          -1
    X345      R482                          -1
    X345      R521                          -1
    X345      R542                          1
    X345      R891                          50
    X345      R1269                         50
    X345      R1311                         50
    X345      R1332                         50
    X345      R1395                         50
    X345      R1458                         50
    X345      R1563                         50
    X345      R1689                         50
    X345      R1752                         50
    X345      R1794                         50
    X346      R116                          -1
    X346      R476                          -1
    X346      R482                          -1
    X346      R521                          -1
    X346      R542                          1
    X346      R892                          50
    X346      R1270                         50
    X346      R1312                         50
    X346      R1333                         50
    X346      R1396                         50
    X346      R1459                         50
    X346      R1564                         50
    X346      R1690                         50
    X346      R1753                         50
    X346      R1795                         50
    X347      R116                          -1
    X347      R482                          -1
    X347      R521                          -1
    X347      R542                          1
    X347      R893                          50
    X347      R1271                         50
    X347      R1313                         50
    X347      R1334                         50
    X347      R1397                         50
    X347      R1460                         50
    X347      R1565                         50
    X347      R1691                         50
    X347      R1754                         50
    X347      R1796                         50
    X348      R117                          -1
    X348      R471                          -1
    X348      R477                          -1
    X348      R483                          -1
    X348      R522                          -1
    X348      R543                          1
    X348      R894                          50
    X348      R1272                         50
    X348      R1314                         50
    X348      R1335                         50
    X348      R1398                         50
    X348      R1461                         50
    X348      R1566                         50
    X348      R1692                         50
    X348      R1755                         50
    X348      R1797                         50
    X349      R117                          -1
    X349      R477                          -1
    X349      R483                          -1
    X349      R522                          -1
    X349      R543                          1
    X349      R895                          50
    X349      R1273                         50
    X349      R1315                         50
    X349      R1336                         50
    X349      R1399                         50
    X349      R1462                         50
    X349      R1567                         50
    X349      R1693                         50
    X349      R1756                         50
    X349      R1798                         50
    X350      R117                          -1
    X350      R483                          -1
    X350      R522                          -1
    X350      R543                          1
    X350      R896                          50
    X350      R1274                         50
    X350      R1316                         50
    X350      R1337                         50
    X350      R1400                         50
    X350      R1463                         50
    X350      R1568                         50
    X350      R1694                         50
    X350      R1757                         50
    X350      R1799                         50
    X351      R118                          -1
    X351      R472                          -1
    X351      R478                          -1
    X351      R484                          -1
    X351      R523                          -1
    X351      R544                          1
    X351      R897                          50
    X351      R1275                         50
    X351      R1317                         50
    X351      R1338                         50
    X351      R1401                         50
    X351      R1464                         50
    X351      R1569                         50
    X351      R1695                         50
    X351      R1758                         50
    X351      R1800                         50
    X352      R118                          -1
    X352      R478                          -1
    X352      R484                          -1
    X352      R523                          -1
    X352      R544                          1
    X352      R898                          50
    X352      R1276                         50
    X352      R1318                         50
    X352      R1339                         50
    X352      R1402                         50
    X352      R1465                         50
    X352      R1570                         50
    X352      R1696                         50
    X352      R1759                         50
    X352      R1801                         50
    X353      R118                          -1
    X353      R484                          -1
    X353      R523                          -1
    X353      R544                          1
    X353      R899                          50
    X353      R1277                         50
    X353      R1319                         50
    X353      R1340                         50
    X353      R1403                         50
    X353      R1466                         50
    X353      R1571                         50
    X353      R1697                         50
    X353      R1760                         50
    X353      R1802                         50
    X354      R119                          -1
    X354      R473                          -1
    X354      R479                          -1
    X354      R485                          -1
    X354      R524                          -1
    X354      R545                          1
    X354      R900                          50
    X354      R1278                         50
    X354      R1320                         50
    X354      R1341                         50
    X354      R1404                         50
    X354      R1467                         50
    X354      R1572                         50
    X354      R1698                         50
    X354      R1761                         50
    X354      R1803                         50
    X355      R119                          -1
    X355      R479                          -1
    X355      R485                          -1
    X355      R524                          -1
    X355      R545                          1
    X355      R901                          50
    X355      R1279                         50
    X355      R1321                         50
    X355      R1342                         50
    X355      R1405                         50
    X355      R1468                         50
    X355      R1573                         50
    X355      R1699                         50
    X355      R1762                         50
    X355      R1804                         50
    X356      R119                          -1
    X356      R485                          -1
    X356      R524                          -1
    X356      R545                          1
    X356      R902                          50
    X356      R1280                         50
    X356      R1322                         50
    X356      R1343                         50
    X356      R1406                         50
    X356      R1469                         50
    X356      R1574                         50
    X356      R1700                         50
    X356      R1763                         50
    X356      R1805                         50
    X357      R17                           -1
    X357      R177                          -1
    X357      R178                          -1
    X357      R179                          -1
    X357      R506                          -1
    X357      R527                          1
    X357      R903                          50
    X357      R1281                         50
    X357      R1302                         50
    X357      R1323                         50
    X357      R1386                         50
    X357      R1449                         50
    X357      R1575                         50
    X357      R1701                         50
    X357      R1743                         50
    X357      R1785                         50
    X358      R17                           -1
    X358      R178                          -1
    X358      R179                          -1
    X358      R506                          -1
    X358      R527                          1
    X358      R904                          50
    X358      R1282                         50
    X358      R1303                         50
    X358      R1324                         50
    X358      R1387                         50
    X358      R1450                         50
    X358      R1576                         50
    X358      R1702                         50
    X358      R1744                         50
    X358      R1786                         50
    X359      R17                           -1
    X359      R179                          -1
    X359      R506                          -1
    X359      R527                          1
    X359      R905                          50
    X359      R1283                         50
    X359      R1304                         50
    X359      R1325                         50
    X359      R1388                         50
    X359      R1451                         50
    X359      R1577                         50
    X359      R1703                         50
    X359      R1745                         50
    X359      R1787                         50
    X360      R120                          -1
    X360      R486                          -1
    X360      R492                          -1
    X360      R498                          -1
    X360      R519                          -1
    X360      R540                          1
    X360      R906                          50
    X360      R1284                         50
    X360      R1305                         50
    X360      R1326                         50
    X360      R1389                         50
    X360      R1452                         50
    X360      R1578                         50
    X360      R1704                         50
    X360      R1746                         50
    X360      R1788                         50
    X361      R120                          -1
    X361      R492                          -1
    X361      R498                          -1
    X361      R519                          -1
    X361      R540                          1
    X361      R907                          50
    X361      R1285                         50
    X361      R1306                         50
    X361      R1327                         50
    X361      R1390                         50
    X361      R1453                         50
    X361      R1579                         50
    X361      R1705                         50
    X361      R1747                         50
    X361      R1789                         50
    X362      R120                          -1
    X362      R498                          -1
    X362      R519                          -1
    X362      R540                          1
    X362      R908                          50
    X362      R1286                         50
    X362      R1307                         50
    X362      R1328                         50
    X362      R1391                         50
    X362      R1454                         50
    X362      R1580                         50
    X362      R1706                         50
    X362      R1748                         50
    X362      R1790                         50
    X363      R121                          -1
    X363      R487                          -1
    X363      R493                          -1
    X363      R499                          -1
    X363      R520                          -1
    X363      R541                          1
    X363      R909                          50
    X363      R1287                         50
    X363      R1308                         50
    X363      R1329                         50
    X363      R1392                         50
    X363      R1455                         50
    X363      R1581                         50
    X363      R1707                         50
    X363      R1749                         50
    X363      R1791                         50
    X364      R121                          -1
    X364      R493                          -1
    X364      R499                          -1
    X364      R520                          -1
    X364      R541                          1
    X364      R910                          50
    X364      R1288                         50
    X364      R1309                         50
    X364      R1330                         50
    X364      R1393                         50
    X364      R1456                         50
    X364      R1582                         50
    X364      R1708                         50
    X364      R1750                         50
    X364      R1792                         50
    X365      R121                          -1
    X365      R499                          -1
    X365      R520                          -1
    X365      R541                          1
    X365      R911                          50
    X365      R1289                         50
    X365      R1310                         50
    X365      R1331                         50
    X365      R1394                         50
    X365      R1457                         50
    X365      R1583                         50
    X365      R1709                         50
    X365      R1751                         50
    X365      R1793                         50
    X366      R122                          -1
    X366      R488                          -1
    X366      R494                          -1
    X366      R500                          -1
    X366      R521                          -1
    X366      R542                          1
    X366      R912                          50
    X366      R1290                         50
    X366      R1311                         50
    X366      R1332                         50
    X366      R1395                         50
    X366      R1458                         50
    X366      R1584                         50
    X366      R1710                         50
    X366      R1752                         50
    X366      R1794                         50
    X367      R122                          -1
    X367      R494                          -1
    X367      R500                          -1
    X367      R521                          -1
    X367      R542                          1
    X367      R913                          50
    X367      R1291                         50
    X367      R1312                         50
    X367      R1333                         50
    X367      R1396                         50
    X367      R1459                         50
    X367      R1585                         50
    X367      R1711                         50
    X367      R1753                         50
    X367      R1795                         50
    X368      R122                          -1
    X368      R500                          -1
    X368      R521                          -1
    X368      R542                          1
    X368      R914                          50
    X368      R1292                         50
    X368      R1313                         50
    X368      R1334                         50
    X368      R1397                         50
    X368      R1460                         50
    X368      R1586                         50
    X368      R1712                         50
    X368      R1754                         50
    X368      R1796                         50
    X369      R123                          -1
    X369      R489                          -1
    X369      R495                          -1
    X369      R501                          -1
    X369      R522                          -1
    X369      R543                          1
    X369      R915                          50
    X369      R1293                         50
    X369      R1314                         50
    X369      R1335                         50
    X369      R1398                         50
    X369      R1461                         50
    X369      R1587                         50
    X369      R1713                         50
    X369      R1755                         50
    X369      R1797                         50
    X370      R123                          -1
    X370      R495                          -1
    X370      R501                          -1
    X370      R522                          -1
    X370      R543                          1
    X370      R916                          50
    X370      R1294                         50
    X370      R1315                         50
    X370      R1336                         50
    X370      R1399                         50
    X370      R1462                         50
    X370      R1588                         50
    X370      R1714                         50
    X370      R1756                         50
    X370      R1798                         50
    X371      R123                          -1
    X371      R501                          -1
    X371      R522                          -1
    X371      R543                          1
    X371      R917                          50
    X371      R1295                         50
    X371      R1316                         50
    X371      R1337                         50
    X371      R1400                         50
    X371      R1463                         50
    X371      R1589                         50
    X371      R1715                         50
    X371      R1757                         50
    X371      R1799                         50
    X372      R124                          -1
    X372      R490                          -1
    X372      R496                          -1
    X372      R502                          -1
    X372      R523                          -1
    X372      R544                          1
    X372      R918                          50
    X372      R1296                         50
    X372      R1317                         50
    X372      R1338                         50
    X372      R1401                         50
    X372      R1464                         50
    X372      R1590                         50
    X372      R1716                         50
    X372      R1758                         50
    X372      R1800                         50
    X373      R124                          -1
    X373      R496                          -1
    X373      R502                          -1
    X373      R523                          -1
    X373      R544                          1
    X373      R919                          50
    X373      R1297                         50
    X373      R1318                         50
    X373      R1339                         50
    X373      R1402                         50
    X373      R1465                         50
    X373      R1591                         50
    X373      R1717                         50
    X373      R1759                         50
    X373      R1801                         50
    X374      R124                          -1
    X374      R502                          -1
    X374      R523                          -1
    X374      R544                          1
    X374      R920                          50
    X374      R1298                         50
    X374      R1319                         50
    X374      R1340                         50
    X374      R1403                         50
    X374      R1466                         50
    X374      R1592                         50
    X374      R1718                         50
    X374      R1760                         50
    X374      R1802                         50
    X375      R125                          -1
    X375      R491                          -1
    X375      R497                          -1
    X375      R503                          -1
    X375      R524                          -1
    X375      R545                          1
    X375      R921                          50
    X375      R1299                         50
    X375      R1320                         50
    X375      R1341                         50
    X375      R1404                         50
    X375      R1467                         50
    X375      R1593                         50
    X375      R1719                         50
    X375      R1761                         50
    X375      R1803                         50
    X376      R125                          -1
    X376      R497                          -1
    X376      R503                          -1
    X376      R524                          -1
    X376      R545                          1
    X376      R922                          50
    X376      R1300                         50
    X376      R1321                         50
    X376      R1342                         50
    X376      R1405                         50
    X376      R1468                         50
    X376      R1594                         50
    X376      R1720                         50
    X376      R1762                         50
    X376      R1804                         50
    X377      R125                          -1
    X377      R503                          -1
    X377      R524                          -1
    X377      R545                          1
    X377      R923                          50
    X377      R1301                         50
    X377      R1322                         50
    X377      R1343                         50
    X377      R1406                         50
    X377      R1469                         50
    X377      R1595                         50
    X377      R1721                         50
    X377      R1763                         50
    X377      R1805                         50
    X378      R0                            -1
    X378      R18                           1
    X378      R180                          1
    X378      R186                          1
    X378      R192                          1
    X378      R1848                         350
    X379      R18                           -1
    X379      R19                           1
    X379      R181                          1
    X379      R187                          1
    X379      R193                          1
    X379      R1848                         400
    X380      R19                           -1
    X380      R20                           1
    X380      R182                          1
    X380      R188                          1
    X380      R194                          1
    X380      R1848                         500
    X381      R20                           -1
    X381      R21                           1
    X381      R183                          1
    X381      R189                          1
    X381      R195                          1
    X381      R1848                         550
    X382      R21                           -1
    X382      R22                           1
    X382      R184                          1
    X382      R190                          1
    X382      R196                          1
    X382      R1848                         600
    X383      R22                           -1
    X383      R23                           1
    X383      R185                          1
    X383      R191                          1
    X383      R197                          1
    X383      R1848                         1750
    X384      R23                           -1
    X384      R1848                         3500
    X385      R1                            -1
    X385      R24                           1
    X385      R198                          1
    X385      R204                          1
    X385      R210                          1
    X385      R1848                         420
    X386      R24                           -1
    X386      R25                           1
    X386      R199                          1
    X386      R205                          1
    X386      R211                          1
    X386      R1848                         470
    X387      R25                           -1
    X387      R26                           1
    X387      R200                          1
    X387      R206                          1
    X387      R212                          1
    X387      R1848                         520
    X388      R26                           -1
    X388      R27                           1
    X388      R201                          1
    X388      R207                          1
    X388      R213                          1
    X388      R1848                         570
    X389      R27                           -1
    X389      R28                           1
    X389      R202                          1
    X389      R208                          1
    X389      R214                          1
    X389      R1848                         620
    X390      R28                           -1
    X390      R29                           1
    X390      R203                          1
    X390      R209                          1
    X390      R215                          1
    X390      R1848                         2100
    X391      R29                           -1
    X391      R1848                         4200
    X392      R2                            -1
    X392      R30                           1
    X392      R216                          1
    X392      R222                          1
    X392      R228                          1
    X392      R1848                         350
    X393      R30                           -1
    X393      R31                           1
    X393      R217                          1
    X393      R223                          1
    X393      R229                          1
    X393      R1848                         400
    X394      R31                           -1
    X394      R32                           1
    X394      R218                          1
    X394      R224                          1
    X394      R230                          1
    X394      R1848                         450
    X395      R32                           -1
    X395      R33                           1
    X395      R219                          1
    X395      R225                          1
    X395      R231                          1
    X395      R1848                         500
    X396      R33                           -1
    X396      R34                           1
    X396      R220                          1
    X396      R226                          1
    X396      R232                          1
    X396      R1848                         550
    X397      R34                           -1
    X397      R35                           1
    X397      R221                          1
    X397      R227                          1
    X397      R233                          1
    X397      R1848                         1750
    X398      R35                           -1
    X398      R1848                         3500
    X399      R3                            -1
    X399      R36                           1
    X399      R234                          1
    X399      R240                          1
    X399      R246                          1
    X399      R1848                         460
    X400      R36                           -1
    X400      R37                           1
    X400      R235                          1
    X400      R241                          1
    X400      R247                          1
    X400      R1848                         460
    X401      R37                           -1
    X401      R38                           1
    X401      R236                          1
    X401      R242                          1
    X401      R248                          1
    X401      R1848                         460
    X402      R38                           -1
    X402      R39                           1
    X402      R237                          1
    X402      R243                          1
    X402      R249                          1
    X402      R1848                         460
    X403      R39                           -1
    X403      R40                           1
    X403      R238                          1
    X403      R244                          1
    X403      R250                          1
    X403      R1848                         460
    X404      R40                           -1
    X404      R41                           1
    X404      R239                          1
    X404      R245                          1
    X404      R251                          1
    X404      R1848                         3400
    X405      R41                           -1
    X405      R1848                         6800
    X406      R4                            -1
    X406      R42                           1
    X406      R252                          1
    X406      R258                          1
    X406      R264                          1
    X406      R1848                         420
    X407      R42                           -1
    X407      R43                           1
    X407      R253                          1
    X407      R259                          1
    X407      R265                          1
    X407      R1848                         420
    X408      R43                           -1
    X408      R44                           1
    X408      R254                          1
    X408      R260                          1
    X408      R266                          1
    X408      R1848                         420
    X409      R44                           -1
    X409      R45                           1
    X409      R255                          1
    X409      R261                          1
    X409      R267                          1
    X409      R1848                         420
    X410      R45                           -1
    X410      R46                           1
    X410      R256                          1
    X410      R262                          1
    X410      R268                          1
    X410      R1848                         420
    X411      R46                           -1
    X411      R47                           1
    X411      R257                          1
    X411      R263                          1
    X411      R269                          1
    X411      R1848                         630
    X412      R47                           -1
    X412      R1848                         420
    X413      R5                            -1
    X413      R48                           1
    X413      R270                          1
    X413      R276                          1
    X413      R282                          1
    X413      R1848                         350
    X414      R48                           -1
    X414      R49                           1
    X414      R271                          1
    X414      R277                          1
    X414      R283                          1
    X414      R1848                         350
    X415      R49                           -1
    X415      R50                           1
    X415      R272                          1
    X415      R278                          1
    X415      R284                          1
    X415      R1848                         350
    X416      R50                           -1
    X416      R51                           1
    X416      R273                          1
    X416      R279                          1
    X416      R285                          1
    X416      R1848                         350
    X417      R51                           -1
    X417      R52                           1
    X417      R274                          1
    X417      R280                          1
    X417      R286                          1
    X417      R1848                         350
    X418      R52                           -1
    X418      R53                           1
    X418      R275                          1
    X418      R281                          1
    X418      R287                          1
    X418      R1848                         530
    X419      R53                           -1
    X419      R1848                         350
    X420      R6                            -1
    X420      R54                           1
    X420      R288                          1
    X420      R294                          1
    X420      R300                          1
    X420      R1848                         200
    X421      R54                           -1
    X421      R55                           1
    X421      R289                          1
    X421      R295                          1
    X421      R301                          1
    X421      R1848                         250
    X422      R55                           -1
    X422      R56                           1
    X422      R290                          1
    X422      R296                          1
    X422      R302                          1
    X422      R1848                         300
    X423      R56                           -1
    X423      R57                           1
    X423      R291                          1
    X423      R297                          1
    X423      R303                          1
    X423      R1848                         350
    X424      R57                           -1
    X424      R58                           1
    X424      R292                          1
    X424      R298                          1
    X424      R304                          1
    X424      R1848                         400
    X425      R58                           -1
    X425      R59                           1
    X425      R293                          1
    X425      R299                          1
    X425      R305                          1
    X425      R1848                         1000
    X426      R59                           -1
    X426      R1848                         2000
    X427      R7                            -1
    X427      R60                           1
    X427      R306                          1
    X427      R312                          1
    X427      R318                          1
    X427      R1848                         200
    X428      R60                           -1
    X428      R61                           1
    X428      R307                          1
    X428      R313                          1
    X428      R319                          1
    X428      R1848                         250
    X429      R61                           -1
    X429      R62                           1
    X429      R308                          1
    X429      R314                          1
    X429      R320                          1
    X429      R1848                         300
    X430      R62                           -1
    X430      R63                           1
    X430      R309                          1
    X430      R315                          1
    X430      R321                          1
    X430      R1848                         350
    X431      R63                           -1
    X431      R64                           1
    X431      R310                          1
    X431      R316                          1
    X431      R322                          1
    X431      R1848                         400
    X432      R64                           -1
    X432      R65                           1
    X432      R311                          1
    X432      R317                          1
    X432      R323                          1
    X432      R1848                         1000
    X433      R65                           -1
    X433      R1848                         2000
    X434      R8                            -1
    X434      R66                           1
    X434      R324                          1
    X434      R330                          1
    X434      R336                          1
    X434      R1848                         200
    X435      R66                           -1
    X435      R67                           1
    X435      R325                          1
    X435      R331                          1
    X435      R337                          1
    X435      R1848                         250
    X436      R67                           -1
    X436      R68                           1
    X436      R326                          1
    X436      R332                          1
    X436      R338                          1
    X436      R1848                         300
    X437      R68                           -1
    X437      R69                           1
    X437      R327                          1
    X437      R333                          1
    X437      R339                          1
    X437      R1848                         350
    X438      R69                           -1
    X438      R70                           1
    X438      R328                          1
    X438      R334                          1
    X438      R340                          1
    X438      R1848                         400
    X439      R70                           -1
    X439      R71                           1
    X439      R329                          1
    X439      R335                          1
    X439      R341                          1
    X439      R1848                         1000
    X440      R71                           -1
    X440      R1848                         2000
    X441      R9                            -1
    X441      R72                           1
    X441      R342                          1
    X441      R348                          1
    X441      R354                          1
    X441      R1848                         200
    X442      R72                           -1
    X442      R73                           1
    X442      R343                          1
    X442      R349                          1
    X442      R355                          1
    X442      R1848                         250
    X443      R73                           -1
    X443      R74                           1
    X443      R344                          1
    X443      R350                          1
    X443      R356                          1
    X443      R1848                         300
    X444      R74                           -1
    X444      R75                           1
    X444      R345                          1
    X444      R351                          1
    X444      R357                          1
    X444      R1848                         350
    X445      R75                           -1
    X445      R76                           1
    X445      R346                          1
    X445      R352                          1
    X445      R358                          1
    X445      R1848                         400
    X446      R76                           -1
    X446      R77                           1
    X446      R347                          1
    X446      R353                          1
    X446      R359                          1
    X446      R1848                         450
    X447      R77                           -1
    X447      R1848                         2000
    X448      R10                           -1
    X448      R78                           1
    X448      R360                          1
    X448      R366                          1
    X448      R372                          1
    X448      R1848                         200
    X449      R78                           -1
    X449      R79                           1
    X449      R361                          1
    X449      R367                          1
    X449      R373                          1
    X449      R1848                         250
    X450      R79                           -1
    X450      R80                           1
    X450      R362                          1
    X450      R368                          1
    X450      R374                          1
    X450      R1848                         300
    X451      R80                           -1
    X451      R81                           1
    X451      R363                          1
    X451      R369                          1
    X451      R375                          1
    X451      R1848                         350
    X452      R81                           -1
    X452      R82                           1
    X452      R364                          1
    X452      R370                          1
    X452      R376                          1
    X452      R1848                         400
    X453      R82                           -1
    X453      R83                           1
    X453      R365                          1
    X453      R371                          1
    X453      R377                          1
    X453      R1848                         1000
    X454      R83                           -1
    X454      R1848                         2000
    X455      R11                           -1
    X455      R84                           1
    X455      R378                          1
    X455      R384                          1
    X455      R390                          1
    X455      R1848                         200
    X456      R84                           -1
    X456      R85                           1
    X456      R379                          1
    X456      R385                          1
    X456      R391                          1
    X456      R1848                         250
    X457      R85                           -1
    X457      R86                           1
    X457      R380                          1
    X457      R386                          1
    X457      R392                          1
    X457      R1848                         300
    X458      R86                           -1
    X458      R87                           1
    X458      R381                          1
    X458      R387                          1
    X458      R393                          1
    X458      R1848                         350
    X459      R87                           -1
    X459      R88                           1
    X459      R382                          1
    X459      R388                          1
    X459      R394                          1
    X459      R1848                         400
    X460      R88                           -1
    X460      R89                           1
    X460      R383                          1
    X460      R389                          1
    X460      R395                          1
    X460      R1848                         1000
    X461      R89                           -1
    X461      R1848                         2000
    X462      R12                           -1
    X462      R90                           1
    X462      R396                          1
    X462      R402                          1
    X462      R408                          1
    X462      R1848                         180
    X463      R90                           -1
    X463      R91                           1
    X463      R397                          1
    X463      R403                          1
    X463      R409                          1
    X463      R1848                         230
    X464      R91                           -1
    X464      R92                           1
    X464      R398                          1
    X464      R404                          1
    X464      R410                          1
    X464      R1848                         280
    X465      R92                           -1
    X465      R93                           1
    X465      R399                          1
    X465      R405                          1
    X465      R411                          1
    X465      R1848                         330
    X466      R93                           -1
    X466      R94                           1
    X466      R400                          1
    X466      R406                          1
    X466      R412                          1
    X466      R1848                         380
    X467      R94                           -1
    X467      R95                           1
    X467      R401                          1
    X467      R407                          1
    X467      R413                          1
    X467      R1848                         900
    X468      R95                           -1
    X468      R1848                         1800
    X469      R13                           -1
    X469      R96                           1
    X469      R414                          1
    X469      R420                          1
    X469      R426                          1
    X469      R1848                         210
    X470      R96                           -1
    X470      R97                           1
    X470      R415                          1
    X470      R421                          1
    X470      R427                          1
    X470      R1848                         260
    X471      R97                           -1
    X471      R98                           1
    X471      R416                          1
    X471      R422                          1
    X471      R428                          1
    X471      R1848                         310
    X472      R98                           -1
    X472      R99                           1
    X472      R417                          1
    X472      R423                          1
    X472      R429                          1
    X472      R1848                         360
    X473      R99                           -1
    X473      R100                          1
    X473      R418                          1
    X473      R424                          1
    X473      R430                          1
    X473      R1848                         410
    X474      R100                          -1
    X474      R101                          1
    X474      R419                          1
    X474      R425                          1
    X474      R431                          1
    X474      R1848                         1050
    X475      R101                          -1
    X475      R1848                         2100
    X476      R14                           -1
    X476      R102                          1
    X476      R432                          1
    X476      R438                          1
    X476      R444                          1
    X476      R1848                         180
    X477      R102                          -1
    X477      R103                          1
    X477      R433                          1
    X477      R439                          1
    X477      R445                          1
    X477      R1848                         180
    X478      R103                          -1
    X478      R104                          1
    X478      R434                          1
    X478      R440                          1
    X478      R446                          1
    X478      R1848                         180
    X479      R104                          -1
    X479      R105                          1
    X479      R435                          1
    X479      R441                          1
    X479      R447                          1
    X479      R1848                         180
    X480      R105                          -1
    X480      R106                          1
    X480      R436                          1
    X480      R442                          1
    X480      R448                          1
    X480      R1848                         180
    X481      R106                          -1
    X481      R107                          1
    X481      R437                          1
    X481      R443                          1
    X481      R449                          1
    X481      R1848                         260
    X482      R107                          -1
    X482      R1848                         180
    X483      R15                           -1
    X483      R108                          1
    X483      R450                          1
    X483      R456                          1
    X483      R462                          1
    X483      R1848                         230
    X484      R108                          -1
    X484      R109                          1
    X484      R451                          1
    X484      R457                          1
    X484      R463                          1
    X484      R1848                         280
    X485      R109                          -1
    X485      R110                          1
    X485      R452                          1
    X485      R458                          1
    X485      R464                          1
    X485      R1848                         330
    X486      R110                          -1
    X486      R111                          1
    X486      R453                          1
    X486      R459                          1
    X486      R465                          1
    X486      R1848                         250
    X487      R111                          -1
    X487      R112                          1
    X487      R454                          1
    X487      R460                          1
    X487      R466                          1
    X487      R1848                         380
    X488      R112                          -1
    X488      R113                          1
    X488      R455                          1
    X488      R461                          1
    X488      R467                          1
    X488      R1848                         1150
    X489      R113                          -1
    X489      R1848                         2300
    X490      R16                           -1
    X490      R114                          1
    X490      R468                          1
    X490      R474                          1
    X490      R480                          1
    X490      R1848                         210
    X491      R114                          -1
    X491      R115                          1
    X491      R469                          1
    X491      R475                          1
    X491      R481                          1
    X491      R1848                         260
    X492      R115                          -1
    X492      R116                          1
    X492      R470                          1
    X492      R476                          1
    X492      R482                          1
    X492      R1848                         310
    X493      R116                          -1
    X493      R117                          1
    X493      R471                          1
    X493      R477                          1
    X493      R483                          1
    X493      R1848                         260
    X494      R117                          -1
    X494      R118                          1
    X494      R472                          1
    X494      R478                          1
    X494      R484                          1
    X494      R1848                         310
    X495      R118                          -1
    X495      R119                          1
    X495      R473                          1
    X495      R479                          1
    X495      R485                          1
    X495      R1848                         105
    X496      R119                          -1
    X496      R1848                         210
    X497      R17                           -1
    X497      R120                          1
    X497      R486                          1
    X497      R492                          1
    X497      R498                          1
    X497      R1848                         180
    X498      R120                          -1
    X498      R121                          1
    X498      R487                          1
    X498      R493                          1
    X498      R499                          1
    X498      R1848                         230
    X499      R121                          -1
    X499      R122                          1
    X499      R488                          1
    X499      R494                          1
    X499      R500                          1
    X499      R1848                         280
    X500      R122                          -1
    X500      R123                          1
    X500      R489                          1
    X500      R495                          1
    X500      R501                          1
    X500      R1848                         330
    X501      R123                          -1
    X501      R124                          1
    X501      R490                          1
    X501      R496                          1
    X501      R502                          1
    X501      R1848                         380
    X502      R124                          -1
    X502      R125                          1
    X502      R491                          1
    X502      R497                          1
    X502      R503                          1
    X502      R1848                         900
    X503      R125                          -1
    X503      R1848                         1800
    X504      R126                          -1
    X505      R127                          -1
    X506      R128                          -1
    X507      R180                          -1
    X508      R186                          -1
    X509      R192                          -1
    X510      R181                          -1
    X511      R187                          -1
    X512      R193                          -1
    X513      R182                          -1
    X514      R188                          -1
    X515      R194                          -1
    X516      R183                          -1
    X517      R189                          -1
    X518      R195                          -1
    X519      R184                          -1
    X520      R190                          -1
    X521      R196                          -1
    X522      R185                          -1
    X523      R191                          -1
    X524      R197                          -1
    X525      R129                          -1
    X526      R130                          -1
    X527      R131                          -1
    X528      R198                          -1
    X529      R204                          -1
    X530      R210                          -1
    X531      R199                          -1
    X532      R205                          -1
    X533      R211                          -1
    X534      R200                          -1
    X535      R206                          -1
    X536      R212                          -1
    X537      R201                          -1
    X538      R207                          -1
    X539      R213                          -1
    X540      R202                          -1
    X541      R208                          -1
    X542      R214                          -1
    X543      R203                          -1
    X544      R209                          -1
    X545      R215                          -1
    X546      R132                          -1
    X547      R133                          -1
    X548      R134                          -1
    X549      R216                          -1
    X550      R222                          -1
    X551      R228                          -1
    X552      R217                          -1
    X553      R223                          -1
    X554      R229                          -1
    X555      R218                          -1
    X556      R224                          -1
    X557      R230                          -1
    X558      R219                          -1
    X559      R225                          -1
    X560      R231                          -1
    X561      R220                          -1
    X562      R226                          -1
    X563      R232                          -1
    X564      R221                          -1
    X565      R227                          -1
    X566      R233                          -1
    X567      R135                          -1
    X568      R136                          -1
    X569      R137                          -1
    X570      R234                          -1
    X571      R240                          -1
    X572      R246                          -1
    X573      R235                          -1
    X574      R241                          -1
    X575      R247                          -1
    X576      R236                          -1
    X577      R242                          -1
    X578      R248                          -1
    X579      R237                          -1
    X580      R243                          -1
    X581      R249                          -1
    X582      R238                          -1
    X583      R244                          -1
    X584      R250                          -1
    X585      R239                          -1
    X586      R245                          -1
    X587      R251                          -1
    X588      R138                          -1
    X589      R139                          -1
    X590      R140                          -1
    X591      R252                          -1
    X592      R258                          -1
    X593      R264                          -1
    X594      R253                          -1
    X595      R259                          -1
    X596      R265                          -1
    X597      R254                          -1
    X598      R260                          -1
    X599      R266                          -1
    X600      R255                          -1
    X601      R261                          -1
    X602      R267                          -1
    X603      R256                          -1
    X604      R262                          -1
    X605      R268                          -1
    X606      R257                          -1
    X607      R263                          -1
    X608      R269                          -1
    X609      R141                          -1
    X610      R142                          -1
    X611      R143                          -1
    X612      R270                          -1
    X613      R276                          -1
    X614      R282                          -1
    X615      R271                          -1
    X616      R277                          -1
    X617      R283                          -1
    X618      R272                          -1
    X619      R278                          -1
    X620      R284                          -1
    X621      R273                          -1
    X622      R279                          -1
    X623      R285                          -1
    X624      R274                          -1
    X625      R280                          -1
    X626      R286                          -1
    X627      R275                          -1
    X628      R281                          -1
    X629      R287                          -1
    X630      R144                          -1
    X631      R145                          -1
    X632      R146                          -1
    X633      R288                          -1
    X634      R294                          -1
    X635      R300                          -1
    X636      R289                          -1
    X637      R295                          -1
    X638      R301                          -1
    X639      R290                          -1
    X640      R296                          -1
    X641      R302                          -1
    X642      R291                          -1
    X643      R297                          -1
    X644      R303                          -1
    X645      R292                          -1
    X646      R298                          -1
    X647      R304                          -1
    X648      R293                          -1
    X649      R299                          -1
    X650      R305                          -1
    X651      R147                          -1
    X652      R148                          -1
    X653      R149                          -1
    X654      R306                          -1
    X655      R312                          -1
    X656      R318                          -1
    X657      R307                          -1
    X658      R313                          -1
    X659      R319                          -1
    X660      R308                          -1
    X661      R314                          -1
    X662      R320                          -1
    X663      R309                          -1
    X664      R315                          -1
    X665      R321                          -1
    X666      R310                          -1
    X667      R316                          -1
    X668      R322                          -1
    X669      R311                          -1
    X670      R317                          -1
    X671      R323                          -1
    X672      R150                          -1
    X673      R151                          -1
    X674      R152                          -1
    X675      R324                          -1
    X676      R330                          -1
    X677      R336                          -1
    X678      R325                          -1
    X679      R331                          -1
    X680      R337                          -1
    X681      R326                          -1
    X682      R332                          -1
    X683      R338                          -1
    X684      R327                          -1
    X685      R333                          -1
    X686      R339                          -1
    X687      R328                          -1
    X688      R334                          -1
    X689      R340                          -1
    X690      R329                          -1
    X691      R335                          -1
    X692      R341                          -1
    X693      R153                          -1
    X694      R154                          -1
    X695      R155                          -1
    X696      R342                          -1
    X697      R348                          -1
    X698      R354                          -1
    X699      R343                          -1
    X700      R349                          -1
    X701      R355                          -1
    X702      R344                          -1
    X703      R350                          -1
    X704      R356                          -1
    X705      R345                          -1
    X706      R351                          -1
    X707      R357                          -1
    X708      R346                          -1
    X709      R352                          -1
    X710      R358                          -1
    X711      R347                          -1
    X712      R353                          -1
    X713      R359                          -1
    X714      R156                          -1
    X715      R157                          -1
    X716      R158                          -1
    X717      R360                          -1
    X718      R366                          -1
    X719      R372                          -1
    X720      R361                          -1
    X721      R367                          -1
    X722      R373                          -1
    X723      R362                          -1
    X724      R368                          -1
    X725      R374                          -1
    X726      R363                          -1
    X727      R369                          -1
    X728      R375                          -1
    X729      R364                          -1
    X730      R370                          -1
    X731      R376                          -1
    X732      R365                          -1
    X733      R371                          -1
    X734      R377                          -1
    X735      R159                          -1
    X736      R160                          -1
    X737      R161                          -1
    X738      R378                          -1
    X739      R384                          -1
    X740      R390                          -1
    X741      R379                          -1
    X742      R385                          -1
    X743      R391                          -1
    X744      R380                          -1
    X745      R386                          -1
    X746      R392                          -1
    X747      R381                          -1
    X748      R387                          -1
    X749      R393                          -1
    X750      R382                          -1
    X751      R388                          -1
    X752      R394                          -1
    X753      R383                          -1
    X754      R389                          -1
    X755      R395                          -1
    X756      R162                          -1
    X757      R163                          -1
    X758      R164                          -1
    X759      R396                          -1
    X760      R402                          -1
    X761      R408                          -1
    X762      R397                          -1
    X763      R403                          -1
    X764      R409                          -1
    X765      R398                          -1
    X766      R404                          -1
    X767      R410                          -1
    X768      R399                          -1
    X769      R405                          -1
    X770      R411                          -1
    X771      R400                          -1
    X772      R406                          -1
    X773      R412                          -1
    X774      R401                          -1
    X775      R407                          -1
    X776      R413                          -1
    X777      R165                          -1
    X778      R166                          -1
    X779      R167                          -1
    X780      R414                          -1
    X781      R420                          -1
    X782      R426                          -1
    X783      R415                          -1
    X784      R421                          -1
    X785      R427                          -1
    X786      R416                          -1
    X787      R422                          -1
    X788      R428                          -1
    X789      R417                          -1
    X790      R423                          -1
    X791      R429                          -1
    X792      R418                          -1
    X793      R424                          -1
    X794      R430                          -1
    X795      R419                          -1
    X796      R425                          -1
    X797      R431                          -1
    X798      R168                          -1
    X799      R169                          -1
    X800      R170                          -1
    X801      R432                          -1
    X802      R438                          -1
    X803      R444                          -1
    X804      R433                          -1
    X805      R439                          -1
    X806      R445                          -1
    X807      R434                          -1
    X808      R440                          -1
    X809      R446                          -1
    X810      R435                          -1
    X811      R441                          -1
    X812      R447                          -1
    X813      R436                          -1
    X814      R442                          -1
    X815      R448                          -1
    X816      R437                          -1
    X817      R443                          -1
    X818      R449                          -1
    X819      R171                          -1
    X820      R172                          -1
    X821      R173                          -1
    X822      R450                          -1
    X823      R456                          -1
    X824      R462                          -1
    X825      R451                          -1
    X826      R457                          -1
    X827      R463                          -1
    X828      R452                          -1
    X829      R458                          -1
    X830      R464                          -1
    X831      R453                          -1
    X832      R459                          -1
    X833      R465                          -1
    X834      R454                          -1
    X835      R460                          -1
    X836      R466                          -1
    X837      R455                          -1
    X838      R461                          -1
    X839      R467                          -1
    X840      R174                          -1
    X841      R175                          -1
    X842      R176                          -1
    X843      R468                          -1
    X844      R474                          -1
    X845      R480                          -1
    X846      R469                          -1
    X847      R475                          -1
    X848      R481                          -1
    X849      R470                          -1
    X850      R476                          -1
    X851      R482                          -1
    X852      R471                          -1
    X853      R477                          -1
    X854      R483                          -1
    X855      R472                          -1
    X856      R478                          -1
    X857      R484                          -1
    X858      R473                          -1
    X859      R479                          -1
    X860      R485                          -1
    X861      R177                          -1
    X862      R178                          -1
    X863      R179                          -1
    X864      R486                          -1
    X865      R492                          -1
    X866      R498                          -1
    X867      R487                          -1
    X868      R493                          -1
    X869      R499                          -1
    X870      R488                          -1
    X871      R494                          -1
    X872      R500                          -1
    X873      R489                          -1
    X874      R495                          -1
    X875      R501                          -1
    X876      R490                          -1
    X877      R496                          -1
    X878      R502                          -1
    X879      R491                          -1
    X880      R497                          -1
    X881      R503                          -1
    X882      R504                          -1
    X882      R507                          1
    X882      R528                          -1
    X883      R507                          -1
    X883      R508                          1
    X883      R529                          -1
    X884      R508                          -1
    X884      R509                          1
    X884      R530                          -1
    X885      R509                          -1
    X885      R510                          1
    X885      R531                          -1
    X886      R510                          -1
    X886      R511                          1
    X886      R532                          -1
    X887      R511                          -1
    X887      R512                          1
    X887      R533                          -1
    X888      R512                          -1
    X889      R505                          -1
    X889      R513                          1
    X889      R534                          -1
    X890      R513                          -1
    X890      R514                          1
    X890      R535                          -1
    X891      R514                          -1
    X891      R515                          1
    X891      R536                          -1
    X892      R515                          -1
    X892      R516                          1
    X892      R537                          -1
    X893      R516                          -1
    X893      R517                          1
    X893      R538                          -1
    X894      R517                          -1
    X894      R518                          1
    X894      R539                          -1
    X895      R518                          -1
    X896      R506                          -1
    X896      R519                          1
    X896      R540                          -1
    X897      R519                          -1
    X897      R520                          1
    X897      R541                          -1
    X898      R520                          -1
    X898      R521                          1
    X898      R542                          -1
    X899      R521                          -1
    X899      R522                          1
    X899      R543                          -1
    X900      R522                          -1
    X900      R523                          1
    X900      R544                          -1
    X901      R523                          -1
    X901      R524                          1
    X901      R545                          -1
    X902      R524                          -1
    X903      R546                          -17000
    X903      R924                          -17000
    X904      R547                          -8500
    X904      R925                          -8500
    X905      R548                          -17000
    X905      R926                          -17000
    X906      R549                          -17000
    X906      R927                          -17000
    X907      R550                          -8500
    X907      R928                          -8500
    X908      R551                          -17000
    X908      R929                          -17000
    X909      R552                          -17000
    X909      R930                          -17000
    X910      R553                          -8500
    X910      R931                          -8500
    X911      R554                          -17000
    X911      R932                          -17000
    X912      R555                          -17000
    X912      R933                          -17000
    X913      R556                          -8500
    X913      R934                          -8500
    X914      R557                          -17000
    X914      R935                          -17000
    X915      R558                          -17000
    X915      R936                          -17000
    X916      R559                          -8500
    X916      R937                          -8500
    X917      R560                          -17000
    X917      R938                          -17000
    X918      R561                          -17000
    X918      R939                          -17000
    X919      R562                          -8500
    X919      R940                          -8500
    X920      R563                          -17000
    X920      R941                          -17000
    X921      R564                          -17000
    X921      R942                          -17000
    X922      R565                          -8500
    X922      R943                          -8500
    X923      R566                          -17000
    X923      R944                          -17000
    X924      R567                          -17000
    X924      R945                          -17000
    X925      R568                          -8500
    X925      R946                          -8500
    X926      R569                          -17000
    X926      R947                          -17000
    X927      R570                          -17000
    X927      R948                          -17000
    X928      R571                          -8500
    X928      R949                          -8500
    X929      R572                          -17000
    X929      R950                          -17000
    X930      R573                          -17000
    X930      R951                          -17000
    X931      R574                          -8500
    X931      R952                          -8500
    X932      R575                          -17000
    X932      R953                          -17000
    X933      R576                          -17000
    X933      R954                          -17000
    X934      R577                          -8500
    X934      R955                          -8500
    X935      R578                          -17000
    X935      R956                          -17000
    X936      R579                          -17000
    X936      R957                          -17000
    X937      R580                          -8500
    X937      R958                          -8500
    X938      R581                          -17000
    X938      R959                          -17000
    X939      R582                          -17000
    X939      R960                          -17000
    X940      R583                          -8500
    X940      R961                          -8500
    X941      R584                          -17000
    X941      R962                          -17000
    X942      R585                          -17000
    X942      R963                          -17000
    X943      R586                          -8500
    X943      R964                          -8500
    X944      R587                          -17000
    X944      R965                          -17000
    X945      R588                          -17000
    X945      R966                          -17000
    X946      R589                          -8500
    X946      R967                          -8500
    X947      R590                          -17000
    X947      R968                          -17000
    X948      R591                          -17000
    X948      R969                          -17000
    X949      R592                          -8500
    X949      R970                          -8500
    X950      R593                          -17000
    X950      R971                          -17000
    X951      R594                          -17000
    X951      R972                          -17000
    X952      R595                          -8500
    X952      R973                          -8500
    X953      R596                          -17000
    X953      R974                          -17000
    X954      R597                          -17000
    X954      R975                          -17000
    X955      R598                          -8500
    X955      R976                          -8500
    X956      R599                          -17000
    X956      R977                          -17000
    X957      R600                          -17000
    X957      R978                          -17000
    X958      R601                          -8500
    X958      R979                          -8500
    X959      R602                          -17000
    X959      R980                          -17000
    X960      R603                          -17000
    X960      R981                          -17000
    X961      R604                          -8500
    X961      R982                          -8500
    X962      R605                          -17000
    X962      R983                          -17000
    X963      R606                          -17000
    X963      R984                          -17000
    X964      R607                          -8500
    X964      R985                          -8500
    X965      R608                          -17000
    X965      R986                          -17000
    X966      R609                          -17000
    X966      R987                          -17000
    X967      R610                          -8500
    X967      R988                          -8500
    X968      R611                          -17000
    X968      R989                          -17000
    X969      R612                          -17000
    X969      R990                          -17000
    X970      R613                          -8500
    X970      R991                          -8500
    X971      R614                          -17000
    X971      R992                          -17000
    X972      R615                          -17000
    X972      R993                          -17000
    X973      R616                          -8500
    X973      R994                          -8500
    X974      R617                          -17000
    X974      R995                          -17000
    X975      R618                          -17000
    X975      R996                          -17000
    X976      R619                          -8500
    X976      R997                          -8500
    X977      R620                          -17000
    X977      R998                          -17000
    X978      R621                          -17000
    X978      R999                          -17000
    X979      R622                          -8500
    X979      R1000                         -8500
    X980      R623                          -17000
    X980      R1001                         -17000
    X981      R624                          -17000
    X981      R1002                         -17000
    X982      R625                          -8500
    X982      R1003                         -8500
    X983      R626                          -17000
    X983      R1004                         -17000
    X984      R627                          -17000
    X984      R1005                         -17000
    X985      R628                          -8500
    X985      R1006                         -8500
    X986      R629                          -17000
    X986      R1007                         -17000
    X987      R630                          -17000
    X987      R1008                         -17000
    X988      R631                          -8500
    X988      R1009                         -8500
    X989      R632                          -17000
    X989      R1010                         -17000
    X990      R633                          -17000
    X990      R1011                         -17000
    X991      R634                          -8500
    X991      R1012                         -8500
    X992      R635                          -17000
    X992      R1013                         -17000
    X993      R636                          -17000
    X993      R1014                         -17000
    X994      R637                          -8500
    X994      R1015                         -8500
    X995      R638                          -17000
    X995      R1016                         -17000
    X996      R639                          -17000
    X996      R1017                         -17000
    X997      R640                          -8500
    X997      R1018                         -8500
    X998      R641                          -17000
    X998      R1019                         -17000
    X999      R642                          -17000
    X999      R1020                         -17000
    X1000     R643                          -8500
    X1000     R1021                         -8500
    X1001     R644                          -17000
    X1001     R1022                         -17000
    X1002     R645                          -17000
    X1002     R1023                         -17000
    X1003     R646                          -8500
    X1003     R1024                         -8500
    X1004     R647                          -17000
    X1004     R1025                         -17000
    X1005     R648                          -17000
    X1005     R1026                         -17000
    X1006     R649                          -8500
    X1006     R1027                         -8500
    X1007     R650                          -17000
    X1007     R1028                         -17000
    X1008     R651                          -17000
    X1008     R1029                         -17000
    X1009     R652                          -8500
    X1009     R1030                         -8500
    X1010     R653                          -17000
    X1010     R1031                         -17000
    X1011     R654                          -17000
    X1011     R1032                         -17000
    X1012     R655                          -8500
    X1012     R1033                         -8500
    X1013     R656                          -17000
    X1013     R1034                         -17000
    X1014     R657                          -17000
    X1014     R1035                         -17000
    X1015     R658                          -8500
    X1015     R1036                         -8500
    X1016     R659                          -17000
    X1016     R1037                         -17000
    X1017     R660                          -17000
    X1017     R1038                         -17000
    X1018     R661                          -8500
    X1018     R1039                         -8500
    X1019     R662                          -17000
    X1019     R1040                         -17000
    X1020     R663                          -17000
    X1020     R1041                         -17000
    X1021     R664                          -8500
    X1021     R1042                         -8500
    X1022     R665                          -17000
    X1022     R1043                         -17000
    X1023     R666                          -17000
    X1023     R1044                         -17000
    X1024     R667                          -8500
    X1024     R1045                         -8500
    X1025     R668                          -17000
    X1025     R1046                         -17000
    X1026     R669                          -17000
    X1026     R1047                         -17000
    X1027     R670                          -8500
    X1027     R1048                         -8500
    X1028     R671                          -17000
    X1028     R1049                         -17000
    X1029     R672                          -17000
    X1029     R1050                         -17000
    X1030     R673                          -8500
    X1030     R1051                         -8500
    X1031     R674                          -17000
    X1031     R1052                         -17000
    X1032     R675                          -17000
    X1032     R1053                         -17000
    X1033     R676                          -8500
    X1033     R1054                         -8500
    X1034     R677                          -17000
    X1034     R1055                         -17000
    X1035     R678                          -17000
    X1035     R1056                         -17000
    X1036     R679                          -8500
    X1036     R1057                         -8500
    X1037     R680                          -17000
    X1037     R1058                         -17000
    X1038     R681                          -17000
    X1038     R1059                         -17000
    X1039     R682                          -8500
    X1039     R1060                         -8500
    X1040     R683                          -17000
    X1040     R1061                         -17000
    X1041     R684                          -17000
    X1041     R1062                         -17000
    X1042     R685                          -8500
    X1042     R1063                         -8500
    X1043     R686                          -17000
    X1043     R1064                         -17000
    X1044     R687                          -17000
    X1044     R1065                         -17000
    X1045     R688                          -8500
    X1045     R1066                         -8500
    X1046     R689                          -17000
    X1046     R1067                         -17000
    X1047     R690                          -17000
    X1047     R1068                         -17000
    X1048     R691                          -8500
    X1048     R1069                         -8500
    X1049     R692                          -17000
    X1049     R1070                         -17000
    X1050     R693                          -17000
    X1050     R1071                         -17000
    X1051     R694                          -8500
    X1051     R1072                         -8500
    X1052     R695                          -17000
    X1052     R1073                         -17000
    X1053     R696                          -17000
    X1053     R1074                         -17000
    X1054     R697                          -8500
    X1054     R1075                         -8500
    X1055     R698                          -17000
    X1055     R1076                         -17000
    X1056     R699                          -17000
    X1056     R1077                         -17000
    X1057     R700                          -8500
    X1057     R1078                         -8500
    X1058     R701                          -17000
    X1058     R1079                         -17000
    X1059     R702                          -17000
    X1059     R1080                         -17000
    X1060     R703                          -8500
    X1060     R1081                         -8500
    X1061     R704                          -17000
    X1061     R1082                         -17000
    X1062     R705                          -17000
    X1062     R1083                         -17000
    X1063     R706                          -8500
    X1063     R1084                         -8500
    X1064     R707                          -17000
    X1064     R1085                         -17000
    X1065     R708                          -17000
    X1065     R1086                         -17000
    X1066     R709                          -8500
    X1066     R1087                         -8500
    X1067     R710                          -17000
    X1067     R1088                         -17000
    X1068     R711                          -17000
    X1068     R1089                         -17000
    X1069     R712                          -8500
    X1069     R1090                         -8500
    X1070     R713                          -17000
    X1070     R1091                         -17000
    X1071     R714                          -17000
    X1071     R1092                         -17000
    X1072     R715                          -8500
    X1072     R1093                         -8500
    X1073     R716                          -17000
    X1073     R1094                         -17000
    X1074     R717                          -17000
    X1074     R1095                         -17000
    X1075     R718                          -8500
    X1075     R1096                         -8500
    X1076     R719                          -17000
    X1076     R1097                         -17000
    X1077     R720                          -17000
    X1077     R1098                         -17000
    X1078     R721                          -8500
    X1078     R1099                         -8500
    X1079     R722                          -17000
    X1079     R1100                         -17000
    X1080     R723                          -17000
    X1080     R1101                         -17000
    X1081     R724                          -8500
    X1081     R1102                         -8500
    X1082     R725                          -17000
    X1082     R1103                         -17000
    X1083     R726                          -17000
    X1083     R1104                         -17000
    X1084     R727                          -8500
    X1084     R1105                         -8500
    X1085     R728                          -17000
    X1085     R1106                         -17000
    X1086     R729                          -17000
    X1086     R1107                         -17000
    X1087     R730                          -8500
    X1087     R1108                         -8500
    X1088     R731                          -17000
    X1088     R1109                         -17000
    X1089     R732                          -17000
    X1089     R1110                         -17000
    X1090     R733                          -8500
    X1090     R1111                         -8500
    X1091     R734                          -17000
    X1091     R1112                         -17000
    X1092     R735                          -17000
    X1092     R1113                         -17000
    X1093     R736                          -8500
    X1093     R1114                         -8500
    X1094     R737                          -17000
    X1094     R1115                         -17000
    X1095     R738                          -17000
    X1095     R1116                         -17000
    X1096     R739                          -8500
    X1096     R1117                         -8500
    X1097     R740                          -17000
    X1097     R1118                         -17000
    X1098     R741                          -17000
    X1098     R1119                         -17000
    X1099     R742                          -8500
    X1099     R1120                         -8500
    X1100     R743                          -17000
    X1100     R1121                         -17000
    X1101     R744                          -17000
    X1101     R1122                         -17000
    X1102     R745                          -8500
    X1102     R1123                         -8500
    X1103     R746                          -17000
    X1103     R1124                         -17000
    X1104     R747                          -17000
    X1104     R1125                         -17000
    X1105     R748                          -8500
    X1105     R1126                         -8500
    X1106     R749                          -17000
    X1106     R1127                         -17000
    X1107     R750                          -17000
    X1107     R1128                         -17000
    X1108     R751                          -8500
    X1108     R1129                         -8500
    X1109     R752                          -17000
    X1109     R1130                         -17000
    X1110     R753                          -17000
    X1110     R1131                         -17000
    X1111     R754                          -8500
    X1111     R1132                         -8500
    X1112     R755                          -17000
    X1112     R1133                         -17000
    X1113     R756                          -17000
    X1113     R1134                         -17000
    X1114     R757                          -8500
    X1114     R1135                         -8500
    X1115     R758                          -17000
    X1115     R1136                         -17000
    X1116     R759                          -17000
    X1116     R1137                         -17000
    X1117     R760                          -8500
    X1117     R1138                         -8500
    X1118     R761                          -17000
    X1118     R1139                         -17000
    X1119     R762                          -17000
    X1119     R1140                         -17000
    X1120     R763                          -8500
    X1120     R1141                         -8500
    X1121     R764                          -17000
    X1121     R1142                         -17000
    X1122     R765                          -17000
    X1122     R1143                         -17000
    X1123     R766                          -8500
    X1123     R1144                         -8500
    X1124     R767                          -17000
    X1124     R1145                         -17000
    X1125     R768                          -17000
    X1125     R1146                         -17000
    X1126     R769                          -8500
    X1126     R1147                         -8500
    X1127     R770                          -17000
    X1127     R1148                         -17000
    X1128     R771                          -17000
    X1128     R1149                         -17000
    X1129     R772                          -8500
    X1129     R1150                         -8500
    X1130     R773                          -17000
    X1130     R1151                         -17000
    X1131     R774                          -17000
    X1131     R1152                         -17000
    X1132     R775                          -8500
    X1132     R1153                         -8500
    X1133     R776                          -17000
    X1133     R1154                         -17000
    X1134     R777                          -17000
    X1134     R1155                         -17000
    X1135     R778                          -8500
    X1135     R1156                         -8500
    X1136     R779                          -17000
    X1136     R1157                         -17000
    X1137     R780                          -17000
    X1137     R1158                         -17000
    X1138     R781                          -8500
    X1138     R1159                         -8500
    X1139     R782                          -17000
    X1139     R1160                         -17000
    X1140     R783                          -17000
    X1140     R1161                         -17000
    X1141     R784                          -8500
    X1141     R1162                         -8500
    X1142     R785                          -17000
    X1142     R1163                         -17000
    X1143     R786                          -17000
    X1143     R1164                         -17000
    X1144     R787                          -8500
    X1144     R1165                         -8500
    X1145     R788                          -17000
    X1145     R1166                         -17000
    X1146     R789                          -17000
    X1146     R1167                         -17000
    X1147     R790                          -8500
    X1147     R1168                         -8500
    X1148     R791                          -17000
    X1148     R1169                         -17000
    X1149     R792                          -17000
    X1149     R1170                         -17000
    X1150     R793                          -8500
    X1150     R1171                         -8500
    X1151     R794                          -17000
    X1151     R1172                         -17000
    X1152     R795                          -17000
    X1152     R1173                         -17000
    X1153     R796                          -8500
    X1153     R1174                         -8500
    X1154     R797                          -17000
    X1154     R1175                         -17000
    X1155     R798                          -17000
    X1155     R1176                         -17000
    X1156     R799                          -8500
    X1156     R1177                         -8500
    X1157     R800                          -17000
    X1157     R1178                         -17000
    X1158     R801                          -17000
    X1158     R1179                         -17000
    X1159     R802                          -8500
    X1159     R1180                         -8500
    X1160     R803                          -17000
    X1160     R1181                         -17000
    X1161     R804                          -17000
    X1161     R1182                         -17000
    X1162     R805                          -8500
    X1162     R1183                         -8500
    X1163     R806                          -17000
    X1163     R1184                         -17000
    X1164     R807                          -17000
    X1164     R1185                         -17000
    X1165     R808                          -8500
    X1165     R1186                         -8500
    X1166     R809                          -17000
    X1166     R1187                         -17000
    X1167     R810                          -17000
    X1167     R1188                         -17000
    X1168     R811                          -8500
    X1168     R1189                         -8500
    X1169     R812                          -17000
    X1169     R1190                         -17000
    X1170     R813                          -17000
    X1170     R1191                         -17000
    X1171     R814                          -8500
    X1171     R1192                         -8500
    X1172     R815                          -17000
    X1172     R1193                         -17000
    X1173     R816                          -17000
    X1173     R1194                         -17000
    X1174     R817                          -8500
    X1174     R1195                         -8500
    X1175     R818                          -17000
    X1175     R1196                         -17000
    X1176     R819                          -17000
    X1176     R1197                         -17000
    X1177     R820                          -8500
    X1177     R1198                         -8500
    X1178     R821                          -17000
    X1178     R1199                         -17000
    X1179     R822                          -17000
    X1179     R1200                         -17000
    X1180     R823                          -8500
    X1180     R1201                         -8500
    X1181     R824                          -17000
    X1181     R1202                         -17000
    X1182     R825                          -17000
    X1182     R1203                         -17000
    X1183     R826                          -8500
    X1183     R1204                         -8500
    X1184     R827                          -17000
    X1184     R1205                         -17000
    X1185     R828                          -17000
    X1185     R1206                         -17000
    X1186     R829                          -8500
    X1186     R1207                         -8500
    X1187     R830                          -17000
    X1187     R1208                         -17000
    X1188     R831                          -17000
    X1188     R1209                         -17000
    X1189     R832                          -8500
    X1189     R1210                         -8500
    X1190     R833                          -17000
    X1190     R1211                         -17000
    X1191     R834                          -17000
    X1191     R1212                         -17000
    X1192     R835                          -8500
    X1192     R1213                         -8500
    X1193     R836                          -17000
    X1193     R1214                         -17000
    X1194     R837                          -17000
    X1194     R1215                         -17000
    X1195     R838                          -8500
    X1195     R1216                         -8500
    X1196     R839                          -17000
    X1196     R1217                         -17000
    X1197     R840                          -17000
    X1197     R1218                         -17000
    X1198     R841                          -8500
    X1198     R1219                         -8500
    X1199     R842                          -17000
    X1199     R1220                         -17000
    X1200     R843                          -17000
    X1200     R1221                         -17000
    X1201     R844                          -8500
    X1201     R1222                         -8500
    X1202     R845                          -17000
    X1202     R1223                         -17000
    X1203     R846                          -17000
    X1203     R1224                         -17000
    X1204     R847                          -8500
    X1204     R1225                         -8500
    X1205     R848                          -17000
    X1205     R1226                         -17000
    X1206     R849                          -17000
    X1206     R1227                         -17000
    X1207     R850                          -8500
    X1207     R1228                         -8500
    X1208     R851                          -17000
    X1208     R1229                         -17000
    X1209     R852                          -17000
    X1209     R1230                         -17000
    X1210     R853                          -8500
    X1210     R1231                         -8500
    X1211     R854                          -17000
    X1211     R1232                         -17000
    X1212     R855                          -17000
    X1212     R1233                         -17000
    X1213     R856                          -8500
    X1213     R1234                         -8500
    X1214     R857                          -17000
    X1214     R1235                         -17000
    X1215     R858                          -17000
    X1215     R1236                         -17000
    X1216     R859                          -8500
    X1216     R1237                         -8500
    X1217     R860                          -17000
    X1217     R1238                         -17000
    X1218     R861                          -17000
    X1218     R1239                         -17000
    X1219     R862                          -8500
    X1219     R1240                         -8500
    X1220     R863                          -17000
    X1220     R1241                         -17000
    X1221     R864                          -17000
    X1221     R1242                         -17000
    X1222     R865                          -8500
    X1222     R1243                         -8500
    X1223     R866                          -17000
    X1223     R1244                         -17000
    X1224     R867                          -17000
    X1224     R1245                         -17000
    X1225     R868                          -8500
    X1225     R1246                         -8500
    X1226     R869                          -17000
    X1226     R1247                         -17000
    X1227     R870                          -17000
    X1227     R1248                         -17000
    X1228     R871                          -8500
    X1228     R1249                         -8500
    X1229     R872                          -17000
    X1229     R1250                         -17000
    X1230     R873                          -17000
    X1230     R1251                         -17000
    X1231     R874                          -8500
    X1231     R1252                         -8500
    X1232     R875                          -17000
    X1232     R1253                         -17000
    X1233     R876                          -17000
    X1233     R1254                         -17000
    X1234     R877                          -8500
    X1234     R1255                         -8500
    X1235     R878                          -17000
    X1235     R1256                         -17000
    X1236     R879                          -17000
    X1236     R1257                         -17000
    X1237     R880                          -8500
    X1237     R1258                         -8500
    X1238     R881                          -17000
    X1238     R1259                         -17000
    X1239     R882                          -17000
    X1239     R1260                         -17000
    X1240     R883                          -8500
    X1240     R1261                         -8500
    X1241     R884                          -17000
    X1241     R1262                         -17000
    X1242     R885                          -17000
    X1242     R1263                         -17000
    X1243     R886                          -8500
    X1243     R1264                         -8500
    X1244     R887                          -17000
    X1244     R1265                         -17000
    X1245     R888                          -17000
    X1245     R1266                         -17000
    X1246     R889                          -8500
    X1246     R1267                         -8500
    X1247     R890                          -17000
    X1247     R1268                         -17000
    X1248     R891                          -17000
    X1248     R1269                         -17000
    X1249     R892                          -8500
    X1249     R1270                         -8500
    X1250     R893                          -17000
    X1250     R1271                         -17000
    X1251     R894                          -17000
    X1251     R1272                         -17000
    X1252     R895                          -8500
    X1252     R1273                         -8500
    X1253     R896                          -17000
    X1253     R1274                         -17000
    X1254     R897                          -17000
    X1254     R1275                         -17000
    X1255     R898                          -8500
    X1255     R1276                         -8500
    X1256     R899                          -17000
    X1256     R1277                         -17000
    X1257     R900                          -17000
    X1257     R1278                         -17000
    X1258     R901                          -8500
    X1258     R1279                         -8500
    X1259     R902                          -17000
    X1259     R1280                         -17000
    X1260     R903                          -17000
    X1260     R1281                         -17000
    X1261     R904                          -8500
    X1261     R1282                         -8500
    X1262     R905                          -17000
    X1262     R1283                         -17000
    X1263     R906                          -17000
    X1263     R1284                         -17000
    X1264     R907                          -8500
    X1264     R1285                         -8500
    X1265     R908                          -17000
    X1265     R1286                         -17000
    X1266     R909                          -17000
    X1266     R1287                         -17000
    X1267     R910                          -8500
    X1267     R1288                         -8500
    X1268     R911                          -17000
    X1268     R1289                         -17000
    X1269     R912                          -17000
    X1269     R1290                         -17000
    X1270     R913                          -8500
    X1270     R1291                         -8500
    X1271     R914                          -17000
    X1271     R1292                         -17000
    X1272     R915                          -17000
    X1272     R1293                         -17000
    X1273     R916                          -8500
    X1273     R1294                         -8500
    X1274     R917                          -17000
    X1274     R1295                         -17000
    X1275     R918                          -17000
    X1275     R1296                         -17000
    X1276     R919                          -8500
    X1276     R1297                         -8500
    X1277     R920                          -17000
    X1277     R1298                         -17000
    X1278     R921                          -17000
    X1278     R1299                         -17000
    X1279     R922                          -8500
    X1279     R1300                         -8500
    X1280     R923                          -17000
    X1280     R1301                         -17000
    X1281     R1302                         -17000
    X1281     R1323                         -17000
    X1282     R1303                         -8500
    X1282     R1324                         -8500
    X1283     R1304                         -17000
    X1283     R1325                         -17000
    X1284     R1305                         -17000
    X1284     R1326                         -17000
    X1285     R1306                         -8500
    X1285     R1327                         -8500
    X1286     R1307                         -17000
    X1286     R1328                         -17000
    X1287     R1308                         -17000
    X1287     R1329                         -17000
    X1288     R1309                         -8500
    X1288     R1330                         -8500
    X1289     R1310                         -17000
    X1289     R1331                         -17000
    X1290     R1311                         -17000
    X1290     R1332                         -17000
    X1291     R1312                         -8500
    X1291     R1333                         -8500
    X1292     R1313                         -17000
    X1292     R1334                         -17000
    X1293     R1314                         -17000
    X1293     R1335                         -17000
    X1294     R1315                         -8500
    X1294     R1336                         -8500
    X1295     R1316                         -17000
    X1295     R1337                         -17000
    X1296     R1317                         -17000
    X1296     R1338                         -17000
    X1297     R1318                         -8500
    X1297     R1339                         -8500
    X1298     R1319                         -17000
    X1298     R1340                         -17000
    X1299     R1320                         -17000
    X1299     R1341                         -17000
    X1300     R1321                         -8500
    X1300     R1342                         -8500
    X1301     R1322                         -17000
    X1301     R1343                         -17000
    X1302     R1344                         -17000
    X1302     R1407                         -17000
    X1303     R1345                         -8500
    X1303     R1408                         -8500
    X1304     R1346                         -17000
    X1304     R1409                         -17000
    X1305     R1347                         -17000
    X1305     R1410                         -17000
    X1306     R1348                         -8500
    X1306     R1411                         -8500
    X1307     R1349                         -17000
    X1307     R1412                         -17000
    X1308     R1350                         -17000
    X1308     R1413                         -17000
    X1309     R1351                         -8500
    X1309     R1414                         -8500
    X1310     R1352                         -17000
    X1310     R1415                         -17000
    X1311     R1353                         -17000
    X1311     R1416                         -17000
    X1312     R1354                         -8500
    X1312     R1417                         -8500
    X1313     R1355                         -17000
    X1313     R1418                         -17000
    X1314     R1356                         -17000
    X1314     R1419                         -17000
    X1315     R1357                         -8500
    X1315     R1420                         -8500
    X1316     R1358                         -17000
    X1316     R1421                         -17000
    X1317     R1359                         -17000
    X1317     R1422                         -17000
    X1318     R1360                         -8500
    X1318     R1423                         -8500
    X1319     R1361                         -17000
    X1319     R1424                         -17000
    X1320     R1362                         -17000
    X1320     R1425                         -17000
    X1321     R1363                         -8500
    X1321     R1426                         -8500
    X1322     R1364                         -17000
    X1322     R1427                         -17000
    X1323     R1365                         -17000
    X1323     R1428                         -17000
    X1324     R1366                         -8500
    X1324     R1429                         -8500
    X1325     R1367                         -17000
    X1325     R1430                         -17000
    X1326     R1368                         -17000
    X1326     R1431                         -17000
    X1327     R1369                         -8500
    X1327     R1432                         -8500
    X1328     R1370                         -17000
    X1328     R1433                         -17000
    X1329     R1371                         -17000
    X1329     R1434                         -17000
    X1330     R1372                         -8500
    X1330     R1435                         -8500
    X1331     R1373                         -17000
    X1331     R1436                         -17000
    X1332     R1374                         -17000
    X1332     R1437                         -17000
    X1333     R1375                         -8500
    X1333     R1438                         -8500
    X1334     R1376                         -17000
    X1334     R1439                         -17000
    X1335     R1377                         -17000
    X1335     R1440                         -17000
    X1336     R1378                         -8500
    X1336     R1441                         -8500
    X1337     R1379                         -17000
    X1337     R1442                         -17000
    X1338     R1380                         -17000
    X1338     R1443                         -17000
    X1339     R1381                         -8500
    X1339     R1444                         -8500
    X1340     R1382                         -17000
    X1340     R1445                         -17000
    X1341     R1383                         -17000
    X1341     R1446                         -17000
    X1342     R1384                         -8500
    X1342     R1447                         -8500
    X1343     R1385                         -17000
    X1343     R1448                         -17000
    X1344     R1386                         -17000
    X1344     R1449                         -17000
    X1345     R1387                         -8500
    X1345     R1450                         -8500
    X1346     R1388                         -17000
    X1346     R1451                         -17000
    X1347     R1389                         -17000
    X1347     R1452                         -17000
    X1348     R1390                         -8500
    X1348     R1453                         -8500
    X1349     R1391                         -17000
    X1349     R1454                         -17000
    X1350     R1392                         -17000
    X1350     R1455                         -17000
    X1351     R1393                         -8500
    X1351     R1456                         -8500
    X1352     R1394                         -17000
    X1352     R1457                         -17000
    X1353     R1395                         -17000
    X1353     R1458                         -17000
    X1354     R1396                         -8500
    X1354     R1459                         -8500
    X1355     R1397                         -17000
    X1355     R1460                         -17000
    X1356     R1398                         -17000
    X1356     R1461                         -17000
    X1357     R1399                         -8500
    X1357     R1462                         -8500
    X1358     R1400                         -17000
    X1358     R1463                         -17000
    X1359     R1401                         -17000
    X1359     R1464                         -17000
    X1360     R1402                         -8500
    X1360     R1465                         -8500
    X1361     R1403                         -17000
    X1361     R1466                         -17000
    X1362     R1404                         -17000
    X1362     R1467                         -17000
    X1363     R1405                         -8500
    X1363     R1468                         -8500
    X1364     R1406                         -17000
    X1364     R1469                         -17000
    X1365     R1470                         -17000
    X1365     R1596                         -17000
    X1365     R1848                         64538
    X1366     R1471                         -8500
    X1366     R1597                         -8500
    X1366     R1848                         41273
    X1367     R1472                         -17000
    X1367     R1598                         -17000
    X1367     R1848                         64538
    X1368     R1473                         -17000
    X1368     R1599                         -17000
    X1368     R1848                         64538
    X1369     R1474                         -8500
    X1369     R1600                         -8500
    X1369     R1848                         41273
    X1370     R1475                         -17000
    X1370     R1601                         -17000
    X1370     R1848                         64538
    X1371     R1476                         -17000
    X1371     R1602                         -17000
    X1371     R1848                         64538
    X1372     R1477                         -8500
    X1372     R1603                         -8500
    X1372     R1848                         41273
    X1373     R1478                         -17000
    X1373     R1604                         -17000
    X1373     R1848                         64538
    X1374     R1479                         -17000
    X1374     R1605                         -17000
    X1374     R1848                         64538
    X1375     R1480                         -8500
    X1375     R1606                         -8500
    X1375     R1848                         41273
    X1376     R1481                         -17000
    X1376     R1607                         -17000
    X1376     R1848                         64538
    X1377     R1482                         -17000
    X1377     R1608                         -17000
    X1377     R1848                         64538
    X1378     R1483                         -8500
    X1378     R1609                         -8500
    X1378     R1848                         41273
    X1379     R1484                         -17000
    X1379     R1610                         -17000
    X1379     R1848                         64538
    X1380     R1485                         -17000
    X1380     R1611                         -17000
    X1380     R1848                         64538
    X1381     R1486                         -8500
    X1381     R1612                         -8500
    X1381     R1848                         41273
    X1382     R1487                         -17000
    X1382     R1613                         -17000
    X1382     R1848                         64538
    X1383     R1488                         -17000
    X1383     R1614                         -17000
    X1383     R1848                         70992
    X1384     R1489                         -8500
    X1384     R1615                         -8500
    X1384     R1848                         45400
    X1385     R1490                         -17000
    X1385     R1616                         -17000
    X1385     R1848                         70992
    X1386     R1491                         -17000
    X1386     R1617                         -17000
    X1386     R1848                         64538
    X1387     R1492                         -8500
    X1387     R1618                         -8500
    X1387     R1848                         41273
    X1388     R1493                         -17000
    X1388     R1619                         -17000
    X1388     R1848                         64538
    X1389     R1494                         -17000
    X1389     R1620                         -17000
    X1389     R1848                         64538
    X1390     R1495                         -8500
    X1390     R1621                         -8500
    X1390     R1848                         41273
    X1391     R1496                         -17000
    X1391     R1622                         -17000
    X1391     R1848                         64538
    X1392     R1497                         -17000
    X1392     R1623                         -17000
    X1392     R1848                         64538
    X1393     R1498                         -8500
    X1393     R1624                         -8500
    X1393     R1848                         41273
    X1394     R1499                         -17000
    X1394     R1625                         -17000
    X1394     R1848                         64538
    X1395     R1500                         -17000
    X1395     R1626                         -17000
    X1395     R1848                         64538
    X1396     R1501                         -8500
    X1396     R1627                         -8500
    X1396     R1848                         41273
    X1397     R1502                         -17000
    X1397     R1628                         -17000
    X1397     R1848                         64538
    X1398     R1503                         -17000
    X1398     R1629                         -17000
    X1398     R1848                         64538
    X1399     R1504                         -8500
    X1399     R1630                         -8500
    X1399     R1848                         41273
    X1400     R1505                         -17000
    X1400     R1631                         -17000
    X1400     R1848                         64538
    X1401     R1506                         -17000
    X1401     R1632                         -17000
    X1401     R1848                         64538
    X1402     R1507                         -8500
    X1402     R1633                         -8500
    X1402     R1848                         41273
    X1403     R1508                         -17000
    X1403     R1634                         -17000
    X1403     R1848                         64538
    X1404     R1509                         -17000
    X1404     R1635                         -17000
    X1404     R1848                         70992
    X1405     R1510                         -8500
    X1405     R1636                         -8500
    X1405     R1848                         45400
    X1406     R1511                         -17000
    X1406     R1637                         -17000
    X1406     R1848                         70992
    X1407     R1512                         -17000
    X1407     R1638                         -17000
    X1407     R1848                         65897
    X1408     R1513                         -8500
    X1408     R1639                         -8500
    X1408     R1848                         42088
    X1409     R1514                         -17000
    X1409     R1640                         -17000
    X1409     R1848                         65897
    X1410     R1515                         -17000
    X1410     R1641                         -17000
    X1410     R1848                         65897
    X1411     R1516                         -8500
    X1411     R1642                         -8500
    X1411     R1848                         42088
    X1412     R1517                         -17000
    X1412     R1643                         -17000
    X1412     R1848                         65897
    X1413     R1518                         -17000
    X1413     R1644                         -17000
    X1413     R1848                         65897
    X1414     R1519                         -8500
    X1414     R1645                         -8500
    X1414     R1848                         42088
    X1415     R1520                         -17000
    X1415     R1646                         -17000
    X1415     R1848                         65897
    X1416     R1521                         -17000
    X1416     R1647                         -17000
    X1416     R1848                         65897
    X1417     R1522                         -8500
    X1417     R1648                         -8500
    X1417     R1848                         42088
    X1418     R1523                         -17000
    X1418     R1649                         -17000
    X1418     R1848                         65897
    X1419     R1524                         -17000
    X1419     R1650                         -17000
    X1419     R1848                         65897
    X1420     R1525                         -8500
    X1420     R1651                         -8500
    X1420     R1848                         42088
    X1421     R1526                         -17000
    X1421     R1652                         -17000
    X1421     R1848                         65897
    X1422     R1527                         -17000
    X1422     R1653                         -17000
    X1422     R1848                         65897
    X1423     R1528                         -8500
    X1423     R1654                         -8500
    X1423     R1848                         42088
    X1424     R1529                         -17000
    X1424     R1655                         -17000
    X1424     R1848                         65897
    X1425     R1530                         -17000
    X1425     R1656                         -17000
    X1425     R1848                         72486
    X1426     R1531                         -8500
    X1426     R1657                         -8500
    X1426     R1848                         46297
    X1427     R1532                         -17000
    X1427     R1658                         -17000
    X1427     R1848                         72486
    X1428     R1533                         -17000
    X1428     R1659                         -17000
    X1428     R1848                         65897
    X1429     R1534                         -8500
    X1429     R1660                         -8500
    X1429     R1848                         42088
    X1430     R1535                         -17000
    X1430     R1661                         -17000
    X1430     R1848                         65897
    X1431     R1536                         -17000
    X1431     R1662                         -17000
    X1431     R1848                         65897
    X1432     R1537                         -8500
    X1432     R1663                         -8500
    X1432     R1848                         42088
    X1433     R1538                         -17000
    X1433     R1664                         -17000
    X1433     R1848                         65897
    X1434     R1539                         -17000
    X1434     R1665                         -17000
    X1434     R1848                         65897
    X1435     R1540                         -8500
    X1435     R1666                         -8500
    X1435     R1848                         42088
    X1436     R1541                         -17000
    X1436     R1667                         -17000
    X1436     R1848                         65897
    X1437     R1542                         -17000
    X1437     R1668                         -17000
    X1437     R1848                         65897
    X1438     R1543                         -8500
    X1438     R1669                         -8500
    X1438     R1848                         42088
    X1439     R1544                         -17000
    X1439     R1670                         -17000
    X1439     R1848                         65897
    X1440     R1545                         -17000
    X1440     R1671                         -17000
    X1440     R1848                         65897
    X1441     R1546                         -8500
    X1441     R1672                         -8500
    X1441     R1848                         42088
    X1442     R1547                         -17000
    X1442     R1673                         -17000
    X1442     R1848                         65897
    X1443     R1548                         -17000
    X1443     R1674                         -17000
    X1443     R1848                         65897
    X1444     R1549                         -8500
    X1444     R1675                         -8500
    X1444     R1848                         42088
    X1445     R1550                         -17000
    X1445     R1676                         -17000
    X1445     R1848                         65897
    X1446     R1551                         -17000
    X1446     R1677                         -17000
    X1446     R1848                         72486
    X1447     R1552                         -8500
    X1447     R1678                         -8500
    X1447     R1848                         46297
    X1448     R1553                         -17000
    X1448     R1679                         -17000
    X1448     R1848                         72486
    X1449     R1554                         -17000
    X1449     R1680                         -17000
    X1449     R1848                         65291
    X1450     R1555                         -8500
    X1450     R1681                         -8500
    X1450     R1848                         41725
    X1451     R1556                         -17000
    X1451     R1682                         -17000
    X1451     R1848                         65291
    X1452     R1557                         -17000
    X1452     R1683                         -17000
    X1452     R1848                         65291
    X1453     R1558                         -8500
    X1453     R1684                         -8500
    X1453     R1848                         41725
    X1454     R1559                         -17000
    X1454     R1685                         -17000
    X1454     R1848                         65291
    X1455     R1560                         -17000
    X1455     R1686                         -17000
    X1455     R1848                         65291
    X1456     R1561                         -8500
    X1456     R1687                         -8500
    X1456     R1848                         41725
    X1457     R1562                         -17000
    X1457     R1688                         -17000
    X1457     R1848                         65291
    X1458     R1563                         -17000
    X1458     R1689                         -17000
    X1458     R1848                         65291
    X1459     R1564                         -8500
    X1459     R1690                         -8500
    X1459     R1848                         41725
    X1460     R1565                         -17000
    X1460     R1691                         -17000
    X1460     R1848                         65291
    X1461     R1566                         -17000
    X1461     R1692                         -17000
    X1461     R1848                         65291
    X1462     R1567                         -8500
    X1462     R1693                         -8500
    X1462     R1848                         41725
    X1463     R1568                         -17000
    X1463     R1694                         -17000
    X1463     R1848                         65291
    X1464     R1569                         -17000
    X1464     R1695                         -17000
    X1464     R1848                         65291
    X1465     R1570                         -8500
    X1465     R1696                         -8500
    X1465     R1848                         41725
    X1466     R1571                         -17000
    X1466     R1697                         -17000
    X1466     R1848                         65291
    X1467     R1572                         -17000
    X1467     R1698                         -17000
    X1467     R1848                         71820
    X1468     R1573                         -8500
    X1468     R1699                         -8500
    X1468     R1848                         45897
    X1469     R1574                         -17000
    X1469     R1700                         -17000
    X1469     R1848                         71820
    X1470     R1575                         -17000
    X1470     R1701                         -17000
    X1470     R1848                         65291
    X1471     R1576                         -8500
    X1471     R1702                         -8500
    X1471     R1848                         41725
    X1472     R1577                         -17000
    X1472     R1703                         -17000
    X1472     R1848                         65291
    X1473     R1578                         -17000
    X1473     R1704                         -17000
    X1473     R1848                         65291
    X1474     R1579                         -8500
    X1474     R1705                         -8500
    X1474     R1848                         41725
    X1475     R1580                         -17000
    X1475     R1706                         -17000
    X1475     R1848                         65291
    X1476     R1581                         -17000
    X1476     R1707                         -17000
    X1476     R1848                         65291
    X1477     R1582                         -8500
    X1477     R1708                         -8500
    X1477     R1848                         41725
    X1478     R1583                         -17000
    X1478     R1709                         -17000
    X1478     R1848                         65291
    X1479     R1584                         -17000
    X1479     R1710                         -17000
    X1479     R1848                         65291
    X1480     R1585                         -8500
    X1480     R1711                         -8500
    X1480     R1848                         41725
    X1481     R1586                         -17000
    X1481     R1712                         -17000
    X1481     R1848                         65291
    X1482     R1587                         -17000
    X1482     R1713                         -17000
    X1482     R1848                         65291
    X1483     R1588                         -8500
    X1483     R1714                         -8500
    X1483     R1848                         41725
    X1484     R1589                         -17000
    X1484     R1715                         -17000
    X1484     R1848                         65291
    X1485     R1590                         -17000
    X1485     R1716                         -17000
    X1485     R1848                         65291
    X1486     R1591                         -8500
    X1486     R1717                         -8500
    X1486     R1848                         41725
    X1487     R1592                         -17000
    X1487     R1718                         -17000
    X1487     R1848                         65291
    X1488     R1593                         -17000
    X1488     R1719                         -17000
    X1488     R1848                         71820
    X1489     R1594                         -8500
    X1489     R1720                         -8500
    X1489     R1848                         45897
    X1490     R1595                         -17000
    X1490     R1721                         -17000
    X1490     R1848                         71820
    X1491     R1722                         -17000
    X1491     R1764                         -17000
    X1491     R1806                         1
    X1491     R1827                         1
    X1492     R1723                         -8500
    X1492     R1765                         -8500
    X1492     R1807                         1
    X1492     R1828                         1
    X1493     R1724                         -17000
    X1493     R1766                         -17000
    X1493     R1808                         1
    X1493     R1829                         1
    X1494     R1725                         -17000
    X1494     R1767                         -17000
    X1494     R1809                         1
    X1494     R1830                         1
    X1495     R1726                         -8500
    X1495     R1768                         -8500
    X1495     R1810                         1
    X1495     R1831                         1
    X1496     R1727                         -17000
    X1496     R1769                         -17000
    X1496     R1811                         1
    X1496     R1832                         1
    X1497     R1728                         -17000
    X1497     R1770                         -17000
    X1497     R1812                         1
    X1497     R1833                         1
    X1498     R1729                         -8500
    X1498     R1771                         -8500
    X1498     R1813                         1
    X1498     R1834                         1
    X1499     R1730                         -17000
    X1499     R1772                         -17000
    X1499     R1814                         1
    X1499     R1835                         1
    X1500     R1731                         -17000
    X1500     R1773                         -17000
    X1500     R1815                         1
    X1500     R1836                         1
    X1501     R1732                         -8500
    X1501     R1774                         -8500
    X1501     R1816                         1
    X1501     R1837                         1
    X1502     R1733                         -17000
    X1502     R1775                         -17000
    X1502     R1817                         1
    X1502     R1838                         1
    X1503     R1734                         -17000
    X1503     R1776                         -17000
    X1503     R1818                         1
    X1503     R1839                         1
    X1504     R1735                         -8500
    X1504     R1777                         -8500
    X1504     R1819                         1
    X1504     R1840                         1
    X1505     R1736                         -17000
    X1505     R1778                         -17000
    X1505     R1820                         1
    X1505     R1841                         1
    X1506     R1737                         -17000
    X1506     R1779                         -17000
    X1506     R1821                         1
    X1506     R1842                         1
    X1507     R1738                         -8500
    X1507     R1780                         -8500
    X1507     R1822                         1
    X1507     R1843                         1
    X1508     R1739                         -17000
    X1508     R1781                         -17000
    X1508     R1823                         1
    X1508     R1844                         1
    X1509     R1740                         -17000
    X1509     R1782                         -17000
    X1509     R1824                         1
    X1509     R1845                         1
    X1510     R1741                         -8500
    X1510     R1783                         -8500
    X1510     R1825                         1
    X1510     R1846                         1
    X1511     R1742                         -17000
    X1511     R1784                         -17000
    X1511     R1826                         1
    X1511     R1847                         1
    X1512     R1743                         -17000
    X1512     R1785                         -17000
    X1512     R1806                         1
    X1512     R1827                         1
    X1513     R1744                         -8500
    X1513     R1786                         -8500
    X1513     R1807                         1
    X1513     R1828                         1
    X1514     R1745                         -17000
    X1514     R1787                         -17000
    X1514     R1808                         1
    X1514     R1829                         1
    X1515     R1746                         -17000
    X1515     R1788                         -17000
    X1515     R1809                         1
    X1515     R1830                         1
    X1516     R1747                         -8500
    X1516     R1789                         -8500
    X1516     R1810                         1
    X1516     R1831                         1
    X1517     R1748                         -17000
    X1517     R1790                         -17000
    X1517     R1811                         1
    X1517     R1832                         1
    X1518     R1749                         -17000
    X1518     R1791                         -17000
    X1518     R1812                         1
    X1518     R1833                         1
    X1519     R1750                         -8500
    X1519     R1792                         -8500
    X1519     R1813                         1
    X1519     R1834                         1
    X1520     R1751                         -17000
    X1520     R1793                         -17000
    X1520     R1814                         1
    X1520     R1835                         1
    X1521     R1752                         -17000
    X1521     R1794                         -17000
    X1521     R1815                         1
    X1521     R1836                         1
    X1522     R1753                         -8500
    X1522     R1795                         -8500
    X1522     R1816                         1
    X1522     R1837                         1
    X1523     R1754                         -17000
    X1523     R1796                         -17000
    X1523     R1817                         1
    X1523     R1838                         1
    X1524     R1755                         -17000
    X1524     R1797                         -17000
    X1524     R1818                         1
    X1524     R1839                         1
    X1525     R1756                         -8500
    X1525     R1798                         -8500
    X1525     R1819                         1
    X1525     R1840                         1
    X1526     R1757                         -17000
    X1526     R1799                         -17000
    X1526     R1820                         1
    X1526     R1841                         1
    X1527     R1758                         -17000
    X1527     R1800                         -17000
    X1527     R1821                         1
    X1527     R1842                         1
    X1528     R1759                         -8500
    X1528     R1801                         -8500
    X1528     R1822                         1
    X1528     R1843                         1
    X1529     R1760                         -17000
    X1529     R1802                         -17000
    X1529     R1823                         1
    X1529     R1844                         1
    X1530     R1761                         -17000
    X1530     R1803                         -17000
    X1530     R1824                         1
    X1530     R1845                         1
    X1531     R1762                         -8500
    X1531     R1804                         -8500
    X1531     R1825                         1
    X1531     R1846                         1
    X1532     R1763                         -17000
    X1532     R1805                         -17000
    X1532     R1826                         1
    X1532     R1847                         1
RHS
    RHS       R0                            -39
    RHS       R1                            -59
    RHS       R2                            -30
    RHS       R3                            -11
    RHS       R4                            -26
    RHS       R5                            -74
    RHS       R6                            -5
    RHS       R7                            -38
    RHS       R8                            -21
    RHS       R9                            -17
    RHS       R10                           -39
    RHS       R11                           -57
    RHS       R12                           -26
    RHS       R13                           -47
    RHS       R14                           -16
    RHS       R15                           -19
    RHS       R16                           -16
    RHS       R17                           -45
    RHS       R18                           -19
    RHS       R19                           -25
    RHS       R20                           -8
    RHS       R21                           -19
    RHS       R22                           -6
    RHS       R24                           -34
    RHS       R25                           -49
    RHS       R26                           -55
    RHS       R27                           -25
    RHS       R28                           -33
    RHS       R30                           -16
    RHS       R31                           -25
    RHS       R32                           -22
    RHS       R33                           -22
    RHS       R34                           -15
    RHS       R36                           -33
    RHS       R37                           -25
    RHS       R38                           -9
    RHS       R39                           -12
    RHS       R40                           -9
    RHS       R42                           -9
    RHS       R43                           -24
    RHS       R44                           -8
    RHS       R45                           -9
    RHS       R46                           -18
    RHS       R48                           -54
    RHS       R49                           -45
    RHS       R50                           -44
    RHS       R51                           -39
    RHS       R52                           -38
    RHS       R54                           -11
    RHS       R55                           -2
    RHS       R56                           -16
    RHS       R57                           -8
    RHS       R58                           -9
    RHS       R60                           -18
    RHS       R61                           -43
    RHS       R62                           -24
    RHS       R63                           -56
    RHS       R64                           -45
    RHS       R66                           -5
    RHS       R67                           -4
    RHS       R68                           -17
    RHS       R69                           -6
    RHS       R70                           -8
    RHS       R72                           -11
    RHS       R73                           -24
    RHS       R74                           -30
    RHS       R75                           -12
    RHS       R76                           -12
    RHS       R78                           -18
    RHS       R79                           -22
    RHS       R80                           -6
    RHS       R81                           -19
    RHS       R82                           -21
    RHS       R84                           -56
    RHS       R85                           -47
    RHS       R86                           -39
    RHS       R87                           -30
    RHS       R88                           -28
    RHS       R90                           -13
    RHS       R91                           -8
    RHS       R92                           -7
    RHS       R93                           -12
    RHS       R94                           -13
    RHS       R96                           -50
    RHS       R97                           -27
    RHS       R98                           -27
    RHS       R99                           -32
    RHS       R100                          -19
    RHS       R102                          -5
    RHS       R103                          -14
    RHS       R104                          -2
    RHS       R105                          -15
    RHS       R106                          -3
    RHS       R108                          -24
    RHS       R109                          -7
    RHS       R110                          -14
    RHS       R111                          -7
    RHS       R112                          -4
    RHS       R114                          -17
    RHS       R115                          -6
    RHS       R116                          -17
    RHS       R117                          -3
    RHS       R118                          -19
    RHS       R120                          -47
    RHS       R121                          -34
    RHS       R122                          -54
    RHS       R123                          -32
    RHS       R124                          -43
    RHS       R126                          -39
    RHS       R127                          -39
    RHS       R128                          -39
    RHS       R129                          -59
    RHS       R130                          -59
    RHS       R131                          -59
    RHS       R132                          -30
    RHS       R133                          -30
    RHS       R134                          -30
    RHS       R135                          -11
    RHS       R136                          -11
    RHS       R137                          -11
    RHS       R138                          -26
    RHS       R139                          -26
    RHS       R140                          -26
    RHS       R141                          -74
    RHS       R142                          -74
    RHS       R143                          -74
    RHS       R144                          -5
    RHS       R145                          -5
    RHS       R146                          -5
    RHS       R147                          -38
    RHS       R148                          -38
    RHS       R149                          -38
    RHS       R150                          -21
    RHS       R151                          -21
    RHS       R152                          -21
    RHS       R153                          -17
    RHS       R154                          -17
    RHS       R155                          -17
    RHS       R156                          -39
    RHS       R157                          -39
    RHS       R158                          -39
    RHS       R159                          -57
    RHS       R160                          -57
    RHS       R161                          -57
    RHS       R162                          -26
    RHS       R163                          -26
    RHS       R164                          -26
    RHS       R165                          -47
    RHS       R166                          -47
    RHS       R167                          -47
    RHS       R168                          -16
    RHS       R169                          -16
    RHS       R170                          -16
    RHS       R171                          -19
    RHS       R172                          -19
    RHS       R173                          -19
    RHS       R174                          -16
    RHS       R175                          -16
    RHS       R176                          -16
    RHS       R177                          -45
    RHS       R178                          -45
    RHS       R179                          -45
    RHS       R180                          -19
    RHS       R181                          -25
    RHS       R182                          -8
    RHS       R183                          -19
    RHS       R184                          -6
    RHS       R186                          -19
    RHS       R187                          -25
    RHS       R188                          -8
    RHS       R189                          -19
    RHS       R190                          -6
    RHS       R192                          -19
    RHS       R193                          -25
    RHS       R194                          -8
    RHS       R195                          -19
    RHS       R196                          -6
    RHS       R198                          -34
    RHS       R199                          -49
    RHS       R200                          -55
    RHS       R201                          -25
    RHS       R202                          -33
    RHS       R204                          -34
    RHS       R205                          -49
    RHS       R206                          -55
    RHS       R207                          -25
    RHS       R208                          -33
    RHS       R210                          -34
    RHS       R211                          -49
    RHS       R212                          -55
    RHS       R213                          -25
    RHS       R214                          -33
    RHS       R216                          -16
    RHS       R217                          -25
    RHS       R218                          -22
    RHS       R219                          -22
    RHS       R220                          -15
    RHS       R222                          -16
    RHS       R223                          -25
    RHS       R224                          -22
    RHS       R225                          -22
    RHS       R226                          -15
    RHS       R228                          -16
    RHS       R229                          -25
    RHS       R230                          -22
    RHS       R231                          -22
    RHS       R232                          -15
    RHS       R234                          -33
    RHS       R235                          -25
    RHS       R236                          -9
    RHS       R237                          -12
    RHS       R238                          -9
    RHS       R240                          -33
    RHS       R241                          -25
    RHS       R242                          -9
    RHS       R243                          -12
    RHS       R244                          -9
    RHS       R246                          -33
    RHS       R247                          -25
    RHS       R248                          -9
    RHS       R249                          -12
    RHS       R250                          -9
    RHS       R252                          -9
    RHS       R253                          -24
    RHS       R254                          -8
    RHS       R255                          -9
    RHS       R256                          -18
    RHS       R258                          -9
    RHS       R259                          -24
    RHS       R260                          -8
    RHS       R261                          -9
    RHS       R262                          -18
    RHS       R264                          -9
    RHS       R265                          -24
    RHS       R266                          -8
    RHS       R267                          -9
    RHS       R268                          -18
    RHS       R270                          -54
    RHS       R271                          -45
    RHS       R272                          -44
    RHS       R273                          -39
    RHS       R274                          -38
    RHS       R276                          -54
    RHS       R277                          -45
    RHS       R278                          -44
    RHS       R279                          -39
    RHS       R280                          -38
    RHS       R282                          -54
    RHS       R283                          -45
    RHS       R284                          -44
    RHS       R285                          -39
    RHS       R286                          -38
    RHS       R288                          -11
    RHS       R289                          -2
    RHS       R290                          -16
    RHS       R291                          -8
    RHS       R292                          -9
    RHS       R294                          -11
    RHS       R295                          -2
    RHS       R296                          -16
    RHS       R297                          -8
    RHS       R298                          -9
    RHS       R300                          -11
    RHS       R301                          -2
    RHS       R302                          -16
    RHS       R303                          -8
    RHS       R304                          -9
    RHS       R306                          -18
    RHS       R307                          -43
    RHS       R308                          -24
    RHS       R309                          -56
    RHS       R310                          -45
    RHS       R312                          -18
    RHS       R313                          -43
    RHS       R314                          -24
    RHS       R315                          -56
    RHS       R316                          -45
    RHS       R318                          -18
    RHS       R319                          -43
    RHS       R320                          -24
    RHS       R321                          -56
    RHS       R322                          -45
    RHS       R324                          -5
    RHS       R325                          -4
    RHS       R326                          -17
    RHS       R327                          -6
    RHS       R328                          -8
    RHS       R330                          -5
    RHS       R331                          -4
    RHS       R332                          -17
    RHS       R333                          -6
    RHS       R334                          -8
    RHS       R336                          -5
    RHS       R337                          -4
    RHS       R338                          -17
    RHS       R339                          -6
    RHS       R340                          -8
    RHS       R342                          -11
    RHS       R343                          -24
    RHS       R344                          -30
    RHS       R345                          -12
    RHS       R346                          -12
    RHS       R348                          -11
    RHS       R349                          -24
    RHS       R350                          -30
    RHS       R351                          -12
    RHS       R352                          -12
    RHS       R354                          -11
    RHS       R355                          -24
    RHS       R356                          -30
    RHS       R357                          -12
    RHS       R358                          -12
    RHS       R360                          -18
    RHS       R361                          -22
    RHS       R362                          -6
    RHS       R363                          -19
    RHS       R364                          -21
    RHS       R366                          -18
    RHS       R367                          -22
    RHS       R368                          -6
    RHS       R369                          -19
    RHS       R370                          -21
    RHS       R372                          -18
    RHS       R373                          -22
    RHS       R374                          -6
    RHS       R375                          -19
    RHS       R376                          -21
    RHS       R378                          -56
    RHS       R379                          -47
    RHS       R380                          -39
    RHS       R381                          -30
    RHS       R382                          -28
    RHS       R384                          -56
    RHS       R385                          -47
    RHS       R386                          -39
    RHS       R387                          -30
    RHS       R388                          -28
    RHS       R390                          -56
    RHS       R391                          -47
    RHS       R392                          -39
    RHS       R393                          -30
    RHS       R394                          -28
    RHS       R396                          -13
    RHS       R397                          -8
    RHS       R398                          -7
    RHS       R399                          -12
    RHS       R400                          -13
    RHS       R402                          -13
    RHS       R403                          -8
    RHS       R404                          -7
    RHS       R405                          -12
    RHS       R406                          -13
    RHS       R408                          -13
    RHS       R409                          -8
    RHS       R410                          -7
    RHS       R411                          -12
    RHS       R412                          -13
    RHS       R414                          -50
    RHS       R415                          -27
    RHS       R416                          -27
    RHS       R417                          -32
    RHS       R418                          -19
    RHS       R420                          -50
    RHS       R421                          -27
    RHS       R422                          -27
    RHS       R423                          -32
    RHS       R424                          -19
    RHS       R426                          -50
    RHS       R427                          -27
    RHS       R428                          -27
    RHS       R429                          -32
    RHS       R430                          -19
    RHS       R432                          -5
    RHS       R433                          -14
    RHS       R434                          -2
    RHS       R435                          -15
    RHS       R436                          -3
    RHS       R438                          -5
    RHS       R439                          -14
    RHS       R440                          -2
    RHS       R441                          -15
    RHS       R442                          -3
    RHS       R444                          -5
    RHS       R445                          -14
    RHS       R446                          -2
    RHS       R447                          -15
    RHS       R448                          -3
    RHS       R450                          -24
    RHS       R451                          -7
    RHS       R452                          -14
    RHS       R453                          -7
    RHS       R454                          -4
    RHS       R456                          -24
    RHS       R457                          -7
    RHS       R458                          -14
    RHS       R459                          -7
    RHS       R460                          -4
    RHS       R462                          -24
    RHS       R463                          -7
    RHS       R464                          -14
    RHS       R465                          -7
    RHS       R466                          -4
    RHS       R468                          -17
    RHS       R469                          -6
    RHS       R470                          -17
    RHS       R471                          -3
    RHS       R472                          -19
    RHS       R474                          -17
    RHS       R475                          -6
    RHS       R476                          -17
    RHS       R477                          -3
    RHS       R478                          -19
    RHS       R480                          -17
    RHS       R481                          -6
    RHS       R482                          -17
    RHS       R483                          -3
    RHS       R484                          -19
    RHS       R486                          -47
    RHS       R487                          -34
    RHS       R488                          -54
    RHS       R489                          -32
    RHS       R490                          -43
    RHS       R492                          -47
    RHS       R493                          -34
    RHS       R494                          -54
    RHS       R495                          -32
    RHS       R496                          -43
    RHS       R498                          -47
    RHS       R499                          -34
    RHS       R500                          -54
    RHS       R501                          -32
    RHS       R502                          -43
    RHS       R504                          -200
    RHS       R505                          -240
    RHS       R506                          -220
    RHS       R507                          -100
    RHS       R508                          -100
    RHS       R509                          -100
    RHS       R510                          -100
    RHS       R511                          -30
    RHS       R513                          -140
    RHS       R514                          -140
    RHS       R515                          -140
    RHS       R516                          -140
    RHS       R517                          -70
    RHS       R519                          -120
    RHS       R520                          -120
    RHS       R521                          -120
    RHS       R522                          -120
    RHS       R523                          -50
    RHS       R525                          200
    RHS       R526                          240
    RHS       R527                          220
    RHS       R528                          100
    RHS       R529                          100
    RHS       R530                          100
    RHS       R531                          100
    RHS       R532                          30
    RHS       R534                          140
    RHS       R535                          140
    RHS       R536                          140
    RHS       R537                          140
    RHS       R538                          70
    RHS       R540                          120
    RHS       R541                          120
    RHS       R542                          120
    RHS       R543                          120
    RHS       R544                          50
    RHS       R1806                         1
    RHS       R1807                         1
    RHS       R1808                         1
    RHS       R1809                         1
    RHS       R1810                         1
    RHS       R1811                         1
    RHS       R1812                         1
    RHS       R1813                         1
    RHS       R1814                         1
    RHS       R1815                         1
    RHS       R1816                         1
    RHS       R1817                         1
    RHS       R1818                         1
    RHS       R1819                         1
    RHS       R1820                         1
    RHS       R1821                         1
    RHS       R1822                         1
    RHS       R1823                         1
    RHS       R1824                         1
    RHS       R1825                         1
    RHS       R1826                         1
    RHS       R1827                         1
    RHS       R1828                         1
    RHS       R1829                         1
    RHS       R1830                         1
    RHS       R1831                         1
    RHS       R1832                         1
    RHS       R1833                         1
    RHS       R1834                         1
    RHS       R1835                         1
    RHS       R1836                         1
    RHS       R1837                         1
    RHS       R1838                         1
    RHS       R1839                         1
    RHS       R1840                         1
    RHS       R1841                         1
    RHS       R1842                         1
    RHS       R1843                         1
    RHS       R1844                         1
    RHS       R1845                         1
    RHS       R1846                         1
    RHS       R1847                         1
BOUNDS
 UP BND       X903                          1
 UP BND       X904                          1
 UP BND       X905                          1
 UP BND       X906                          1
 UP BND       X907                          1
 UP BND       X908                          1
 UP BND       X909                          1
 UP BND       X910                          1
 UP BND       X911                          1
 UP BND       X912                          1
 UP BND       X913                          1
 UP BND       X914                          1
 UP BND       X915                          1
 UP BND       X916                          1
 UP BND       X917                          1
 UP BND       X918                          1
 UP BND       X919                          1
 UP BND       X920                          1
 UP BND       X921                          1
 UP BND       X922                          1
 UP BND       X923                          1
 UP BND       X924                          1
 UP BND       X925                          1
 UP BND       X926                          1
 UP BND       X927                          1
 UP BND       X928                          1
 UP BND       X929                          1
 UP BND       X930                          1
 UP BND       X931                          1
 UP BND       X932                          1
 UP BND       X933                          1
 UP BND       X934                          1
 UP BND       X935                          1
 UP BND       X936                          1
 UP BND       X937                          1
 UP BND       X938                          1
 UP BND       X939                          1
 UP BND       X940                          1
 UP BND       X941                          1
 UP BND       X942                          1
 UP BND       X943                          1
 UP BND       X944                          1
 UP BND       X945                          1
 UP BND       X946                          1
 UP BND       X947                          1
 UP BND       X948                          1
 UP BND       X949                          1
 UP BND       X950                          1
 UP BND       X951                          1
 UP BND       X952                          1
 UP BND       X953                          1
 UP BND       X954                          1
 UP BND       X955                          1
 UP BND       X956                          1
 UP BND       X957                          1
 UP BND       X958                          1
 UP BND       X959                          1
 UP BND       X960                          1
 UP BND       X961                          1
 UP BND       X962                          1
 UP BND       X963                          1
 UP BND       X964                          1
 UP BND       X965                          1
 UP BND       X966                          1
 UP BND       X967                          1
 UP BND       X968                          1
 UP BND       X969                          1
 UP BND       X970                          1
 UP BND       X971                          1
 UP BND       X972                          1
 UP BND       X973                          1
 UP BND       X974                          1
 UP BND       X975                          1
 UP BND       X976                          1
 UP BND       X977                          1
 UP BND       X978                          1
 UP BND       X979                          1
 UP BND       X980                          1
 UP BND       X981                          1
 UP BND       X982                          1
 UP BND       X983                          1
 UP BND       X984                          1
 UP BND       X985                          1
 UP BND       X986                          1
 UP BND       X987                          1
 UP BND       X988                          1
 UP BND       X989                          1
 UP BND       X990                          1
 UP BND       X991                          1
 UP BND       X992                          1
 UP BND       X993                          1
 UP BND       X994                          1
 UP BND       X995                          1
 UP BND       X996                          1
 UP BND       X997                          1
 UP BND       X998                          1
 UP BND       X999                          1
 UP BND       X1000                         1
 UP BND       X1001                         1
 UP BND       X1002                         1
 UP BND       X1003                         1
 UP BND       X1004                         1
 UP BND       X1005                         1
 UP BND       X1006                         1
 UP BND       X1007                         1
 UP BND       X1008                         1
 UP BND       X1009                         1
 UP BND       X1010                         1
 UP BND       X1011                         1
 UP BND       X1012                         1
 UP BND       X1013                         1
 UP BND       X1014                         1
 UP BND       X1015                         1
 UP BND       X1016                         1
 UP BND       X1017                         1
 UP BND       X1018                         1
 UP BND       X1019                         1
 UP BND       X1020                         1
 UP BND       X1021                         1
 UP BND       X1022                         1
 UP BND       X1023                         1
 UP BND       X1024                         1
 UP BND       X1025                         1
 UP BND       X1026                         1
 UP BND       X1027                         1
 UP BND       X1028                         1
 UP BND       X1029                         1
 UP BND       X1030                         1
 UP BND       X1031                         1
 UP BND       X1032                         1
 UP BND       X1033                         1
 UP BND       X1034                         1
 UP BND       X1035                         1
 UP BND       X1036                         1
 UP BND       X1037                         1
 UP BND       X1038                         1
 UP BND       X1039                         1
 UP BND       X1040                         1
 UP BND       X1041                         1
 UP BND       X1042                         1
 UP BND       X1043                         1
 UP BND       X1044                         1
 UP BND       X1045                         1
 UP BND       X1046                         1
 UP BND       X1047                         1
 UP BND       X1048                         1
 UP BND       X1049                         1
 UP BND       X1050                         1
 UP BND       X1051                         1
 UP BND       X1052                         1
 UP BND       X1053                         1
 UP BND       X1054                         1
 UP BND       X1055                         1
 UP BND       X1056                         1
 UP BND       X1057                         1
 UP BND       X1058                         1
 UP BND       X1059                         1
 UP BND       X1060                         1
 UP BND       X1061                         1
 UP BND       X1062                         1
 UP BND       X1063                         1
 UP BND       X1064                         1
 UP BND       X1065                         1
 UP BND       X1066                         1
 UP BND       X1067                         1
 UP BND       X1068                         1
 UP BND       X1069                         1
 UP BND       X1070                         1
 UP BND       X1071                         1
 UP BND       X1072                         1
 UP BND       X1073                         1
 UP BND       X1074                         1
 UP BND       X1075                         1
 UP BND       X1076                         1
 UP BND       X1077                         1
 UP BND       X1078                         1
 UP BND       X1079                         1
 UP BND       X1080                         1
 UP BND       X1081                         1
 UP BND       X1082                         1
 UP BND       X1083                         1
 UP BND       X1084                         1
 UP BND       X1085                         1
 UP BND       X1086                         1
 UP BND       X1087                         1
 UP BND       X1088                         1
 UP BND       X1089                         1
 UP BND       X1090                         1
 UP BND       X1091                         1
 UP BND       X1092                         1
 UP BND       X1093                         1
 UP BND       X1094                         1
 UP BND       X1095                         1
 UP BND       X1096                         1
 UP BND       X1097                         1
 UP BND       X1098                         1
 UP BND       X1099                         1
 UP BND       X1100                         1
 UP BND       X1101                         1
 UP BND       X1102                         1
 UP BND       X1103                         1
 UP BND       X1104                         1
 UP BND       X1105                         1
 UP BND       X1106                         1
 UP BND       X1107                         1
 UP BND       X1108                         1
 UP BND       X1109                         1
 UP BND       X1110                         1
 UP BND       X1111                         1
 UP BND       X1112                         1
 UP BND       X1113                         1
 UP BND       X1114                         1
 UP BND       X1115                         1
 UP BND       X1116                         1
 UP BND       X1117                         1
 UP BND       X1118                         1
 UP BND       X1119                         1
 UP BND       X1120                         1
 UP BND       X1121                         1
 UP BND       X1122                         1
 UP BND       X1123                         1
 UP BND       X1124                         1
 UP BND       X1125                         1
 UP BND       X1126                         1
 UP BND       X1127                         1
 UP BND       X1128                         1
 UP BND       X1129                         1
 UP BND       X1130                         1
 UP BND       X1131                         1
 UP BND       X1132                         1
 UP BND       X1133                         1
 UP BND       X1134                         1
 UP BND       X1135                         1
 UP BND       X1136                         1
 UP BND       X1137                         1
 UP BND       X1138                         1
 UP BND       X1139                         1
 UP BND       X1140                         1
 UP BND       X1141                         1
 UP BND       X1142                         1
 UP BND       X1143                         1
 UP BND       X1144                         1
 UP BND       X1145                         1
 UP BND       X1146                         1
 UP BND       X1147                         1
 UP BND       X1148                         1
 UP BND       X1149                         1
 UP BND       X1150                         1
 UP BND       X1151                         1
 UP BND       X1152                         1
 UP BND       X1153                         1
 UP BND       X1154                         1
 UP BND       X1155                         1
 UP BND       X1156                         1
 UP BND       X1157                         1
 UP BND       X1158                         1
 UP BND       X1159                         1
 UP BND       X1160                         1
 UP BND       X1161                         1
 UP BND       X1162                         1
 UP BND       X1163                         1
 UP BND       X1164                         1
 UP BND       X1165                         1
 UP BND       X1166                         1
 UP BND       X1167                         1
 UP BND       X1168                         1
 UP BND       X1169                         1
 UP BND       X1170                         1
 UP BND       X1171                         1
 UP BND       X1172                         1
 UP BND       X1173                         1
 UP BND       X1174                         1
 UP BND       X1175                         1
 UP BND       X1176                         1
 UP BND       X1177                         1
 UP BND       X1178                         1
 UP BND       X1179                         1
 UP BND       X1180                         1
 UP BND       X1181                         1
 UP BND       X1182                         1
 UP BND       X1183                         1
 UP BND       X1184                         1
 UP BND       X1185                         1
 UP BND       X1186                         1
 UP BND       X1187                         1
 UP BND       X1188                         1
 UP BND       X1189                         1
 UP BND       X1190                         1
 UP BND       X1191                         1
 UP BND       X1192                         1
 UP BND       X1193                         1
 UP BND       X1194                         1
 UP BND       X1195                         1
 UP BND       X1196                         1
 UP BND       X1197                         1
 UP BND       X1198                         1
 UP BND       X1199                         1
 UP BND       X1200                         1
 UP BND       X1201                         1
 UP BND       X1202                         1
 UP BND       X1203                         1
 UP BND       X1204                         1
 UP BND       X1205                         1
 UP BND       X1206                         1
 UP BND       X1207                         1
 UP BND       X1208                         1
 UP BND       X1209                         1
 UP BND       X1210                         1
 UP BND       X1211                         1
 UP BND       X1212                         1
 UP BND       X1213                         1
 UP BND       X1214                         1
 UP BND       X1215                         1
 UP BND       X1216                         1
 UP BND       X1217                         1
 UP BND       X1218                         1
 UP BND       X1219                         1
 UP BND       X1220                         1
 UP BND       X1221                         1
 UP BND       X1222                         1
 UP BND       X1223                         1
 UP BND       X1224                         1
 UP BND       X1225                         1
 UP BND       X1226                         1
 UP BND       X1227                         1
 UP BND       X1228                         1
 UP BND       X1229                         1
 UP BND       X1230                         1
 UP BND       X1231                         1
 UP BND       X1232                         1
 UP BND       X1233                         1
 UP BND       X1234                         1
 UP BND       X1235                         1
 UP BND       X1236                         1
 UP BND       X1237                         1
 UP BND       X1238                         1
 UP BND       X1239                         1
 UP BND       X1240                         1
 UP BND       X1241                         1
 UP BND       X1242                         1
 UP BND       X1243                         1
 UP BND       X1244                         1
 UP BND       X1245                         1
 UP BND       X1246                         1
 UP BND       X1247                         1
 UP BND       X1248                         1
 UP BND       X1249                         1
 UP BND       X1250                         1
 UP BND       X1251                         1
 UP BND       X1252                         1
 UP BND       X1253                         1
 UP BND       X1254                         1
 UP BND       X1255                         1
 UP BND       X1256                         1
 UP BND       X1257                         1
 UP BND       X1258                         1
 UP BND       X1259                         1
 UP BND       X1260                         1
 UP BND       X1261                         1
 UP BND       X1262                         1
 UP BND       X1263                         1
 UP BND       X1264                         1
 UP BND       X1265                         1
 UP BND       X1266                         1
 UP BND       X1267                         1
 UP BND       X1268                         1
 UP BND       X1269                         1
 UP BND       X1270                         1
 UP BND       X1271                         1
 UP BND       X1272                         1
 UP BND       X1273                         1
 UP BND       X1274                         1
 UP BND       X1275                         1
 UP BND       X1276                         1
 UP BND       X1277                         1
 UP BND       X1278                         1
 UP BND       X1279                         1
 UP BND       X1280                         1
 UP BND       X1281                         1
 UP BND       X1282                         1
 UP BND       X1283                         1
 UP BND       X1284                         1
 UP BND       X1285                         1
 UP BND       X1286                         1
 UP BND       X1287                         1
 UP BND       X1288                         1
 UP BND       X1289                         1
 UP BND       X1290                         1
 UP BND       X1291                         1
 UP BND       X1292                         1
 UP BND       X1293                         1
 UP BND       X1294                         1
 UP BND       X1295                         1
 UP BND       X1296                         1
 UP BND       X1297                         1
 UP BND       X1298                         1
 UP BND       X1299                         1
 UP BND       X1300                         1
 UP BND       X1301                         1
 UP BND       X1302                         1
 UP BND       X1303                         1
 UP BND       X1304                         1
 UP BND       X1305                         1
 UP BND       X1306                         1
 UP BND       X1307                         1
 UP BND       X1308                         1
 UP BND       X1309                         1
 UP BND       X1310                         1
 UP BND       X1311                         1
 UP BND       X1312                         1
 UP BND       X1313                         1
 UP BND       X1314                         1
 UP BND       X1315                         1
 UP BND       X1316                         1
 UP BND       X1317                         1
 UP BND       X1318                         1
 UP BND       X1319                         1
 UP BND       X1320                         1
 UP BND       X1321                         1
 UP BND       X1322                         1
 UP BND       X1323                         1
 UP BND       X1324                         1
 UP BND       X1325                         1
 UP BND       X1326                         1
 UP BND       X1327                         1
 UP BND       X1328                         1
 UP BND       X1329                         1
 UP BND       X1330                         1
 UP BND       X1331                         1
 UP BND       X1332                         1
 UP BND       X1333                         1
 UP BND       X1334                         1
 UP BND       X1335                         1
 UP BND       X1336                         1
 UP BND       X1337                         1
 UP BND       X1338                         1
 UP BND       X1339                         1
 UP BND       X1340                         1
 UP BND       X1341                         1
 UP BND       X1342                         1
 UP BND       X1343                         1
 UP BND       X1344                         1
 UP BND       X1345                         1
 UP BND       X1346                         1
 UP BND       X1347                         1
 UP BND       X1348                         1
 UP BND       X1349                         1
 UP BND       X1350                         1
 UP BND       X1351                         1
 UP BND       X1352                         1
 UP BND       X1353                         1
 UP BND       X1354                         1
 UP BND       X1355                         1
 UP BND       X1356                         1
 UP BND       X1357                         1
 UP BND       X1358                         1
 UP BND       X1359                         1
 UP BND       X1360                         1
 UP BND       X1361                         1
 UP BND       X1362                         1
 UP BND       X1363                         1
 UP BND       X1364                         1
 UP BND       X1365                         1
 UP BND       X1366                         1
 UP BND       X1367                         1
 UP BND       X1368                         1
 UP BND       X1369                         1
 UP BND       X1370                         1
 UP BND       X1371                         1
 UP BND       X1372                         1
 UP BND       X1373                         1
 UP BND       X1374                         1
 UP BND       X1375                         1
 UP BND       X1376                         1
 UP BND       X1377                         1
 UP BND       X1378                         1
 UP BND       X1379                         1
 UP BND       X1380                         1
 UP BND       X1381                         1
 UP BND       X1382                         1
 UP BND       X1383                         1
 UP BND       X1384                         1
 UP BND       X1385                         1
 UP BND       X1386                         1
 UP BND       X1387                         1
 UP BND       X1388                         1
 UP BND       X1389                         1
 UP BND       X1390                         1
 UP BND       X1391                         1
 UP BND       X1392                         1
 UP BND       X1393                         1
 UP BND       X1394                         1
 UP BND       X1395                         1
 UP BND       X1396                         1
 UP BND       X1397                         1
 UP BND       X1398                         1
 UP BND       X1399                         1
 UP BND       X1400                         1
 UP BND       X1401                         1
 UP BND       X1402                         1
 UP BND       X1403                         1
 UP BND       X1404                         1
 UP BND       X1405                         1
 UP BND       X1406                         1
 UP BND       X1407                         1
 UP BND       X1408                         1
 UP BND       X1409                         1
 UP BND       X1410                         1
 UP BND       X1411                         1
 UP BND       X1412                         1
 UP BND       X1413                         1
 UP BND       X1414                         1
 UP BND       X1415                         1
 UP BND       X1416                         1
 UP BND       X1417                         1
 UP BND       X1418                         1
 UP BND       X1419                         1
 UP BND       X1420                         1
 UP BND       X1421                         1
 UP BND       X1422                         1
 UP BND       X1423                         1
 UP BND       X1424                         1
 UP BND       X1425                         1
 UP BND       X1426                         1
 UP BND       X1427                         1
 UP BND       X1428                         1
 UP BND       X1429                         1
 UP BND       X1430                         1
 UP BND       X1431                         1
 UP BND       X1432                         1
 UP BND       X1433                         1
 UP BND       X1434                         1
 UP BND       X1435                         1
 UP BND       X1436                         1
 UP BND       X1437                         1
 UP BND       X1438                         1
 UP BND       X1439                         1
 UP BND       X1440                         1
 UP BND       X1441                         1
 UP BND       X1442                         1
 UP BND       X1443                         1
 UP BND       X1444                         1
 UP BND       X1445                         1
 UP BND       X1446                         1
 UP BND       X1447                         1
 UP BND       X1448                         1
 UP BND       X1449                         1
 UP BND       X1450                         1
 UP BND       X1451                         1
 UP BND       X1452                         1
 UP BND       X1453                         1
 UP BND       X1454                         1
 UP BND       X1455                         1
 UP BND       X1456                         1
 UP BND       X1457                         1
 UP BND       X1458                         1
 UP BND       X1459                         1
 UP BND       X1460                         1
 UP BND       X1461                         1
 UP BND       X1462                         1
 UP BND       X1463                         1
 UP BND       X1464                         1
 UP BND       X1465                         1
 UP BND       X1466                         1
 UP BND       X1467                         1
 UP BND       X1468                         1
 UP BND       X1469                         1
 UP BND       X1470                         1
 UP BND       X1471                         1
 UP BND       X1472                         1
 UP BND       X1473                         1
 UP BND       X1474                         1
 UP BND       X1475                         1
 UP BND       X1476                         1
 UP BND       X1477                         1
 UP BND       X1478                         1
 UP BND       X1479                         1
 UP BND       X1480                         1
 UP BND       X1481                         1
 UP BND       X1482                         1
 UP BND       X1483                         1
 UP BND       X1484                         1
 UP BND       X1485                         1
 UP BND       X1486                         1
 UP BND       X1487                         1
 UP BND       X1488                         1
 UP BND       X1489                         1
 UP BND       X1490                         1
 UP BND       X1491                         1
 UP BND       X1492                         1
 UP BND       X1493                         1
 UP BND       X1494                         1
 UP BND       X1495                         1
 UP BND       X1496                         1
 UP BND       X1497                         1
 UP BND       X1498                         1
 UP BND       X1499                         1
 UP BND       X1500                         1
 UP BND       X1501                         1
 UP BND       X1502                         1
 UP BND       X1503                         1
 UP BND       X1504                         1
 UP BND       X1505                         1
 UP BND       X1506                         1
 UP BND       X1507                         1
 UP BND       X1508                         1
 UP BND       X1509                         1
 UP BND       X1510                         1
 UP BND       X1511                         1
 UP BND       X1512                         1
 UP BND       X1513                         1
 UP BND       X1514                         1
 UP BND       X1515                         1
 UP BND       X1516                         1
 UP BND       X1517                         1
 UP BND       X1518                         1
 UP BND       X1519                         1
 UP BND       X1520                         1
 UP BND       X1521                         1
 UP BND       X1522                         1
 UP BND       X1523                         1
 UP BND       X1524                         1
 UP BND       X1525                         1
 UP BND       X1526                         1
 UP BND       X1527                         1
 UP BND       X1528                         1
 UP BND       X1529                         1
 UP BND       X1530                         1
 UP BND       X1531                         1
 UP BND       X1532                         1
ENDATA
