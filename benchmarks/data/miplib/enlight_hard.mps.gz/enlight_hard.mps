NAME          enlight_hard
ROWS
 N R0
 E R1
 E R2
 E R3
 E R4
 E R5
 E R6
 E R7
 E R8
 E R9
 E R10
 E R11
 E R12
 E R13
 E R14
 E R15
 E R16
 E R17
 E R18
 E R19
 E R20
 E R21
 E R22
 E R23
 E R24
 E R25
 E R26
 E R27
 E R28
 E R29
 E R30
 E R31
 E R32
 E R33
 E R34
 E R35
 E R36
 E R37
 E R38
 E R39
 E R40
 E R41
 E R42
 E R43
 E R44
 E R45
 E R46
 E R47
 E R48
 E R49
 E R50
 E R51
 E R52
 E R53
 E R54
 E R55
 E R56
 E R57
 E R58
 E R59
 E R60
 E R61
 E R62
 E R63
 E R64
 E R65
 E R66
 E R67
 E R68
 E R69
 E R70
 E R71
 E R72
 E R73
 E R74
 E R75
 E R76
 E R77
 E R78
 E R79
 E R80
 E R81
 E R82
 E R83
 E R84
 E R85
 E R86
 E R87
 E R88
 E R89
 E R90
 E R91
 E R92
 E R93
 E R94
 E R95
 E R96
 E R97
 E R98
 E R99
 E R100
COLUMNS
    X0        R0                            1
    X0        R65                           1
    X0        R81                           1
    X0        R97                           1
    X1        R0                            1
    X1        R1                            1
    X1        R65                           1
    X1        R66                           1
    X1        R97                           1
    X2        R0                            1
    X2        R2                            1
    X2        R65                           1
    X2        R66                           1
    X2        R67                           1
    X3        R0                            1
    X3        R3                            1
    X3        R66                           1
    X3        R67                           1
    X3        R68                           1
    X4        R0                            1
    X4        R4                            1
    X4        R67                           1
    X4        R68                           1
    X4        R69                           1
    X5        R0                            1
    X5        R5                            1
    X5        R68                           1
    X5        R69                           1
    X5        R70                           1
    X6        R0                            1
    X6        R6                            1
    X6        R69                           1
    X6        R70                           1
    X6        R71                           1
    X7        R0                            1
    X7        R7                            1
    X7        R70                           1
    X7        R71                           1
    X7        R72                           1
    X8        R0                            1
    X8        R8                            1
    X8        R71                           1
    X8        R72                           1
    X8        R99                           1
    X9        R0                            1
    X9        R72                           1
    X9        R89                           1
    X9        R99                           1
    X10       R0                            1
    X10       R1                            1
    X10       R81                           1
    X10       R82                           1
    X10       R97                           1
    X11       R0                            1
    X11       R1                            1
    X11       R2                            1
    X11       R9                            1
    X11       R65                           1
    X11       R81                           1
    X12       R0                            1
    X12       R1                            1
    X12       R2                            1
    X12       R3                            1
    X12       R10                           1
    X12       R66                           1
    X13       R0                            1
    X13       R2                            1
    X13       R3                            1
    X13       R4                            1
    X13       R11                           1
    X13       R67                           1
    X14       R0                            1
    X14       R3                            1
    X14       R4                            1
    X14       R5                            1
    X14       R12                           1
    X14       R68                           1
    X15       R0                            1
    X15       R4                            1
    X15       R5                            1
    X15       R6                            1
    X15       R13                           1
    X15       R69                           1
    X16       R0                            1
    X16       R5                            1
    X16       R6                            1
    X16       R7                            1
    X16       R14                           1
    X16       R70                           1
    X17       R0                            1
    X17       R6                            1
    X17       R7                            1
    X17       R8                            1
    X17       R15                           1
    X17       R71                           1
    X18       R0                            1
    X18       R7                            1
    X18       R8                            1
    X18       R16                           1
    X18       R72                           1
    X18       R89                           1
    X19       R0                            1
    X19       R8                            1
    X19       R89                           1
    X19       R90                           1
    X19       R99                           1
    X20       R0                            1
    X20       R9                            1
    X20       R81                           1
    X20       R82                           1
    X20       R83                           1
    X21       R0                            1
    X21       R1                            1
    X21       R9                            1
    X21       R10                           1
    X21       R17                           1
    X21       R82                           1
    X22       R0                            1
    X22       R2                            1
    X22       R9                            1
    X22       R10                           1
    X22       R11                           1
    X22       R18                           1
    X23       R0                            1
    X23       R3                            1
    X23       R10                           1
    X23       R11                           1
    X23       R12                           1
    X23       R19                           1
    X24       R0                            1
    X24       R4                            1
    X24       R11                           1
    X24       R12                           1
    X24       R13                           1
    X24       R20                           1
    X25       R0                            1
    X25       R5                            1
    X25       R12                           1
    X25       R13                           1
    X25       R14                           1
    X25       R21                           1
    X26       R0                            1
    X26       R6                            1
    X26       R13                           1
    X26       R14                           1
    X26       R15                           1
    X26       R22                           1
    X27       R0                            1
    X27       R7                            1
    X27       R14                           1
    X27       R15                           1
    X27       R16                           1
    X27       R23                           1
    X28       R0                            1
    X28       R8                            1
    X28       R15                           1
    X28       R16                           1
    X28       R24                           1
    X28       R90                           1
    X29       R0                            1
    X29       R16                           1
    X29       R89                           1
    X29       R90                           1
    X29       R91                           1
    X30       R0                            1
    X30       R17                           1
    X30       R82                           1
    X30       R83                           1
    X30       R84                           1
    X31       R0                            1
    X31       R9                            1
    X31       R17                           1
    X31       R18                           1
    X31       R25                           1
    X31       R83                           1
    X32       R0                            1
    X32       R10                           1
    X32       R17                           1
    X32       R18                           1
    X32       R19                           1
    X32       R26                           1
    X33       R0                            1
    X33       R11                           1
    X33       R18                           1
    X33       R19                           1
    X33       R20                           1
    X33       R27                           1
    X34       R0                            1
    X34       R12                           1
    X34       R19                           1
    X34       R20                           1
    X34       R21                           1
    X34       R28                           1
    X35       R0                            1
    X35       R13                           1
    X35       R20                           1
    X35       R21                           1
    X35       R22                           1
    X35       R29                           1
    X36       R0                            1
    X36       R14                           1
    X36       R21                           1
    X36       R22                           1
    X36       R23                           1
    X36       R30                           1
    X37       R0                            1
    X37       R15                           1
    X37       R22                           1
    X37       R23                           1
    X37       R24                           1
    X37       R31                           1
    X38       R0                            1
    X38       R16                           1
    X38       R23                           1
    X38       R24                           1
    X38       R32                           1
    X38       R91                           1
    X39       R0                            1
    X39       R24                           1
    X39       R90                           1
    X39       R91                           1
    X39       R92                           1
    X40       R0                            1
    X40       R25                           1
    X40       R83                           1
    X40       R84                           1
    X40       R85                           1
    X41       R0                            1
    X41       R17                           1
    X41       R25                           1
    X41       R26                           1
    X41       R33                           1
    X41       R84                           1
    X42       R0                            1
    X42       R18                           1
    X42       R25                           1
    X42       R26                           1
    X42       R27                           1
    X42       R34                           1
    X43       R0                            1
    X43       R19                           1
    X43       R26                           1
    X43       R27                           1
    X43       R28                           1
    X43       R35                           1
    X44       R0                            1
    X44       R20                           1
    X44       R27                           1
    X44       R28                           1
    X44       R29                           1
    X44       R36                           1
    X45       R0                            1
    X45       R21                           1
    X45       R28                           1
    X45       R29                           1
    X45       R30                           1
    X45       R37                           1
    X46       R0                            1
    X46       R22                           1
    X46       R29                           1
    X46       R30                           1
    X46       R31                           1
    X46       R38                           1
    X47       R0                            1
    X47       R23                           1
    X47       R30                           1
    X47       R31                           1
    X47       R32                           1
    X47       R39                           1
    X48       R0                            1
    X48       R24                           1
    X48       R31                           1
    X48       R32                           1
    X48       R40                           1
    X48       R92                           1
    X49       R0                            1
    X49       R32                           1
    X49       R91                           1
    X49       R92                           1
    X49       R93                           1
    X50       R0                            1
    X50       R33                           1
    X50       R84                           1
    X50       R85                           1
    X50       R86                           1
    X51       R0                            1
    X51       R25                           1
    X51       R33                           1
    X51       R34                           1
    X51       R41                           1
    X51       R85                           1
    X52       R0                            1
    X52       R26                           1
    X52       R33                           1
    X52       R34                           1
    X52       R35                           1
    X52       R42                           1
    X53       R0                            1
    X53       R27                           1
    X53       R34                           1
    X53       R35                           1
    X53       R36                           1
    X53       R43                           1
    X54       R0                            1
    X54       R28                           1
    X54       R35                           1
    X54       R36                           1
    X54       R37                           1
    X54       R44                           1
    X55       R0                            1
    X55       R29                           1
    X55       R36                           1
    X55       R37                           1
    X55       R38                           1
    X55       R45                           1
    X56       R0                            1
    X56       R30                           1
    X56       R37                           1
    X56       R38                           1
    X56       R39                           1
    X56       R46                           1
    X57       R0                            1
    X57       R31                           1
    X57       R38                           1
    X57       R39                           1
    X57       R40                           1
    X57       R47                           1
    X58       R0                            1
    X58       R32                           1
    X58       R39                           1
    X58       R40                           1
    X58       R48                           1
    X58       R93                           1
    X59       R0                            1
    X59       R40                           1
    X59       R92                           1
    X59       R93                           1
    X59       R94                           1
    X60       R0                            1
    X60       R41                           1
    X60       R85                           1
    X60       R86                           1
    X60       R87                           1
    X61       R0                            1
    X61       R33                           1
    X61       R41                           1
    X61       R42                           1
    X61       R49                           1
    X61       R86                           1
    X62       R0                            1
    X62       R34                           1
    X62       R41                           1
    X62       R42                           1
    X62       R43                           1
    X62       R50                           1
    X63       R0                            1
    X63       R35                           1
    X63       R42                           1
    X63       R43                           1
    X63       R44                           1
    X63       R51                           1
    X64       R0                            1
    X64       R36                           1
    X64       R43                           1
    X64       R44                           1
    X64       R45                           1
    X64       R52                           1
    X65       R0                            1
    X65       R37                           1
    X65       R44                           1
    X65       R45                           1
    X65       R46                           1
    X65       R53                           1
    X66       R0                            1
    X66       R38                           1
    X66       R45                           1
    X66       R46                           1
    X66       R47                           1
    X66       R54                           1
    X67       R0                            1
    X67       R39                           1
    X67       R46                           1
    X67       R47                           1
    X67       R48                           1
    X67       R55                           1
    X68       R0                            1
    X68       R40                           1
    X68       R47                           1
    X68       R48                           1
    X68       R56                           1
    X68       R94                           1
    X69       R0                            1
    X69       R48                           1
    X69       R93                           1
    X69       R94                           1
    X69       R95                           1
    X70       R0                            1
    X70       R49                           1
    X70       R86                           1
    X70       R87                           1
    X70       R88                           1
    X71       R0                            1
    X71       R41                           1
    X71       R49                           1
    X71       R50                           1
    X71       R57                           1
    X71       R87                           1
    X72       R0                            1
    X72       R42                           1
    X72       R49                           1
    X72       R50                           1
    X72       R51                           1
    X72       R58                           1
    X73       R0                            1
    X73       R43                           1
    X73       R50                           1
    X73       R51                           1
    X73       R52                           1
    X73       R59                           1
    X74       R0                            1
    X74       R44                           1
    X74       R51                           1
    X74       R52                           1
    X74       R53                           1
    X74       R60                           1
    X75       R0                            1
    X75       R45                           1
    X75       R52                           1
    X75       R53                           1
    X75       R54                           1
    X75       R61                           1
    X76       R0                            1
    X76       R46                           1
    X76       R53                           1
    X76       R54                           1
    X76       R55                           1
    X76       R62                           1
    X77       R0                            1
    X77       R47                           1
    X77       R54                           1
    X77       R55                           1
    X77       R56                           1
    X77       R63                           1
    X78       R0                            1
    X78       R48                           1
    X78       R55                           1
    X78       R56                           1
    X78       R64                           1
    X78       R95                           1
    X79       R0                            1
    X79       R56                           1
    X79       R94                           1
    X79       R95                           1
    X79       R96                           1
    X80       R0                            1
    X80       R57                           1
    X80       R87                           1
    X80       R88                           1
    X80       R98                           1
    X81       R0                            1
    X81       R49                           1
    X81       R57                           1
    X81       R58                           1
    X81       R73                           1
    X81       R88                           1
    X82       R0                            1
    X82       R50                           1
    X82       R57                           1
    X82       R58                           1
    X82       R59                           1
    X82       R74                           1
    X83       R0                            1
    X83       R51                           1
    X83       R58                           1
    X83       R59                           1
    X83       R60                           1
    X83       R75                           1
    X84       R0                            1
    X84       R52                           1
    X84       R59                           1
    X84       R60                           1
    X84       R61                           1
    X84       R76                           1
    X85       R0                            1
    X85       R53                           1
    X85       R60                           1
    X85       R61                           1
    X85       R62                           1
    X85       R77                           1
    X86       R0                            1
    X86       R54                           1
    X86       R61                           1
    X86       R62                           1
    X86       R63                           1
    X86       R78                           1
    X87       R0                            1
    X87       R55                           1
    X87       R62                           1
    X87       R63                           1
    X87       R64                           1
    X87       R79                           1
    X88       R0                            1
    X88       R56                           1
    X88       R63                           1
    X88       R64                           1
    X88       R80                           1
    X88       R96                           1
    X89       R0                            1
    X89       R64                           1
    X89       R95                           1
    X89       R96                           1
    X89       R100                          1
    X90       R0                            1
    X90       R73                           1
    X90       R88                           1
    X90       R98                           1
    X91       R0                            1
    X91       R57                           1
    X91       R73                           1
    X91       R74                           1
    X91       R98                           1
    X92       R0                            1
    X92       R58                           1
    X92       R73                           1
    X92       R74                           1
    X92       R75                           1
    X93       R0                            1
    X93       R59                           1
    X93       R74                           1
    X93       R75                           1
    X93       R76                           1
    X94       R0                            1
    X94       R60                           1
    X94       R75                           1
    X94       R76                           1
    X94       R77                           1
    X95       R0                            1
    X95       R61                           1
    X95       R76                           1
    X95       R77                           1
    X95       R78                           1
    X96       R0                            1
    X96       R62                           1
    X96       R77                           1
    X96       R78                           1
    X96       R79                           1
    X97       R0                            1
    X97       R63                           1
    X97       R78                           1
    X97       R79                           1
    X97       R80                           1
    X98       R0                            1
    X98       R64                           1
    X98       R79                           1
    X98       R80                           1
    X98       R100                          1
    X99       R0                            1
    X99       R80                           1
    X99       R96                           1
    X99       R100                          1
    X100      R1                            -2
    X101      R2                            -2
    X102      R3                            -2
    X103      R4                            -2
    X104      R5                            -2
    X105      R6                            -2
    X106      R7                            -2
    X107      R8                            -2
    X108      R9                            -2
    X109      R10                           -2
    X110      R11                           -2
    X111      R12                           -2
    X112      R13                           -2
    X113      R14                           -2
    X114      R15                           -2
    X115      R16                           -2
    X116      R17                           -2
    X117      R18                           -2
    X118      R19                           -2
    X119      R20                           -2
    X120      R21                           -2
    X121      R22                           -2
    X122      R23                           -2
    X123      R24                           -2
    X124      R25                           -2
    X125      R26                           -2
    X126      R27                           -2
    X127      R28                           -2
    X128      R29                           -2
    X129      R30                           -2
    X130      R31                           -2
    X131      R32                           -2
    X132      R33                           -2
    X133      R34                           -2
    X134      R35                           -2
    X135      R36                           -2
    X136      R37                           -2
    X137      R38                           -2
    X138      R39                           -2
    X139      R40                           -2
    X140      R41                           -2
    X141      R42                           -2
    X142      R43                           -2
    X143      R44                           -2
    X144      R45                           -2
    X145      R46                           -2
    X146      R47                           -2
    X147      R48                           -2
    X148      R49                           -2
    X149      R50                           -2
    X150      R51                           -2
    X151      R52                           -2
    X152      R53                           -2
    X153      R54                           -2
    X154      R55                           -2
    X155      R56                           -2
    X156      R57                           -2
    X157      R58                           -2
    X158      R59                           -2
    X159      R60                           -2
    X160      R61                           -2
    X161      R62                           -2
    X162      R63                           -2
    X163      R64                           -2
    X164      R65                           -2
    X165      R66                           -2
    X166      R67                           -2
    X167      R68                           -2
    X168      R69                           -2
    X169      R70                           -2
    X170      R71                           -2
    X171      R72                           -2
    X172      R73                           -2
    X173      R74                           -2
    X174      R75                           -2
    X175      R76                           -2
    X176      R77                           -2
    X177      R78                           -2
    X178      R79                           -2
    X179      R80                           -2
    X180      R81                           -2
    X181      R82                           -2
    X182      R83                           -2
    X183      R84                           -2
    X184      R85                           -2
    X185      R86                           -2
    X186      R87                           -2
    X187      R88                           -2
    X188      R89                           -2
    X189      R90                           -2
    X190      R91                           -2
    X191      R92                           -2
    X192      R93                           -2
    X193      R94                           -2
    X194      R95                           -2
    X195      R96                           -2
    X196      R97                           -2
    X197      R98                           -2
    X198      R99                           -2
    X199      R100                          -2
RHS
    RHS       R6                            -1
    RHS       R9                            -1
    RHS       R12                           -1
    RHS       R13                           -1
    RHS       R23                           -1
    RHS       R29                           -1
    RHS       R34                           -1
    RHS       R39                           -1
    RHS       R43                           -1
    RHS       R46                           -1
    RHS       R48                           -1
    RHS       R52                           -1
    RHS       R55                           -1
    RHS       R57                           -1
    RHS       R62                           -1
    RHS       R63                           -1
    RHS       R71                           -1
    RHS       R74                           -1
    RHS       R75                           -1
    RHS       R76                           -1
    RHS       R78                           -1
    RHS       R80                           -1
    RHS       R84                           -1
    RHS       R87                           -1
    RHS       R90                           -1
    RHS       R95                           -1
    RHS       R96                           -1
    RHS       R97                           -1
    RHS       R98                           -1
BOUNDS
 UP BND       X0                            1
 UP BND       X1                            1
 UP BND       X2                            1
 UP BND       X3                            1
 UP BND       X4                            1
 UP BND       X5                            1
 UP BND       X6                            1
 UP BND       X7                            1
 UP BND       X8                            1
 UP BND       X9                            1
 UP BND       X10                           1
 UP BND       X11                           1
 UP BND       X12                           1
 UP BND       X13                           1
 UP BND       X14                           1
 UP BND       X15                           1
 UP BND       X16                           1
 UP BND       X17                           1
 UP BND       X18                           1
 UP BND       X19                           1
 UP BND       X20                           1
 UP BND       X21                           1
 UP BND       X22                           1
 UP BND       X23                           1
 UP BND       X24                           1
 UP BND       X25                           1
 UP BND       X26                           1
 UP BND       X27                           1
 UP BND       X28                           1
 UP BND       X29                           1
 UP BND       X30                           1
 UP BND       X31                           1
 UP BND       X32                           1
 UP BND       X33                           1
 UP BND       X34                           1
 UP BND       X35                           1
 UP BND       X36                           1
 UP BND       X37                           1
 UP BND       X38                           1
 UP BND       X39                           1
 UP BND       X40                           1
 UP BND       X41                           1
 UP BND       X42                           1
 UP BND       X43                           1
 UP BND       X44                           1
 UP BND       X45                           1
 UP BND       X46                           1
 UP BND       X47                           1
 UP BND       X48                           1
 UP BND       X49                           1
 UP BND       X50                           1
 UP BND       X51                           1
 UP BND       X52                           1
 UP BND       X53                           1
 UP BND       X54                           1
 UP BND       X55                           1
 UP BND       X56                           1
 UP BND       X57                           1
 UP BND       X58                           1
 UP BND       X59                           1
 UP BND       X60                           1
 UP BND       X61                           1
 UP BND       X62                           1
 UP BND       X63                           1
 UP BND       X64                           1
 UP BND       X65                           1
 UP BND       X66                           1
 UP BND       X67                           1
 UP BND       X68                           1
 UP BND       X69                           1
 UP BND       X70                           1
 UP BND       X71                           1
 UP BND       X72                           1
 UP BND       X73                           1
 UP BND       X74                           1
 UP BND       X75                           1
 UP BND       X76                           1
 UP BND       X77                           1
 UP BND       X78                           1
 UP BND       X79                           1
 UP BND       X80                           1
 UP BND       X81                           1
 UP BND       X82                           1
 UP BND       X83                           1
 UP BND       X84                           1
 UP BND       X85                           1
 UP BND       X86                           1
 UP BND       X87                           1
 UP BND       X88                           1
 UP BND       X89                           1
 UP BND       X90                           1
 UP BND       X91                           1
 UP BND       X92                           1
 UP BND       X93                           1
 UP BND       X94                           1
 UP BND       X95                           1
 UP BND       X96                           1
 UP BND       X97                           1
 UP BND       X98                           1
 UP BND       X99                           1
 LO BND       X100                          0
 LO BND       X101                          0
 LO BND       X102                          0
 LO BND       X103                          0
 LO BND       X104                          0
 LO BND       X105                          0
 LO BND       X106                          0
 LO BND       X107                          0
 LO BND       X108                          0
 LO BND       X109                          0
 LO BND       X110                          0
 LO BND       X111                          0
 LO BND       X112                          0
 LO BND       X113                          0
 LO BND       X114                          0
 LO BND       X115                          0
 LO BND       X116                          0
 LO BND       X117                          0
 LO BND       X118                          0
 LO BND       X119                          0
 LO BND       X120                          0
 LO BND       X121                          0
 LO BND       X122                          0
 LO BND       X123                          0
 LO BND       X124                          0
 LO BND       X125                          0
 LO BND       X126                          0
 LO BND       X127                          0
 LO BND       X128                          0
 LO BND       X129                          0
 LO BND       X130                          0
 LO BND       X131                          0
 LO BND       X132                          0
 LO BND       X133                          0
 LO BND       X134                          0
 LO BND       X135                          0
 LO BND       X136                          0
 LO BND       X137                          0
 LO BND       X138                          0
 LO BND       X139                          0
 LO BND       X140                          0
 LO BND       X141                          0
 LO BND       X142                          0
 LO BND       X143                          0
 LO BND       X144                          0
 LO BND       X145                          0
 LO BND       X146                          0
 LO BND       X147                          0
 LO BND       X148                          0
 LO BND       X149                          0
 LO BND       X150                          0
 LO BND       X151                          0
 LO BND       X152                          0
 LO BND       X153                          0
 LO BND       X154                          0
 LO BND       X155                          0
 LO BND       X156                          0
 LO BND       X157                          0
 LO BND       X158                          0
 LO BND       X159                          0
 LO BND       X160                          0
 LO BND       X161                          0
 LO BND       X162                          0
 LO BND       X163                          0
 LO BND       X164                          0
 LO BND       X165                          0
 LO BND       X166                          0
 LO BND       X167                          0
 LO BND       X168                          0
 LO BND       X169                          0
 LO BND       X170                          0
 LO BND       X171                          0
 LO BND       X172                          0
 LO BND       X173                          0
 LO BND       X174                          0
 LO BND       X175                          0
 LO BND       X176                          0
 LO BND       X177                          0
 LO BND       X178                          0
 LO BND       X179                          0
 LO BND       X180                          0
 LO BND       X181                          0
 LO BND       X182                          0
 LO BND       X183                          0
 LO BND       X184                          0
 LO BND       X185                          0
 LO BND       X186                          0
 LO BND       X187                          0
 LO BND       X188                          0
 LO BND       X189                          0
 LO BND       X190                          0
 LO BND       X191                          0
 LO BND       X192                          0
 LO BND       X193                          0
 LO BND       X194                          0
 LO BND       X195                          0
 LO BND       X196                          0
 LO BND       X197                          0
 LO BND       X198                          0
 LO BND       X199                          0
ENDATA
