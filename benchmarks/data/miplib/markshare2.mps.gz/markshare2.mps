NAME           markshare2
ROWS
 N R0
 E R1
 E R2
 E R3
 E R4
 E R5
 E R6
 E R7
COLUMNS
    X0        R0                            1
    X0        R1                            1
    X1        R0                            -1
    X1        R1                            1
    X2        R0                            1
    X2        R2                            1
    X3        R0                            -1
    X3        R2                            1
    X4        R0                            1
    X4        R3                            1
    X5        R0                            -1
    X5        R3                            1
    X6        R0                            1
    X6        R4                            1
    X7        R0                            -1
    X7        R4                            1
    X8        R0                            1
    X8        R5                            1
    X9        R0                            -1
    X9        R5                            1
    X10       R0                            1
    X10       R6                            1
    X11       R0                            -1
    X11       R6                            1
    X12       R0                            1
    X12       R7                            1
    X13       R0                            -1
    X13       R7                            1
    X14       R1                            74
    X14       R2                            20
    X14       R3                            85
    X14       R4                            13
    X14       R5                            35
    X14       R6                            86
    X14       R7                            41
    X15       R1                            49
    X15       R2                            7
    X15       R3                            47
    X15       R4                            71
    X15       R5                            61
    X15       R6                            8
    X15       R7                            64
    X16       R1                            12
    X16       R2                            68
    X16       R3                            67
    X16       R4                            78
    X16       R5                            66
    X16       R6                            44
    X16       R7                            82
    X17       R1                            93
    X17       R2                            69
    X17       R3                            59
    X17       R4                            84
    X17       R5                            78
    X17       R6                            96
    X17       R7                            24
    X18       R1                            56
    X18       R2                            95
    X18       R3                            84
    X18       R4                            56
    X18       R5                            46
    X18       R6                            64
    X18       R7                            48
    X19       R1                            16
    X19       R2                            64
    X19       R3                            59
    X19       R4                            66
    X19       R5                            89
    X19       R6                            65
    X19       R7                            41
    X20       R1                            39
    X20       R2                            76
    X20       R3                            19
    X20       R4                            8
    X20       R5                            61
    X20       R6                            68
    X20       R7                            29
    X21       R1                            77
    X21       R2                            12
    X21       R3                            8
    X21       R4                            68
    X21       R5                            25
    X21       R6                            53
    X21       R7                            93
    X22       R1                            56
    X22       R2                            45
    X22       R3                            50
    X22       R4                            48
    X22       R5                            55
    X22       R6                            19
    X22       R7                            64
    X23       R1                            73
    X23       R2                            43
    X23       R3                            66
    X23       R4                            28
    X23       R5                            16
    X23       R6                            33
    X23       R7                            39
    X24       R1                            1
    X24       R2                            83
    X24       R3                            5
    X24       R4                            33
    X24       R5                            81
    X24       R6                            28
    X24       R7                            92
    X25       R1                            3
    X25       R2                            15
    X25       R3                            51
    X25       R4                            34
    X25       R5                            35
    X25       R6                            42
    X25       R7                            86
    X26       R1                            68
    X26       R2                            90
    X26       R3                            51
    X26       R4                            8
    X26       R5                            96
    X26       R6                            72
    X26       R7                            64
    X27       R1                            61
    X27       R2                            10
    X27       R3                            64
    X27       R4                            99
    X27       R5                            23
    X27       R6                            39
    X27       R7                            45
    X28       R1                            8
    X28       R2                            96
    X28       R3                            64
    X28       R4                            80
    X28       R5                            83
    X28       R6                            5
    X28       R7                            87
    X29       R1                            55
    X29       R2                            98
    X29       R3                            53
    X29       R4                            74
    X29       R5                            39
    X29       R6                            77
    X29       R7                            34
    X30       R1                            18
    X30       R2                            53
    X30       R3                            61
    X30       R4                            2
    X30       R5                            14
    X30       R6                            37
    X30       R7                            39
    X31       R1                            21
    X31       R2                            1
    X31       R3                            45
    X31       R4                            10
    X31       R5                            53
    X31       R6                            89
    X31       R7                            88
    X32       R1                            57
    X32       R2                            2
    X32       R3                            3
    X32       R4                            96
    X32       R5                            23
    X32       R6                            7
    X32       R7                            99
    X33       R1                            98
    X33       R2                            58
    X33       R3                            76
    X33       R4                            41
    X33       R5                            23
    X33       R6                            78
    X33       R7                            63
    X34       R1                            58
    X34       R2                            24
    X34       R3                            17
    X34       R4                            98
    X34       R5                            93
    X34       R6                            10
    X34       R7                            85
    X35       R1                            57
    X35       R2                            90
    X35       R3                            54
    X35       R4                            74
    X35       R5                            38
    X35       R6                            78
    X35       R7                            48
    X36       R1                            46
    X36       R2                            29
    X36       R3                            13
    X36       R4                            39
    X36       R5                            15
    X36       R6                            10
    X36       R7                            83
    X37       R1                            72
    X37       R2                            57
    X37       R3                            89
    X37       R4                            91
    X37       R5                            20
    X37       R6                            96
    X37       R7                            88
    X38       R1                            6
    X38       R2                            19
    X38       R3                            68
    X38       R4                            85
    X38       R5                            19
    X38       R6                            55
    X38       R7                            85
    X39       R1                            16
    X39       R2                            73
    X39       R3                            57
    X39       R4                            95
    X39       R5                            28
    X39       R6                            1
    X39       R7                            5
    X40       R1                            76
    X40       R2                            89
    X40       R3                            4
    X40       R4                            96
    X40       R5                            79
    X40       R6                            64
    X40       R7                            14
    X41       R1                            21
    X41       R2                            31
    X41       R3                            24
    X41       R4                            1
    X41       R5                            51
    X41       R6                            61
    X41       R7                            31
    X42       R1                            78
    X42       R2                            12
    X42       R3                            96
    X42       R4                            80
    X42       R5                            24
    X42       R6                            63
    X42       R7                            12
    X43       R1                            18
    X43       R2                            34
    X43       R3                            81
    X43       R4                            90
    X43       R5                            6
    X43       R6                            90
    X43       R7                            93
    X44       R1                            11
    X44       R2                            67
    X44       R3                            36
    X44       R4                            97
    X44       R5                            3
    X44       R6                            22
    X44       R7                            55
    X45       R1                            58
    X45       R2                            48
    X45       R3                            54
    X45       R4                            36
    X45       R5                            47
    X45       R6                            78
    X45       R7                            1
    X46       R1                            59
    X46       R2                            11
    X46       R3                            3
    X46       R4                            7
    X46       R5                            61
    X46       R6                            92
    X46       R7                            2
    X47       R1                            25
    X47       R2                            22
    X47       R3                            82
    X47       R4                            69
    X47       R5                            60
    X47       R6                            25
    X47       R7                            22
    X48       R1                            32
    X48       R2                            36
    X48       R3                            33
    X48       R4                            9
    X48       R5                            71
    X48       R6                            24
    X48       R7                            93
    X49       R1                            14
    X49       R2                            78
    X49       R3                            88
    X49       R4                            9
    X49       R5                            63
    X49       R6                            65
    X49       R7                            49
    X50       R1                            16
    X50       R2                            75
    X50       R3                            1
    X50       R4                            93
    X50       R5                            26
    X50       R6                            6
    X50       R7                            35
    X51       R1                            3
    X51       R2                            52
    X51       R3                            29
    X51       R4                            94
    X51       R5                            66
    X51       R6                            68
    X51       R7                            25
    X52       R1                            60
    X52       R2                            95
    X52       R3                            4
    X52       R4                            44
    X52       R5                            71
    X52       R6                            66
    X52       R7                            39
    X53       R1                            12
    X53       R2                            57
    X53       R3                            48
    X53       R4                            36
    X53       R5                            63
    X53       R6                            66
    X53       R7                            1
    X54       R1                            7
    X54       R2                            62
    X54       R3                            51
    X54       R4                            71
    X54       R5                            56
    X54       R6                            1
    X54       R7                            77
    X55       R1                            42
    X55       R2                            94
    X55       R3                            14
    X55       R4                            37
    X55       R5                            32
    X55       R6                            67
    X55       R7                            43
    X56       R1                            98
    X56       R2                            10
    X56       R3                            86
    X56       R4                            72
    X56       R5                            39
    X56       R6                            78
    X56       R7                            7
    X57       R1                            34
    X57       R2                            42
    X57       R3                            64
    X57       R4                            38
    X57       R5                            31
    X57       R6                            21
    X57       R7                            42
    X58       R1                            33
    X58       R2                            89
    X58       R3                            73
    X58       R4                            74
    X58       R5                            64
    X58       R6                            47
    X58       R7                            36
    X59       R1                            16
    X59       R2                            11
    X59       R3                            78
    X59       R4                            89
    X59       R5                            89
    X59       R6                            17
    X59       R7                            63
    X60       R1                            97
    X60       R2                            77
    X60       R3                            45
    X60       R4                            37
    X60       R5                            62
    X60       R6                            89
    X60       R7                            5
    X61       R1                            63
    X61       R2                            85
    X61       R3                            65
    X61       R4                            24
    X61       R5                            68
    X61       R6                            77
    X61       R7                            8
    X62       R1                            66
    X62       R2                            30
    X62       R3                            30
    X62       R4                            88
    X62       R5                            59
    X62       R6                            88
    X62       R7                            43
    X63       R1                            28
    X63       R2                            82
    X63       R3                            52
    X63       R4                            77
    X63       R5                            71
    X63       R6                            54
    X63       R7                            18
    X64       R1                            57
    X64       R2                            20
    X64       R3                            6
    X64       R4                            61
    X64       R5                            48
    X64       R6                            10
    X64       R7                            60
    X65       R1                            19
    X65       R2                            52
    X65       R3                            78
    X65       R4                            80
    X65       R5                            76
    X65       R6                            87
    X65       R7                            47
    X66       R1                            74
    X66       R2                            78
    X66       R3                            9
    X66       R4                            2
    X66       R5                            96
    X66       R6                            88
    X66       R7                            47
    X67       R1                            44
    X67       R2                            6
    X67       R3                            19
    X67       R4                            60
    X67       R5                            74
    X67       R6                            80
    X67       R7                            46
    X68       R1                            45
    X68       R2                            57
    X68       R3                            87
    X68       R4                            87
    X68       R5                            61
    X68       R6                            76
    X68       R7                            45
    X69       R1                            49
    X69       R2                            65
    X69       R3                            73
    X69       R4                            80
    X69       R5                            21
    X69       R6                            9
    X69       R7                            38
    X70       R1                            76
    X70       R2                            79
    X70       R3                            10
    X70       R4                            74
    X70       R5                            46
    X70       R6                            83
    X70       R7                            9
    X71       R1                            74
    X71       R2                            83
    X71       R3                            87
    X71       R4                            42
    X71       R5                            18
    X71       R6                            95
    X71       R7                            37
    X72       R1                            9
    X72       R2                            16
    X72       R3                            33
    X72       R4                            2
    X72       R5                            23
    X72       R6                            86
    X72       R7                            8
    X73       R1                            44
    X73       R2                            67
    X73       R3                            1
    X73       R4                            37
    X73       R5                            24
    X73       R6                            24
    X73       R7                            82
RHS
    RHS       R1                            1324
    RHS       R2                            1554
    RHS       R3                            1429
    RHS       R4                            1686
    RHS       R5                            1482
    RHS       R6                            1613
    RHS       R7                            1424
BOUNDS
 FX BND       X1                            0
 FX BND       X3                            0
 FX BND       X5                            0
 FX BND       X7                            0
 FX BND       X9                            0
 FX BND       X11                           0
 FX BND       X13                           0
 UP BND       X14                           1
 UP BND       X15                           1
 UP BND       X16                           1
 UP BND       X17                           1
 UP BND       X18                           1
 UP BND       X19                           1
 UP BND       X20                           1
 UP BND       X21                           1
 UP BND       X22                           1
 UP BND       X23                           1
 UP BND       X24                           1
 UP BND       X25                           1
 UP BND       X26                           1
 UP BND       X27                           1
 UP BND       X28                           1
 UP BND       X29                           1
 UP BND       X30                           1
 UP BND       X31                           1
 UP BND       X32                           1
 UP BND       X33                           1
 UP BND       X34                           1
 UP BND       X35                           1
 UP BND       X36                           1
 UP BND       X37                           1
 UP BND       X38                           1
 UP BND       X39                           1
 UP BND       X40                           1
 UP BND       X41                           1
 UP BND       X42                           1
 UP BND       X43                           1
 UP BND       X44                           1
 UP BND       X45                           1
 UP BND       X46                           1
 UP BND       X47                           1
 UP BND       X48                           1
 UP BND       X49                           1
 UP BND       X50                           1
 UP BND       X51                           1
 UP BND       X52                           1
 UP BND       X53                           1
 UP BND       X54                           1
 UP BND       X55                           1
 UP BND       X56                           1
 UP BND       X57                           1
 UP BND       X58                           1
 UP BND       X59                           1
 UP BND       X60                           1
 UP BND       X61                           1
 UP BND       X62                           1
 UP BND       X63                           1
 UP BND       X64                           1
 UP BND       X65                           1
 UP BND       X66                           1
 UP BND       X67                           1
 UP BND       X68                           1
 UP BND       X69                           1
 UP BND       X70                           1
 UP BND       X71                           1
 UP BND       X72                           1
 UP BND       X73                           1
ENDATA
