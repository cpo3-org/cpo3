NAME          lotsize
ROWS
 E R0
 E R1
 E R2
 E R3
 E R4
 E R5
 E R6
 E R7
 E R8
 E R9
 E R10
 E R11
 E R12
 E R13
 E R14
 E R15
 E R16
 E R17
 E R18
 E R19
 E R20
 E R21
 E R22
 E R23
 E R24
 E R25
 E R26
 E R27
 E R28
 E R29
 E R30
 E R31
 E R32
 E R33
 E R34
 E R35
 E R36
 E R37
 E R38
 E R39
 E R40
 E R41
 E R42
 E R43
 E R44
 E R45
 E R46
 E R47
 E R48
 E R49
 E R50
 E R51
 E R52
 E R53
 E R54
 E R55
 E R56
 E R57
 E R58
 E R59
 E R60
 E R61
 E R62
 E R63
 E R64
 E R65
 E R66
 E R67
 E R68
 E R69
 E R70
 E R71
 E R72
 E R73
 E R74
 E R75
 E R76
 E R77
 E R78
 E R79
 E R80
 E R81
 E R82
 E R83
 E R84
 E R85
 E R86
 E R87
 E R88
 E R89
 E R90
 E R91
 E R92
 E R93
 E R94
 E R95
 E R96
 E R97
 E R98
 E R99
 E R100
 E R101
 E R102
 E R103
 E R104
 E R105
 E R106
 E R107
 E R108
 E R109
 E R110
 E R111
 E R112
 E R113
 E R114
 E R115
 E R116
 E R117
 E R118
 E R119
 E R120
 E R121
 E R122
 E R123
 E R124
 E R125
 E R126
 E R127
 E R128
 E R129
 E R130
 E R131
 E R132
 E R133
 E R134
 E R135
 E R136
 E R137
 E R138
 E R139
 E R140
 E R141
 E R142
 E R143
 E R144
 E R145
 E R146
 E R147
 E R148
 E R149
 E R150
 E R151
 E R152
 E R153
 E R154
 E R155
 E R156
 E R157
 E R158
 E R159
 E R160
 E R161
 E R162
 E R163
 E R164
 E R165
 E R166
 E R167
 E R168
 E R169
 E R170
 E R171
 E R172
 E R173
 E R174
 E R175
 E R176
 E R177
 E R178
 E R179
 E R180
 E R181
 E R182
 E R183
 E R184
 E R185
 E R186
 E R187
 E R188
 E R189
 E R190
 E R191
 E R192
 E R193
 E R194
 E R195
 E R196
 E R197
 E R198
 E R199
 E R200
 E R201
 E R202
 E R203
 E R204
 E R205
 E R206
 E R207
 E R208
 E R209
 E R210
 E R211
 E R212
 E R213
 E R214
 E R215
 E R216
 E R217
 E R218
 E R219
 E R220
 E R221
 E R222
 E R223
 E R224
 E R225
 E R226
 E R227
 E R228
 E R229
 E R230
 E R231
 E R232
 E R233
 E R234
 E R235
 E R236
 E R237
 E R238
 E R239
 E R240
 E R241
 E R242
 E R243
 E R244
 E R245
 E R246
 E R247
 E R248
 E R249
 E R250
 E R251
 E R252
 E R253
 E R254
 E R255
 E R256
 E R257
 E R258
 E R259
 E R260
 E R261
 E R262
 E R263
 E R264
 E R265
 E R266
 E R267
 E R268
 E R269
 E R270
 E R271
 E R272
 E R273
 E R274
 E R275
 E R276
 E R277
 E R278
 E R279
 E R280
 E R281
 E R282
 E R283
 E R284
 E R285
 E R286
 E R287
 E R288
 E R289
 E R290
 E R291
 E R292
 E R293
 E R294
 E R295
 E R296
 E R297
 E R298
 E R299
 E R300
 E R301
 E R302
 E R303
 E R304
 E R305
 E R306
 E R307
 E R308
 E R309
 E R310
 E R311
 E R312
 E R313
 E R314
 E R315
 E R316
 E R317
 E R318
 E R319
 E R320
 E R321
 E R322
 E R323
 E R324
 E R325
 E R326
 E R327
 E R328
 E R329
 E R330
 E R331
 E R332
 E R333
 E R334
 E R335
 E R336
 E R337
 E R338
 E R339
 E R340
 E R341
 E R342
 E R343
 E R344
 E R345
 E R346
 E R347
 E R348
 E R349
 E R350
 E R351
 E R352
 E R353
 E R354
 E R355
 E R356
 E R357
 E R358
 E R359
 E R360
 E R361
 E R362
 E R363
 E R364
 E R365
 E R366
 E R367
 E R368
 E R369
 E R370
 E R371
 E R372
 E R373
 E R374
 E R375
 E R376
 E R377
 E R378
 E R379
 E R380
 E R381
 E R382
 E R383
 E R384
 E R385
 E R386
 E R387
 E R388
 E R389
 E R390
 E R391
 E R392
 E R393
 E R394
 E R395
 E R396
 E R397
 E R398
 E R399
 E R400
 E R401
 E R402
 E R403
 E R404
 E R405
 E R406
 E R407
 E R408
 E R409
 E R410
 E R411
 E R412
 E R413
 E R414
 E R415
 E R416
 E R417
 E R418
 E R419
 E R420
 E R421
 E R422
 E R423
 E R424
 E R425
 E R426
 E R427
 E R428
 E R429
 E R430
 E R431
 E R432
 E R433
 E R434
 E R435
 E R436
 E R437
 E R438
 E R439
 E R440
 E R441
 E R442
 E R443
 E R444
 E R445
 E R446
 E R447
 E R448
 E R449
 E R450
 E R451
 E R452
 E R453
 E R454
 E R455
 E R456
 E R457
 E R458
 E R459
 E R460
 E R461
 E R462
 E R463
 E R464
 E R465
 E R466
 E R467
 E R468
 E R469
 E R470
 E R471
 E R472
 E R473
 E R474
 E R475
 E R476
 E R477
 E R478
 E R479
 E R480
 E R481
 E R482
 E R483
 E R484
 E R485
 E R486
 E R487
 E R488
 E R489
 E R490
 E R491
 E R492
 E R493
 E R494
 E R495
 E R496
 E R497
 E R498
 E R499
 E R500
 E R501
 E R502
 E R503
 E R504
 E R505
 E R506
 E R507
 E R508
 E R509
 E R510
 E R511
 E R512
 E R513
 E R514
 E R515
 E R516
 E R517
 E R518
 E R519
 E R520
 E R521
 E R522
 E R523
 E R524
 E R525
 E R526
 E R527
 E R528
 E R529
 E R530
 E R531
 E R532
 E R533
 E R534
 E R535
 E R536
 E R537
 E R538
 E R539
 E R540
 E R541
 E R542
 E R543
 E R544
 E R545
 E R546
 E R547
 E R548
 E R549
 E R550
 E R551
 E R552
 E R553
 E R554
 E R555
 E R556
 E R557
 E R558
 E R559
 E R560
 E R561
 E R562
 E R563
 E R564
 E R565
 E R566
 E R567
 E R568
 E R569
 E R570
 E R571
 E R572
 E R573
 E R574
 E R575
 E R576
 E R577
 E R578
 E R579
 E R580
 E R581
 E R582
 E R583
 E R584
 E R585
 E R586
 E R587
 E R588
 E R589
 E R590
 E R591
 E R592
 E R593
 E R594
 E R595
 E R596
 E R597
 E R598
 E R599
 L R600
 L R601
 L R602
 L R603
 L R604
 L R605
 L R606
 L R607
 L R608
 L R609
 L R610
 L R611
 L R612
 L R613
 L R614
 L R615
 L R616
 L R617
 L R618
 L R619
 L R620
 L R621
 L R622
 L R623
 L R624
 L R625
 L R626
 L R627
 L R628
 L R629
 L R630
 L R631
 L R632
 L R633
 L R634
 L R635
 L R636
 L R637
 L R638
 L R639
 L R640
 L R641
 L R642
 L R643
 L R644
 L R645
 L R646
 L R647
 L R648
 L R649
 L R650
 L R651
 L R652
 L R653
 L R654
 L R655
 L R656
 L R657
 L R658
 L R659
 L R660
 L R661
 L R662
 L R663
 L R664
 L R665
 L R666
 L R667
 L R668
 L R669
 L R670
 L R671
 L R672
 L R673
 L R674
 L R675
 L R676
 L R677
 L R678
 L R679
 L R680
 L R681
 L R682
 L R683
 L R684
 L R685
 L R686
 L R687
 L R688
 L R689
 L R690
 L R691
 L R692
 L R693
 L R694
 L R695
 L R696
 L R697
 L R698
 L R699
 L R700
 L R701
 L R702
 L R703
 L R704
 L R705
 L R706
 L R707
 L R708
 L R709
 L R710
 L R711
 L R712
 L R713
 L R714
 L R715
 L R716
 L R717
 L R718
 L R719
 L R720
 L R721
 L R722
 L R723
 L R724
 L R725
 L R726
 L R727
 L R728
 L R729
 L R730
 L R731
 L R732
 L R733
 L R734
 L R735
 L R736
 L R737
 L R738
 L R739
 L R740
 L R741
 L R742
 L R743
 L R744
 L R745
 L R746
 L R747
 L R748
 L R749
 L R750
 L R751
 L R752
 L R753
 L R754
 L R755
 L R756
 L R757
 L R758
 L R759
 L R760
 L R761
 L R762
 L R763
 L R764
 L R765
 L R766
 L R767
 L R768
 L R769
 L R770
 L R771
 L R772
 L R773
 L R774
 L R775
 L R776
 L R777
 L R778
 L R779
 L R780
 L R781
 L R782
 L R783
 L R784
 L R785
 L R786
 L R787
 L R788
 L R789
 L R790
 L R791
 L R792
 L R793
 L R794
 L R795
 L R796
 L R797
 L R798
 L R799
 L R800
 L R801
 L R802
 L R803
 L R804
 L R805
 L R806
 L R807
 L R808
 L R809
 L R810
 L R811
 L R812
 L R813
 L R814
 L R815
 L R816
 L R817
 L R818
 L R819
 L R820
 L R821
 L R822
 L R823
 L R824
 L R825
 L R826
 L R827
 L R828
 L R829
 L R830
 L R831
 L R832
 L R833
 L R834
 L R835
 L R836
 L R837
 L R838
 L R839
 L R840
 L R841
 L R842
 L R843
 L R844
 L R845
 L R846
 L R847
 L R848
 L R849
 L R850
 L R851
 L R852
 L R853
 L R854
 L R855
 L R856
 L R857
 L R858
 L R859
 L R860
 L R861
 L R862
 L R863
 L R864
 L R865
 L R866
 L R867
 L R868
 L R869
 L R870
 L R871
 L R872
 L R873
 L R874
 L R875
 L R876
 L R877
 L R878
 L R879
 L R880
 L R881
 L R882
 L R883
 L R884
 L R885
 L R886
 L R887
 L R888
 L R889
 L R890
 L R891
 L R892
 L R893
 L R894
 L R895
 L R896
 L R897
 L R898
 L R899
 L R900
 L R901
 L R902
 L R903
 L R904
 L R905
 L R906
 L R907
 L R908
 L R909
 L R910
 L R911
 L R912
 L R913
 L R914
 L R915
 L R916
 L R917
 L R918
 L R919
 L R920
 L R921
 L R922
 L R923
 L R924
 L R925
 L R926
 L R927
 L R928
 L R929
 L R930
 L R931
 L R932
 L R933
 L R934
 L R935
 L R936
 L R937
 L R938
 L R939
 L R940
 L R941
 L R942
 L R943
 L R944
 L R945
 L R946
 L R947
 L R948
 L R949
 L R950
 L R951
 L R952
 L R953
 L R954
 L R955
 L R956
 L R957
 L R958
 L R959
 L R960
 L R961
 L R962
 L R963
 L R964
 L R965
 L R966
 L R967
 L R968
 L R969
 L R970
 L R971
 L R972
 L R973
 L R974
 L R975
 L R976
 L R977
 L R978
 L R979
 L R980
 L R981
 L R982
 L R983
 L R984
 L R985
 L R986
 L R987
 L R988
 L R989
 L R990
 L R991
 L R992
 L R993
 L R994
 L R995
 L R996
 L R997
 L R998
 L R999
 L R1000
 L R1001
 L R1002
 L R1003
 L R1004
 L R1005
 L R1006
 L R1007
 L R1008
 L R1009
 L R1010
 L R1011
 L R1012
 L R1013
 L R1014
 L R1015
 L R1016
 L R1017
 L R1018
 L R1019
 L R1020
 L R1021
 L R1022
 L R1023
 L R1024
 L R1025
 L R1026
 L R1027
 L R1028
 L R1029
 L R1030
 L R1031
 L R1032
 L R1033
 L R1034
 L R1035
 L R1036
 L R1037
 L R1038
 L R1039
 L R1040
 L R1041
 L R1042
 L R1043
 L R1044
 L R1045
 L R1046
 L R1047
 L R1048
 L R1049
 L R1050
 L R1051
 L R1052
 L R1053
 L R1054
 L R1055
 L R1056
 L R1057
 L R1058
 L R1059
 L R1060
 L R1061
 L R1062
 L R1063
 L R1064
 L R1065
 L R1066
 L R1067
 L R1068
 L R1069
 L R1070
 L R1071
 L R1072
 L R1073
 L R1074
 L R1075
 L R1076
 L R1077
 L R1078
 L R1079
 L R1080
 L R1081
 L R1082
 L R1083
 L R1084
 L R1085
 L R1086
 L R1087
 L R1088
 L R1089
 L R1090
 L R1091
 L R1092
 L R1093
 L R1094
 L R1095
 L R1096
 L R1097
 L R1098
 L R1099
 L R1100
 L R1101
 L R1102
 L R1103
 L R1104
 L R1105
 L R1106
 L R1107
 L R1108
 L R1109
 L R1110
 L R1111
 L R1112
 L R1113
 L R1114
 L R1115
 L R1116
 L R1117
 L R1118
 L R1119
 L R1120
 L R1121
 L R1122
 L R1123
 L R1124
 L R1125
 L R1126
 L R1127
 L R1128
 L R1129
 L R1130
 L R1131
 L R1132
 L R1133
 L R1134
 L R1135
 L R1136
 L R1137
 L R1138
 L R1139
 L R1140
 L R1141
 L R1142
 L R1143
 L R1144
 L R1145
 L R1146
 L R1147
 L R1148
 L R1149
 L R1150
 L R1151
 L R1152
 L R1153
 L R1154
 L R1155
 L R1156
 L R1157
 L R1158
 L R1159
 L R1160
 L R1161
 L R1162
 L R1163
 L R1164
 L R1165
 L R1166
 L R1167
 L R1168
 L R1169
 L R1170
 L R1171
 L R1172
 L R1173
 L R1174
 L R1175
 L R1176
 L R1177
 L R1178
 L R1179
 L R1180
 L R1181
 L R1182
 L R1183
 L R1184
 L R1185
 L R1186
 L R1187
 L R1188
 L R1189
 L R1190
 L R1191
 L R1192
 L R1193
 L R1194
 L R1195
 L R1196
 L R1197
 L R1198
 L R1199
 L R1200
 L R1201
 L R1202
 L R1203
 L R1204
 L R1205
 L R1206
 L R1207
 L R1208
 L R1209
 L R1210
 L R1211
 L R1212
 L R1213
 L R1214
 L R1215
 L R1216
 L R1217
 L R1218
 L R1219
 L R1220
 L R1221
 L R1222
 L R1223
 L R1224
 L R1225
 L R1226
 L R1227
 L R1228
 L R1229
 L R1230
 L R1231
 L R1232
 L R1233
 L R1234
 L R1235
 L R1236
 L R1237
 L R1238
 L R1239
 L R1240
 L R1241
 L R1242
 L R1243
 L R1244
 L R1245
 L R1246
 L R1247
 L R1248
 L R1249
 L R1250
 L R1251
 L R1252
 L R1253
 L R1254
 L R1255
 L R1256
 L R1257
 L R1258
 L R1259
 L R1260
 L R1261
 L R1262
 L R1263
 L R1264
 L R1265
 L R1266
 L R1267
 L R1268
 L R1269
 L R1270
 L R1271
 L R1272
 L R1273
 L R1274
 L R1275
 L R1276
 L R1277
 L R1278
 L R1279
 L R1280
 L R1281
 L R1282
 L R1283
 L R1284
 L R1285
 L R1286
 L R1287
 L R1288
 L R1289
 L R1290
 L R1291
 L R1292
 L R1293
 L R1294
 L R1295
 L R1296
 L R1297
 L R1298
 L R1299
 L R1300
 L R1301
 L R1302
 L R1303
 L R1304
 L R1305
 L R1306
 L R1307
 L R1308
 L R1309
 L R1310
 L R1311
 L R1312
 L R1313
 L R1314
 L R1315
 L R1316
 L R1317
 L R1318
 L R1319
 L R1320
 L R1321
 L R1322
 L R1323
 L R1324
 L R1325
 L R1326
 L R1327
 L R1328
 L R1329
 L R1330
 L R1331
 L R1332
 L R1333
 L R1334
 L R1335
 L R1336
 L R1337
 L R1338
 L R1339
 L R1340
 L R1341
 L R1342
 L R1343
 L R1344
 L R1345
 L R1346
 L R1347
 L R1348
 L R1349
 L R1350
 L R1351
 L R1352
 L R1353
 L R1354
 L R1355
 L R1356
 L R1357
 L R1358
 L R1359
 L R1360
 L R1361
 L R1362
 L R1363
 L R1364
 L R1365
 L R1366
 L R1367
 L R1368
 L R1369
 L R1370
 L R1371
 L R1372
 L R1373
 L R1374
 L R1375
 L R1376
 L R1377
 L R1378
 L R1379
 L R1380
 L R1381
 L R1382
 L R1383
 L R1384
 L R1385
 L R1386
 L R1387
 L R1388
 L R1389
 L R1390
 L R1391
 L R1392
 L R1393
 L R1394
 L R1395
 L R1396
 L R1397
 L R1398
 L R1399
 L R1400
 L R1401
 L R1402
 L R1403
 L R1404
 L R1405
 L R1406
 L R1407
 L R1408
 L R1409
 L R1410
 L R1411
 L R1412
 L R1413
 L R1414
 L R1415
 L R1416
 L R1417
 L R1418
 L R1419
 L R1420
 L R1421
 L R1422
 L R1423
 L R1424
 L R1425
 L R1426
 L R1427
 L R1428
 L R1429
 L R1430
 L R1431
 L R1432
 L R1433
 L R1434
 L R1435
 L R1436
 L R1437
 L R1438
 L R1439
 L R1440
 L R1441
 L R1442
 L R1443
 L R1444
 L R1445
 L R1446
 L R1447
 L R1448
 L R1449
 L R1450
 L R1451
 L R1452
 L R1453
 L R1454
 L R1455
 L R1456
 L R1457
 L R1458
 L R1459
 L R1460
 L R1461
 L R1462
 L R1463
 L R1464
 L R1465
 L R1466
 L R1467
 L R1468
 L R1469
 L R1470
 L R1471
 L R1472
 L R1473
 L R1474
 L R1475
 L R1476
 L R1477
 L R1478
 L R1479
 L R1480
 L R1481
 L R1482
 L R1483
 L R1484
 L R1485
 L R1486
 L R1487
 L R1488
 L R1489
 L R1490
 L R1491
 L R1492
 L R1493
 L R1494
 L R1495
 L R1496
 L R1497
 L R1498
 L R1499
 L R1500
 L R1501
 L R1502
 L R1503
 L R1504
 L R1505
 L R1506
 L R1507
 L R1508
 L R1509
 L R1510
 L R1511
 L R1512
 L R1513
 L R1514
 L R1515
 L R1516
 L R1517
 L R1518
 L R1519
 L R1520
 L R1521
 L R1522
 L R1523
 L R1524
 L R1525
 L R1526
 L R1527
 L R1528
 L R1529
 L R1530
 L R1531
 L R1532
 L R1533
 L R1534
 L R1535
 L R1536
 L R1537
 L R1538
 L R1539
 L R1540
 L R1541
 L R1542
 L R1543
 L R1544
 L R1545
 L R1546
 L R1547
 L R1548
 L R1549
 L R1550
 L R1551
 L R1552
 L R1553
 L R1554
 L R1555
 L R1556
 L R1557
 L R1558
 L R1559
 L R1560
 L R1561
 L R1562
 L R1563
 L R1564
 L R1565
 L R1566
 L R1567
 L R1568
 L R1569
 L R1570
 L R1571
 L R1572
 L R1573
 L R1574
 L R1575
 L R1576
 L R1577
 L R1578
 L R1579
 L R1580
 L R1581
 L R1582
 L R1583
 L R1584
 L R1585
 L R1586
 L R1587
 L R1588
 L R1589
 L R1590
 L R1591
 L R1592
 L R1593
 L R1594
 L R1595
 L R1596
 L R1597
 L R1598
 L R1599
 L R1600
 L R1601
 L R1602
 L R1603
 L R1604
 L R1605
 L R1606
 L R1607
 L R1608
 L R1609
 L R1610
 L R1611
 L R1612
 L R1613
 L R1614
 L R1615
 L R1616
 L R1617
 L R1618
 L R1619
 L R1620
 L R1621
 L R1622
 L R1623
 L R1624
 L R1625
 L R1626
 L R1627
 L R1628
 L R1629
 L R1630
 L R1631
 L R1632
 L R1633
 L R1634
 L R1635
 L R1636
 L R1637
 L R1638
 L R1639
 L R1640
 L R1641
 L R1642
 L R1643
 L R1644
 L R1645
 L R1646
 L R1647
 L R1648
 L R1649
 L R1650
 L R1651
 L R1652
 L R1653
 L R1654
 L R1655
 L R1656
 L R1657
 L R1658
 L R1659
 L R1660
 L R1661
 L R1662
 L R1663
 L R1664
 L R1665
 L R1666
 L R1667
 L R1668
 L R1669
 L R1670
 L R1671
 L R1672
 L R1673
 L R1674
 L R1675
 L R1676
 L R1677
 L R1678
 L R1679
 L R1680
 L R1681
 L R1682
 L R1683
 L R1684
 L R1685
 L R1686
 L R1687
 L R1688
 L R1689
 L R1690
 L R1691
 L R1692
 L R1693
 L R1694
 L R1695
 L R1696
 L R1697
 L R1698
 L R1699
 L R1700
 L R1701
 L R1702
 L R1703
 L R1704
 L R1705
 L R1706
 L R1707
 L R1708
 L R1709
 L R1710
 L R1711
 L R1712
 L R1713
 L R1714
 L R1715
 L R1716
 L R1717
 L R1718
 L R1719
 L R1720
 L R1721
 L R1722
 L R1723
 L R1724
 L R1725
 L R1726
 L R1727
 L R1728
 L R1729
 L R1730
 L R1731
 L R1732
 L R1733
 L R1734
 L R1735
 L R1736
 L R1737
 L R1738
 L R1739
 L R1740
 L R1741
 L R1742
 L R1743
 L R1744
 L R1745
 L R1746
 L R1747
 L R1748
 L R1749
 L R1750
 L R1751
 L R1752
 L R1753
 L R1754
 L R1755
 L R1756
 L R1757
 L R1758
 L R1759
 L R1760
 L R1761
 L R1762
 L R1763
 L R1764
 L R1765
 L R1766
 L R1767
 L R1768
 L R1769
 L R1770
 L R1771
 L R1772
 L R1773
 L R1774
 L R1775
 L R1776
 L R1777
 L R1778
 L R1779
 L R1780
 L R1781
 L R1782
 L R1783
 L R1784
 L R1785
 L R1786
 L R1787
 L R1788
 L R1789
 L R1790
 L R1791
 L R1792
 L R1793
 L R1794
 L R1795
 L R1796
 L R1797
 L R1798
 L R1799
 L R1800
 L R1801
 L R1802
 L R1803
 L R1804
 L R1805
 L R1806
 L R1807
 L R1808
 L R1809
 L R1810
 L R1811
 L R1812
 L R1813
 L R1814
 L R1815
 L R1816
 L R1817
 L R1818
 L R1819
 L R1820
 L R1821
 L R1822
 L R1823
 L R1824
 L R1825
 L R1826
 L R1827
 L R1828
 L R1829
 L R1830
 L R1831
 L R1832
 L R1833
 L R1834
 L R1835
 L R1836
 L R1837
 L R1838
 L R1839
 L R1840
 L R1841
 L R1842
 L R1843
 L R1844
 L R1845
 L R1846
 L R1847
 L R1848
 L R1849
 L R1850
 L R1851
 L R1852
 L R1853
 L R1854
 L R1855
 L R1856
 L R1857
 L R1858
 L R1859
 L R1860
 L R1861
 L R1862
 L R1863
 L R1864
 L R1865
 L R1866
 L R1867
 L R1868
 L R1869
 L R1870
 L R1871
 L R1872
 L R1873
 L R1874
 L R1875
 L R1876
 L R1877
 L R1878
 L R1879
 L R1880
 L R1881
 L R1882
 L R1883
 L R1884
 L R1885
 L R1886
 L R1887
 L R1888
 L R1889
 L R1890
 L R1891
 L R1892
 L R1893
 L R1894
 L R1895
 L R1896
 L R1897
 L R1898
 L R1899
 L R1900
 L R1901
 L R1902
 L R1903
 L R1904
 L R1905
 L R1906
 L R1907
 L R1908
 L R1909
 L R1910
 L R1911
 L R1912
 L R1913
 L R1914
 L R1915
 L R1916
 L R1917
 L R1918
 L R1919
 N R1920
COLUMNS
    X0        R0                            1
    X0        R600                          1
    X0        R1920                         8
    X1        R1                            1
    X1        R601                          1
    X1        R1920                         8
    X2        R2                            1
    X2        R602                          1
    X2        R1920                         9
    X3        R3                            1
    X3        R603                          1
    X3        R1920                         1
    X4        R4                            1
    X4        R604                          1
    X4        R1920                         3
    X5        R5                            1
    X5        R605                          1
    X5        R1920                         1
    X6        R6                            1
    X6        R606                          1
    X6        R1920                         5
    X7        R7                            1
    X7        R607                          1
    X7        R1920                         3
    X8        R8                            1
    X8        R608                          1
    X8        R1920                         8
    X9        R9                            1
    X9        R609                          1
    X9        R1920                         4
    X10       R10                           1
    X10       R610                          1
    X10       R1920                         9
    X11       R11                           1
    X11       R611                          1
    X11       R1920                         2
    X12       R12                           1
    X12       R612                          1
    X12       R1920                         6
    X13       R13                           1
    X13       R613                          1
    X13       R1920                         3
    X14       R14                           1
    X14       R614                          1
    X14       R1920                         6
    X15       R15                           1
    X15       R615                          1
    X15       R1920                         1
    X16       R16                           1
    X16       R616                          1
    X16       R1920                         8
    X17       R17                           1
    X17       R617                          1
    X17       R1920                         5
    X18       R18                           1
    X18       R618                          1
    X18       R1920                         7
    X19       R19                           1
    X19       R619                          1
    X19       R1920                         3
    X20       R20                           1
    X20       R620                          1
    X20       R1920                         4
    X21       R21                           1
    X21       R621                          1
    X21       R1920                         9
    X22       R22                           1
    X22       R622                          1
    X22       R1920                         4
    X23       R23                           1
    X23       R623                          1
    X23       R1920                         6
    X24       R24                           1
    X24       R624                          1
    X24       R1920                         7
    X25       R25                           1
    X25       R625                          1
    X25       R1920                         3
    X26       R26                           1
    X26       R626                          1
    X26       R1920                         9
    X27       R27                           1
    X27       R627                          1
    X27       R1920                         7
    X28       R28                           1
    X28       R628                          1
    X28       R1920                         2
    X29       R29                           1
    X29       R629                          1
    X29       R1920                         5
    X30       R30                           1
    X30       R630                          1
    X30       R1920                         6
    X31       R31                           1
    X31       R631                          1
    X31       R1920                         7
    X32       R32                           1
    X32       R632                          1
    X32       R1920                         5
    X33       R33                           1
    X33       R633                          1
    X33       R1920                         8
    X34       R34                           1
    X34       R634                          1
    X34       R1920                         3
    X35       R35                           1
    X35       R635                          1
    X35       R1920                         4
    X36       R36                           1
    X36       R636                          1
    X36       R1920                         6
    X37       R37                           1
    X37       R637                          1
    X37       R1920                         4
    X38       R38                           1
    X38       R638                          1
    X38       R1920                         2
    X39       R39                           1
    X39       R639                          1
    X39       R1920                         2
    X40       R40                           1
    X40       R640                          1
    X40       R1920                         2
    X41       R41                           1
    X41       R641                          1
    X41       R1920                         4
    X42       R42                           1
    X42       R642                          1
    X42       R1920                         9
    X43       R43                           1
    X43       R643                          1
    X43       R1920                         7
    X44       R44                           1
    X44       R644                          1
    X44       R1920                         6
    X45       R45                           1
    X45       R645                          1
    X45       R1920                         4
    X46       R46                           1
    X46       R646                          1
    X46       R1920                         7
    X47       R47                           1
    X47       R647                          1
    X47       R1920                         9
    X48       R48                           1
    X48       R648                          1
    X48       R1920                         9
    X49       R49                           1
    X49       R649                          1
    X49       R1920                         2
    X50       R50                           1
    X50       R650                          1
    X50       R1920                         6
    X51       R51                           1
    X51       R651                          1
    X51       R1920                         1
    X52       R52                           1
    X52       R652                          1
    X52       R1920                         9
    X53       R53                           1
    X53       R653                          1
    X53       R1920                         7
    X54       R54                           1
    X54       R654                          1
    X54       R1920                         8
    X55       R55                           1
    X55       R655                          1
    X55       R1920                         3
    X56       R56                           1
    X56       R656                          1
    X56       R1920                         3
    X57       R57                           1
    X57       R657                          1
    X57       R1920                         6
    X58       R58                           1
    X58       R658                          1
    X58       R1920                         8
    X59       R59                           1
    X59       R659                          1
    X59       R1920                         6
    X60       R60                           1
    X60       R660                          1
    X60       R1920                         4
    X61       R61                           1
    X61       R661                          1
    X61       R1920                         2
    X62       R62                           1
    X62       R662                          1
    X62       R1920                         9
    X63       R63                           1
    X63       R663                          1
    X63       R1920                         4
    X64       R64                           1
    X64       R664                          1
    X64       R1920                         4
    X65       R65                           1
    X65       R665                          1
    X65       R1920                         5
    X66       R66                           1
    X66       R666                          1
    X66       R1920                         1
    X67       R67                           1
    X67       R667                          1
    X67       R1920                         6
    X68       R68                           1
    X68       R668                          1
    X68       R1920                         5
    X69       R69                           1
    X69       R669                          1
    X69       R1920                         1
    X70       R70                           1
    X70       R670                          1
    X70       R1920                         3
    X71       R71                           1
    X71       R671                          1
    X71       R1920                         1
    X72       R72                           1
    X72       R672                          1
    X72       R1920                         5
    X73       R73                           1
    X73       R673                          1
    X73       R1920                         1
    X74       R74                           1
    X74       R674                          1
    X74       R1920                         3
    X75       R75                           1
    X75       R675                          1
    X75       R1920                         2
    X76       R76                           1
    X76       R676                          1
    X76       R1920                         6
    X77       R77                           1
    X77       R677                          1
    X77       R1920                         6
    X78       R78                           1
    X78       R678                          1
    X78       R1920                         4
    X79       R79                           1
    X79       R679                          1
    X79       R1920                         7
    X80       R80                           1
    X80       R680                          1
    X80       R1920                         4
    X81       R81                           1
    X81       R681                          1
    X81       R1920                         4
    X82       R82                           1
    X82       R682                          1
    X82       R1920                         5
    X83       R83                           1
    X83       R683                          1
    X83       R1920                         7
    X84       R84                           1
    X84       R684                          1
    X84       R1920                         4
    X85       R85                           1
    X85       R685                          1
    X85       R1920                         8
    X86       R86                           1
    X86       R686                          1
    X86       R1920                         3
    X87       R87                           1
    X87       R687                          1
    X87       R1920                         3
    X88       R88                           1
    X88       R688                          1
    X88       R1920                         5
    X89       R89                           1
    X89       R689                          1
    X89       R1920                         6
    X90       R90                           1
    X90       R690                          1
    X90       R1920                         8
    X91       R91                           1
    X91       R691                          1
    X91       R1920                         7
    X92       R92                           1
    X92       R692                          1
    X92       R1920                         8
    X93       R93                           1
    X93       R693                          1
    X93       R1920                         1
    X94       R94                           1
    X94       R694                          1
    X94       R1920                         4
    X95       R95                           1
    X95       R695                          1
    X95       R1920                         9
    X96       R96                           1
    X96       R696                          1
    X96       R1920                         5
    X97       R97                           1
    X97       R697                          1
    X97       R1920                         2
    X98       R98                           1
    X98       R698                          1
    X98       R1920                         5
    X99       R99                           1
    X99       R699                          1
    X99       R1920                         8
    X100      R100                          1
    X100      R700                          1
    X100      R1920                         9
    X101      R101                          1
    X101      R701                          1
    X101      R1920                         8
    X102      R102                          1
    X102      R702                          1
    X102      R1920                         4
    X103      R103                          1
    X103      R703                          1
    X103      R1920                         2
    X104      R104                          1
    X104      R704                          1
    X104      R1920                         8
    X105      R105                          1
    X105      R705                          1
    X105      R1920                         8
    X106      R106                          1
    X106      R706                          1
    X106      R1920                         6
    X107      R107                          1
    X107      R707                          1
    X107      R1920                         7
    X108      R108                          1
    X108      R708                          1
    X108      R1920                         1
    X109      R109                          1
    X109      R709                          1
    X109      R1920                         4
    X110      R110                          1
    X110      R710                          1
    X110      R1920                         4
    X111      R111                          1
    X111      R711                          1
    X111      R1920                         5
    X112      R112                          1
    X112      R712                          1
    X112      R1920                         2
    X113      R113                          1
    X113      R713                          1
    X113      R1920                         2
    X114      R114                          1
    X114      R714                          1
    X114      R1920                         9
    X115      R115                          1
    X115      R715                          1
    X115      R1920                         4
    X116      R116                          1
    X116      R716                          1
    X116      R1920                         1
    X117      R117                          1
    X117      R717                          1
    X117      R1920                         5
    X118      R118                          1
    X118      R718                          1
    X118      R1920                         2
    X119      R119                          1
    X119      R719                          1
    X119      R1920                         1
    X120      R120                          1
    X120      R720                          1
    X120      R1920                         8
    X121      R121                          1
    X121      R721                          1
    X121      R1920                         7
    X122      R122                          1
    X122      R722                          1
    X122      R1920                         3
    X123      R123                          1
    X123      R723                          1
    X123      R1920                         2
    X124      R124                          1
    X124      R724                          1
    X124      R1920                         2
    X125      R125                          1
    X125      R725                          1
    X125      R1920                         3
    X126      R126                          1
    X126      R726                          1
    X126      R1920                         8
    X127      R127                          1
    X127      R727                          1
    X127      R1920                         5
    X128      R128                          1
    X128      R728                          1
    X128      R1920                         9
    X129      R129                          1
    X129      R729                          1
    X129      R1920                         8
    X130      R130                          1
    X130      R730                          1
    X130      R1920                         7
    X131      R131                          1
    X131      R731                          1
    X131      R1920                         8
    X132      R132                          1
    X132      R732                          1
    X132      R1920                         2
    X133      R133                          1
    X133      R733                          1
    X133      R1920                         9
    X134      R134                          1
    X134      R734                          1
    X134      R1920                         6
    X135      R135                          1
    X135      R735                          1
    X135      R1920                         9
    X136      R136                          1
    X136      R736                          1
    X136      R1920                         2
    X137      R137                          1
    X137      R737                          1
    X137      R1920                         1
    X138      R138                          1
    X138      R738                          1
    X138      R1920                         2
    X139      R139                          1
    X139      R739                          1
    X139      R1920                         8
    X140      R140                          1
    X140      R740                          1
    X140      R1920                         4
    X141      R141                          1
    X141      R741                          1
    X141      R1920                         3
    X142      R142                          1
    X142      R742                          1
    X142      R1920                         5
    X143      R143                          1
    X143      R743                          1
    X143      R1920                         9
    X144      R144                          1
    X144      R744                          1
    X144      R1920                         6
    X145      R145                          1
    X145      R745                          1
    X145      R1920                         6
    X146      R146                          1
    X146      R746                          1
    X146      R1920                         5
    X147      R147                          1
    X147      R747                          1
    X147      R1920                         7
    X148      R148                          1
    X148      R748                          1
    X148      R1920                         9
    X149      R149                          1
    X149      R749                          1
    X149      R1920                         7
    X150      R150                          1
    X150      R750                          1
    X150      R1920                         8
    X151      R151                          1
    X151      R751                          1
    X151      R1920                         7
    X152      R152                          1
    X152      R752                          1
    X152      R1920                         8
    X153      R153                          1
    X153      R753                          1
    X153      R1920                         6
    X154      R154                          1
    X154      R754                          1
    X154      R1920                         8
    X155      R155                          1
    X155      R755                          1
    X155      R1920                         6
    X156      R156                          1
    X156      R756                          1
    X156      R1920                         4
    X157      R157                          1
    X157      R757                          1
    X157      R1920                         5
    X158      R158                          1
    X158      R758                          1
    X158      R1920                         4
    X159      R159                          1
    X159      R759                          1
    X159      R1920                         4
    X160      R160                          1
    X160      R760                          1
    X160      R1920                         1
    X161      R161                          1
    X161      R761                          1
    X161      R1920                         1
    X162      R162                          1
    X162      R762                          1
    X162      R1920                         9
    X163      R163                          1
    X163      R763                          1
    X163      R1920                         6
    X164      R164                          1
    X164      R764                          1
    X164      R1920                         7
    X165      R165                          1
    X165      R765                          1
    X165      R1920                         1
    X166      R166                          1
    X166      R766                          1
    X166      R1920                         3
    X167      R167                          1
    X167      R767                          1
    X167      R1920                         8
    X168      R168                          1
    X168      R768                          1
    X168      R1920                         3
    X169      R169                          1
    X169      R769                          1
    X169      R1920                         4
    X170      R170                          1
    X170      R770                          1
    X170      R1920                         5
    X171      R171                          1
    X171      R771                          1
    X171      R1920                         2
    X172      R172                          1
    X172      R772                          1
    X172      R1920                         2
    X173      R173                          1
    X173      R773                          1
    X173      R1920                         9
    X174      R174                          1
    X174      R774                          1
    X174      R1920                         6
    X175      R175                          1
    X175      R775                          1
    X175      R1920                         6
    X176      R176                          1
    X176      R776                          1
    X176      R1920                         2
    X177      R177                          1
    X177      R777                          1
    X177      R1920                         3
    X178      R178                          1
    X178      R778                          1
    X178      R1920                         8
    X179      R179                          1
    X179      R779                          1
    X179      R1920                         9
    X180      R180                          1
    X180      R780                          1
    X180      R1920                         2
    X181      R181                          1
    X181      R781                          1
    X181      R1920                         2
    X182      R182                          1
    X182      R782                          1
    X182      R1920                         4
    X183      R183                          1
    X183      R783                          1
    X183      R1920                         2
    X184      R184                          1
    X184      R784                          1
    X184      R1920                         1
    X185      R185                          1
    X185      R785                          1
    X185      R1920                         3
    X186      R186                          1
    X186      R786                          1
    X186      R1920                         2
    X187      R187                          1
    X187      R787                          1
    X187      R1920                         8
    X188      R188                          1
    X188      R788                          1
    X188      R1920                         8
    X189      R189                          1
    X189      R789                          1
    X189      R1920                         7
    X190      R190                          1
    X190      R790                          1
    X190      R1920                         7
    X191      R191                          1
    X191      R791                          1
    X191      R1920                         2
    X192      R192                          1
    X192      R792                          1
    X192      R1920                         9
    X193      R193                          1
    X193      R793                          1
    X193      R1920                         6
    X194      R194                          1
    X194      R794                          1
    X194      R1920                         8
    X195      R195                          1
    X195      R795                          1
    X195      R1920                         9
    X196      R196                          1
    X196      R796                          1
    X196      R1920                         5
    X197      R197                          1
    X197      R797                          1
    X197      R1920                         3
    X198      R198                          1
    X198      R798                          1
    X198      R1920                         1
    X199      R199                          1
    X199      R799                          1
    X199      R1920                         1
    X200      R200                          1
    X200      R800                          1
    X200      R1920                         8
    X201      R201                          1
    X201      R801                          1
    X201      R1920                         8
    X202      R202                          1
    X202      R802                          1
    X202      R1920                         9
    X203      R203                          1
    X203      R803                          1
    X203      R1920                         8
    X204      R204                          1
    X204      R804                          1
    X204      R1920                         2
    X205      R205                          1
    X205      R805                          1
    X205      R1920                         7
    X206      R206                          1
    X206      R806                          1
    X206      R1920                         1
    X207      R207                          1
    X207      R807                          1
    X207      R1920                         3
    X208      R208                          1
    X208      R808                          1
    X208      R1920                         4
    X209      R209                          1
    X209      R809                          1
    X209      R1920                         6
    X210      R210                          1
    X210      R810                          1
    X210      R1920                         3
    X211      R211                          1
    X211      R811                          1
    X211      R1920                         2
    X212      R212                          1
    X212      R812                          1
    X212      R1920                         8
    X213      R213                          1
    X213      R813                          1
    X213      R1920                         1
    X214      R214                          1
    X214      R814                          1
    X214      R1920                         5
    X215      R215                          1
    X215      R815                          1
    X215      R1920                         7
    X216      R216                          1
    X216      R816                          1
    X216      R1920                         4
    X217      R217                          1
    X217      R817                          1
    X217      R1920                         4
    X218      R218                          1
    X218      R818                          1
    X218      R1920                         8
    X219      R219                          1
    X219      R819                          1
    X219      R1920                         7
    X220      R220                          1
    X220      R820                          1
    X220      R1920                         7
    X221      R221                          1
    X221      R821                          1
    X221      R1920                         6
    X222      R222                          1
    X222      R822                          1
    X222      R1920                         8
    X223      R223                          1
    X223      R823                          1
    X223      R1920                         7
    X224      R224                          1
    X224      R824                          1
    X224      R1920                         3
    X225      R225                          1
    X225      R825                          1
    X225      R1920                         2
    X226      R226                          1
    X226      R826                          1
    X226      R1920                         4
    X227      R227                          1
    X227      R827                          1
    X227      R1920                         5
    X228      R228                          1
    X228      R828                          1
    X228      R1920                         3
    X229      R229                          1
    X229      R829                          1
    X229      R1920                         2
    X230      R230                          1
    X230      R830                          1
    X230      R1920                         4
    X231      R231                          1
    X231      R831                          1
    X231      R1920                         3
    X232      R232                          1
    X232      R832                          1
    X232      R1920                         4
    X233      R233                          1
    X233      R833                          1
    X233      R1920                         9
    X234      R234                          1
    X234      R834                          1
    X234      R1920                         3
    X235      R235                          1
    X235      R835                          1
    X235      R1920                         5
    X236      R236                          1
    X236      R836                          1
    X236      R1920                         5
    X237      R237                          1
    X237      R837                          1
    X237      R1920                         2
    X238      R238                          1
    X238      R838                          1
    X238      R1920                         1
    X239      R239                          1
    X239      R839                          1
    X239      R1920                         3
    X240      R240                          1
    X240      R840                          1
    X240      R1920                         8
    X241      R241                          1
    X241      R841                          1
    X241      R1920                         4
    X242      R242                          1
    X242      R842                          1
    X242      R1920                         7
    X243      R243                          1
    X243      R843                          1
    X243      R1920                         9
    X244      R244                          1
    X244      R844                          1
    X244      R1920                         7
    X245      R245                          1
    X245      R845                          1
    X245      R1920                         2
    X246      R246                          1
    X246      R846                          1
    X246      R1920                         6
    X247      R247                          1
    X247      R847                          1
    X247      R1920                         6
    X248      R248                          1
    X248      R848                          1
    X248      R1920                         2
    X249      R249                          1
    X249      R849                          1
    X249      R1920                         4
    X250      R250                          1
    X250      R850                          1
    X250      R1920                         9
    X251      R251                          1
    X251      R851                          1
    X251      R1920                         8
    X252      R252                          1
    X252      R852                          1
    X252      R1920                         1
    X253      R253                          1
    X253      R853                          1
    X253      R1920                         7
    X254      R254                          1
    X254      R854                          1
    X254      R1920                         5
    X255      R255                          1
    X255      R855                          1
    X255      R1920                         1
    X256      R256                          1
    X256      R856                          1
    X256      R1920                         4
    X257      R257                          1
    X257      R857                          1
    X257      R1920                         7
    X258      R258                          1
    X258      R858                          1
    X258      R1920                         8
    X259      R259                          1
    X259      R859                          1
    X259      R1920                         1
    X260      R260                          1
    X260      R860                          1
    X260      R1920                         9
    X261      R261                          1
    X261      R861                          1
    X261      R1920                         8
    X262      R262                          1
    X262      R862                          1
    X262      R1920                         1
    X263      R263                          1
    X263      R863                          1
    X263      R1920                         7
    X264      R264                          1
    X264      R864                          1
    X264      R1920                         2
    X265      R265                          1
    X265      R865                          1
    X265      R1920                         8
    X266      R266                          1
    X266      R866                          1
    X266      R1920                         9
    X267      R267                          1
    X267      R867                          1
    X267      R1920                         8
    X268      R268                          1
    X268      R868                          1
    X268      R1920                         6
    X269      R269                          1
    X269      R869                          1
    X269      R1920                         7
    X270      R270                          1
    X270      R870                          1
    X270      R1920                         3
    X271      R271                          1
    X271      R871                          1
    X271      R1920                         3
    X272      R272                          1
    X272      R872                          1
    X272      R1920                         9
    X273      R273                          1
    X273      R873                          1
    X273      R1920                         1
    X274      R274                          1
    X274      R874                          1
    X274      R1920                         1
    X275      R275                          1
    X275      R875                          1
    X275      R1920                         3
    X276      R276                          1
    X276      R876                          1
    X276      R1920                         4
    X277      R277                          1
    X277      R877                          1
    X277      R1920                         3
    X278      R278                          1
    X278      R878                          1
    X278      R1920                         2
    X279      R279                          1
    X279      R879                          1
    X279      R1920                         2
    X280      R280                          1
    X280      R880                          1
    X280      R1920                         9
    X281      R281                          1
    X281      R881                          1
    X281      R1920                         4
    X282      R282                          1
    X282      R882                          1
    X282      R1920                         8
    X283      R283                          1
    X283      R883                          1
    X283      R1920                         5
    X284      R284                          1
    X284      R884                          1
    X284      R1920                         7
    X285      R285                          1
    X285      R885                          1
    X285      R1920                         3
    X286      R286                          1
    X286      R886                          1
    X286      R1920                         6
    X287      R287                          1
    X287      R887                          1
    X287      R1920                         8
    X288      R288                          1
    X288      R888                          1
    X288      R1920                         5
    X289      R289                          1
    X289      R889                          1
    X289      R1920                         8
    X290      R290                          1
    X290      R890                          1
    X290      R1920                         8
    X291      R291                          1
    X291      R891                          1
    X291      R1920                         3
    X292      R292                          1
    X292      R892                          1
    X292      R1920                         3
    X293      R293                          1
    X293      R893                          1
    X293      R1920                         6
    X294      R294                          1
    X294      R894                          1
    X294      R1920                         2
    X295      R295                          1
    X295      R895                          1
    X295      R1920                         9
    X296      R296                          1
    X296      R896                          1
    X296      R1920                         7
    X297      R297                          1
    X297      R897                          1
    X297      R1920                         7
    X298      R298                          1
    X298      R898                          1
    X298      R1920                         7
    X299      R299                          1
    X299      R899                          1
    X299      R1920                         5
    X300      R300                          1
    X300      R900                          1
    X300      R1920                         1
    X301      R301                          1
    X301      R901                          1
    X301      R1920                         4
    X302      R302                          1
    X302      R902                          1
    X302      R1920                         5
    X303      R303                          1
    X303      R903                          1
    X303      R1920                         5
    X304      R304                          1
    X304      R904                          1
    X304      R1920                         7
    X305      R305                          1
    X305      R905                          1
    X305      R1920                         1
    X306      R306                          1
    X306      R906                          1
    X306      R1920                         6
    X307      R307                          1
    X307      R907                          1
    X307      R1920                         4
    X308      R308                          1
    X308      R908                          1
    X308      R1920                         5
    X309      R309                          1
    X309      R909                          1
    X309      R1920                         7
    X310      R310                          1
    X310      R910                          1
    X310      R1920                         6
    X311      R311                          1
    X311      R911                          1
    X311      R1920                         1
    X312      R312                          1
    X312      R912                          1
    X312      R1920                         4
    X313      R313                          1
    X313      R913                          1
    X313      R1920                         4
    X314      R314                          1
    X314      R914                          1
    X314      R1920                         9
    X315      R315                          1
    X315      R915                          1
    X315      R1920                         8
    X316      R316                          1
    X316      R916                          1
    X316      R1920                         8
    X317      R317                          1
    X317      R917                          1
    X317      R1920                         4
    X318      R318                          1
    X318      R918                          1
    X318      R1920                         4
    X319      R319                          1
    X319      R919                          1
    X319      R1920                         5
    X320      R320                          1
    X320      R920                          1
    X320      R1920                         9
    X321      R321                          1
    X321      R921                          1
    X321      R1920                         7
    X322      R322                          1
    X322      R922                          1
    X322      R1920                         9
    X323      R323                          1
    X323      R923                          1
    X323      R1920                         5
    X324      R324                          1
    X324      R924                          1
    X324      R1920                         2
    X325      R325                          1
    X325      R925                          1
    X325      R1920                         5
    X326      R326                          1
    X326      R926                          1
    X326      R1920                         2
    X327      R327                          1
    X327      R927                          1
    X327      R1920                         1
    X328      R328                          1
    X328      R928                          1
    X328      R1920                         8
    X329      R329                          1
    X329      R929                          1
    X329      R1920                         2
    X330      R330                          1
    X330      R930                          1
    X330      R1920                         6
    X331      R331                          1
    X331      R931                          1
    X331      R1920                         4
    X332      R332                          1
    X332      R932                          1
    X332      R1920                         6
    X333      R333                          1
    X333      R933                          1
    X333      R1920                         6
    X334      R334                          1
    X334      R934                          1
    X334      R1920                         3
    X335      R335                          1
    X335      R935                          1
    X335      R1920                         2
    X336      R336                          1
    X336      R936                          1
    X336      R1920                         5
    X337      R337                          1
    X337      R937                          1
    X337      R1920                         5
    X338      R338                          1
    X338      R938                          1
    X338      R1920                         9
    X339      R339                          1
    X339      R939                          1
    X339      R1920                         7
    X340      R340                          1
    X340      R940                          1
    X340      R1920                         2
    X341      R341                          1
    X341      R941                          1
    X341      R1920                         2
    X342      R342                          1
    X342      R942                          1
    X342      R1920                         9
    X343      R343                          1
    X343      R943                          1
    X343      R1920                         2
    X344      R344                          1
    X344      R944                          1
    X344      R1920                         1
    X345      R345                          1
    X345      R945                          1
    X345      R1920                         6
    X346      R346                          1
    X346      R946                          1
    X346      R1920                         4
    X347      R347                          1
    X347      R947                          1
    X347      R1920                         6
    X348      R348                          1
    X348      R948                          1
    X348      R1920                         6
    X349      R349                          1
    X349      R949                          1
    X349      R1920                         6
    X350      R350                          1
    X350      R950                          1
    X350      R1920                         9
    X351      R351                          1
    X351      R951                          1
    X351      R1920                         4
    X352      R352                          1
    X352      R952                          1
    X352      R1920                         6
    X353      R353                          1
    X353      R953                          1
    X353      R1920                         1
    X354      R354                          1
    X354      R954                          1
    X354      R1920                         3
    X355      R355                          1
    X355      R955                          1
    X355      R1920                         1
    X356      R356                          1
    X356      R956                          1
    X356      R1920                         7
    X357      R357                          1
    X357      R957                          1
    X357      R1920                         5
    X358      R358                          1
    X358      R958                          1
    X358      R1920                         1
    X359      R359                          1
    X359      R959                          1
    X359      R1920                         9
    X360      R360                          1
    X360      R960                          1
    X360      R1920                         5
    X361      R361                          1
    X361      R961                          1
    X361      R1920                         6
    X362      R362                          1
    X362      R962                          1
    X362      R1920                         7
    X363      R363                          1
    X363      R963                          1
    X363      R1920                         3
    X364      R364                          1
    X364      R964                          1
    X364      R1920                         5
    X365      R365                          1
    X365      R965                          1
    X365      R1920                         2
    X366      R366                          1
    X366      R966                          1
    X366      R1920                         5
    X367      R367                          1
    X367      R967                          1
    X367      R1920                         3
    X368      R368                          1
    X368      R968                          1
    X368      R1920                         1
    X369      R369                          1
    X369      R969                          1
    X369      R1920                         7
    X370      R370                          1
    X370      R970                          1
    X370      R1920                         5
    X371      R371                          1
    X371      R971                          1
    X371      R1920                         2
    X372      R372                          1
    X372      R972                          1
    X372      R1920                         3
    X373      R373                          1
    X373      R973                          1
    X373      R1920                         1
    X374      R374                          1
    X374      R974                          1
    X374      R1920                         2
    X375      R375                          1
    X375      R975                          1
    X375      R1920                         9
    X376      R376                          1
    X376      R976                          1
    X376      R1920                         3
    X377      R377                          1
    X377      R977                          1
    X377      R1920                         9
    X378      R378                          1
    X378      R978                          1
    X378      R1920                         9
    X379      R379                          1
    X379      R979                          1
    X379      R1920                         2
    X380      R380                          1
    X380      R980                          1
    X380      R1920                         7
    X381      R381                          1
    X381      R981                          1
    X381      R1920                         9
    X382      R382                          1
    X382      R982                          1
    X382      R1920                         3
    X383      R383                          1
    X383      R983                          1
    X383      R1920                         5
    X384      R384                          1
    X384      R984                          1
    X384      R1920                         2
    X385      R385                          1
    X385      R985                          1
    X385      R1920                         5
    X386      R386                          1
    X386      R986                          1
    X386      R1920                         7
    X387      R387                          1
    X387      R987                          1
    X387      R1920                         9
    X388      R388                          1
    X388      R988                          1
    X388      R1920                         5
    X389      R389                          1
    X389      R989                          1
    X389      R1920                         7
    X390      R390                          1
    X390      R990                          1
    X390      R1920                         5
    X391      R391                          1
    X391      R991                          1
    X391      R1920                         1
    X392      R392                          1
    X392      R992                          1
    X392      R1920                         3
    X393      R393                          1
    X393      R993                          1
    X393      R1920                         9
    X394      R394                          1
    X394      R994                          1
    X394      R1920                         4
    X395      R395                          1
    X395      R995                          1
    X395      R1920                         3
    X396      R396                          1
    X396      R996                          1
    X396      R1920                         7
    X397      R397                          1
    X397      R997                          1
    X397      R1920                         1
    X398      R398                          1
    X398      R998                          1
    X398      R1920                         6
    X399      R399                          1
    X399      R999                          1
    X399      R1920                         7
    X400      R400                          1
    X400      R1000                         1
    X400      R1920                         8
    X401      R401                          1
    X401      R1001                         1
    X401      R1920                         8
    X402      R402                          1
    X402      R1002                         1
    X402      R1920                         8
    X403      R403                          1
    X403      R1003                         1
    X403      R1920                         7
    X404      R404                          1
    X404      R1004                         1
    X404      R1920                         5
    X405      R405                          1
    X405      R1005                         1
    X405      R1920                         5
    X406      R406                          1
    X406      R1006                         1
    X406      R1920                         7
    X407      R407                          1
    X407      R1007                         1
    X407      R1920                         2
    X408      R408                          1
    X408      R1008                         1
    X408      R1920                         5
    X409      R409                          1
    X409      R1009                         1
    X409      R1920                         7
    X410      R410                          1
    X410      R1010                         1
    X410      R1920                         3
    X411      R411                          1
    X411      R1011                         1
    X411      R1920                         3
    X412      R412                          1
    X412      R1012                         1
    X412      R1920                         8
    X413      R413                          1
    X413      R1013                         1
    X413      R1920                         9
    X414      R414                          1
    X414      R1014                         1
    X414      R1920                         8
    X415      R415                          1
    X415      R1015                         1
    X415      R1920                         8
    X416      R416                          1
    X416      R1016                         1
    X416      R1920                         8
    X417      R417                          1
    X417      R1017                         1
    X417      R1920                         5
    X418      R418                          1
    X418      R1018                         1
    X418      R1920                         7
    X419      R419                          1
    X419      R1019                         1
    X419      R1920                         4
    X420      R420                          1
    X420      R1020                         1
    X420      R1920                         8
    X421      R421                          1
    X421      R1021                         1
    X421      R1920                         6
    X422      R422                          1
    X422      R1022                         1
    X422      R1920                         2
    X423      R423                          1
    X423      R1023                         1
    X423      R1920                         4
    X424      R424                          1
    X424      R1024                         1
    X424      R1920                         2
    X425      R425                          1
    X425      R1025                         1
    X425      R1920                         3
    X426      R426                          1
    X426      R1026                         1
    X426      R1920                         1
    X427      R427                          1
    X427      R1027                         1
    X427      R1920                         9
    X428      R428                          1
    X428      R1028                         1
    X428      R1920                         1
    X429      R429                          1
    X429      R1029                         1
    X429      R1920                         2
    X430      R430                          1
    X430      R1030                         1
    X430      R1920                         2
    X431      R431                          1
    X431      R1031                         1
    X431      R1920                         8
    X432      R432                          1
    X432      R1032                         1
    X432      R1920                         3
    X433      R433                          1
    X433      R1033                         1
    X433      R1920                         9
    X434      R434                          1
    X434      R1034                         1
    X434      R1920                         7
    X435      R435                          1
    X435      R1035                         1
    X435      R1920                         9
    X436      R436                          1
    X436      R1036                         1
    X436      R1920                         2
    X437      R437                          1
    X437      R1037                         1
    X437      R1920                         3
    X438      R438                          1
    X438      R1038                         1
    X438      R1920                         6
    X439      R439                          1
    X439      R1039                         1
    X439      R1920                         8
    X440      R440                          1
    X440      R1040                         1
    X440      R1920                         1
    X441      R441                          1
    X441      R1041                         1
    X441      R1920                         1
    X442      R442                          1
    X442      R1042                         1
    X442      R1920                         8
    X443      R443                          1
    X443      R1043                         1
    X443      R1920                         4
    X444      R444                          1
    X444      R1044                         1
    X444      R1920                         6
    X445      R445                          1
    X445      R1045                         1
    X445      R1920                         5
    X446      R446                          1
    X446      R1046                         1
    X446      R1920                         3
    X447      R447                          1
    X447      R1047                         1
    X447      R1920                         7
    X448      R448                          1
    X448      R1048                         1
    X448      R1920                         7
    X449      R449                          1
    X449      R1049                         1
    X449      R1920                         6
    X450      R450                          1
    X450      R1050                         1
    X450      R1920                         3
    X451      R451                          1
    X451      R1051                         1
    X451      R1920                         4
    X452      R452                          1
    X452      R1052                         1
    X452      R1920                         7
    X453      R453                          1
    X453      R1053                         1
    X453      R1920                         1
    X454      R454                          1
    X454      R1054                         1
    X454      R1920                         3
    X455      R455                          1
    X455      R1055                         1
    X455      R1920                         4
    X456      R456                          1
    X456      R1056                         1
    X456      R1920                         6
    X457      R457                          1
    X457      R1057                         1
    X457      R1920                         3
    X458      R458                          1
    X458      R1058                         1
    X458      R1920                         8
    X459      R459                          1
    X459      R1059                         1
    X459      R1920                         4
    X460      R460                          1
    X460      R1060                         1
    X460      R1920                         5
    X461      R461                          1
    X461      R1061                         1
    X461      R1920                         5
    X462      R462                          1
    X462      R1062                         1
    X462      R1920                         1
    X463      R463                          1
    X463      R1063                         1
    X463      R1920                         8
    X464      R464                          1
    X464      R1064                         1
    X464      R1920                         4
    X465      R465                          1
    X465      R1065                         1
    X465      R1920                         8
    X466      R466                          1
    X466      R1066                         1
    X466      R1920                         1
    X467      R467                          1
    X467      R1067                         1
    X467      R1920                         5
    X468      R468                          1
    X468      R1068                         1
    X468      R1920                         5
    X469      R469                          1
    X469      R1069                         1
    X469      R1920                         6
    X470      R470                          1
    X470      R1070                         1
    X470      R1920                         1
    X471      R471                          1
    X471      R1071                         1
    X471      R1920                         9
    X472      R472                          1
    X472      R1072                         1
    X472      R1920                         3
    X473      R473                          1
    X473      R1073                         1
    X473      R1920                         2
    X474      R474                          1
    X474      R1074                         1
    X474      R1920                         4
    X475      R475                          1
    X475      R1075                         1
    X475      R1920                         1
    X476      R476                          1
    X476      R1076                         1
    X476      R1920                         9
    X477      R477                          1
    X477      R1077                         1
    X477      R1920                         2
    X478      R478                          1
    X478      R1078                         1
    X478      R1920                         1
    X479      R479                          1
    X479      R1079                         1
    X479      R1920                         3
    X480      R480                          1
    X480      R1080                         1
    X480      R1920                         6
    X481      R481                          1
    X481      R1081                         1
    X481      R1920                         1
    X482      R482                          1
    X482      R1082                         1
    X482      R1920                         1
    X483      R483                          1
    X483      R1083                         1
    X483      R1920                         3
    X484      R484                          1
    X484      R1084                         1
    X484      R1920                         1
    X485      R485                          1
    X485      R1085                         1
    X485      R1920                         3
    X486      R486                          1
    X486      R1086                         1
    X486      R1920                         4
    X487      R487                          1
    X487      R1087                         1
    X487      R1920                         5
    X488      R488                          1
    X488      R1088                         1
    X488      R1920                         7
    X489      R489                          1
    X489      R1089                         1
    X489      R1920                         5
    X490      R490                          1
    X490      R1090                         1
    X490      R1920                         4
    X491      R491                          1
    X491      R1091                         1
    X491      R1920                         1
    X492      R492                          1
    X492      R1092                         1
    X492      R1920                         3
    X493      R493                          1
    X493      R1093                         1
    X493      R1920                         3
    X494      R494                          1
    X494      R1094                         1
    X494      R1920                         5
    X495      R495                          1
    X495      R1095                         1
    X495      R1920                         1
    X496      R496                          1
    X496      R1096                         1
    X496      R1920                         1
    X497      R497                          1
    X497      R1097                         1
    X497      R1920                         4
    X498      R498                          1
    X498      R1098                         1
    X498      R1920                         6
    X499      R499                          1
    X499      R1099                         1
    X499      R1920                         9
    X500      R500                          1
    X500      R1100                         1
    X500      R1920                         8
    X501      R501                          1
    X501      R1101                         1
    X501      R1920                         1
    X502      R502                          1
    X502      R1102                         1
    X502      R1920                         3
    X503      R503                          1
    X503      R1103                         1
    X503      R1920                         1
    X504      R504                          1
    X504      R1104                         1
    X504      R1920                         5
    X505      R505                          1
    X505      R1105                         1
    X505      R1920                         4
    X506      R506                          1
    X506      R1106                         1
    X506      R1920                         7
    X507      R507                          1
    X507      R1107                         1
    X507      R1920                         1
    X508      R508                          1
    X508      R1108                         1
    X508      R1920                         7
    X509      R509                          1
    X509      R1109                         1
    X509      R1920                         8
    X510      R510                          1
    X510      R1110                         1
    X510      R1920                         1
    X511      R511                          1
    X511      R1111                         1
    X511      R1920                         1
    X512      R512                          1
    X512      R1112                         1
    X512      R1920                         8
    X513      R513                          1
    X513      R1113                         1
    X513      R1920                         6
    X514      R514                          1
    X514      R1114                         1
    X514      R1920                         9
    X515      R515                          1
    X515      R1115                         1
    X515      R1920                         6
    X516      R516                          1
    X516      R1116                         1
    X516      R1920                         8
    X517      R517                          1
    X517      R1117                         1
    X517      R1920                         1
    X518      R518                          1
    X518      R1118                         1
    X518      R1920                         9
    X519      R519                          1
    X519      R1119                         1
    X519      R1920                         1
    X520      R520                          1
    X520      R1120                         1
    X520      R1920                         5
    X521      R521                          1
    X521      R1121                         1
    X521      R1920                         8
    X522      R522                          1
    X522      R1122                         1
    X522      R1920                         8
    X523      R523                          1
    X523      R1123                         1
    X523      R1920                         1
    X524      R524                          1
    X524      R1124                         1
    X524      R1920                         6
    X525      R525                          1
    X525      R1125                         1
    X525      R1920                         7
    X526      R526                          1
    X526      R1126                         1
    X526      R1920                         7
    X527      R527                          1
    X527      R1127                         1
    X527      R1920                         2
    X528      R528                          1
    X528      R1128                         1
    X528      R1920                         2
    X529      R529                          1
    X529      R1129                         1
    X529      R1920                         6
    X530      R530                          1
    X530      R1130                         1
    X530      R1920                         8
    X531      R531                          1
    X531      R1131                         1
    X531      R1920                         7
    X532      R532                          1
    X532      R1132                         1
    X532      R1920                         1
    X533      R533                          1
    X533      R1133                         1
    X533      R1920                         2
    X534      R534                          1
    X534      R1134                         1
    X534      R1920                         1
    X535      R535                          1
    X535      R1135                         1
    X535      R1920                         3
    X536      R536                          1
    X536      R1136                         1
    X536      R1920                         6
    X537      R537                          1
    X537      R1137                         1
    X537      R1920                         4
    X538      R538                          1
    X538      R1138                         1
    X538      R1920                         5
    X539      R539                          1
    X539      R1139                         1
    X539      R1920                         2
    X540      R540                          1
    X540      R1140                         1
    X540      R1920                         3
    X541      R541                          1
    X541      R1141                         1
    X541      R1920                         7
    X542      R542                          1
    X542      R1142                         1
    X542      R1920                         3
    X543      R543                          1
    X543      R1143                         1
    X543      R1920                         1
    X544      R544                          1
    X544      R1144                         1
    X544      R1920                         1
    X545      R545                          1
    X545      R1145                         1
    X545      R1920                         6
    X546      R546                          1
    X546      R1146                         1
    X546      R1920                         8
    X547      R547                          1
    X547      R1147                         1
    X547      R1920                         4
    X548      R548                          1
    X548      R1148                         1
    X548      R1920                         7
    X549      R549                          1
    X549      R1149                         1
    X549      R1920                         1
    X550      R550                          1
    X550      R1150                         1
    X550      R1920                         2
    X551      R551                          1
    X551      R1151                         1
    X551      R1920                         5
    X552      R552                          1
    X552      R1152                         1
    X552      R1920                         3
    X553      R553                          1
    X553      R1153                         1
    X553      R1920                         9
    X554      R554                          1
    X554      R1154                         1
    X554      R1920                         2
    X555      R555                          1
    X555      R1155                         1
    X555      R1920                         4
    X556      R556                          1
    X556      R1156                         1
    X556      R1920                         1
    X557      R557                          1
    X557      R1157                         1
    X557      R1920                         4
    X558      R558                          1
    X558      R1158                         1
    X558      R1920                         3
    X559      R559                          1
    X559      R1159                         1
    X559      R1920                         1
    X560      R560                          1
    X560      R1160                         1
    X560      R1920                         4
    X561      R561                          1
    X561      R1161                         1
    X561      R1920                         1
    X562      R562                          1
    X562      R1162                         1
    X562      R1920                         6
    X563      R563                          1
    X563      R1163                         1
    X563      R1920                         5
    X564      R564                          1
    X564      R1164                         1
    X564      R1920                         3
    X565      R565                          1
    X565      R1165                         1
    X565      R1920                         1
    X566      R566                          1
    X566      R1166                         1
    X566      R1920                         7
    X567      R567                          1
    X567      R1167                         1
    X567      R1920                         4
    X568      R568                          1
    X568      R1168                         1
    X568      R1920                         7
    X569      R569                          1
    X569      R1169                         1
    X569      R1920                         4
    X570      R570                          1
    X570      R1170                         1
    X570      R1920                         3
    X571      R571                          1
    X571      R1171                         1
    X571      R1920                         9
    X572      R572                          1
    X572      R1172                         1
    X572      R1920                         5
    X573      R573                          1
    X573      R1173                         1
    X573      R1920                         1
    X574      R574                          1
    X574      R1174                         1
    X574      R1920                         2
    X575      R575                          1
    X575      R1175                         1
    X575      R1920                         4
    X576      R576                          1
    X576      R1176                         1
    X576      R1920                         1
    X577      R577                          1
    X577      R1177                         1
    X577      R1920                         7
    X578      R578                          1
    X578      R1178                         1
    X578      R1920                         3
    X579      R579                          1
    X579      R1179                         1
    X579      R1920                         3
    X580      R580                          1
    X580      R1180                         1
    X580      R1920                         2
    X581      R581                          1
    X581      R1181                         1
    X581      R1920                         8
    X582      R582                          1
    X582      R1182                         1
    X582      R1920                         9
    X583      R583                          1
    X583      R1183                         1
    X583      R1920                         3
    X584      R584                          1
    X584      R1184                         1
    X584      R1920                         8
    X585      R585                          1
    X585      R1185                         1
    X585      R1920                         5
    X586      R586                          1
    X586      R1186                         1
    X586      R1920                         4
    X587      R587                          1
    X587      R1187                         1
    X587      R1920                         2
    X588      R588                          1
    X588      R1188                         1
    X588      R1920                         8
    X589      R589                          1
    X589      R1189                         1
    X589      R1920                         8
    X590      R590                          1
    X590      R1190                         1
    X590      R1920                         1
    X591      R591                          1
    X591      R1191                         1
    X591      R1920                         8
    X592      R592                          1
    X592      R1192                         1
    X592      R1920                         5
    X593      R593                          1
    X593      R1193                         1
    X593      R1920                         1
    X594      R594                          1
    X594      R1194                         1
    X594      R1920                         6
    X595      R595                          1
    X595      R1195                         1
    X595      R1920                         7
    X596      R596                          1
    X596      R1196                         1
    X596      R1920                         6
    X597      R597                          1
    X597      R1197                         1
    X597      R1920                         9
    X598      R598                          1
    X598      R1198                         1
    X598      R1920                         6
    X599      R599                          1
    X599      R1199                         1
    X599      R1920                         4
    X600      R0                            1
    X600      R1                            -1
    X600      R1200                         1
    X600      R1920                         1
    X601      R1                            1
    X601      R2                            -1
    X601      R1201                         1
    X601      R1920                         1
    X602      R2                            1
    X602      R3                            -1
    X602      R1202                         1
    X602      R1920                         1
    X603      R3                            1
    X603      R4                            -1
    X603      R1203                         1
    X603      R1920                         1
    X604      R4                            1
    X604      R5                            -1
    X604      R1204                         1
    X604      R1920                         1
    X605      R5                            1
    X605      R6                            -1
    X605      R1205                         1
    X605      R1920                         1
    X606      R6                            1
    X606      R7                            -1
    X606      R1206                         1
    X606      R1920                         1
    X607      R7                            1
    X607      R8                            -1
    X607      R1207                         1
    X607      R1920                         1
    X608      R8                            1
    X608      R9                            -1
    X608      R1208                         1
    X608      R1920                         1
    X609      R9                            1
    X609      R10                           -1
    X609      R1209                         1
    X609      R1920                         1
    X610      R10                           1
    X610      R11                           -1
    X610      R1210                         1
    X610      R1920                         1
    X611      R11                           1
    X611      R12                           -1
    X611      R1211                         1
    X611      R1920                         1
    X612      R12                           1
    X612      R13                           -1
    X612      R1212                         1
    X612      R1920                         1
    X613      R13                           1
    X613      R14                           -1
    X613      R1213                         1
    X613      R1920                         1
    X614      R14                           1
    X614      R15                           -1
    X614      R1214                         1
    X614      R1920                         1
    X615      R15                           1
    X615      R16                           -1
    X615      R1215                         1
    X615      R1920                         1
    X616      R16                           1
    X616      R17                           -1
    X616      R1216                         1
    X616      R1920                         1
    X617      R17                           1
    X617      R18                           -1
    X617      R1217                         1
    X617      R1920                         1
    X618      R18                           1
    X618      R19                           -1
    X618      R1218                         1
    X618      R1920                         1
    X619      R19                           1
    X619      R20                           -1
    X619      R1219                         1
    X619      R1920                         1
    X620      R20                           1
    X620      R21                           -1
    X620      R1220                         1
    X620      R1920                         1
    X621      R21                           1
    X621      R22                           -1
    X621      R1221                         1
    X621      R1920                         1
    X622      R22                           1
    X622      R23                           -1
    X622      R1222                         1
    X622      R1920                         1
    X623      R23                           1
    X623      R24                           -1
    X623      R1223                         1
    X623      R1920                         1
    X624      R24                           1
    X624      R25                           -1
    X624      R1224                         1
    X624      R1920                         1
    X625      R25                           1
    X625      R26                           -1
    X625      R1225                         1
    X625      R1920                         1
    X626      R26                           1
    X626      R27                           -1
    X626      R1226                         1
    X626      R1920                         1
    X627      R27                           1
    X627      R28                           -1
    X627      R1227                         1
    X627      R1920                         1
    X628      R28                           1
    X628      R29                           -1
    X628      R1228                         1
    X628      R1920                         1
    X629      R29                           1
    X629      R30                           -1
    X629      R1229                         1
    X629      R1920                         1
    X630      R30                           1
    X630      R31                           -1
    X630      R1230                         1
    X630      R1920                         1
    X631      R31                           1
    X631      R32                           -1
    X631      R1231                         1
    X631      R1920                         1
    X632      R32                           1
    X632      R33                           -1
    X632      R1232                         1
    X632      R1920                         1
    X633      R33                           1
    X633      R34                           -1
    X633      R1233                         1
    X633      R1920                         1
    X634      R34                           1
    X634      R35                           -1
    X634      R1234                         1
    X634      R1920                         1
    X635      R35                           1
    X635      R36                           -1
    X635      R1235                         1
    X635      R1920                         1
    X636      R36                           1
    X636      R37                           -1
    X636      R1236                         1
    X636      R1920                         1
    X637      R37                           1
    X637      R38                           -1
    X637      R1237                         1
    X637      R1920                         1
    X638      R38                           1
    X638      R39                           -1
    X638      R1238                         1
    X638      R1920                         1
    X639      R39                           1
    X639      R40                           -1
    X639      R1239                         1
    X639      R1920                         1
    X640      R40                           1
    X640      R41                           -1
    X640      R1240                         1
    X640      R1920                         1
    X641      R41                           1
    X641      R42                           -1
    X641      R1241                         1
    X641      R1920                         1
    X642      R42                           1
    X642      R43                           -1
    X642      R1242                         1
    X642      R1920                         1
    X643      R43                           1
    X643      R44                           -1
    X643      R1243                         1
    X643      R1920                         1
    X644      R44                           1
    X644      R45                           -1
    X644      R1244                         1
    X644      R1920                         1
    X645      R45                           1
    X645      R46                           -1
    X645      R1245                         1
    X645      R1920                         1
    X646      R46                           1
    X646      R47                           -1
    X646      R1246                         1
    X646      R1920                         1
    X647      R47                           1
    X647      R48                           -1
    X647      R1247                         1
    X647      R1920                         1
    X648      R48                           1
    X648      R49                           -1
    X648      R1248                         1
    X648      R1920                         1
    X649      R49                           1
    X649      R50                           -1
    X649      R1249                         1
    X649      R1920                         1
    X650      R50                           1
    X650      R51                           -1
    X650      R1250                         1
    X650      R1920                         1
    X651      R51                           1
    X651      R52                           -1
    X651      R1251                         1
    X651      R1920                         1
    X652      R52                           1
    X652      R53                           -1
    X652      R1252                         1
    X652      R1920                         1
    X653      R53                           1
    X653      R54                           -1
    X653      R1253                         1
    X653      R1920                         1
    X654      R54                           1
    X654      R55                           -1
    X654      R1254                         1
    X654      R1920                         1
    X655      R55                           1
    X655      R56                           -1
    X655      R1255                         1
    X655      R1920                         1
    X656      R56                           1
    X656      R57                           -1
    X656      R1256                         1
    X656      R1920                         1
    X657      R57                           1
    X657      R58                           -1
    X657      R1257                         1
    X657      R1920                         1
    X658      R58                           1
    X658      R59                           -1
    X658      R1258                         1
    X658      R1920                         1
    X659      R59                           1
    X659      R60                           -1
    X659      R1259                         1
    X659      R1920                         1
    X660      R60                           1
    X660      R61                           -1
    X660      R1260                         1
    X660      R1920                         1
    X661      R61                           1
    X661      R62                           -1
    X661      R1261                         1
    X661      R1920                         1
    X662      R62                           1
    X662      R63                           -1
    X662      R1262                         1
    X662      R1920                         1
    X663      R63                           1
    X663      R64                           -1
    X663      R1263                         1
    X663      R1920                         1
    X664      R64                           1
    X664      R65                           -1
    X664      R1264                         1
    X664      R1920                         1
    X665      R65                           1
    X665      R66                           -1
    X665      R1265                         1
    X665      R1920                         1
    X666      R66                           1
    X666      R67                           -1
    X666      R1266                         1
    X666      R1920                         1
    X667      R67                           1
    X667      R68                           -1
    X667      R1267                         1
    X667      R1920                         1
    X668      R68                           1
    X668      R69                           -1
    X668      R1268                         1
    X668      R1920                         1
    X669      R69                           1
    X669      R70                           -1
    X669      R1269                         1
    X669      R1920                         1
    X670      R70                           1
    X670      R71                           -1
    X670      R1270                         1
    X670      R1920                         1
    X671      R71                           1
    X671      R72                           -1
    X671      R1271                         1
    X671      R1920                         1
    X672      R72                           1
    X672      R73                           -1
    X672      R1272                         1
    X672      R1920                         1
    X673      R73                           1
    X673      R74                           -1
    X673      R1273                         1
    X673      R1920                         1
    X674      R74                           1
    X674      R75                           -1
    X674      R1274                         1
    X674      R1920                         1
    X675      R75                           1
    X675      R76                           -1
    X675      R1275                         1
    X675      R1920                         1
    X676      R76                           1
    X676      R77                           -1
    X676      R1276                         1
    X676      R1920                         1
    X677      R77                           1
    X677      R78                           -1
    X677      R1277                         1
    X677      R1920                         1
    X678      R78                           1
    X678      R79                           -1
    X678      R1278                         1
    X678      R1920                         1
    X679      R79                           1
    X679      R80                           -1
    X679      R1279                         1
    X679      R1920                         1
    X680      R80                           1
    X680      R81                           -1
    X680      R1280                         1
    X680      R1920                         1
    X681      R81                           1
    X681      R82                           -1
    X681      R1281                         1
    X681      R1920                         1
    X682      R82                           1
    X682      R83                           -1
    X682      R1282                         1
    X682      R1920                         1
    X683      R83                           1
    X683      R84                           -1
    X683      R1283                         1
    X683      R1920                         1
    X684      R84                           1
    X684      R85                           -1
    X684      R1284                         1
    X684      R1920                         1
    X685      R85                           1
    X685      R86                           -1
    X685      R1285                         1
    X685      R1920                         1
    X686      R86                           1
    X686      R87                           -1
    X686      R1286                         1
    X686      R1920                         1
    X687      R87                           1
    X687      R88                           -1
    X687      R1287                         1
    X687      R1920                         1
    X688      R88                           1
    X688      R89                           -1
    X688      R1288                         1
    X688      R1920                         1
    X689      R89                           1
    X689      R90                           -1
    X689      R1289                         1
    X689      R1920                         1
    X690      R90                           1
    X690      R91                           -1
    X690      R1290                         1
    X690      R1920                         1
    X691      R91                           1
    X691      R92                           -1
    X691      R1291                         1
    X691      R1920                         1
    X692      R92                           1
    X692      R93                           -1
    X692      R1292                         1
    X692      R1920                         1
    X693      R93                           1
    X693      R94                           -1
    X693      R1293                         1
    X693      R1920                         1
    X694      R94                           1
    X694      R95                           -1
    X694      R1294                         1
    X694      R1920                         1
    X695      R95                           1
    X695      R96                           -1
    X695      R1295                         1
    X695      R1920                         1
    X696      R96                           1
    X696      R97                           -1
    X696      R1296                         1
    X696      R1920                         1
    X697      R97                           1
    X697      R98                           -1
    X697      R1297                         1
    X697      R1920                         1
    X698      R98                           1
    X698      R99                           -1
    X698      R1298                         1
    X698      R1920                         1
    X699      R99                           1
    X699      R100                          -1
    X699      R1299                         1
    X699      R1920                         1
    X700      R100                          1
    X700      R101                          -1
    X700      R1300                         1
    X700      R1920                         1
    X701      R101                          1
    X701      R102                          -1
    X701      R1301                         1
    X701      R1920                         1
    X702      R102                          1
    X702      R103                          -1
    X702      R1302                         1
    X702      R1920                         1
    X703      R103                          1
    X703      R104                          -1
    X703      R1303                         1
    X703      R1920                         1
    X704      R104                          1
    X704      R105                          -1
    X704      R1304                         1
    X704      R1920                         1
    X705      R105                          1
    X705      R106                          -1
    X705      R1305                         1
    X705      R1920                         1
    X706      R106                          1
    X706      R107                          -1
    X706      R1306                         1
    X706      R1920                         1
    X707      R107                          1
    X707      R108                          -1
    X707      R1307                         1
    X707      R1920                         1
    X708      R108                          1
    X708      R109                          -1
    X708      R1308                         1
    X708      R1920                         1
    X709      R109                          1
    X709      R110                          -1
    X709      R1309                         1
    X709      R1920                         1
    X710      R110                          1
    X710      R111                          -1
    X710      R1310                         1
    X710      R1920                         1
    X711      R111                          1
    X711      R112                          -1
    X711      R1311                         1
    X711      R1920                         1
    X712      R112                          1
    X712      R113                          -1
    X712      R1312                         1
    X712      R1920                         1
    X713      R113                          1
    X713      R114                          -1
    X713      R1313                         1
    X713      R1920                         1
    X714      R114                          1
    X714      R115                          -1
    X714      R1314                         1
    X714      R1920                         1
    X715      R115                          1
    X715      R116                          -1
    X715      R1315                         1
    X715      R1920                         1
    X716      R116                          1
    X716      R117                          -1
    X716      R1316                         1
    X716      R1920                         1
    X717      R117                          1
    X717      R118                          -1
    X717      R1317                         1
    X717      R1920                         1
    X718      R118                          1
    X718      R119                          -1
    X718      R1318                         1
    X718      R1920                         1
    X719      R120                          1
    X719      R121                          -1
    X719      R1319                         1
    X719      R1920                         1
    X720      R121                          1
    X720      R122                          -1
    X720      R1320                         1
    X720      R1920                         1
    X721      R122                          1
    X721      R123                          -1
    X721      R1321                         1
    X721      R1920                         1
    X722      R123                          1
    X722      R124                          -1
    X722      R1322                         1
    X722      R1920                         1
    X723      R124                          1
    X723      R125                          -1
    X723      R1323                         1
    X723      R1920                         1
    X724      R125                          1
    X724      R126                          -1
    X724      R1324                         1
    X724      R1920                         1
    X725      R126                          1
    X725      R127                          -1
    X725      R1325                         1
    X725      R1920                         1
    X726      R127                          1
    X726      R128                          -1
    X726      R1326                         1
    X726      R1920                         1
    X727      R128                          1
    X727      R129                          -1
    X727      R1327                         1
    X727      R1920                         1
    X728      R129                          1
    X728      R130                          -1
    X728      R1328                         1
    X728      R1920                         1
    X729      R130                          1
    X729      R131                          -1
    X729      R1329                         1
    X729      R1920                         1
    X730      R131                          1
    X730      R132                          -1
    X730      R1330                         1
    X730      R1920                         1
    X731      R132                          1
    X731      R133                          -1
    X731      R1331                         1
    X731      R1920                         1
    X732      R133                          1
    X732      R134                          -1
    X732      R1332                         1
    X732      R1920                         1
    X733      R134                          1
    X733      R135                          -1
    X733      R1333                         1
    X733      R1920                         1
    X734      R135                          1
    X734      R136                          -1
    X734      R1334                         1
    X734      R1920                         1
    X735      R136                          1
    X735      R137                          -1
    X735      R1335                         1
    X735      R1920                         1
    X736      R137                          1
    X736      R138                          -1
    X736      R1336                         1
    X736      R1920                         1
    X737      R138                          1
    X737      R139                          -1
    X737      R1337                         1
    X737      R1920                         1
    X738      R139                          1
    X738      R140                          -1
    X738      R1338                         1
    X738      R1920                         1
    X739      R140                          1
    X739      R141                          -1
    X739      R1339                         1
    X739      R1920                         1
    X740      R141                          1
    X740      R142                          -1
    X740      R1340                         1
    X740      R1920                         1
    X741      R142                          1
    X741      R143                          -1
    X741      R1341                         1
    X741      R1920                         1
    X742      R143                          1
    X742      R144                          -1
    X742      R1342                         1
    X742      R1920                         1
    X743      R144                          1
    X743      R145                          -1
    X743      R1343                         1
    X743      R1920                         1
    X744      R145                          1
    X744      R146                          -1
    X744      R1344                         1
    X744      R1920                         1
    X745      R146                          1
    X745      R147                          -1
    X745      R1345                         1
    X745      R1920                         1
    X746      R147                          1
    X746      R148                          -1
    X746      R1346                         1
    X746      R1920                         1
    X747      R148                          1
    X747      R149                          -1
    X747      R1347                         1
    X747      R1920                         1
    X748      R149                          1
    X748      R150                          -1
    X748      R1348                         1
    X748      R1920                         1
    X749      R150                          1
    X749      R151                          -1
    X749      R1349                         1
    X749      R1920                         1
    X750      R151                          1
    X750      R152                          -1
    X750      R1350                         1
    X750      R1920                         1
    X751      R152                          1
    X751      R153                          -1
    X751      R1351                         1
    X751      R1920                         1
    X752      R153                          1
    X752      R154                          -1
    X752      R1352                         1
    X752      R1920                         1
    X753      R154                          1
    X753      R155                          -1
    X753      R1353                         1
    X753      R1920                         1
    X754      R155                          1
    X754      R156                          -1
    X754      R1354                         1
    X754      R1920                         1
    X755      R156                          1
    X755      R157                          -1
    X755      R1355                         1
    X755      R1920                         1
    X756      R157                          1
    X756      R158                          -1
    X756      R1356                         1
    X756      R1920                         1
    X757      R158                          1
    X757      R159                          -1
    X757      R1357                         1
    X757      R1920                         1
    X758      R159                          1
    X758      R160                          -1
    X758      R1358                         1
    X758      R1920                         1
    X759      R160                          1
    X759      R161                          -1
    X759      R1359                         1
    X759      R1920                         1
    X760      R161                          1
    X760      R162                          -1
    X760      R1360                         1
    X760      R1920                         1
    X761      R162                          1
    X761      R163                          -1
    X761      R1361                         1
    X761      R1920                         1
    X762      R163                          1
    X762      R164                          -1
    X762      R1362                         1
    X762      R1920                         1
    X763      R164                          1
    X763      R165                          -1
    X763      R1363                         1
    X763      R1920                         1
    X764      R165                          1
    X764      R166                          -1
    X764      R1364                         1
    X764      R1920                         1
    X765      R166                          1
    X765      R167                          -1
    X765      R1365                         1
    X765      R1920                         1
    X766      R167                          1
    X766      R168                          -1
    X766      R1366                         1
    X766      R1920                         1
    X767      R168                          1
    X767      R169                          -1
    X767      R1367                         1
    X767      R1920                         1
    X768      R169                          1
    X768      R170                          -1
    X768      R1368                         1
    X768      R1920                         1
    X769      R170                          1
    X769      R171                          -1
    X769      R1369                         1
    X769      R1920                         1
    X770      R171                          1
    X770      R172                          -1
    X770      R1370                         1
    X770      R1920                         1
    X771      R172                          1
    X771      R173                          -1
    X771      R1371                         1
    X771      R1920                         1
    X772      R173                          1
    X772      R174                          -1
    X772      R1372                         1
    X772      R1920                         1
    X773      R174                          1
    X773      R175                          -1
    X773      R1373                         1
    X773      R1920                         1
    X774      R175                          1
    X774      R176                          -1
    X774      R1374                         1
    X774      R1920                         1
    X775      R176                          1
    X775      R177                          -1
    X775      R1375                         1
    X775      R1920                         1
    X776      R177                          1
    X776      R178                          -1
    X776      R1376                         1
    X776      R1920                         1
    X777      R178                          1
    X777      R179                          -1
    X777      R1377                         1
    X777      R1920                         1
    X778      R179                          1
    X778      R180                          -1
    X778      R1378                         1
    X778      R1920                         1
    X779      R180                          1
    X779      R181                          -1
    X779      R1379                         1
    X779      R1920                         1
    X780      R181                          1
    X780      R182                          -1
    X780      R1380                         1
    X780      R1920                         1
    X781      R182                          1
    X781      R183                          -1
    X781      R1381                         1
    X781      R1920                         1
    X782      R183                          1
    X782      R184                          -1
    X782      R1382                         1
    X782      R1920                         1
    X783      R184                          1
    X783      R185                          -1
    X783      R1383                         1
    X783      R1920                         1
    X784      R185                          1
    X784      R186                          -1
    X784      R1384                         1
    X784      R1920                         1
    X785      R186                          1
    X785      R187                          -1
    X785      R1385                         1
    X785      R1920                         1
    X786      R187                          1
    X786      R188                          -1
    X786      R1386                         1
    X786      R1920                         1
    X787      R188                          1
    X787      R189                          -1
    X787      R1387                         1
    X787      R1920                         1
    X788      R189                          1
    X788      R190                          -1
    X788      R1388                         1
    X788      R1920                         1
    X789      R190                          1
    X789      R191                          -1
    X789      R1389                         1
    X789      R1920                         1
    X790      R191                          1
    X790      R192                          -1
    X790      R1390                         1
    X790      R1920                         1
    X791      R192                          1
    X791      R193                          -1
    X791      R1391                         1
    X791      R1920                         1
    X792      R193                          1
    X792      R194                          -1
    X792      R1392                         1
    X792      R1920                         1
    X793      R194                          1
    X793      R195                          -1
    X793      R1393                         1
    X793      R1920                         1
    X794      R195                          1
    X794      R196                          -1
    X794      R1394                         1
    X794      R1920                         1
    X795      R196                          1
    X795      R197                          -1
    X795      R1395                         1
    X795      R1920                         1
    X796      R197                          1
    X796      R198                          -1
    X796      R1396                         1
    X796      R1920                         1
    X797      R198                          1
    X797      R199                          -1
    X797      R1397                         1
    X797      R1920                         1
    X798      R199                          1
    X798      R200                          -1
    X798      R1398                         1
    X798      R1920                         1
    X799      R200                          1
    X799      R201                          -1
    X799      R1399                         1
    X799      R1920                         1
    X800      R201                          1
    X800      R202                          -1
    X800      R1400                         1
    X800      R1920                         1
    X801      R202                          1
    X801      R203                          -1
    X801      R1401                         1
    X801      R1920                         1
    X802      R203                          1
    X802      R204                          -1
    X802      R1402                         1
    X802      R1920                         1
    X803      R204                          1
    X803      R205                          -1
    X803      R1403                         1
    X803      R1920                         1
    X804      R205                          1
    X804      R206                          -1
    X804      R1404                         1
    X804      R1920                         1
    X805      R206                          1
    X805      R207                          -1
    X805      R1405                         1
    X805      R1920                         1
    X806      R207                          1
    X806      R208                          -1
    X806      R1406                         1
    X806      R1920                         1
    X807      R208                          1
    X807      R209                          -1
    X807      R1407                         1
    X807      R1920                         1
    X808      R209                          1
    X808      R210                          -1
    X808      R1408                         1
    X808      R1920                         1
    X809      R210                          1
    X809      R211                          -1
    X809      R1409                         1
    X809      R1920                         1
    X810      R211                          1
    X810      R212                          -1
    X810      R1410                         1
    X810      R1920                         1
    X811      R212                          1
    X811      R213                          -1
    X811      R1411                         1
    X811      R1920                         1
    X812      R213                          1
    X812      R214                          -1
    X812      R1412                         1
    X812      R1920                         1
    X813      R214                          1
    X813      R215                          -1
    X813      R1413                         1
    X813      R1920                         1
    X814      R215                          1
    X814      R216                          -1
    X814      R1414                         1
    X814      R1920                         1
    X815      R216                          1
    X815      R217                          -1
    X815      R1415                         1
    X815      R1920                         1
    X816      R217                          1
    X816      R218                          -1
    X816      R1416                         1
    X816      R1920                         1
    X817      R218                          1
    X817      R219                          -1
    X817      R1417                         1
    X817      R1920                         1
    X818      R219                          1
    X818      R220                          -1
    X818      R1418                         1
    X818      R1920                         1
    X819      R220                          1
    X819      R221                          -1
    X819      R1419                         1
    X819      R1920                         1
    X820      R221                          1
    X820      R222                          -1
    X820      R1420                         1
    X820      R1920                         1
    X821      R222                          1
    X821      R223                          -1
    X821      R1421                         1
    X821      R1920                         1
    X822      R223                          1
    X822      R224                          -1
    X822      R1422                         1
    X822      R1920                         1
    X823      R224                          1
    X823      R225                          -1
    X823      R1423                         1
    X823      R1920                         1
    X824      R225                          1
    X824      R226                          -1
    X824      R1424                         1
    X824      R1920                         1
    X825      R226                          1
    X825      R227                          -1
    X825      R1425                         1
    X825      R1920                         1
    X826      R227                          1
    X826      R228                          -1
    X826      R1426                         1
    X826      R1920                         1
    X827      R228                          1
    X827      R229                          -1
    X827      R1427                         1
    X827      R1920                         1
    X828      R229                          1
    X828      R230                          -1
    X828      R1428                         1
    X828      R1920                         1
    X829      R230                          1
    X829      R231                          -1
    X829      R1429                         1
    X829      R1920                         1
    X830      R231                          1
    X830      R232                          -1
    X830      R1430                         1
    X830      R1920                         1
    X831      R232                          1
    X831      R233                          -1
    X831      R1431                         1
    X831      R1920                         1
    X832      R233                          1
    X832      R234                          -1
    X832      R1432                         1
    X832      R1920                         1
    X833      R234                          1
    X833      R235                          -1
    X833      R1433                         1
    X833      R1920                         1
    X834      R235                          1
    X834      R236                          -1
    X834      R1434                         1
    X834      R1920                         1
    X835      R236                          1
    X835      R237                          -1
    X835      R1435                         1
    X835      R1920                         1
    X836      R237                          1
    X836      R238                          -1
    X836      R1436                         1
    X836      R1920                         1
    X837      R238                          1
    X837      R239                          -1
    X837      R1437                         1
    X837      R1920                         1
    X838      R240                          1
    X838      R241                          -1
    X838      R1438                         1
    X838      R1920                         1
    X839      R241                          1
    X839      R242                          -1
    X839      R1439                         1
    X839      R1920                         1
    X840      R242                          1
    X840      R243                          -1
    X840      R1440                         1
    X840      R1920                         1
    X841      R243                          1
    X841      R244                          -1
    X841      R1441                         1
    X841      R1920                         1
    X842      R244                          1
    X842      R245                          -1
    X842      R1442                         1
    X842      R1920                         1
    X843      R245                          1
    X843      R246                          -1
    X843      R1443                         1
    X843      R1920                         1
    X844      R246                          1
    X844      R247                          -1
    X844      R1444                         1
    X844      R1920                         1
    X845      R247                          1
    X845      R248                          -1
    X845      R1445                         1
    X845      R1920                         1
    X846      R248                          1
    X846      R249                          -1
    X846      R1446                         1
    X846      R1920                         1
    X847      R249                          1
    X847      R250                          -1
    X847      R1447                         1
    X847      R1920                         1
    X848      R250                          1
    X848      R251                          -1
    X848      R1448                         1
    X848      R1920                         1
    X849      R251                          1
    X849      R252                          -1
    X849      R1449                         1
    X849      R1920                         1
    X850      R252                          1
    X850      R253                          -1
    X850      R1450                         1
    X850      R1920                         1
    X851      R253                          1
    X851      R254                          -1
    X851      R1451                         1
    X851      R1920                         1
    X852      R254                          1
    X852      R255                          -1
    X852      R1452                         1
    X852      R1920                         1
    X853      R255                          1
    X853      R256                          -1
    X853      R1453                         1
    X853      R1920                         1
    X854      R256                          1
    X854      R257                          -1
    X854      R1454                         1
    X854      R1920                         1
    X855      R257                          1
    X855      R258                          -1
    X855      R1455                         1
    X855      R1920                         1
    X856      R258                          1
    X856      R259                          -1
    X856      R1456                         1
    X856      R1920                         1
    X857      R259                          1
    X857      R260                          -1
    X857      R1457                         1
    X857      R1920                         1
    X858      R260                          1
    X858      R261                          -1
    X858      R1458                         1
    X858      R1920                         1
    X859      R261                          1
    X859      R262                          -1
    X859      R1459                         1
    X859      R1920                         1
    X860      R262                          1
    X860      R263                          -1
    X860      R1460                         1
    X860      R1920                         1
    X861      R263                          1
    X861      R264                          -1
    X861      R1461                         1
    X861      R1920                         1
    X862      R264                          1
    X862      R265                          -1
    X862      R1462                         1
    X862      R1920                         1
    X863      R265                          1
    X863      R266                          -1
    X863      R1463                         1
    X863      R1920                         1
    X864      R266                          1
    X864      R267                          -1
    X864      R1464                         1
    X864      R1920                         1
    X865      R267                          1
    X865      R268                          -1
    X865      R1465                         1
    X865      R1920                         1
    X866      R268                          1
    X866      R269                          -1
    X866      R1466                         1
    X866      R1920                         1
    X867      R269                          1
    X867      R270                          -1
    X867      R1467                         1
    X867      R1920                         1
    X868      R270                          1
    X868      R271                          -1
    X868      R1468                         1
    X868      R1920                         1
    X869      R271                          1
    X869      R272                          -1
    X869      R1469                         1
    X869      R1920                         1
    X870      R272                          1
    X870      R273                          -1
    X870      R1470                         1
    X870      R1920                         1
    X871      R273                          1
    X871      R274                          -1
    X871      R1471                         1
    X871      R1920                         1
    X872      R274                          1
    X872      R275                          -1
    X872      R1472                         1
    X872      R1920                         1
    X873      R275                          1
    X873      R276                          -1
    X873      R1473                         1
    X873      R1920                         1
    X874      R276                          1
    X874      R277                          -1
    X874      R1474                         1
    X874      R1920                         1
    X875      R277                          1
    X875      R278                          -1
    X875      R1475                         1
    X875      R1920                         1
    X876      R278                          1
    X876      R279                          -1
    X876      R1476                         1
    X876      R1920                         1
    X877      R279                          1
    X877      R280                          -1
    X877      R1477                         1
    X877      R1920                         1
    X878      R280                          1
    X878      R281                          -1
    X878      R1478                         1
    X878      R1920                         1
    X879      R281                          1
    X879      R282                          -1
    X879      R1479                         1
    X879      R1920                         1
    X880      R282                          1
    X880      R283                          -1
    X880      R1480                         1
    X880      R1920                         1
    X881      R283                          1
    X881      R284                          -1
    X881      R1481                         1
    X881      R1920                         1
    X882      R284                          1
    X882      R285                          -1
    X882      R1482                         1
    X882      R1920                         1
    X883      R285                          1
    X883      R286                          -1
    X883      R1483                         1
    X883      R1920                         1
    X884      R286                          1
    X884      R287                          -1
    X884      R1484                         1
    X884      R1920                         1
    X885      R287                          1
    X885      R288                          -1
    X885      R1485                         1
    X885      R1920                         1
    X886      R288                          1
    X886      R289                          -1
    X886      R1486                         1
    X886      R1920                         1
    X887      R289                          1
    X887      R290                          -1
    X887      R1487                         1
    X887      R1920                         1
    X888      R290                          1
    X888      R291                          -1
    X888      R1488                         1
    X888      R1920                         1
    X889      R291                          1
    X889      R292                          -1
    X889      R1489                         1
    X889      R1920                         1
    X890      R292                          1
    X890      R293                          -1
    X890      R1490                         1
    X890      R1920                         1
    X891      R293                          1
    X891      R294                          -1
    X891      R1491                         1
    X891      R1920                         1
    X892      R294                          1
    X892      R295                          -1
    X892      R1492                         1
    X892      R1920                         1
    X893      R295                          1
    X893      R296                          -1
    X893      R1493                         1
    X893      R1920                         1
    X894      R296                          1
    X894      R297                          -1
    X894      R1494                         1
    X894      R1920                         1
    X895      R297                          1
    X895      R298                          -1
    X895      R1495                         1
    X895      R1920                         1
    X896      R298                          1
    X896      R299                          -1
    X896      R1496                         1
    X896      R1920                         1
    X897      R299                          1
    X897      R300                          -1
    X897      R1497                         1
    X897      R1920                         1
    X898      R300                          1
    X898      R301                          -1
    X898      R1498                         1
    X898      R1920                         1
    X899      R301                          1
    X899      R302                          -1
    X899      R1499                         1
    X899      R1920                         1
    X900      R302                          1
    X900      R303                          -1
    X900      R1500                         1
    X900      R1920                         1
    X901      R303                          1
    X901      R304                          -1
    X901      R1501                         1
    X901      R1920                         1
    X902      R304                          1
    X902      R305                          -1
    X902      R1502                         1
    X902      R1920                         1
    X903      R305                          1
    X903      R306                          -1
    X903      R1503                         1
    X903      R1920                         1
    X904      R306                          1
    X904      R307                          -1
    X904      R1504                         1
    X904      R1920                         1
    X905      R307                          1
    X905      R308                          -1
    X905      R1505                         1
    X905      R1920                         1
    X906      R308                          1
    X906      R309                          -1
    X906      R1506                         1
    X906      R1920                         1
    X907      R309                          1
    X907      R310                          -1
    X907      R1507                         1
    X907      R1920                         1
    X908      R310                          1
    X908      R311                          -1
    X908      R1508                         1
    X908      R1920                         1
    X909      R311                          1
    X909      R312                          -1
    X909      R1509                         1
    X909      R1920                         1
    X910      R312                          1
    X910      R313                          -1
    X910      R1510                         1
    X910      R1920                         1
    X911      R313                          1
    X911      R314                          -1
    X911      R1511                         1
    X911      R1920                         1
    X912      R314                          1
    X912      R315                          -1
    X912      R1512                         1
    X912      R1920                         1
    X913      R315                          1
    X913      R316                          -1
    X913      R1513                         1
    X913      R1920                         1
    X914      R316                          1
    X914      R317                          -1
    X914      R1514                         1
    X914      R1920                         1
    X915      R317                          1
    X915      R318                          -1
    X915      R1515                         1
    X915      R1920                         1
    X916      R318                          1
    X916      R319                          -1
    X916      R1516                         1
    X916      R1920                         1
    X917      R319                          1
    X917      R320                          -1
    X917      R1517                         1
    X917      R1920                         1
    X918      R320                          1
    X918      R321                          -1
    X918      R1518                         1
    X918      R1920                         1
    X919      R321                          1
    X919      R322                          -1
    X919      R1519                         1
    X919      R1920                         1
    X920      R322                          1
    X920      R323                          -1
    X920      R1520                         1
    X920      R1920                         1
    X921      R323                          1
    X921      R324                          -1
    X921      R1521                         1
    X921      R1920                         1
    X922      R324                          1
    X922      R325                          -1
    X922      R1522                         1
    X922      R1920                         1
    X923      R325                          1
    X923      R326                          -1
    X923      R1523                         1
    X923      R1920                         1
    X924      R326                          1
    X924      R327                          -1
    X924      R1524                         1
    X924      R1920                         1
    X925      R327                          1
    X925      R328                          -1
    X925      R1525                         1
    X925      R1920                         1
    X926      R328                          1
    X926      R329                          -1
    X926      R1526                         1
    X926      R1920                         1
    X927      R329                          1
    X927      R330                          -1
    X927      R1527                         1
    X927      R1920                         1
    X928      R330                          1
    X928      R331                          -1
    X928      R1528                         1
    X928      R1920                         1
    X929      R331                          1
    X929      R332                          -1
    X929      R1529                         1
    X929      R1920                         1
    X930      R332                          1
    X930      R333                          -1
    X930      R1530                         1
    X930      R1920                         1
    X931      R333                          1
    X931      R334                          -1
    X931      R1531                         1
    X931      R1920                         1
    X932      R334                          1
    X932      R335                          -1
    X932      R1532                         1
    X932      R1920                         1
    X933      R335                          1
    X933      R336                          -1
    X933      R1533                         1
    X933      R1920                         1
    X934      R336                          1
    X934      R337                          -1
    X934      R1534                         1
    X934      R1920                         1
    X935      R337                          1
    X935      R338                          -1
    X935      R1535                         1
    X935      R1920                         1
    X936      R338                          1
    X936      R339                          -1
    X936      R1536                         1
    X936      R1920                         1
    X937      R339                          1
    X937      R340                          -1
    X937      R1537                         1
    X937      R1920                         1
    X938      R340                          1
    X938      R341                          -1
    X938      R1538                         1
    X938      R1920                         1
    X939      R341                          1
    X939      R342                          -1
    X939      R1539                         1
    X939      R1920                         1
    X940      R342                          1
    X940      R343                          -1
    X940      R1540                         1
    X940      R1920                         1
    X941      R343                          1
    X941      R344                          -1
    X941      R1541                         1
    X941      R1920                         1
    X942      R344                          1
    X942      R345                          -1
    X942      R1542                         1
    X942      R1920                         1
    X943      R345                          1
    X943      R346                          -1
    X943      R1543                         1
    X943      R1920                         1
    X944      R346                          1
    X944      R347                          -1
    X944      R1544                         1
    X944      R1920                         1
    X945      R347                          1
    X945      R348                          -1
    X945      R1545                         1
    X945      R1920                         1
    X946      R348                          1
    X946      R349                          -1
    X946      R1546                         1
    X946      R1920                         1
    X947      R349                          1
    X947      R350                          -1
    X947      R1547                         1
    X947      R1920                         1
    X948      R350                          1
    X948      R351                          -1
    X948      R1548                         1
    X948      R1920                         1
    X949      R351                          1
    X949      R352                          -1
    X949      R1549                         1
    X949      R1920                         1
    X950      R352                          1
    X950      R353                          -1
    X950      R1550                         1
    X950      R1920                         1
    X951      R353                          1
    X951      R354                          -1
    X951      R1551                         1
    X951      R1920                         1
    X952      R354                          1
    X952      R355                          -1
    X952      R1552                         1
    X952      R1920                         1
    X953      R355                          1
    X953      R356                          -1
    X953      R1553                         1
    X953      R1920                         1
    X954      R356                          1
    X954      R357                          -1
    X954      R1554                         1
    X954      R1920                         1
    X955      R357                          1
    X955      R358                          -1
    X955      R1555                         1
    X955      R1920                         1
    X956      R358                          1
    X956      R359                          -1
    X956      R1556                         1
    X956      R1920                         1
    X957      R360                          1
    X957      R361                          -1
    X957      R1557                         1
    X957      R1920                         1
    X958      R361                          1
    X958      R362                          -1
    X958      R1558                         1
    X958      R1920                         1
    X959      R362                          1
    X959      R363                          -1
    X959      R1559                         1
    X959      R1920                         1
    X960      R363                          1
    X960      R364                          -1
    X960      R1560                         1
    X960      R1920                         1
    X961      R364                          1
    X961      R365                          -1
    X961      R1561                         1
    X961      R1920                         1
    X962      R365                          1
    X962      R366                          -1
    X962      R1562                         1
    X962      R1920                         1
    X963      R366                          1
    X963      R367                          -1
    X963      R1563                         1
    X963      R1920                         1
    X964      R367                          1
    X964      R368                          -1
    X964      R1564                         1
    X964      R1920                         1
    X965      R368                          1
    X965      R369                          -1
    X965      R1565                         1
    X965      R1920                         1
    X966      R369                          1
    X966      R370                          -1
    X966      R1566                         1
    X966      R1920                         1
    X967      R370                          1
    X967      R371                          -1
    X967      R1567                         1
    X967      R1920                         1
    X968      R371                          1
    X968      R372                          -1
    X968      R1568                         1
    X968      R1920                         1
    X969      R372                          1
    X969      R373                          -1
    X969      R1569                         1
    X969      R1920                         1
    X970      R373                          1
    X970      R374                          -1
    X970      R1570                         1
    X970      R1920                         1
    X971      R374                          1
    X971      R375                          -1
    X971      R1571                         1
    X971      R1920                         1
    X972      R375                          1
    X972      R376                          -1
    X972      R1572                         1
    X972      R1920                         1
    X973      R376                          1
    X973      R377                          -1
    X973      R1573                         1
    X973      R1920                         1
    X974      R377                          1
    X974      R378                          -1
    X974      R1574                         1
    X974      R1920                         1
    X975      R378                          1
    X975      R379                          -1
    X975      R1575                         1
    X975      R1920                         1
    X976      R379                          1
    X976      R380                          -1
    X976      R1576                         1
    X976      R1920                         1
    X977      R380                          1
    X977      R381                          -1
    X977      R1577                         1
    X977      R1920                         1
    X978      R381                          1
    X978      R382                          -1
    X978      R1578                         1
    X978      R1920                         1
    X979      R382                          1
    X979      R383                          -1
    X979      R1579                         1
    X979      R1920                         1
    X980      R383                          1
    X980      R384                          -1
    X980      R1580                         1
    X980      R1920                         1
    X981      R384                          1
    X981      R385                          -1
    X981      R1581                         1
    X981      R1920                         1
    X982      R385                          1
    X982      R386                          -1
    X982      R1582                         1
    X982      R1920                         1
    X983      R386                          1
    X983      R387                          -1
    X983      R1583                         1
    X983      R1920                         1
    X984      R387                          1
    X984      R388                          -1
    X984      R1584                         1
    X984      R1920                         1
    X985      R388                          1
    X985      R389                          -1
    X985      R1585                         1
    X985      R1920                         1
    X986      R389                          1
    X986      R390                          -1
    X986      R1586                         1
    X986      R1920                         1
    X987      R390                          1
    X987      R391                          -1
    X987      R1587                         1
    X987      R1920                         1
    X988      R391                          1
    X988      R392                          -1
    X988      R1588                         1
    X988      R1920                         1
    X989      R392                          1
    X989      R393                          -1
    X989      R1589                         1
    X989      R1920                         1
    X990      R393                          1
    X990      R394                          -1
    X990      R1590                         1
    X990      R1920                         1
    X991      R394                          1
    X991      R395                          -1
    X991      R1591                         1
    X991      R1920                         1
    X992      R395                          1
    X992      R396                          -1
    X992      R1592                         1
    X992      R1920                         1
    X993      R396                          1
    X993      R397                          -1
    X993      R1593                         1
    X993      R1920                         1
    X994      R397                          1
    X994      R398                          -1
    X994      R1594                         1
    X994      R1920                         1
    X995      R398                          1
    X995      R399                          -1
    X995      R1595                         1
    X995      R1920                         1
    X996      R399                          1
    X996      R400                          -1
    X996      R1596                         1
    X996      R1920                         1
    X997      R400                          1
    X997      R401                          -1
    X997      R1597                         1
    X997      R1920                         1
    X998      R401                          1
    X998      R402                          -1
    X998      R1598                         1
    X998      R1920                         1
    X999      R402                          1
    X999      R403                          -1
    X999      R1599                         1
    X999      R1920                         1
    X1000     R403                          1
    X1000     R404                          -1
    X1000     R1600                         1
    X1000     R1920                         1
    X1001     R404                          1
    X1001     R405                          -1
    X1001     R1601                         1
    X1001     R1920                         1
    X1002     R405                          1
    X1002     R406                          -1
    X1002     R1602                         1
    X1002     R1920                         1
    X1003     R406                          1
    X1003     R407                          -1
    X1003     R1603                         1
    X1003     R1920                         1
    X1004     R407                          1
    X1004     R408                          -1
    X1004     R1604                         1
    X1004     R1920                         1
    X1005     R408                          1
    X1005     R409                          -1
    X1005     R1605                         1
    X1005     R1920                         1
    X1006     R409                          1
    X1006     R410                          -1
    X1006     R1606                         1
    X1006     R1920                         1
    X1007     R410                          1
    X1007     R411                          -1
    X1007     R1607                         1
    X1007     R1920                         1
    X1008     R411                          1
    X1008     R412                          -1
    X1008     R1608                         1
    X1008     R1920                         1
    X1009     R412                          1
    X1009     R413                          -1
    X1009     R1609                         1
    X1009     R1920                         1
    X1010     R413                          1
    X1010     R414                          -1
    X1010     R1610                         1
    X1010     R1920                         1
    X1011     R414                          1
    X1011     R415                          -1
    X1011     R1611                         1
    X1011     R1920                         1
    X1012     R415                          1
    X1012     R416                          -1
    X1012     R1612                         1
    X1012     R1920                         1
    X1013     R416                          1
    X1013     R417                          -1
    X1013     R1613                         1
    X1013     R1920                         1
    X1014     R417                          1
    X1014     R418                          -1
    X1014     R1614                         1
    X1014     R1920                         1
    X1015     R418                          1
    X1015     R419                          -1
    X1015     R1615                         1
    X1015     R1920                         1
    X1016     R419                          1
    X1016     R420                          -1
    X1016     R1616                         1
    X1016     R1920                         1
    X1017     R420                          1
    X1017     R421                          -1
    X1017     R1617                         1
    X1017     R1920                         1
    X1018     R421                          1
    X1018     R422                          -1
    X1018     R1618                         1
    X1018     R1920                         1
    X1019     R422                          1
    X1019     R423                          -1
    X1019     R1619                         1
    X1019     R1920                         1
    X1020     R423                          1
    X1020     R424                          -1
    X1020     R1620                         1
    X1020     R1920                         1
    X1021     R424                          1
    X1021     R425                          -1
    X1021     R1621                         1
    X1021     R1920                         1
    X1022     R425                          1
    X1022     R426                          -1
    X1022     R1622                         1
    X1022     R1920                         1
    X1023     R426                          1
    X1023     R427                          -1
    X1023     R1623                         1
    X1023     R1920                         1
    X1024     R427                          1
    X1024     R428                          -1
    X1024     R1624                         1
    X1024     R1920                         1
    X1025     R428                          1
    X1025     R429                          -1
    X1025     R1625                         1
    X1025     R1920                         1
    X1026     R429                          1
    X1026     R430                          -1
    X1026     R1626                         1
    X1026     R1920                         1
    X1027     R430                          1
    X1027     R431                          -1
    X1027     R1627                         1
    X1027     R1920                         1
    X1028     R431                          1
    X1028     R432                          -1
    X1028     R1628                         1
    X1028     R1920                         1
    X1029     R432                          1
    X1029     R433                          -1
    X1029     R1629                         1
    X1029     R1920                         1
    X1030     R433                          1
    X1030     R434                          -1
    X1030     R1630                         1
    X1030     R1920                         1
    X1031     R434                          1
    X1031     R435                          -1
    X1031     R1631                         1
    X1031     R1920                         1
    X1032     R435                          1
    X1032     R436                          -1
    X1032     R1632                         1
    X1032     R1920                         1
    X1033     R436                          1
    X1033     R437                          -1
    X1033     R1633                         1
    X1033     R1920                         1
    X1034     R437                          1
    X1034     R438                          -1
    X1034     R1634                         1
    X1034     R1920                         1
    X1035     R438                          1
    X1035     R439                          -1
    X1035     R1635                         1
    X1035     R1920                         1
    X1036     R439                          1
    X1036     R440                          -1
    X1036     R1636                         1
    X1036     R1920                         1
    X1037     R440                          1
    X1037     R441                          -1
    X1037     R1637                         1
    X1037     R1920                         1
    X1038     R441                          1
    X1038     R442                          -1
    X1038     R1638                         1
    X1038     R1920                         1
    X1039     R442                          1
    X1039     R443                          -1
    X1039     R1639                         1
    X1039     R1920                         1
    X1040     R443                          1
    X1040     R444                          -1
    X1040     R1640                         1
    X1040     R1920                         1
    X1041     R444                          1
    X1041     R445                          -1
    X1041     R1641                         1
    X1041     R1920                         1
    X1042     R445                          1
    X1042     R446                          -1
    X1042     R1642                         1
    X1042     R1920                         1
    X1043     R446                          1
    X1043     R447                          -1
    X1043     R1643                         1
    X1043     R1920                         1
    X1044     R447                          1
    X1044     R448                          -1
    X1044     R1644                         1
    X1044     R1920                         1
    X1045     R448                          1
    X1045     R449                          -1
    X1045     R1645                         1
    X1045     R1920                         1
    X1046     R449                          1
    X1046     R450                          -1
    X1046     R1646                         1
    X1046     R1920                         1
    X1047     R450                          1
    X1047     R451                          -1
    X1047     R1647                         1
    X1047     R1920                         1
    X1048     R451                          1
    X1048     R452                          -1
    X1048     R1648                         1
    X1048     R1920                         1
    X1049     R452                          1
    X1049     R453                          -1
    X1049     R1649                         1
    X1049     R1920                         1
    X1050     R453                          1
    X1050     R454                          -1
    X1050     R1650                         1
    X1050     R1920                         1
    X1051     R454                          1
    X1051     R455                          -1
    X1051     R1651                         1
    X1051     R1920                         1
    X1052     R455                          1
    X1052     R456                          -1
    X1052     R1652                         1
    X1052     R1920                         1
    X1053     R456                          1
    X1053     R457                          -1
    X1053     R1653                         1
    X1053     R1920                         1
    X1054     R457                          1
    X1054     R458                          -1
    X1054     R1654                         1
    X1054     R1920                         1
    X1055     R458                          1
    X1055     R459                          -1
    X1055     R1655                         1
    X1055     R1920                         1
    X1056     R459                          1
    X1056     R460                          -1
    X1056     R1656                         1
    X1056     R1920                         1
    X1057     R460                          1
    X1057     R461                          -1
    X1057     R1657                         1
    X1057     R1920                         1
    X1058     R461                          1
    X1058     R462                          -1
    X1058     R1658                         1
    X1058     R1920                         1
    X1059     R462                          1
    X1059     R463                          -1
    X1059     R1659                         1
    X1059     R1920                         1
    X1060     R463                          1
    X1060     R464                          -1
    X1060     R1660                         1
    X1060     R1920                         1
    X1061     R464                          1
    X1061     R465                          -1
    X1061     R1661                         1
    X1061     R1920                         1
    X1062     R465                          1
    X1062     R466                          -1
    X1062     R1662                         1
    X1062     R1920                         1
    X1063     R466                          1
    X1063     R467                          -1
    X1063     R1663                         1
    X1063     R1920                         1
    X1064     R467                          1
    X1064     R468                          -1
    X1064     R1664                         1
    X1064     R1920                         1
    X1065     R468                          1
    X1065     R469                          -1
    X1065     R1665                         1
    X1065     R1920                         1
    X1066     R469                          1
    X1066     R470                          -1
    X1066     R1666                         1
    X1066     R1920                         1
    X1067     R470                          1
    X1067     R471                          -1
    X1067     R1667                         1
    X1067     R1920                         1
    X1068     R471                          1
    X1068     R472                          -1
    X1068     R1668                         1
    X1068     R1920                         1
    X1069     R472                          1
    X1069     R473                          -1
    X1069     R1669                         1
    X1069     R1920                         1
    X1070     R473                          1
    X1070     R474                          -1
    X1070     R1670                         1
    X1070     R1920                         1
    X1071     R474                          1
    X1071     R475                          -1
    X1071     R1671                         1
    X1071     R1920                         1
    X1072     R475                          1
    X1072     R476                          -1
    X1072     R1672                         1
    X1072     R1920                         1
    X1073     R476                          1
    X1073     R477                          -1
    X1073     R1673                         1
    X1073     R1920                         1
    X1074     R477                          1
    X1074     R478                          -1
    X1074     R1674                         1
    X1074     R1920                         1
    X1075     R478                          1
    X1075     R479                          -1
    X1075     R1675                         1
    X1075     R1920                         1
    X1076     R480                          1
    X1076     R481                          -1
    X1076     R1676                         1
    X1076     R1920                         1
    X1077     R481                          1
    X1077     R482                          -1
    X1077     R1677                         1
    X1077     R1920                         1
    X1078     R482                          1
    X1078     R483                          -1
    X1078     R1678                         1
    X1078     R1920                         1
    X1079     R483                          1
    X1079     R484                          -1
    X1079     R1679                         1
    X1079     R1920                         1
    X1080     R484                          1
    X1080     R485                          -1
    X1080     R1680                         1
    X1080     R1920                         1
    X1081     R485                          1
    X1081     R486                          -1
    X1081     R1681                         1
    X1081     R1920                         1
    X1082     R486                          1
    X1082     R487                          -1
    X1082     R1682                         1
    X1082     R1920                         1
    X1083     R487                          1
    X1083     R488                          -1
    X1083     R1683                         1
    X1083     R1920                         1
    X1084     R488                          1
    X1084     R489                          -1
    X1084     R1684                         1
    X1084     R1920                         1
    X1085     R489                          1
    X1085     R490                          -1
    X1085     R1685                         1
    X1085     R1920                         1
    X1086     R490                          1
    X1086     R491                          -1
    X1086     R1686                         1
    X1086     R1920                         1
    X1087     R491                          1
    X1087     R492                          -1
    X1087     R1687                         1
    X1087     R1920                         1
    X1088     R492                          1
    X1088     R493                          -1
    X1088     R1688                         1
    X1088     R1920                         1
    X1089     R493                          1
    X1089     R494                          -1
    X1089     R1689                         1
    X1089     R1920                         1
    X1090     R494                          1
    X1090     R495                          -1
    X1090     R1690                         1
    X1090     R1920                         1
    X1091     R495                          1
    X1091     R496                          -1
    X1091     R1691                         1
    X1091     R1920                         1
    X1092     R496                          1
    X1092     R497                          -1
    X1092     R1692                         1
    X1092     R1920                         1
    X1093     R497                          1
    X1093     R498                          -1
    X1093     R1693                         1
    X1093     R1920                         1
    X1094     R498                          1
    X1094     R499                          -1
    X1094     R1694                         1
    X1094     R1920                         1
    X1095     R499                          1
    X1095     R500                          -1
    X1095     R1695                         1
    X1095     R1920                         1
    X1096     R500                          1
    X1096     R501                          -1
    X1096     R1696                         1
    X1096     R1920                         1
    X1097     R501                          1
    X1097     R502                          -1
    X1097     R1697                         1
    X1097     R1920                         1
    X1098     R502                          1
    X1098     R503                          -1
    X1098     R1698                         1
    X1098     R1920                         1
    X1099     R503                          1
    X1099     R504                          -1
    X1099     R1699                         1
    X1099     R1920                         1
    X1100     R504                          1
    X1100     R505                          -1
    X1100     R1700                         1
    X1100     R1920                         1
    X1101     R505                          1
    X1101     R506                          -1
    X1101     R1701                         1
    X1101     R1920                         1
    X1102     R506                          1
    X1102     R507                          -1
    X1102     R1702                         1
    X1102     R1920                         1
    X1103     R507                          1
    X1103     R508                          -1
    X1103     R1703                         1
    X1103     R1920                         1
    X1104     R508                          1
    X1104     R509                          -1
    X1104     R1704                         1
    X1104     R1920                         1
    X1105     R509                          1
    X1105     R510                          -1
    X1105     R1705                         1
    X1105     R1920                         1
    X1106     R510                          1
    X1106     R511                          -1
    X1106     R1706                         1
    X1106     R1920                         1
    X1107     R511                          1
    X1107     R512                          -1
    X1107     R1707                         1
    X1107     R1920                         1
    X1108     R512                          1
    X1108     R513                          -1
    X1108     R1708                         1
    X1108     R1920                         1
    X1109     R513                          1
    X1109     R514                          -1
    X1109     R1709                         1
    X1109     R1920                         1
    X1110     R514                          1
    X1110     R515                          -1
    X1110     R1710                         1
    X1110     R1920                         1
    X1111     R515                          1
    X1111     R516                          -1
    X1111     R1711                         1
    X1111     R1920                         1
    X1112     R516                          1
    X1112     R517                          -1
    X1112     R1712                         1
    X1112     R1920                         1
    X1113     R517                          1
    X1113     R518                          -1
    X1113     R1713                         1
    X1113     R1920                         1
    X1114     R518                          1
    X1114     R519                          -1
    X1114     R1714                         1
    X1114     R1920                         1
    X1115     R519                          1
    X1115     R520                          -1
    X1115     R1715                         1
    X1115     R1920                         1
    X1116     R520                          1
    X1116     R521                          -1
    X1116     R1716                         1
    X1116     R1920                         1
    X1117     R521                          1
    X1117     R522                          -1
    X1117     R1717                         1
    X1117     R1920                         1
    X1118     R522                          1
    X1118     R523                          -1
    X1118     R1718                         1
    X1118     R1920                         1
    X1119     R523                          1
    X1119     R524                          -1
    X1119     R1719                         1
    X1119     R1920                         1
    X1120     R524                          1
    X1120     R525                          -1
    X1120     R1720                         1
    X1120     R1920                         1
    X1121     R525                          1
    X1121     R526                          -1
    X1121     R1721                         1
    X1121     R1920                         1
    X1122     R526                          1
    X1122     R527                          -1
    X1122     R1722                         1
    X1122     R1920                         1
    X1123     R527                          1
    X1123     R528                          -1
    X1123     R1723                         1
    X1123     R1920                         1
    X1124     R528                          1
    X1124     R529                          -1
    X1124     R1724                         1
    X1124     R1920                         1
    X1125     R529                          1
    X1125     R530                          -1
    X1125     R1725                         1
    X1125     R1920                         1
    X1126     R530                          1
    X1126     R531                          -1
    X1126     R1726                         1
    X1126     R1920                         1
    X1127     R531                          1
    X1127     R532                          -1
    X1127     R1727                         1
    X1127     R1920                         1
    X1128     R532                          1
    X1128     R533                          -1
    X1128     R1728                         1
    X1128     R1920                         1
    X1129     R533                          1
    X1129     R534                          -1
    X1129     R1729                         1
    X1129     R1920                         1
    X1130     R534                          1
    X1130     R535                          -1
    X1130     R1730                         1
    X1130     R1920                         1
    X1131     R535                          1
    X1131     R536                          -1
    X1131     R1731                         1
    X1131     R1920                         1
    X1132     R536                          1
    X1132     R537                          -1
    X1132     R1732                         1
    X1132     R1920                         1
    X1133     R537                          1
    X1133     R538                          -1
    X1133     R1733                         1
    X1133     R1920                         1
    X1134     R538                          1
    X1134     R539                          -1
    X1134     R1734                         1
    X1134     R1920                         1
    X1135     R539                          1
    X1135     R540                          -1
    X1135     R1735                         1
    X1135     R1920                         1
    X1136     R540                          1
    X1136     R541                          -1
    X1136     R1736                         1
    X1136     R1920                         1
    X1137     R541                          1
    X1137     R542                          -1
    X1137     R1737                         1
    X1137     R1920                         1
    X1138     R542                          1
    X1138     R543                          -1
    X1138     R1738                         1
    X1138     R1920                         1
    X1139     R543                          1
    X1139     R544                          -1
    X1139     R1739                         1
    X1139     R1920                         1
    X1140     R544                          1
    X1140     R545                          -1
    X1140     R1740                         1
    X1140     R1920                         1
    X1141     R545                          1
    X1141     R546                          -1
    X1141     R1741                         1
    X1141     R1920                         1
    X1142     R546                          1
    X1142     R547                          -1
    X1142     R1742                         1
    X1142     R1920                         1
    X1143     R547                          1
    X1143     R548                          -1
    X1143     R1743                         1
    X1143     R1920                         1
    X1144     R548                          1
    X1144     R549                          -1
    X1144     R1744                         1
    X1144     R1920                         1
    X1145     R549                          1
    X1145     R550                          -1
    X1145     R1745                         1
    X1145     R1920                         1
    X1146     R550                          1
    X1146     R551                          -1
    X1146     R1746                         1
    X1146     R1920                         1
    X1147     R551                          1
    X1147     R552                          -1
    X1147     R1747                         1
    X1147     R1920                         1
    X1148     R552                          1
    X1148     R553                          -1
    X1148     R1748                         1
    X1148     R1920                         1
    X1149     R553                          1
    X1149     R554                          -1
    X1149     R1749                         1
    X1149     R1920                         1
    X1150     R554                          1
    X1150     R555                          -1
    X1150     R1750                         1
    X1150     R1920                         1
    X1151     R555                          1
    X1151     R556                          -1
    X1151     R1751                         1
    X1151     R1920                         1
    X1152     R556                          1
    X1152     R557                          -1
    X1152     R1752                         1
    X1152     R1920                         1
    X1153     R557                          1
    X1153     R558                          -1
    X1153     R1753                         1
    X1153     R1920                         1
    X1154     R558                          1
    X1154     R559                          -1
    X1154     R1754                         1
    X1154     R1920                         1
    X1155     R559                          1
    X1155     R560                          -1
    X1155     R1755                         1
    X1155     R1920                         1
    X1156     R560                          1
    X1156     R561                          -1
    X1156     R1756                         1
    X1156     R1920                         1
    X1157     R561                          1
    X1157     R562                          -1
    X1157     R1757                         1
    X1157     R1920                         1
    X1158     R562                          1
    X1158     R563                          -1
    X1158     R1758                         1
    X1158     R1920                         1
    X1159     R563                          1
    X1159     R564                          -1
    X1159     R1759                         1
    X1159     R1920                         1
    X1160     R564                          1
    X1160     R565                          -1
    X1160     R1760                         1
    X1160     R1920                         1
    X1161     R565                          1
    X1161     R566                          -1
    X1161     R1761                         1
    X1161     R1920                         1
    X1162     R566                          1
    X1162     R567                          -1
    X1162     R1762                         1
    X1162     R1920                         1
    X1163     R567                          1
    X1163     R568                          -1
    X1163     R1763                         1
    X1163     R1920                         1
    X1164     R568                          1
    X1164     R569                          -1
    X1164     R1764                         1
    X1164     R1920                         1
    X1165     R569                          1
    X1165     R570                          -1
    X1165     R1765                         1
    X1165     R1920                         1
    X1166     R570                          1
    X1166     R571                          -1
    X1166     R1766                         1
    X1166     R1920                         1
    X1167     R571                          1
    X1167     R572                          -1
    X1167     R1767                         1
    X1167     R1920                         1
    X1168     R572                          1
    X1168     R573                          -1
    X1168     R1768                         1
    X1168     R1920                         1
    X1169     R573                          1
    X1169     R574                          -1
    X1169     R1769                         1
    X1169     R1920                         1
    X1170     R574                          1
    X1170     R575                          -1
    X1170     R1770                         1
    X1170     R1920                         1
    X1171     R575                          1
    X1171     R576                          -1
    X1171     R1771                         1
    X1171     R1920                         1
    X1172     R576                          1
    X1172     R577                          -1
    X1172     R1772                         1
    X1172     R1920                         1
    X1173     R577                          1
    X1173     R578                          -1
    X1173     R1773                         1
    X1173     R1920                         1
    X1174     R578                          1
    X1174     R579                          -1
    X1174     R1774                         1
    X1174     R1920                         1
    X1175     R579                          1
    X1175     R580                          -1
    X1175     R1775                         1
    X1175     R1920                         1
    X1176     R580                          1
    X1176     R581                          -1
    X1176     R1776                         1
    X1176     R1920                         1
    X1177     R581                          1
    X1177     R582                          -1
    X1177     R1777                         1
    X1177     R1920                         1
    X1178     R582                          1
    X1178     R583                          -1
    X1178     R1778                         1
    X1178     R1920                         1
    X1179     R583                          1
    X1179     R584                          -1
    X1179     R1779                         1
    X1179     R1920                         1
    X1180     R584                          1
    X1180     R585                          -1
    X1180     R1780                         1
    X1180     R1920                         1
    X1181     R585                          1
    X1181     R586                          -1
    X1181     R1781                         1
    X1181     R1920                         1
    X1182     R586                          1
    X1182     R587                          -1
    X1182     R1782                         1
    X1182     R1920                         1
    X1183     R587                          1
    X1183     R588                          -1
    X1183     R1783                         1
    X1183     R1920                         1
    X1184     R588                          1
    X1184     R589                          -1
    X1184     R1784                         1
    X1184     R1920                         1
    X1185     R589                          1
    X1185     R590                          -1
    X1185     R1785                         1
    X1185     R1920                         1
    X1186     R590                          1
    X1186     R591                          -1
    X1186     R1786                         1
    X1186     R1920                         1
    X1187     R591                          1
    X1187     R592                          -1
    X1187     R1787                         1
    X1187     R1920                         1
    X1188     R592                          1
    X1188     R593                          -1
    X1188     R1788                         1
    X1188     R1920                         1
    X1189     R593                          1
    X1189     R594                          -1
    X1189     R1789                         1
    X1189     R1920                         1
    X1190     R594                          1
    X1190     R595                          -1
    X1190     R1790                         1
    X1190     R1920                         1
    X1191     R595                          1
    X1191     R596                          -1
    X1191     R1791                         1
    X1191     R1920                         1
    X1192     R596                          1
    X1192     R597                          -1
    X1192     R1792                         1
    X1192     R1920                         1
    X1193     R597                          1
    X1193     R598                          -1
    X1193     R1793                         1
    X1193     R1920                         1
    X1194     R598                          1
    X1194     R599                          -1
    X1194     R1794                         1
    X1194     R1920                         1
    X1195     R0                            -1
    X1195     R1                            1
    X1195     R1920                         3
    X1196     R1                            -1
    X1196     R2                            1
    X1196     R1920                         2
    X1197     R2                            -1
    X1197     R3                            1
    X1197     R1920                         1
    X1198     R3                            -1
    X1198     R4                            1
    X1198     R1920                         5
    X1199     R4                            -1
    X1199     R5                            1
    X1199     R1920                         3
    X1200     R5                            -1
    X1200     R6                            1
    X1200     R1920                         5
    X1201     R6                            -1
    X1201     R7                            1
    X1201     R1920                         4
    X1202     R7                            -1
    X1202     R8                            1
    X1202     R1920                         1
    X1203     R8                            -1
    X1203     R9                            1
    X1203     R1920                         2
    X1204     R9                            -1
    X1204     R10                           1
    X1204     R1920                         4
    X1205     R10                           -1
    X1205     R11                           1
    X1205     R1920                         5
    X1206     R11                           -1
    X1206     R12                           1
    X1206     R1920                         1
    X1207     R12                           -1
    X1207     R13                           1
    X1207     R1920                         4
    X1208     R13                           -1
    X1208     R14                           1
    X1208     R1920                         4
    X1209     R14                           -1
    X1209     R15                           1
    X1209     R1920                         1
    X1210     R15                           -1
    X1210     R16                           1
    X1210     R1920                         5
    X1211     R16                           -1
    X1211     R17                           1
    X1211     R1920                         4
    X1212     R17                           -1
    X1212     R18                           1
    X1212     R1920                         2
    X1213     R18                           -1
    X1213     R19                           1
    X1213     R1920                         1
    X1214     R19                           -1
    X1214     R20                           1
    X1214     R1920                         4
    X1215     R20                           -1
    X1215     R21                           1
    X1215     R1920                         5
    X1216     R21                           -1
    X1216     R22                           1
    X1216     R1920                         4
    X1217     R22                           -1
    X1217     R23                           1
    X1217     R1920                         3
    X1218     R23                           -1
    X1218     R24                           1
    X1218     R1920                         4
    X1219     R24                           -1
    X1219     R25                           1
    X1219     R1920                         3
    X1220     R25                           -1
    X1220     R26                           1
    X1220     R1920                         1
    X1221     R26                           -1
    X1221     R27                           1
    X1221     R1920                         2
    X1222     R27                           -1
    X1222     R28                           1
    X1222     R1920                         1
    X1223     R28                           -1
    X1223     R29                           1
    X1223     R1920                         1
    X1224     R29                           -1
    X1224     R30                           1
    X1224     R1920                         4
    X1225     R30                           -1
    X1225     R31                           1
    X1225     R1920                         4
    X1226     R31                           -1
    X1226     R32                           1
    X1226     R1920                         3
    X1227     R32                           -1
    X1227     R33                           1
    X1227     R1920                         4
    X1228     R33                           -1
    X1228     R34                           1
    X1228     R1920                         4
    X1229     R34                           -1
    X1229     R35                           1
    X1229     R1920                         3
    X1230     R35                           -1
    X1230     R36                           1
    X1230     R1920                         3
    X1231     R36                           -1
    X1231     R37                           1
    X1231     R1920                         4
    X1232     R37                           -1
    X1232     R38                           1
    X1232     R1920                         5
    X1233     R38                           -1
    X1233     R39                           1
    X1233     R1920                         2
    X1234     R39                           -1
    X1234     R40                           1
    X1234     R1920                         5
    X1235     R40                           -1
    X1235     R41                           1
    X1235     R1920                         2
    X1236     R41                           -1
    X1236     R42                           1
    X1236     R1920                         2
    X1237     R42                           -1
    X1237     R43                           1
    X1237     R1920                         5
    X1238     R43                           -1
    X1238     R44                           1
    X1238     R1920                         2
    X1239     R44                           -1
    X1239     R45                           1
    X1239     R1920                         4
    X1240     R45                           -1
    X1240     R46                           1
    X1240     R1920                         4
    X1241     R46                           -1
    X1241     R47                           1
    X1241     R1920                         4
    X1242     R47                           -1
    X1242     R48                           1
    X1242     R1920                         5
    X1243     R48                           -1
    X1243     R49                           1
    X1243     R1920                         3
    X1244     R49                           -1
    X1244     R50                           1
    X1244     R1920                         2
    X1245     R50                           -1
    X1245     R51                           1
    X1245     R1920                         1
    X1246     R51                           -1
    X1246     R52                           1
    X1246     R1920                         2
    X1247     R52                           -1
    X1247     R53                           1
    X1247     R1920                         4
    X1248     R53                           -1
    X1248     R54                           1
    X1248     R1920                         4
    X1249     R54                           -1
    X1249     R55                           1
    X1249     R1920                         3
    X1250     R55                           -1
    X1250     R56                           1
    X1250     R1920                         5
    X1251     R56                           -1
    X1251     R57                           1
    X1251     R1920                         2
    X1252     R57                           -1
    X1252     R58                           1
    X1252     R1920                         5
    X1253     R58                           -1
    X1253     R59                           1
    X1253     R1920                         2
    X1254     R59                           -1
    X1254     R60                           1
    X1254     R1920                         2
    X1255     R60                           -1
    X1255     R61                           1
    X1255     R1920                         3
    X1256     R61                           -1
    X1256     R62                           1
    X1256     R1920                         1
    X1257     R62                           -1
    X1257     R63                           1
    X1257     R1920                         2
    X1258     R63                           -1
    X1258     R64                           1
    X1258     R1920                         1
    X1259     R64                           -1
    X1259     R65                           1
    X1259     R1920                         1
    X1260     R65                           -1
    X1260     R66                           1
    X1260     R1920                         4
    X1261     R66                           -1
    X1261     R67                           1
    X1261     R1920                         3
    X1262     R67                           -1
    X1262     R68                           1
    X1262     R1920                         1
    X1263     R68                           -1
    X1263     R69                           1
    X1263     R1920                         3
    X1264     R69                           -1
    X1264     R70                           1
    X1264     R1920                         2
    X1265     R70                           -1
    X1265     R71                           1
    X1265     R1920                         3
    X1266     R71                           -1
    X1266     R72                           1
    X1266     R1920                         1
    X1267     R72                           -1
    X1267     R73                           1
    X1267     R1920                         3
    X1268     R73                           -1
    X1268     R74                           1
    X1268     R1920                         3
    X1269     R74                           -1
    X1269     R75                           1
    X1269     R1920                         4
    X1270     R75                           -1
    X1270     R76                           1
    X1270     R1920                         1
    X1271     R76                           -1
    X1271     R77                           1
    X1271     R1920                         1
    X1272     R77                           -1
    X1272     R78                           1
    X1272     R1920                         3
    X1273     R78                           -1
    X1273     R79                           1
    X1273     R1920                         4
    X1274     R79                           -1
    X1274     R80                           1
    X1274     R1920                         5
    X1275     R80                           -1
    X1275     R81                           1
    X1275     R1920                         5
    X1276     R81                           -1
    X1276     R82                           1
    X1276     R1920                         5
    X1277     R82                           -1
    X1277     R83                           1
    X1277     R1920                         5
    X1278     R83                           -1
    X1278     R84                           1
    X1278     R1920                         5
    X1279     R84                           -1
    X1279     R85                           1
    X1279     R1920                         3
    X1280     R85                           -1
    X1280     R86                           1
    X1280     R1920                         4
    X1281     R86                           -1
    X1281     R87                           1
    X1281     R1920                         1
    X1282     R87                           -1
    X1282     R88                           1
    X1282     R1920                         4
    X1283     R88                           -1
    X1283     R89                           1
    X1283     R1920                         4
    X1284     R89                           -1
    X1284     R90                           1
    X1284     R1920                         5
    X1285     R90                           -1
    X1285     R91                           1
    X1285     R1920                         2
    X1286     R91                           -1
    X1286     R92                           1
    X1286     R1920                         1
    X1287     R92                           -1
    X1287     R93                           1
    X1287     R1920                         3
    X1288     R93                           -1
    X1288     R94                           1
    X1288     R1920                         2
    X1289     R94                           -1
    X1289     R95                           1
    X1289     R1920                         5
    X1290     R95                           -1
    X1290     R96                           1
    X1290     R1920                         4
    X1291     R96                           -1
    X1291     R97                           1
    X1291     R1920                         4
    X1292     R97                           -1
    X1292     R98                           1
    X1292     R1920                         5
    X1293     R98                           -1
    X1293     R99                           1
    X1293     R1920                         3
    X1294     R99                           -1
    X1294     R100                          1
    X1294     R1920                         1
    X1295     R100                          -1
    X1295     R101                          1
    X1295     R1920                         1
    X1296     R101                          -1
    X1296     R102                          1
    X1296     R1920                         3
    X1297     R102                          -1
    X1297     R103                          1
    X1297     R1920                         1
    X1298     R103                          -1
    X1298     R104                          1
    X1298     R1920                         5
    X1299     R104                          -1
    X1299     R105                          1
    X1299     R1920                         2
    X1300     R105                          -1
    X1300     R106                          1
    X1300     R1920                         5
    X1301     R106                          -1
    X1301     R107                          1
    X1301     R1920                         5
    X1302     R107                          -1
    X1302     R108                          1
    X1302     R1920                         3
    X1303     R108                          -1
    X1303     R109                          1
    X1303     R1920                         1
    X1304     R109                          -1
    X1304     R110                          1
    X1304     R1920                         4
    X1305     R110                          -1
    X1305     R111                          1
    X1305     R1920                         2
    X1306     R111                          -1
    X1306     R112                          1
    X1306     R1920                         3
    X1307     R112                          -1
    X1307     R113                          1
    X1307     R1920                         5
    X1308     R113                          -1
    X1308     R114                          1
    X1308     R1920                         5
    X1309     R114                          -1
    X1309     R115                          1
    X1309     R1920                         2
    X1310     R115                          -1
    X1310     R116                          1
    X1310     R1920                         4
    X1311     R116                          -1
    X1311     R117                          1
    X1311     R1920                         2
    X1312     R117                          -1
    X1312     R118                          1
    X1312     R1920                         3
    X1313     R118                          -1
    X1313     R119                          1
    X1313     R1920                         3
    X1314     R120                          -1
    X1314     R121                          1
    X1314     R1920                         4
    X1315     R121                          -1
    X1315     R122                          1
    X1315     R1920                         4
    X1316     R122                          -1
    X1316     R123                          1
    X1316     R1920                         4
    X1317     R123                          -1
    X1317     R124                          1
    X1317     R1920                         4
    X1318     R124                          -1
    X1318     R125                          1
    X1318     R1920                         1
    X1319     R125                          -1
    X1319     R126                          1
    X1319     R1920                         2
    X1320     R126                          -1
    X1320     R127                          1
    X1320     R1920                         5
    X1321     R127                          -1
    X1321     R128                          1
    X1321     R1920                         4
    X1322     R128                          -1
    X1322     R129                          1
    X1322     R1920                         4
    X1323     R129                          -1
    X1323     R130                          1
    X1323     R1920                         5
    X1324     R130                          -1
    X1324     R131                          1
    X1324     R1920                         2
    X1325     R131                          -1
    X1325     R132                          1
    X1325     R1920                         4
    X1326     R132                          -1
    X1326     R133                          1
    X1326     R1920                         1
    X1327     R133                          -1
    X1327     R134                          1
    X1327     R1920                         4
    X1328     R134                          -1
    X1328     R135                          1
    X1328     R1920                         4
    X1329     R135                          -1
    X1329     R136                          1
    X1329     R1920                         5
    X1330     R136                          -1
    X1330     R137                          1
    X1330     R1920                         2
    X1331     R137                          -1
    X1331     R138                          1
    X1331     R1920                         2
    X1332     R138                          -1
    X1332     R139                          1
    X1332     R1920                         5
    X1333     R139                          -1
    X1333     R140                          1
    X1333     R1920                         1
    X1334     R140                          -1
    X1334     R141                          1
    X1334     R1920                         2
    X1335     R141                          -1
    X1335     R142                          1
    X1335     R1920                         2
    X1336     R142                          -1
    X1336     R143                          1
    X1336     R1920                         3
    X1337     R143                          -1
    X1337     R144                          1
    X1337     R1920                         1
    X1338     R144                          -1
    X1338     R145                          1
    X1338     R1920                         2
    X1339     R145                          -1
    X1339     R146                          1
    X1339     R1920                         1
    X1340     R146                          -1
    X1340     R147                          1
    X1340     R1920                         5
    X1341     R147                          -1
    X1341     R148                          1
    X1341     R1920                         5
    X1342     R148                          -1
    X1342     R149                          1
    X1342     R1920                         3
    X1343     R149                          -1
    X1343     R150                          1
    X1343     R1920                         1
    X1344     R150                          -1
    X1344     R151                          1
    X1344     R1920                         3
    X1345     R151                          -1
    X1345     R152                          1
    X1345     R1920                         1
    X1346     R152                          -1
    X1346     R153                          1
    X1346     R1920                         4
    X1347     R153                          -1
    X1347     R154                          1
    X1347     R1920                         3
    X1348     R154                          -1
    X1348     R155                          1
    X1348     R1920                         4
    X1349     R155                          -1
    X1349     R156                          1
    X1349     R1920                         2
    X1350     R156                          -1
    X1350     R157                          1
    X1350     R1920                         1
    X1351     R157                          -1
    X1351     R158                          1
    X1351     R1920                         1
    X1352     R158                          -1
    X1352     R159                          1
    X1352     R1920                         5
    X1353     R159                          -1
    X1353     R160                          1
    X1353     R1920                         2
    X1354     R160                          -1
    X1354     R161                          1
    X1354     R1920                         5
    X1355     R161                          -1
    X1355     R162                          1
    X1355     R1920                         3
    X1356     R162                          -1
    X1356     R163                          1
    X1356     R1920                         1
    X1357     R163                          -1
    X1357     R164                          1
    X1357     R1920                         4
    X1358     R164                          -1
    X1358     R165                          1
    X1358     R1920                         1
    X1359     R165                          -1
    X1359     R166                          1
    X1359     R1920                         1
    X1360     R166                          -1
    X1360     R167                          1
    X1360     R1920                         2
    X1361     R167                          -1
    X1361     R168                          1
    X1361     R1920                         3
    X1362     R168                          -1
    X1362     R169                          1
    X1362     R1920                         3
    X1363     R169                          -1
    X1363     R170                          1
    X1363     R1920                         3
    X1364     R170                          -1
    X1364     R171                          1
    X1364     R1920                         5
    X1365     R171                          -1
    X1365     R172                          1
    X1365     R1920                         4
    X1366     R172                          -1
    X1366     R173                          1
    X1366     R1920                         1
    X1367     R173                          -1
    X1367     R174                          1
    X1367     R1920                         1
    X1368     R174                          -1
    X1368     R175                          1
    X1368     R1920                         2
    X1369     R175                          -1
    X1369     R176                          1
    X1369     R1920                         1
    X1370     R176                          -1
    X1370     R177                          1
    X1370     R1920                         3
    X1371     R177                          -1
    X1371     R178                          1
    X1371     R1920                         2
    X1372     R178                          -1
    X1372     R179                          1
    X1372     R1920                         4
    X1373     R179                          -1
    X1373     R180                          1
    X1373     R1920                         4
    X1374     R180                          -1
    X1374     R181                          1
    X1374     R1920                         4
    X1375     R181                          -1
    X1375     R182                          1
    X1375     R1920                         1
    X1376     R182                          -1
    X1376     R183                          1
    X1376     R1920                         1
    X1377     R183                          -1
    X1377     R184                          1
    X1377     R1920                         1
    X1378     R184                          -1
    X1378     R185                          1
    X1378     R1920                         4
    X1379     R185                          -1
    X1379     R186                          1
    X1379     R1920                         3
    X1380     R186                          -1
    X1380     R187                          1
    X1380     R1920                         1
    X1381     R187                          -1
    X1381     R188                          1
    X1381     R1920                         5
    X1382     R188                          -1
    X1382     R189                          1
    X1382     R1920                         3
    X1383     R189                          -1
    X1383     R190                          1
    X1383     R1920                         4
    X1384     R190                          -1
    X1384     R191                          1
    X1384     R1920                         3
    X1385     R191                          -1
    X1385     R192                          1
    X1385     R1920                         3
    X1386     R192                          -1
    X1386     R193                          1
    X1386     R1920                         2
    X1387     R193                          -1
    X1387     R194                          1
    X1387     R1920                         2
    X1388     R194                          -1
    X1388     R195                          1
    X1388     R1920                         3
    X1389     R195                          -1
    X1389     R196                          1
    X1389     R1920                         2
    X1390     R196                          -1
    X1390     R197                          1
    X1390     R1920                         5
    X1391     R197                          -1
    X1391     R198                          1
    X1391     R1920                         4
    X1392     R198                          -1
    X1392     R199                          1
    X1392     R1920                         1
    X1393     R199                          -1
    X1393     R200                          1
    X1393     R1920                         4
    X1394     R200                          -1
    X1394     R201                          1
    X1394     R1920                         5
    X1395     R201                          -1
    X1395     R202                          1
    X1395     R1920                         5
    X1396     R202                          -1
    X1396     R203                          1
    X1396     R1920                         5
    X1397     R203                          -1
    X1397     R204                          1
    X1397     R1920                         2
    X1398     R204                          -1
    X1398     R205                          1
    X1398     R1920                         2
    X1399     R205                          -1
    X1399     R206                          1
    X1399     R1920                         2
    X1400     R206                          -1
    X1400     R207                          1
    X1400     R1920                         1
    X1401     R207                          -1
    X1401     R208                          1
    X1401     R1920                         3
    X1402     R208                          -1
    X1402     R209                          1
    X1402     R1920                         3
    X1403     R209                          -1
    X1403     R210                          1
    X1403     R1920                         5
    X1404     R210                          -1
    X1404     R211                          1
    X1404     R1920                         1
    X1405     R211                          -1
    X1405     R212                          1
    X1405     R1920                         5
    X1406     R212                          -1
    X1406     R213                          1
    X1406     R1920                         4
    X1407     R213                          -1
    X1407     R214                          1
    X1407     R1920                         4
    X1408     R214                          -1
    X1408     R215                          1
    X1408     R1920                         5
    X1409     R215                          -1
    X1409     R216                          1
    X1409     R1920                         2
    X1410     R216                          -1
    X1410     R217                          1
    X1410     R1920                         1
    X1411     R217                          -1
    X1411     R218                          1
    X1411     R1920                         5
    X1412     R218                          -1
    X1412     R219                          1
    X1412     R1920                         2
    X1413     R219                          -1
    X1413     R220                          1
    X1413     R1920                         1
    X1414     R220                          -1
    X1414     R221                          1
    X1414     R1920                         3
    X1415     R221                          -1
    X1415     R222                          1
    X1415     R1920                         1
    X1416     R222                          -1
    X1416     R223                          1
    X1416     R1920                         4
    X1417     R223                          -1
    X1417     R224                          1
    X1417     R1920                         3
    X1418     R224                          -1
    X1418     R225                          1
    X1418     R1920                         3
    X1419     R225                          -1
    X1419     R226                          1
    X1419     R1920                         3
    X1420     R226                          -1
    X1420     R227                          1
    X1420     R1920                         2
    X1421     R227                          -1
    X1421     R228                          1
    X1421     R1920                         1
    X1422     R228                          -1
    X1422     R229                          1
    X1422     R1920                         1
    X1423     R229                          -1
    X1423     R230                          1
    X1423     R1920                         4
    X1424     R230                          -1
    X1424     R231                          1
    X1424     R1920                         1
    X1425     R231                          -1
    X1425     R232                          1
    X1425     R1920                         2
    X1426     R232                          -1
    X1426     R233                          1
    X1426     R1920                         4
    X1427     R233                          -1
    X1427     R234                          1
    X1427     R1920                         3
    X1428     R234                          -1
    X1428     R235                          1
    X1428     R1920                         5
    X1429     R235                          -1
    X1429     R236                          1
    X1429     R1920                         2
    X1430     R236                          -1
    X1430     R237                          1
    X1430     R1920                         3
    X1431     R237                          -1
    X1431     R238                          1
    X1431     R1920                         3
    X1432     R238                          -1
    X1432     R239                          1
    X1432     R1920                         3
    X1433     R240                          -1
    X1433     R241                          1
    X1433     R1920                         2
    X1434     R241                          -1
    X1434     R242                          1
    X1434     R1920                         2
    X1435     R242                          -1
    X1435     R243                          1
    X1435     R1920                         3
    X1436     R243                          -1
    X1436     R244                          1
    X1436     R1920                         2
    X1437     R244                          -1
    X1437     R245                          1
    X1437     R1920                         5
    X1438     R245                          -1
    X1438     R246                          1
    X1438     R1920                         4
    X1439     R246                          -1
    X1439     R247                          1
    X1439     R1920                         3
    X1440     R247                          -1
    X1440     R248                          1
    X1440     R1920                         5
    X1441     R248                          -1
    X1441     R249                          1
    X1441     R1920                         3
    X1442     R249                          -1
    X1442     R250                          1
    X1442     R1920                         4
    X1443     R250                          -1
    X1443     R251                          1
    X1443     R1920                         5
    X1444     R251                          -1
    X1444     R252                          1
    X1444     R1920                         3
    X1445     R252                          -1
    X1445     R253                          1
    X1445     R1920                         2
    X1446     R253                          -1
    X1446     R254                          1
    X1446     R1920                         2
    X1447     R254                          -1
    X1447     R255                          1
    X1447     R1920                         4
    X1448     R255                          -1
    X1448     R256                          1
    X1448     R1920                         2
    X1449     R256                          -1
    X1449     R257                          1
    X1449     R1920                         1
    X1450     R257                          -1
    X1450     R258                          1
    X1450     R1920                         5
    X1451     R258                          -1
    X1451     R259                          1
    X1451     R1920                         3
    X1452     R259                          -1
    X1452     R260                          1
    X1452     R1920                         5
    X1453     R260                          -1
    X1453     R261                          1
    X1453     R1920                         5
    X1454     R261                          -1
    X1454     R262                          1
    X1454     R1920                         5
    X1455     R262                          -1
    X1455     R263                          1
    X1455     R1920                         3
    X1456     R263                          -1
    X1456     R264                          1
    X1456     R1920                         3
    X1457     R264                          -1
    X1457     R265                          1
    X1457     R1920                         1
    X1458     R265                          -1
    X1458     R266                          1
    X1458     R1920                         5
    X1459     R266                          -1
    X1459     R267                          1
    X1459     R1920                         3
    X1460     R267                          -1
    X1460     R268                          1
    X1460     R1920                         1
    X1461     R268                          -1
    X1461     R269                          1
    X1461     R1920                         5
    X1462     R269                          -1
    X1462     R270                          1
    X1462     R1920                         5
    X1463     R270                          -1
    X1463     R271                          1
    X1463     R1920                         2
    X1464     R271                          -1
    X1464     R272                          1
    X1464     R1920                         1
    X1465     R272                          -1
    X1465     R273                          1
    X1465     R1920                         4
    X1466     R273                          -1
    X1466     R274                          1
    X1466     R1920                         2
    X1467     R274                          -1
    X1467     R275                          1
    X1467     R1920                         2
    X1468     R275                          -1
    X1468     R276                          1
    X1468     R1920                         1
    X1469     R276                          -1
    X1469     R277                          1
    X1469     R1920                         4
    X1470     R277                          -1
    X1470     R278                          1
    X1470     R1920                         2
    X1471     R278                          -1
    X1471     R279                          1
    X1471     R1920                         4
    X1472     R279                          -1
    X1472     R280                          1
    X1472     R1920                         2
    X1473     R280                          -1
    X1473     R281                          1
    X1473     R1920                         5
    X1474     R281                          -1
    X1474     R282                          1
    X1474     R1920                         5
    X1475     R282                          -1
    X1475     R283                          1
    X1475     R1920                         5
    X1476     R283                          -1
    X1476     R284                          1
    X1476     R1920                         1
    X1477     R284                          -1
    X1477     R285                          1
    X1477     R1920                         1
    X1478     R285                          -1
    X1478     R286                          1
    X1478     R1920                         5
    X1479     R286                          -1
    X1479     R287                          1
    X1479     R1920                         1
    X1480     R287                          -1
    X1480     R288                          1
    X1480     R1920                         2
    X1481     R288                          -1
    X1481     R289                          1
    X1481     R1920                         4
    X1482     R289                          -1
    X1482     R290                          1
    X1482     R1920                         3
    X1483     R290                          -1
    X1483     R291                          1
    X1483     R1920                         1
    X1484     R291                          -1
    X1484     R292                          1
    X1484     R1920                         4
    X1485     R292                          -1
    X1485     R293                          1
    X1485     R1920                         4
    X1486     R293                          -1
    X1486     R294                          1
    X1486     R1920                         3
    X1487     R294                          -1
    X1487     R295                          1
    X1487     R1920                         5
    X1488     R295                          -1
    X1488     R296                          1
    X1488     R1920                         5
    X1489     R296                          -1
    X1489     R297                          1
    X1489     R1920                         1
    X1490     R297                          -1
    X1490     R298                          1
    X1490     R1920                         4
    X1491     R298                          -1
    X1491     R299                          1
    X1491     R1920                         3
    X1492     R299                          -1
    X1492     R300                          1
    X1492     R1920                         5
    X1493     R300                          -1
    X1493     R301                          1
    X1493     R1920                         4
    X1494     R301                          -1
    X1494     R302                          1
    X1494     R1920                         1
    X1495     R302                          -1
    X1495     R303                          1
    X1495     R1920                         4
    X1496     R303                          -1
    X1496     R304                          1
    X1496     R1920                         4
    X1497     R304                          -1
    X1497     R305                          1
    X1497     R1920                         5
    X1498     R305                          -1
    X1498     R306                          1
    X1498     R1920                         4
    X1499     R306                          -1
    X1499     R307                          1
    X1499     R1920                         5
    X1500     R307                          -1
    X1500     R308                          1
    X1500     R1920                         1
    X1501     R308                          -1
    X1501     R309                          1
    X1501     R1920                         4
    X1502     R309                          -1
    X1502     R310                          1
    X1502     R1920                         3
    X1503     R310                          -1
    X1503     R311                          1
    X1503     R1920                         5
    X1504     R311                          -1
    X1504     R312                          1
    X1504     R1920                         1
    X1505     R312                          -1
    X1505     R313                          1
    X1505     R1920                         1
    X1506     R313                          -1
    X1506     R314                          1
    X1506     R1920                         4
    X1507     R314                          -1
    X1507     R315                          1
    X1507     R1920                         3
    X1508     R315                          -1
    X1508     R316                          1
    X1508     R1920                         1
    X1509     R316                          -1
    X1509     R317                          1
    X1509     R1920                         2
    X1510     R317                          -1
    X1510     R318                          1
    X1510     R1920                         4
    X1511     R318                          -1
    X1511     R319                          1
    X1511     R1920                         1
    X1512     R319                          -1
    X1512     R320                          1
    X1512     R1920                         5
    X1513     R320                          -1
    X1513     R321                          1
    X1513     R1920                         2
    X1514     R321                          -1
    X1514     R322                          1
    X1514     R1920                         1
    X1515     R322                          -1
    X1515     R323                          1
    X1515     R1920                         3
    X1516     R323                          -1
    X1516     R324                          1
    X1516     R1920                         3
    X1517     R324                          -1
    X1517     R325                          1
    X1517     R1920                         1
    X1518     R325                          -1
    X1518     R326                          1
    X1518     R1920                         4
    X1519     R326                          -1
    X1519     R327                          1
    X1519     R1920                         4
    X1520     R327                          -1
    X1520     R328                          1
    X1520     R1920                         3
    X1521     R328                          -1
    X1521     R329                          1
    X1521     R1920                         1
    X1522     R329                          -1
    X1522     R330                          1
    X1522     R1920                         2
    X1523     R330                          -1
    X1523     R331                          1
    X1523     R1920                         3
    X1524     R331                          -1
    X1524     R332                          1
    X1524     R1920                         1
    X1525     R332                          -1
    X1525     R333                          1
    X1525     R1920                         1
    X1526     R333                          -1
    X1526     R334                          1
    X1526     R1920                         1
    X1527     R334                          -1
    X1527     R335                          1
    X1527     R1920                         3
    X1528     R335                          -1
    X1528     R336                          1
    X1528     R1920                         3
    X1529     R336                          -1
    X1529     R337                          1
    X1529     R1920                         2
    X1530     R337                          -1
    X1530     R338                          1
    X1530     R1920                         4
    X1531     R338                          -1
    X1531     R339                          1
    X1531     R1920                         2
    X1532     R339                          -1
    X1532     R340                          1
    X1532     R1920                         3
    X1533     R340                          -1
    X1533     R341                          1
    X1533     R1920                         5
    X1534     R341                          -1
    X1534     R342                          1
    X1534     R1920                         3
    X1535     R342                          -1
    X1535     R343                          1
    X1535     R1920                         1
    X1536     R343                          -1
    X1536     R344                          1
    X1536     R1920                         4
    X1537     R344                          -1
    X1537     R345                          1
    X1537     R1920                         1
    X1538     R345                          -1
    X1538     R346                          1
    X1538     R1920                         3
    X1539     R346                          -1
    X1539     R347                          1
    X1539     R1920                         4
    X1540     R347                          -1
    X1540     R348                          1
    X1540     R1920                         5
    X1541     R348                          -1
    X1541     R349                          1
    X1541     R1920                         5
    X1542     R349                          -1
    X1542     R350                          1
    X1542     R1920                         1
    X1543     R350                          -1
    X1543     R351                          1
    X1543     R1920                         4
    X1544     R351                          -1
    X1544     R352                          1
    X1544     R1920                         4
    X1545     R352                          -1
    X1545     R353                          1
    X1545     R1920                         3
    X1546     R353                          -1
    X1546     R354                          1
    X1546     R1920                         3
    X1547     R354                          -1
    X1547     R355                          1
    X1547     R1920                         2
    X1548     R355                          -1
    X1548     R356                          1
    X1548     R1920                         5
    X1549     R356                          -1
    X1549     R357                          1
    X1549     R1920                         5
    X1550     R357                          -1
    X1550     R358                          1
    X1550     R1920                         3
    X1551     R358                          -1
    X1551     R359                          1
    X1551     R1920                         3
    X1552     R360                          -1
    X1552     R361                          1
    X1552     R1920                         1
    X1553     R361                          -1
    X1553     R362                          1
    X1553     R1920                         3
    X1554     R362                          -1
    X1554     R363                          1
    X1554     R1920                         1
    X1555     R363                          -1
    X1555     R364                          1
    X1555     R1920                         1
    X1556     R364                          -1
    X1556     R365                          1
    X1556     R1920                         3
    X1557     R365                          -1
    X1557     R366                          1
    X1557     R1920                         1
    X1558     R366                          -1
    X1558     R367                          1
    X1558     R1920                         3
    X1559     R367                          -1
    X1559     R368                          1
    X1559     R1920                         1
    X1560     R368                          -1
    X1560     R369                          1
    X1560     R1920                         3
    X1561     R369                          -1
    X1561     R370                          1
    X1561     R1920                         3
    X1562     R370                          -1
    X1562     R371                          1
    X1562     R1920                         5
    X1563     R371                          -1
    X1563     R372                          1
    X1563     R1920                         2
    X1564     R372                          -1
    X1564     R373                          1
    X1564     R1920                         5
    X1565     R373                          -1
    X1565     R374                          1
    X1565     R1920                         5
    X1566     R374                          -1
    X1566     R375                          1
    X1566     R1920                         5
    X1567     R375                          -1
    X1567     R376                          1
    X1567     R1920                         4
    X1568     R376                          -1
    X1568     R377                          1
    X1568     R1920                         5
    X1569     R377                          -1
    X1569     R378                          1
    X1569     R1920                         3
    X1570     R378                          -1
    X1570     R379                          1
    X1570     R1920                         3
    X1571     R379                          -1
    X1571     R380                          1
    X1571     R1920                         1
    X1572     R380                          -1
    X1572     R381                          1
    X1572     R1920                         3
    X1573     R381                          -1
    X1573     R382                          1
    X1573     R1920                         1
    X1574     R382                          -1
    X1574     R383                          1
    X1574     R1920                         1
    X1575     R383                          -1
    X1575     R384                          1
    X1575     R1920                         2
    X1576     R384                          -1
    X1576     R385                          1
    X1576     R1920                         2
    X1577     R385                          -1
    X1577     R386                          1
    X1577     R1920                         2
    X1578     R386                          -1
    X1578     R387                          1
    X1578     R1920                         5
    X1579     R387                          -1
    X1579     R388                          1
    X1579     R1920                         1
    X1580     R388                          -1
    X1580     R389                          1
    X1580     R1920                         2
    X1581     R389                          -1
    X1581     R390                          1
    X1581     R1920                         4
    X1582     R390                          -1
    X1582     R391                          1
    X1582     R1920                         3
    X1583     R391                          -1
    X1583     R392                          1
    X1583     R1920                         2
    X1584     R392                          -1
    X1584     R393                          1
    X1584     R1920                         1
    X1585     R393                          -1
    X1585     R394                          1
    X1585     R1920                         1
    X1586     R394                          -1
    X1586     R395                          1
    X1586     R1920                         3
    X1587     R395                          -1
    X1587     R396                          1
    X1587     R1920                         4
    X1588     R396                          -1
    X1588     R397                          1
    X1588     R1920                         1
    X1589     R397                          -1
    X1589     R398                          1
    X1589     R1920                         4
    X1590     R398                          -1
    X1590     R399                          1
    X1590     R1920                         4
    X1591     R399                          -1
    X1591     R400                          1
    X1591     R1920                         1
    X1592     R400                          -1
    X1592     R401                          1
    X1592     R1920                         5
    X1593     R401                          -1
    X1593     R402                          1
    X1593     R1920                         2
    X1594     R402                          -1
    X1594     R403                          1
    X1594     R1920                         4
    X1595     R403                          -1
    X1595     R404                          1
    X1595     R1920                         5
    X1596     R404                          -1
    X1596     R405                          1
    X1596     R1920                         4
    X1597     R405                          -1
    X1597     R406                          1
    X1597     R1920                         2
    X1598     R406                          -1
    X1598     R407                          1
    X1598     R1920                         4
    X1599     R407                          -1
    X1599     R408                          1
    X1599     R1920                         5
    X1600     R408                          -1
    X1600     R409                          1
    X1600     R1920                         3
    X1601     R409                          -1
    X1601     R410                          1
    X1601     R1920                         1
    X1602     R410                          -1
    X1602     R411                          1
    X1602     R1920                         4
    X1603     R411                          -1
    X1603     R412                          1
    X1603     R1920                         5
    X1604     R412                          -1
    X1604     R413                          1
    X1604     R1920                         1
    X1605     R413                          -1
    X1605     R414                          1
    X1605     R1920                         1
    X1606     R414                          -1
    X1606     R415                          1
    X1606     R1920                         1
    X1607     R415                          -1
    X1607     R416                          1
    X1607     R1920                         3
    X1608     R416                          -1
    X1608     R417                          1
    X1608     R1920                         4
    X1609     R417                          -1
    X1609     R418                          1
    X1609     R1920                         5
    X1610     R418                          -1
    X1610     R419                          1
    X1610     R1920                         4
    X1611     R419                          -1
    X1611     R420                          1
    X1611     R1920                         5
    X1612     R420                          -1
    X1612     R421                          1
    X1612     R1920                         2
    X1613     R421                          -1
    X1613     R422                          1
    X1613     R1920                         2
    X1614     R422                          -1
    X1614     R423                          1
    X1614     R1920                         2
    X1615     R423                          -1
    X1615     R424                          1
    X1615     R1920                         2
    X1616     R424                          -1
    X1616     R425                          1
    X1616     R1920                         2
    X1617     R425                          -1
    X1617     R426                          1
    X1617     R1920                         1
    X1618     R426                          -1
    X1618     R427                          1
    X1618     R1920                         4
    X1619     R427                          -1
    X1619     R428                          1
    X1619     R1920                         1
    X1620     R428                          -1
    X1620     R429                          1
    X1620     R1920                         1
    X1621     R429                          -1
    X1621     R430                          1
    X1621     R1920                         5
    X1622     R430                          -1
    X1622     R431                          1
    X1622     R1920                         1
    X1623     R431                          -1
    X1623     R432                          1
    X1623     R1920                         1
    X1624     R432                          -1
    X1624     R433                          1
    X1624     R1920                         5
    X1625     R433                          -1
    X1625     R434                          1
    X1625     R1920                         5
    X1626     R434                          -1
    X1626     R435                          1
    X1626     R1920                         1
    X1627     R435                          -1
    X1627     R436                          1
    X1627     R1920                         5
    X1628     R436                          -1
    X1628     R437                          1
    X1628     R1920                         5
    X1629     R437                          -1
    X1629     R438                          1
    X1629     R1920                         1
    X1630     R438                          -1
    X1630     R439                          1
    X1630     R1920                         5
    X1631     R439                          -1
    X1631     R440                          1
    X1631     R1920                         5
    X1632     R440                          -1
    X1632     R441                          1
    X1632     R1920                         5
    X1633     R441                          -1
    X1633     R442                          1
    X1633     R1920                         4
    X1634     R442                          -1
    X1634     R443                          1
    X1634     R1920                         2
    X1635     R443                          -1
    X1635     R444                          1
    X1635     R1920                         5
    X1636     R444                          -1
    X1636     R445                          1
    X1636     R1920                         2
    X1637     R445                          -1
    X1637     R446                          1
    X1637     R1920                         1
    X1638     R446                          -1
    X1638     R447                          1
    X1638     R1920                         4
    X1639     R447                          -1
    X1639     R448                          1
    X1639     R1920                         1
    X1640     R448                          -1
    X1640     R449                          1
    X1640     R1920                         2
    X1641     R449                          -1
    X1641     R450                          1
    X1641     R1920                         4
    X1642     R450                          -1
    X1642     R451                          1
    X1642     R1920                         5
    X1643     R451                          -1
    X1643     R452                          1
    X1643     R1920                         5
    X1644     R452                          -1
    X1644     R453                          1
    X1644     R1920                         5
    X1645     R453                          -1
    X1645     R454                          1
    X1645     R1920                         2
    X1646     R454                          -1
    X1646     R455                          1
    X1646     R1920                         4
    X1647     R455                          -1
    X1647     R456                          1
    X1647     R1920                         4
    X1648     R456                          -1
    X1648     R457                          1
    X1648     R1920                         1
    X1649     R457                          -1
    X1649     R458                          1
    X1649     R1920                         2
    X1650     R458                          -1
    X1650     R459                          1
    X1650     R1920                         2
    X1651     R459                          -1
    X1651     R460                          1
    X1651     R1920                         4
    X1652     R460                          -1
    X1652     R461                          1
    X1652     R1920                         2
    X1653     R461                          -1
    X1653     R462                          1
    X1653     R1920                         5
    X1654     R462                          -1
    X1654     R463                          1
    X1654     R1920                         5
    X1655     R463                          -1
    X1655     R464                          1
    X1655     R1920                         3
    X1656     R464                          -1
    X1656     R465                          1
    X1656     R1920                         5
    X1657     R465                          -1
    X1657     R466                          1
    X1657     R1920                         1
    X1658     R466                          -1
    X1658     R467                          1
    X1658     R1920                         1
    X1659     R467                          -1
    X1659     R468                          1
    X1659     R1920                         5
    X1660     R468                          -1
    X1660     R469                          1
    X1660     R1920                         5
    X1661     R469                          -1
    X1661     R470                          1
    X1661     R1920                         4
    X1662     R470                          -1
    X1662     R471                          1
    X1662     R1920                         5
    X1663     R471                          -1
    X1663     R472                          1
    X1663     R1920                         1
    X1664     R472                          -1
    X1664     R473                          1
    X1664     R1920                         5
    X1665     R473                          -1
    X1665     R474                          1
    X1665     R1920                         1
    X1666     R474                          -1
    X1666     R475                          1
    X1666     R1920                         1
    X1667     R475                          -1
    X1667     R476                          1
    X1667     R1920                         4
    X1668     R476                          -1
    X1668     R477                          1
    X1668     R1920                         5
    X1669     R477                          -1
    X1669     R478                          1
    X1669     R1920                         3
    X1670     R478                          -1
    X1670     R479                          1
    X1670     R1920                         5
    X1671     R480                          -1
    X1671     R481                          1
    X1671     R1920                         1
    X1672     R481                          -1
    X1672     R482                          1
    X1672     R1920                         3
    X1673     R482                          -1
    X1673     R483                          1
    X1673     R1920                         3
    X1674     R483                          -1
    X1674     R484                          1
    X1674     R1920                         3
    X1675     R484                          -1
    X1675     R485                          1
    X1675     R1920                         1
    X1676     R485                          -1
    X1676     R486                          1
    X1676     R1920                         3
    X1677     R486                          -1
    X1677     R487                          1
    X1677     R1920                         4
    X1678     R487                          -1
    X1678     R488                          1
    X1678     R1920                         4
    X1679     R488                          -1
    X1679     R489                          1
    X1679     R1920                         1
    X1680     R489                          -1
    X1680     R490                          1
    X1680     R1920                         4
    X1681     R490                          -1
    X1681     R491                          1
    X1681     R1920                         1
    X1682     R491                          -1
    X1682     R492                          1
    X1682     R1920                         3
    X1683     R492                          -1
    X1683     R493                          1
    X1683     R1920                         1
    X1684     R493                          -1
    X1684     R494                          1
    X1684     R1920                         1
    X1685     R494                          -1
    X1685     R495                          1
    X1685     R1920                         2
    X1686     R495                          -1
    X1686     R496                          1
    X1686     R1920                         2
    X1687     R496                          -1
    X1687     R497                          1
    X1687     R1920                         5
    X1688     R497                          -1
    X1688     R498                          1
    X1688     R1920                         5
    X1689     R498                          -1
    X1689     R499                          1
    X1689     R1920                         5
    X1690     R499                          -1
    X1690     R500                          1
    X1690     R1920                         5
    X1691     R500                          -1
    X1691     R501                          1
    X1691     R1920                         4
    X1692     R501                          -1
    X1692     R502                          1
    X1692     R1920                         3
    X1693     R502                          -1
    X1693     R503                          1
    X1693     R1920                         3
    X1694     R503                          -1
    X1694     R504                          1
    X1694     R1920                         3
    X1695     R504                          -1
    X1695     R505                          1
    X1695     R1920                         4
    X1696     R505                          -1
    X1696     R506                          1
    X1696     R1920                         3
    X1697     R506                          -1
    X1697     R507                          1
    X1697     R1920                         3
    X1698     R507                          -1
    X1698     R508                          1
    X1698     R1920                         1
    X1699     R508                          -1
    X1699     R509                          1
    X1699     R1920                         3
    X1700     R509                          -1
    X1700     R510                          1
    X1700     R1920                         4
    X1701     R510                          -1
    X1701     R511                          1
    X1701     R1920                         5
    X1702     R511                          -1
    X1702     R512                          1
    X1702     R1920                         4
    X1703     R512                          -1
    X1703     R513                          1
    X1703     R1920                         3
    X1704     R513                          -1
    X1704     R514                          1
    X1704     R1920                         1
    X1705     R514                          -1
    X1705     R515                          1
    X1705     R1920                         3
    X1706     R515                          -1
    X1706     R516                          1
    X1706     R1920                         1
    X1707     R516                          -1
    X1707     R517                          1
    X1707     R1920                         4
    X1708     R517                          -1
    X1708     R518                          1
    X1708     R1920                         1
    X1709     R518                          -1
    X1709     R519                          1
    X1709     R1920                         2
    X1710     R519                          -1
    X1710     R520                          1
    X1710     R1920                         1
    X1711     R520                          -1
    X1711     R521                          1
    X1711     R1920                         1
    X1712     R521                          -1
    X1712     R522                          1
    X1712     R1920                         4
    X1713     R522                          -1
    X1713     R523                          1
    X1713     R1920                         2
    X1714     R523                          -1
    X1714     R524                          1
    X1714     R1920                         2
    X1715     R524                          -1
    X1715     R525                          1
    X1715     R1920                         1
    X1716     R525                          -1
    X1716     R526                          1
    X1716     R1920                         1
    X1717     R526                          -1
    X1717     R527                          1
    X1717     R1920                         1
    X1718     R527                          -1
    X1718     R528                          1
    X1718     R1920                         5
    X1719     R528                          -1
    X1719     R529                          1
    X1719     R1920                         5
    X1720     R529                          -1
    X1720     R530                          1
    X1720     R1920                         1
    X1721     R530                          -1
    X1721     R531                          1
    X1721     R1920                         2
    X1722     R531                          -1
    X1722     R532                          1
    X1722     R1920                         3
    X1723     R532                          -1
    X1723     R533                          1
    X1723     R1920                         3
    X1724     R533                          -1
    X1724     R534                          1
    X1724     R1920                         5
    X1725     R534                          -1
    X1725     R535                          1
    X1725     R1920                         1
    X1726     R535                          -1
    X1726     R536                          1
    X1726     R1920                         5
    X1727     R536                          -1
    X1727     R537                          1
    X1727     R1920                         1
    X1728     R537                          -1
    X1728     R538                          1
    X1728     R1920                         2
    X1729     R538                          -1
    X1729     R539                          1
    X1729     R1920                         4
    X1730     R539                          -1
    X1730     R540                          1
    X1730     R1920                         4
    X1731     R540                          -1
    X1731     R541                          1
    X1731     R1920                         2
    X1732     R541                          -1
    X1732     R542                          1
    X1732     R1920                         4
    X1733     R542                          -1
    X1733     R543                          1
    X1733     R1920                         5
    X1734     R543                          -1
    X1734     R544                          1
    X1734     R1920                         3
    X1735     R544                          -1
    X1735     R545                          1
    X1735     R1920                         2
    X1736     R545                          -1
    X1736     R546                          1
    X1736     R1920                         3
    X1737     R546                          -1
    X1737     R547                          1
    X1737     R1920                         1
    X1738     R547                          -1
    X1738     R548                          1
    X1738     R1920                         3
    X1739     R548                          -1
    X1739     R549                          1
    X1739     R1920                         1
    X1740     R549                          -1
    X1740     R550                          1
    X1740     R1920                         2
    X1741     R550                          -1
    X1741     R551                          1
    X1741     R1920                         3
    X1742     R551                          -1
    X1742     R552                          1
    X1742     R1920                         5
    X1743     R552                          -1
    X1743     R553                          1
    X1743     R1920                         5
    X1744     R553                          -1
    X1744     R554                          1
    X1744     R1920                         2
    X1745     R554                          -1
    X1745     R555                          1
    X1745     R1920                         4
    X1746     R555                          -1
    X1746     R556                          1
    X1746     R1920                         3
    X1747     R556                          -1
    X1747     R557                          1
    X1747     R1920                         5
    X1748     R557                          -1
    X1748     R558                          1
    X1748     R1920                         3
    X1749     R558                          -1
    X1749     R559                          1
    X1749     R1920                         1
    X1750     R559                          -1
    X1750     R560                          1
    X1750     R1920                         1
    X1751     R560                          -1
    X1751     R561                          1
    X1751     R1920                         1
    X1752     R561                          -1
    X1752     R562                          1
    X1752     R1920                         4
    X1753     R562                          -1
    X1753     R563                          1
    X1753     R1920                         4
    X1754     R563                          -1
    X1754     R564                          1
    X1754     R1920                         5
    X1755     R564                          -1
    X1755     R565                          1
    X1755     R1920                         1
    X1756     R565                          -1
    X1756     R566                          1
    X1756     R1920                         2
    X1757     R566                          -1
    X1757     R567                          1
    X1757     R1920                         4
    X1758     R567                          -1
    X1758     R568                          1
    X1758     R1920                         1
    X1759     R568                          -1
    X1759     R569                          1
    X1759     R1920                         1
    X1760     R569                          -1
    X1760     R570                          1
    X1760     R1920                         5
    X1761     R570                          -1
    X1761     R571                          1
    X1761     R1920                         3
    X1762     R571                          -1
    X1762     R572                          1
    X1762     R1920                         3
    X1763     R572                          -1
    X1763     R573                          1
    X1763     R1920                         1
    X1764     R573                          -1
    X1764     R574                          1
    X1764     R1920                         3
    X1765     R574                          -1
    X1765     R575                          1
    X1765     R1920                         5
    X1766     R575                          -1
    X1766     R576                          1
    X1766     R1920                         2
    X1767     R576                          -1
    X1767     R577                          1
    X1767     R1920                         5
    X1768     R577                          -1
    X1768     R578                          1
    X1768     R1920                         5
    X1769     R578                          -1
    X1769     R579                          1
    X1769     R1920                         4
    X1770     R579                          -1
    X1770     R580                          1
    X1770     R1920                         5
    X1771     R580                          -1
    X1771     R581                          1
    X1771     R1920                         1
    X1772     R581                          -1
    X1772     R582                          1
    X1772     R1920                         2
    X1773     R582                          -1
    X1773     R583                          1
    X1773     R1920                         3
    X1774     R583                          -1
    X1774     R584                          1
    X1774     R1920                         3
    X1775     R584                          -1
    X1775     R585                          1
    X1775     R1920                         3
    X1776     R585                          -1
    X1776     R586                          1
    X1776     R1920                         3
    X1777     R586                          -1
    X1777     R587                          1
    X1777     R1920                         4
    X1778     R587                          -1
    X1778     R588                          1
    X1778     R1920                         2
    X1779     R588                          -1
    X1779     R589                          1
    X1779     R1920                         2
    X1780     R589                          -1
    X1780     R590                          1
    X1780     R1920                         5
    X1781     R590                          -1
    X1781     R591                          1
    X1781     R1920                         1
    X1782     R591                          -1
    X1782     R592                          1
    X1782     R1920                         1
    X1783     R592                          -1
    X1783     R593                          1
    X1783     R1920                         1
    X1784     R593                          -1
    X1784     R594                          1
    X1784     R1920                         1
    X1785     R594                          -1
    X1785     R595                          1
    X1785     R1920                         3
    X1786     R595                          -1
    X1786     R596                          1
    X1786     R1920                         4
    X1787     R596                          -1
    X1787     R597                          1
    X1787     R1920                         5
    X1788     R597                          -1
    X1788     R598                          1
    X1788     R1920                         4
    X1789     R598                          -1
    X1789     R599                          1
    X1789     R1920                         3
    X1790     R600                          -18298
    X1790     R1800                         1
    X1790     R1920                         40000
    X1791     R601                          -18298
    X1791     R1801                         1
    X1791     R1920                         40000
    X1792     R602                          -18298
    X1792     R1802                         1
    X1792     R1920                         45000
    X1793     R603                          -18298
    X1793     R1803                         1
    X1793     R1920                         5000
    X1794     R604                          -18298
    X1794     R1804                         1
    X1794     R1920                         15000
    X1795     R605                          -18298
    X1795     R1805                         1
    X1795     R1920                         5000
    X1796     R606                          -18298
    X1796     R1806                         1
    X1796     R1920                         25000
    X1797     R607                          -18298
    X1797     R1807                         1
    X1797     R1920                         15000
    X1798     R608                          -18298
    X1798     R1808                         1
    X1798     R1920                         40000
    X1799     R609                          -18298
    X1799     R1809                         1
    X1799     R1920                         20000
    X1800     R610                          -18298
    X1800     R1810                         1
    X1800     R1920                         45000
    X1801     R611                          -18298
    X1801     R1811                         1
    X1801     R1920                         10000
    X1802     R612                          -18298
    X1802     R1812                         1
    X1802     R1920                         30000
    X1803     R613                          -18298
    X1803     R1813                         1
    X1803     R1920                         15000
    X1804     R614                          -18298
    X1804     R1814                         1
    X1804     R1920                         30000
    X1805     R615                          -18298
    X1805     R1815                         1
    X1805     R1920                         5000
    X1806     R616                          -18298
    X1806     R1816                         1
    X1806     R1920                         40000
    X1807     R617                          -18298
    X1807     R1817                         1
    X1807     R1920                         25000
    X1808     R618                          -18298
    X1808     R1818                         1
    X1808     R1920                         35000
    X1809     R619                          -18298
    X1809     R1819                         1
    X1809     R1920                         15000
    X1810     R620                          -18298
    X1810     R1820                         1
    X1810     R1920                         20000
    X1811     R621                          -18298
    X1811     R1821                         1
    X1811     R1920                         45000
    X1812     R622                          -18298
    X1812     R1822                         1
    X1812     R1920                         20000
    X1813     R623                          -18298
    X1813     R1823                         1
    X1813     R1920                         30000
    X1814     R624                          -18298
    X1814     R1824                         1
    X1814     R1920                         35000
    X1815     R625                          -18298
    X1815     R1825                         1
    X1815     R1920                         15000
    X1816     R626                          -18298
    X1816     R1826                         1
    X1816     R1920                         45000
    X1817     R627                          -18298
    X1817     R1827                         1
    X1817     R1920                         35000
    X1818     R628                          -18298
    X1818     R1828                         1
    X1818     R1920                         10000
    X1819     R629                          -18298
    X1819     R1829                         1
    X1819     R1920                         25000
    X1820     R630                          -18298
    X1820     R1830                         1
    X1820     R1920                         30000
    X1821     R631                          -18298
    X1821     R1831                         1
    X1821     R1920                         35000
    X1822     R632                          -18298
    X1822     R1832                         1
    X1822     R1920                         25000
    X1823     R633                          -18298
    X1823     R1833                         1
    X1823     R1920                         40000
    X1824     R634                          -18298
    X1824     R1834                         1
    X1824     R1920                         15000
    X1825     R635                          -18298
    X1825     R1835                         1
    X1825     R1920                         20000
    X1826     R636                          -18298
    X1826     R1836                         1
    X1826     R1920                         30000
    X1827     R637                          -18298
    X1827     R1837                         1
    X1827     R1920                         20000
    X1828     R638                          -18298
    X1828     R1838                         1
    X1828     R1920                         10000
    X1829     R639                          -18298
    X1829     R1839                         1
    X1829     R1920                         10000
    X1830     R640                          -18298
    X1830     R1840                         1
    X1830     R1920                         10000
    X1831     R641                          -18298
    X1831     R1841                         1
    X1831     R1920                         20000
    X1832     R642                          -18298
    X1832     R1842                         1
    X1832     R1920                         45000
    X1833     R643                          -18298
    X1833     R1843                         1
    X1833     R1920                         35000
    X1834     R644                          -18298
    X1834     R1844                         1
    X1834     R1920                         30000
    X1835     R645                          -18298
    X1835     R1845                         1
    X1835     R1920                         20000
    X1836     R646                          -18298
    X1836     R1846                         1
    X1836     R1920                         35000
    X1837     R647                          -18298
    X1837     R1847                         1
    X1837     R1920                         45000
    X1838     R648                          -18298
    X1838     R1848                         1
    X1838     R1920                         45000
    X1839     R649                          -18298
    X1839     R1849                         1
    X1839     R1920                         10000
    X1840     R650                          -18298
    X1840     R1850                         1
    X1840     R1920                         30000
    X1841     R651                          -18298
    X1841     R1851                         1
    X1841     R1920                         5000
    X1842     R652                          -18298
    X1842     R1852                         1
    X1842     R1920                         45000
    X1843     R653                          -18298
    X1843     R1853                         1
    X1843     R1920                         35000
    X1844     R654                          -18298
    X1844     R1854                         1
    X1844     R1920                         40000
    X1845     R655                          -18298
    X1845     R1855                         1
    X1845     R1920                         15000
    X1846     R656                          -18298
    X1846     R1856                         1
    X1846     R1920                         15000
    X1847     R657                          -18298
    X1847     R1857                         1
    X1847     R1920                         30000
    X1848     R658                          -18298
    X1848     R1858                         1
    X1848     R1920                         40000
    X1849     R659                          -18298
    X1849     R1859                         1
    X1849     R1920                         30000
    X1850     R660                          -18298
    X1850     R1860                         1
    X1850     R1920                         20000
    X1851     R661                          -18298
    X1851     R1861                         1
    X1851     R1920                         10000
    X1852     R662                          -18298
    X1852     R1862                         1
    X1852     R1920                         45000
    X1853     R663                          -18298
    X1853     R1863                         1
    X1853     R1920                         20000
    X1854     R664                          -18298
    X1854     R1864                         1
    X1854     R1920                         20000
    X1855     R665                          -18298
    X1855     R1865                         1
    X1855     R1920                         25000
    X1856     R666                          -18298
    X1856     R1866                         1
    X1856     R1920                         5000
    X1857     R667                          -18298
    X1857     R1867                         1
    X1857     R1920                         30000
    X1858     R668                          -18298
    X1858     R1868                         1
    X1858     R1920                         25000
    X1859     R669                          -18298
    X1859     R1869                         1
    X1859     R1920                         5000
    X1860     R670                          -18298
    X1860     R1870                         1
    X1860     R1920                         15000
    X1861     R671                          -18298
    X1861     R1871                         1
    X1861     R1920                         5000
    X1862     R672                          -18298
    X1862     R1872                         1
    X1862     R1920                         25000
    X1863     R673                          -18298
    X1863     R1873                         1
    X1863     R1920                         5000
    X1864     R674                          -18298
    X1864     R1874                         1
    X1864     R1920                         15000
    X1865     R675                          -18298
    X1865     R1875                         1
    X1865     R1920                         10000
    X1866     R676                          -18298
    X1866     R1876                         1
    X1866     R1920                         30000
    X1867     R677                          -18298
    X1867     R1877                         1
    X1867     R1920                         30000
    X1868     R678                          -18298
    X1868     R1878                         1
    X1868     R1920                         20000
    X1869     R679                          -18298
    X1869     R1879                         1
    X1869     R1920                         35000
    X1870     R680                          -18298
    X1870     R1880                         1
    X1870     R1920                         20000
    X1871     R681                          -18298
    X1871     R1881                         1
    X1871     R1920                         20000
    X1872     R682                          -18298
    X1872     R1882                         1
    X1872     R1920                         25000
    X1873     R683                          -18298
    X1873     R1883                         1
    X1873     R1920                         35000
    X1874     R684                          -18298
    X1874     R1884                         1
    X1874     R1920                         20000
    X1875     R685                          -18298
    X1875     R1885                         1
    X1875     R1920                         40000
    X1876     R686                          -18298
    X1876     R1886                         1
    X1876     R1920                         15000
    X1877     R687                          -18298
    X1877     R1887                         1
    X1877     R1920                         15000
    X1878     R688                          -18298
    X1878     R1888                         1
    X1878     R1920                         25000
    X1879     R689                          -18298
    X1879     R1889                         1
    X1879     R1920                         30000
    X1880     R690                          -18298
    X1880     R1890                         1
    X1880     R1920                         40000
    X1881     R691                          -18298
    X1881     R1891                         1
    X1881     R1920                         35000
    X1882     R692                          -18298
    X1882     R1892                         1
    X1882     R1920                         40000
    X1883     R693                          -18298
    X1883     R1893                         1
    X1883     R1920                         5000
    X1884     R694                          -18298
    X1884     R1894                         1
    X1884     R1920                         20000
    X1885     R695                          -18298
    X1885     R1895                         1
    X1885     R1920                         45000
    X1886     R696                          -18298
    X1886     R1896                         1
    X1886     R1920                         25000
    X1887     R697                          -18298
    X1887     R1897                         1
    X1887     R1920                         10000
    X1888     R698                          -18298
    X1888     R1898                         1
    X1888     R1920                         25000
    X1889     R699                          -18298
    X1889     R1899                         1
    X1889     R1920                         40000
    X1890     R700                          -18298
    X1890     R1900                         1
    X1890     R1920                         45000
    X1891     R701                          -18298
    X1891     R1901                         1
    X1891     R1920                         40000
    X1892     R702                          -18298
    X1892     R1902                         1
    X1892     R1920                         20000
    X1893     R703                          -18298
    X1893     R1903                         1
    X1893     R1920                         10000
    X1894     R704                          -18298
    X1894     R1904                         1
    X1894     R1920                         40000
    X1895     R705                          -18298
    X1895     R1905                         1
    X1895     R1920                         40000
    X1896     R706                          -18298
    X1896     R1906                         1
    X1896     R1920                         30000
    X1897     R707                          -18298
    X1897     R1907                         1
    X1897     R1920                         35000
    X1898     R708                          -18298
    X1898     R1908                         1
    X1898     R1920                         5000
    X1899     R709                          -18298
    X1899     R1909                         1
    X1899     R1920                         20000
    X1900     R710                          -18298
    X1900     R1910                         1
    X1900     R1920                         20000
    X1901     R711                          -18298
    X1901     R1911                         1
    X1901     R1920                         25000
    X1902     R712                          -18298
    X1902     R1912                         1
    X1902     R1920                         10000
    X1903     R713                          -18298
    X1903     R1913                         1
    X1903     R1920                         10000
    X1904     R714                          -18298
    X1904     R1914                         1
    X1904     R1920                         45000
    X1905     R715                          -18298
    X1905     R1915                         1
    X1905     R1920                         20000
    X1906     R716                          -18298
    X1906     R1916                         1
    X1906     R1920                         5000
    X1907     R717                          -18298
    X1907     R1917                         1
    X1907     R1920                         25000
    X1908     R718                          -18298
    X1908     R1918                         1
    X1908     R1920                         10000
    X1909     R719                          -18298
    X1909     R1919                         1
    X1909     R1920                         5000
    X1910     R720                          -16531
    X1910     R1800                         1
    X1910     R1920                         40000
    X1911     R721                          -16531
    X1911     R1801                         1
    X1911     R1920                         35000
    X1912     R722                          -16531
    X1912     R1802                         1
    X1912     R1920                         15000
    X1913     R723                          -16531
    X1913     R1803                         1
    X1913     R1920                         10000
    X1914     R724                          -16531
    X1914     R1804                         1
    X1914     R1920                         10000
    X1915     R725                          -16531
    X1915     R1805                         1
    X1915     R1920                         15000
    X1916     R726                          -16531
    X1916     R1806                         1
    X1916     R1920                         40000
    X1917     R727                          -16531
    X1917     R1807                         1
    X1917     R1920                         25000
    X1918     R728                          -16531
    X1918     R1808                         1
    X1918     R1920                         45000
    X1919     R729                          -16531
    X1919     R1809                         1
    X1919     R1920                         40000
    X1920     R730                          -16531
    X1920     R1810                         1
    X1920     R1920                         35000
    X1921     R731                          -16531
    X1921     R1811                         1
    X1921     R1920                         40000
    X1922     R732                          -16531
    X1922     R1812                         1
    X1922     R1920                         10000
    X1923     R733                          -16531
    X1923     R1813                         1
    X1923     R1920                         45000
    X1924     R734                          -16531
    X1924     R1814                         1
    X1924     R1920                         30000
    X1925     R735                          -16531
    X1925     R1815                         1
    X1925     R1920                         45000
    X1926     R736                          -16531
    X1926     R1816                         1
    X1926     R1920                         10000
    X1927     R737                          -16531
    X1927     R1817                         1
    X1927     R1920                         5000
    X1928     R738                          -16531
    X1928     R1818                         1
    X1928     R1920                         10000
    X1929     R739                          -16531
    X1929     R1819                         1
    X1929     R1920                         40000
    X1930     R740                          -16531
    X1930     R1820                         1
    X1930     R1920                         20000
    X1931     R741                          -16531
    X1931     R1821                         1
    X1931     R1920                         15000
    X1932     R742                          -16531
    X1932     R1822                         1
    X1932     R1920                         25000
    X1933     R743                          -16531
    X1933     R1823                         1
    X1933     R1920                         45000
    X1934     R744                          -16531
    X1934     R1824                         1
    X1934     R1920                         30000
    X1935     R745                          -16531
    X1935     R1825                         1
    X1935     R1920                         30000
    X1936     R746                          -16531
    X1936     R1826                         1
    X1936     R1920                         25000
    X1937     R747                          -16531
    X1937     R1827                         1
    X1937     R1920                         35000
    X1938     R748                          -16531
    X1938     R1828                         1
    X1938     R1920                         45000
    X1939     R749                          -16531
    X1939     R1829                         1
    X1939     R1920                         35000
    X1940     R750                          -16531
    X1940     R1830                         1
    X1940     R1920                         40000
    X1941     R751                          -16531
    X1941     R1831                         1
    X1941     R1920                         35000
    X1942     R752                          -16531
    X1942     R1832                         1
    X1942     R1920                         40000
    X1943     R753                          -16531
    X1943     R1833                         1
    X1943     R1920                         30000
    X1944     R754                          -16531
    X1944     R1834                         1
    X1944     R1920                         40000
    X1945     R755                          -16531
    X1945     R1835                         1
    X1945     R1920                         30000
    X1946     R756                          -16531
    X1946     R1836                         1
    X1946     R1920                         20000
    X1947     R757                          -16531
    X1947     R1837                         1
    X1947     R1920                         25000
    X1948     R758                          -16531
    X1948     R1838                         1
    X1948     R1920                         20000
    X1949     R759                          -16531
    X1949     R1839                         1
    X1949     R1920                         20000
    X1950     R760                          -16531
    X1950     R1840                         1
    X1950     R1920                         5000
    X1951     R761                          -16531
    X1951     R1841                         1
    X1951     R1920                         5000
    X1952     R762                          -16531
    X1952     R1842                         1
    X1952     R1920                         45000
    X1953     R763                          -16531
    X1953     R1843                         1
    X1953     R1920                         30000
    X1954     R764                          -16531
    X1954     R1844                         1
    X1954     R1920                         35000
    X1955     R765                          -16531
    X1955     R1845                         1
    X1955     R1920                         5000
    X1956     R766                          -16531
    X1956     R1846                         1
    X1956     R1920                         15000
    X1957     R767                          -16531
    X1957     R1847                         1
    X1957     R1920                         40000
    X1958     R768                          -16531
    X1958     R1848                         1
    X1958     R1920                         15000
    X1959     R769                          -16531
    X1959     R1849                         1
    X1959     R1920                         20000
    X1960     R770                          -16531
    X1960     R1850                         1
    X1960     R1920                         25000
    X1961     R771                          -16531
    X1961     R1851                         1
    X1961     R1920                         10000
    X1962     R772                          -16531
    X1962     R1852                         1
    X1962     R1920                         10000
    X1963     R773                          -16531
    X1963     R1853                         1
    X1963     R1920                         45000
    X1964     R774                          -16531
    X1964     R1854                         1
    X1964     R1920                         30000
    X1965     R775                          -16531
    X1965     R1855                         1
    X1965     R1920                         30000
    X1966     R776                          -16531
    X1966     R1856                         1
    X1966     R1920                         10000
    X1967     R777                          -16531
    X1967     R1857                         1
    X1967     R1920                         15000
    X1968     R778                          -16531
    X1968     R1858                         1
    X1968     R1920                         40000
    X1969     R779                          -16531
    X1969     R1859                         1
    X1969     R1920                         45000
    X1970     R780                          -16531
    X1970     R1860                         1
    X1970     R1920                         10000
    X1971     R781                          -16531
    X1971     R1861                         1
    X1971     R1920                         10000
    X1972     R782                          -16531
    X1972     R1862                         1
    X1972     R1920                         20000
    X1973     R783                          -16531
    X1973     R1863                         1
    X1973     R1920                         10000
    X1974     R784                          -16531
    X1974     R1864                         1
    X1974     R1920                         5000
    X1975     R785                          -16531
    X1975     R1865                         1
    X1975     R1920                         15000
    X1976     R786                          -16531
    X1976     R1866                         1
    X1976     R1920                         10000
    X1977     R787                          -16531
    X1977     R1867                         1
    X1977     R1920                         40000
    X1978     R788                          -16531
    X1978     R1868                         1
    X1978     R1920                         40000
    X1979     R789                          -16531
    X1979     R1869                         1
    X1979     R1920                         35000
    X1980     R790                          -16531
    X1980     R1870                         1
    X1980     R1920                         35000
    X1981     R791                          -16531
    X1981     R1871                         1
    X1981     R1920                         10000
    X1982     R792                          -16531
    X1982     R1872                         1
    X1982     R1920                         45000
    X1983     R793                          -16531
    X1983     R1873                         1
    X1983     R1920                         30000
    X1984     R794                          -16531
    X1984     R1874                         1
    X1984     R1920                         40000
    X1985     R795                          -16531
    X1985     R1875                         1
    X1985     R1920                         45000
    X1986     R796                          -16531
    X1986     R1876                         1
    X1986     R1920                         25000
    X1987     R797                          -16531
    X1987     R1877                         1
    X1987     R1920                         15000
    X1988     R798                          -16531
    X1988     R1878                         1
    X1988     R1920                         5000
    X1989     R799                          -16531
    X1989     R1879                         1
    X1989     R1920                         5000
    X1990     R800                          -16531
    X1990     R1880                         1
    X1990     R1920                         40000
    X1991     R801                          -16531
    X1991     R1881                         1
    X1991     R1920                         40000
    X1992     R802                          -16531
    X1992     R1882                         1
    X1992     R1920                         45000
    X1993     R803                          -16531
    X1993     R1883                         1
    X1993     R1920                         40000
    X1994     R804                          -16531
    X1994     R1884                         1
    X1994     R1920                         10000
    X1995     R805                          -16531
    X1995     R1885                         1
    X1995     R1920                         35000
    X1996     R806                          -16531
    X1996     R1886                         1
    X1996     R1920                         5000
    X1997     R807                          -16531
    X1997     R1887                         1
    X1997     R1920                         15000
    X1998     R808                          -16531
    X1998     R1888                         1
    X1998     R1920                         20000
    X1999     R809                          -16531
    X1999     R1889                         1
    X1999     R1920                         30000
    X2000     R810                          -16531
    X2000     R1890                         1
    X2000     R1920                         15000
    X2001     R811                          -16531
    X2001     R1891                         1
    X2001     R1920                         10000
    X2002     R812                          -16531
    X2002     R1892                         1
    X2002     R1920                         40000
    X2003     R813                          -16531
    X2003     R1893                         1
    X2003     R1920                         5000
    X2004     R814                          -16531
    X2004     R1894                         1
    X2004     R1920                         25000
    X2005     R815                          -16531
    X2005     R1895                         1
    X2005     R1920                         35000
    X2006     R816                          -16531
    X2006     R1896                         1
    X2006     R1920                         20000
    X2007     R817                          -16531
    X2007     R1897                         1
    X2007     R1920                         20000
    X2008     R818                          -16531
    X2008     R1898                         1
    X2008     R1920                         40000
    X2009     R819                          -16531
    X2009     R1899                         1
    X2009     R1920                         35000
    X2010     R820                          -16531
    X2010     R1900                         1
    X2010     R1920                         35000
    X2011     R821                          -16531
    X2011     R1901                         1
    X2011     R1920                         30000
    X2012     R822                          -16531
    X2012     R1902                         1
    X2012     R1920                         40000
    X2013     R823                          -16531
    X2013     R1903                         1
    X2013     R1920                         35000
    X2014     R824                          -16531
    X2014     R1904                         1
    X2014     R1920                         15000
    X2015     R825                          -16531
    X2015     R1905                         1
    X2015     R1920                         10000
    X2016     R826                          -16531
    X2016     R1906                         1
    X2016     R1920                         20000
    X2017     R827                          -16531
    X2017     R1907                         1
    X2017     R1920                         25000
    X2018     R828                          -16531
    X2018     R1908                         1
    X2018     R1920                         15000
    X2019     R829                          -16531
    X2019     R1909                         1
    X2019     R1920                         10000
    X2020     R830                          -16531
    X2020     R1910                         1
    X2020     R1920                         20000
    X2021     R831                          -16531
    X2021     R1911                         1
    X2021     R1920                         15000
    X2022     R832                          -16531
    X2022     R1912                         1
    X2022     R1920                         20000
    X2023     R833                          -16531
    X2023     R1913                         1
    X2023     R1920                         45000
    X2024     R834                          -16531
    X2024     R1914                         1
    X2024     R1920                         15000
    X2025     R835                          -16531
    X2025     R1915                         1
    X2025     R1920                         25000
    X2026     R836                          -16531
    X2026     R1916                         1
    X2026     R1920                         25000
    X2027     R837                          -16531
    X2027     R1917                         1
    X2027     R1920                         10000
    X2028     R838                          -16531
    X2028     R1918                         1
    X2028     R1920                         5000
    X2029     R839                          -16531
    X2029     R1919                         1
    X2029     R1920                         15000
    X2030     R840                          -19386
    X2030     R1800                         1
    X2030     R1920                         40000
    X2031     R841                          -19386
    X2031     R1801                         1
    X2031     R1920                         20000
    X2032     R842                          -19386
    X2032     R1802                         1
    X2032     R1920                         35000
    X2033     R843                          -19386
    X2033     R1803                         1
    X2033     R1920                         45000
    X2034     R844                          -19386
    X2034     R1804                         1
    X2034     R1920                         35000
    X2035     R845                          -19386
    X2035     R1805                         1
    X2035     R1920                         10000
    X2036     R846                          -19386
    X2036     R1806                         1
    X2036     R1920                         30000
    X2037     R847                          -19386
    X2037     R1807                         1
    X2037     R1920                         30000
    X2038     R848                          -19386
    X2038     R1808                         1
    X2038     R1920                         10000
    X2039     R849                          -19386
    X2039     R1809                         1
    X2039     R1920                         20000
    X2040     R850                          -19386
    X2040     R1810                         1
    X2040     R1920                         45000
    X2041     R851                          -19386
    X2041     R1811                         1
    X2041     R1920                         40000
    X2042     R852                          -19386
    X2042     R1812                         1
    X2042     R1920                         5000
    X2043     R853                          -19386
    X2043     R1813                         1
    X2043     R1920                         35000
    X2044     R854                          -19386
    X2044     R1814                         1
    X2044     R1920                         25000
    X2045     R855                          -19386
    X2045     R1815                         1
    X2045     R1920                         5000
    X2046     R856                          -19386
    X2046     R1816                         1
    X2046     R1920                         20000
    X2047     R857                          -19386
    X2047     R1817                         1
    X2047     R1920                         35000
    X2048     R858                          -19386
    X2048     R1818                         1
    X2048     R1920                         40000
    X2049     R859                          -19386
    X2049     R1819                         1
    X2049     R1920                         5000
    X2050     R860                          -19386
    X2050     R1820                         1
    X2050     R1920                         45000
    X2051     R861                          -19386
    X2051     R1821                         1
    X2051     R1920                         40000
    X2052     R862                          -19386
    X2052     R1822                         1
    X2052     R1920                         5000
    X2053     R863                          -19386
    X2053     R1823                         1
    X2053     R1920                         35000
    X2054     R864                          -19386
    X2054     R1824                         1
    X2054     R1920                         10000
    X2055     R865                          -19386
    X2055     R1825                         1
    X2055     R1920                         40000
    X2056     R866                          -19386
    X2056     R1826                         1
    X2056     R1920                         45000
    X2057     R867                          -19386
    X2057     R1827                         1
    X2057     R1920                         40000
    X2058     R868                          -19386
    X2058     R1828                         1
    X2058     R1920                         30000
    X2059     R869                          -19386
    X2059     R1829                         1
    X2059     R1920                         35000
    X2060     R870                          -19386
    X2060     R1830                         1
    X2060     R1920                         15000
    X2061     R871                          -19386
    X2061     R1831                         1
    X2061     R1920                         15000
    X2062     R872                          -19386
    X2062     R1832                         1
    X2062     R1920                         45000
    X2063     R873                          -19386
    X2063     R1833                         1
    X2063     R1920                         5000
    X2064     R874                          -19386
    X2064     R1834                         1
    X2064     R1920                         5000
    X2065     R875                          -19386
    X2065     R1835                         1
    X2065     R1920                         15000
    X2066     R876                          -19386
    X2066     R1836                         1
    X2066     R1920                         20000
    X2067     R877                          -19386
    X2067     R1837                         1
    X2067     R1920                         15000
    X2068     R878                          -19386
    X2068     R1838                         1
    X2068     R1920                         10000
    X2069     R879                          -19386
    X2069     R1839                         1
    X2069     R1920                         10000
    X2070     R880                          -19386
    X2070     R1840                         1
    X2070     R1920                         45000
    X2071     R881                          -19386
    X2071     R1841                         1
    X2071     R1920                         20000
    X2072     R882                          -19386
    X2072     R1842                         1
    X2072     R1920                         40000
    X2073     R883                          -19386
    X2073     R1843                         1
    X2073     R1920                         25000
    X2074     R884                          -19386
    X2074     R1844                         1
    X2074     R1920                         35000
    X2075     R885                          -19386
    X2075     R1845                         1
    X2075     R1920                         15000
    X2076     R886                          -19386
    X2076     R1846                         1
    X2076     R1920                         30000
    X2077     R887                          -19386
    X2077     R1847                         1
    X2077     R1920                         40000
    X2078     R888                          -19386
    X2078     R1848                         1
    X2078     R1920                         25000
    X2079     R889                          -19386
    X2079     R1849                         1
    X2079     R1920                         40000
    X2080     R890                          -19386
    X2080     R1850                         1
    X2080     R1920                         40000
    X2081     R891                          -19386
    X2081     R1851                         1
    X2081     R1920                         15000
    X2082     R892                          -19386
    X2082     R1852                         1
    X2082     R1920                         15000
    X2083     R893                          -19386
    X2083     R1853                         1
    X2083     R1920                         30000
    X2084     R894                          -19386
    X2084     R1854                         1
    X2084     R1920                         10000
    X2085     R895                          -19386
    X2085     R1855                         1
    X2085     R1920                         45000
    X2086     R896                          -19386
    X2086     R1856                         1
    X2086     R1920                         35000
    X2087     R897                          -19386
    X2087     R1857                         1
    X2087     R1920                         35000
    X2088     R898                          -19386
    X2088     R1858                         1
    X2088     R1920                         35000
    X2089     R899                          -19386
    X2089     R1859                         1
    X2089     R1920                         25000
    X2090     R900                          -19386
    X2090     R1860                         1
    X2090     R1920                         5000
    X2091     R901                          -19386
    X2091     R1861                         1
    X2091     R1920                         20000
    X2092     R902                          -19386
    X2092     R1862                         1
    X2092     R1920                         25000
    X2093     R903                          -19386
    X2093     R1863                         1
    X2093     R1920                         25000
    X2094     R904                          -19386
    X2094     R1864                         1
    X2094     R1920                         35000
    X2095     R905                          -19386
    X2095     R1865                         1
    X2095     R1920                         5000
    X2096     R906                          -19386
    X2096     R1866                         1
    X2096     R1920                         30000
    X2097     R907                          -19386
    X2097     R1867                         1
    X2097     R1920                         20000
    X2098     R908                          -19386
    X2098     R1868                         1
    X2098     R1920                         25000
    X2099     R909                          -19386
    X2099     R1869                         1
    X2099     R1920                         35000
    X2100     R910                          -19386
    X2100     R1870                         1
    X2100     R1920                         30000
    X2101     R911                          -19386
    X2101     R1871                         1
    X2101     R1920                         5000
    X2102     R912                          -19386
    X2102     R1872                         1
    X2102     R1920                         20000
    X2103     R913                          -19386
    X2103     R1873                         1
    X2103     R1920                         20000
    X2104     R914                          -19386
    X2104     R1874                         1
    X2104     R1920                         45000
    X2105     R915                          -19386
    X2105     R1875                         1
    X2105     R1920                         40000
    X2106     R916                          -19386
    X2106     R1876                         1
    X2106     R1920                         40000
    X2107     R917                          -19386
    X2107     R1877                         1
    X2107     R1920                         20000
    X2108     R918                          -19386
    X2108     R1878                         1
    X2108     R1920                         20000
    X2109     R919                          -19386
    X2109     R1879                         1
    X2109     R1920                         25000
    X2110     R920                          -19386
    X2110     R1880                         1
    X2110     R1920                         45000
    X2111     R921                          -19386
    X2111     R1881                         1
    X2111     R1920                         35000
    X2112     R922                          -19386
    X2112     R1882                         1
    X2112     R1920                         45000
    X2113     R923                          -19386
    X2113     R1883                         1
    X2113     R1920                         25000
    X2114     R924                          -19386
    X2114     R1884                         1
    X2114     R1920                         10000
    X2115     R925                          -19386
    X2115     R1885                         1
    X2115     R1920                         25000
    X2116     R926                          -19386
    X2116     R1886                         1
    X2116     R1920                         10000
    X2117     R927                          -19386
    X2117     R1887                         1
    X2117     R1920                         5000
    X2118     R928                          -19386
    X2118     R1888                         1
    X2118     R1920                         40000
    X2119     R929                          -19386
    X2119     R1889                         1
    X2119     R1920                         10000
    X2120     R930                          -19386
    X2120     R1890                         1
    X2120     R1920                         30000
    X2121     R931                          -19386
    X2121     R1891                         1
    X2121     R1920                         20000
    X2122     R932                          -19386
    X2122     R1892                         1
    X2122     R1920                         30000
    X2123     R933                          -19386
    X2123     R1893                         1
    X2123     R1920                         30000
    X2124     R934                          -19386
    X2124     R1894                         1
    X2124     R1920                         15000
    X2125     R935                          -19386
    X2125     R1895                         1
    X2125     R1920                         10000
    X2126     R936                          -19386
    X2126     R1896                         1
    X2126     R1920                         25000
    X2127     R937                          -19386
    X2127     R1897                         1
    X2127     R1920                         25000
    X2128     R938                          -19386
    X2128     R1898                         1
    X2128     R1920                         45000
    X2129     R939                          -19386
    X2129     R1899                         1
    X2129     R1920                         35000
    X2130     R940                          -19386
    X2130     R1900                         1
    X2130     R1920                         10000
    X2131     R941                          -19386
    X2131     R1901                         1
    X2131     R1920                         10000
    X2132     R942                          -19386
    X2132     R1902                         1
    X2132     R1920                         45000
    X2133     R943                          -19386
    X2133     R1903                         1
    X2133     R1920                         10000
    X2134     R944                          -19386
    X2134     R1904                         1
    X2134     R1920                         5000
    X2135     R945                          -19386
    X2135     R1905                         1
    X2135     R1920                         30000
    X2136     R946                          -19386
    X2136     R1906                         1
    X2136     R1920                         20000
    X2137     R947                          -19386
    X2137     R1907                         1
    X2137     R1920                         30000
    X2138     R948                          -19386
    X2138     R1908                         1
    X2138     R1920                         30000
    X2139     R949                          -19386
    X2139     R1909                         1
    X2139     R1920                         30000
    X2140     R950                          -19386
    X2140     R1910                         1
    X2140     R1920                         45000
    X2141     R951                          -19386
    X2141     R1911                         1
    X2141     R1920                         20000
    X2142     R952                          -19386
    X2142     R1912                         1
    X2142     R1920                         30000
    X2143     R953                          -19386
    X2143     R1913                         1
    X2143     R1920                         5000
    X2144     R954                          -19386
    X2144     R1914                         1
    X2144     R1920                         15000
    X2145     R955                          -19386
    X2145     R1915                         1
    X2145     R1920                         5000
    X2146     R956                          -19386
    X2146     R1916                         1
    X2146     R1920                         35000
    X2147     R957                          -19386
    X2147     R1917                         1
    X2147     R1920                         25000
    X2148     R958                          -19386
    X2148     R1918                         1
    X2148     R1920                         5000
    X2149     R959                          -19386
    X2149     R1919                         1
    X2149     R1920                         45000
    X2150     R960                          -19269
    X2150     R1800                         1
    X2150     R1920                         25000
    X2151     R961                          -19269
    X2151     R1801                         1
    X2151     R1920                         30000
    X2152     R962                          -19269
    X2152     R1802                         1
    X2152     R1920                         35000
    X2153     R963                          -19269
    X2153     R1803                         1
    X2153     R1920                         15000
    X2154     R964                          -19269
    X2154     R1804                         1
    X2154     R1920                         25000
    X2155     R965                          -19269
    X2155     R1805                         1
    X2155     R1920                         10000
    X2156     R966                          -19269
    X2156     R1806                         1
    X2156     R1920                         25000
    X2157     R967                          -19269
    X2157     R1807                         1
    X2157     R1920                         15000
    X2158     R968                          -19269
    X2158     R1808                         1
    X2158     R1920                         5000
    X2159     R969                          -19269
    X2159     R1809                         1
    X2159     R1920                         35000
    X2160     R970                          -19269
    X2160     R1810                         1
    X2160     R1920                         25000
    X2161     R971                          -19269
    X2161     R1811                         1
    X2161     R1920                         10000
    X2162     R972                          -19269
    X2162     R1812                         1
    X2162     R1920                         15000
    X2163     R973                          -19269
    X2163     R1813                         1
    X2163     R1920                         5000
    X2164     R974                          -19269
    X2164     R1814                         1
    X2164     R1920                         10000
    X2165     R975                          -19269
    X2165     R1815                         1
    X2165     R1920                         45000
    X2166     R976                          -19269
    X2166     R1816                         1
    X2166     R1920                         15000
    X2167     R977                          -19269
    X2167     R1817                         1
    X2167     R1920                         45000
    X2168     R978                          -19269
    X2168     R1818                         1
    X2168     R1920                         45000
    X2169     R979                          -19269
    X2169     R1819                         1
    X2169     R1920                         10000
    X2170     R980                          -19269
    X2170     R1820                         1
    X2170     R1920                         35000
    X2171     R981                          -19269
    X2171     R1821                         1
    X2171     R1920                         45000
    X2172     R982                          -19269
    X2172     R1822                         1
    X2172     R1920                         15000
    X2173     R983                          -19269
    X2173     R1823                         1
    X2173     R1920                         25000
    X2174     R984                          -19269
    X2174     R1824                         1
    X2174     R1920                         10000
    X2175     R985                          -19269
    X2175     R1825                         1
    X2175     R1920                         25000
    X2176     R986                          -19269
    X2176     R1826                         1
    X2176     R1920                         35000
    X2177     R987                          -19269
    X2177     R1827                         1
    X2177     R1920                         45000
    X2178     R988                          -19269
    X2178     R1828                         1
    X2178     R1920                         25000
    X2179     R989                          -19269
    X2179     R1829                         1
    X2179     R1920                         35000
    X2180     R990                          -19269
    X2180     R1830                         1
    X2180     R1920                         25000
    X2181     R991                          -19269
    X2181     R1831                         1
    X2181     R1920                         5000
    X2182     R992                          -19269
    X2182     R1832                         1
    X2182     R1920                         15000
    X2183     R993                          -19269
    X2183     R1833                         1
    X2183     R1920                         45000
    X2184     R994                          -19269
    X2184     R1834                         1
    X2184     R1920                         20000
    X2185     R995                          -19269
    X2185     R1835                         1
    X2185     R1920                         15000
    X2186     R996                          -19269
    X2186     R1836                         1
    X2186     R1920                         35000
    X2187     R997                          -19269
    X2187     R1837                         1
    X2187     R1920                         5000
    X2188     R998                          -19269
    X2188     R1838                         1
    X2188     R1920                         30000
    X2189     R999                          -19269
    X2189     R1839                         1
    X2189     R1920                         35000
    X2190     R1000                         -19269
    X2190     R1840                         1
    X2190     R1920                         40000
    X2191     R1001                         -19269
    X2191     R1841                         1
    X2191     R1920                         40000
    X2192     R1002                         -19269
    X2192     R1842                         1
    X2192     R1920                         40000
    X2193     R1003                         -19269
    X2193     R1843                         1
    X2193     R1920                         35000
    X2194     R1004                         -19269
    X2194     R1844                         1
    X2194     R1920                         25000
    X2195     R1005                         -19269
    X2195     R1845                         1
    X2195     R1920                         25000
    X2196     R1006                         -19269
    X2196     R1846                         1
    X2196     R1920                         35000
    X2197     R1007                         -19269
    X2197     R1847                         1
    X2197     R1920                         10000
    X2198     R1008                         -19269
    X2198     R1848                         1
    X2198     R1920                         25000
    X2199     R1009                         -19269
    X2199     R1849                         1
    X2199     R1920                         35000
    X2200     R1010                         -19269
    X2200     R1850                         1
    X2200     R1920                         15000
    X2201     R1011                         -19269
    X2201     R1851                         1
    X2201     R1920                         15000
    X2202     R1012                         -19269
    X2202     R1852                         1
    X2202     R1920                         40000
    X2203     R1013                         -19269
    X2203     R1853                         1
    X2203     R1920                         45000
    X2204     R1014                         -19269
    X2204     R1854                         1
    X2204     R1920                         40000
    X2205     R1015                         -19269
    X2205     R1855                         1
    X2205     R1920                         40000
    X2206     R1016                         -19269
    X2206     R1856                         1
    X2206     R1920                         40000
    X2207     R1017                         -19269
    X2207     R1857                         1
    X2207     R1920                         25000
    X2208     R1018                         -19269
    X2208     R1858                         1
    X2208     R1920                         35000
    X2209     R1019                         -19269
    X2209     R1859                         1
    X2209     R1920                         20000
    X2210     R1020                         -19269
    X2210     R1860                         1
    X2210     R1920                         40000
    X2211     R1021                         -19269
    X2211     R1861                         1
    X2211     R1920                         30000
    X2212     R1022                         -19269
    X2212     R1862                         1
    X2212     R1920                         10000
    X2213     R1023                         -19269
    X2213     R1863                         1
    X2213     R1920                         20000
    X2214     R1024                         -19269
    X2214     R1864                         1
    X2214     R1920                         10000
    X2215     R1025                         -19269
    X2215     R1865                         1
    X2215     R1920                         15000
    X2216     R1026                         -19269
    X2216     R1866                         1
    X2216     R1920                         5000
    X2217     R1027                         -19269
    X2217     R1867                         1
    X2217     R1920                         45000
    X2218     R1028                         -19269
    X2218     R1868                         1
    X2218     R1920                         5000
    X2219     R1029                         -19269
    X2219     R1869                         1
    X2219     R1920                         10000
    X2220     R1030                         -19269
    X2220     R1870                         1
    X2220     R1920                         10000
    X2221     R1031                         -19269
    X2221     R1871                         1
    X2221     R1920                         40000
    X2222     R1032                         -19269
    X2222     R1872                         1
    X2222     R1920                         15000
    X2223     R1033                         -19269
    X2223     R1873                         1
    X2223     R1920                         45000
    X2224     R1034                         -19269
    X2224     R1874                         1
    X2224     R1920                         35000
    X2225     R1035                         -19269
    X2225     R1875                         1
    X2225     R1920                         45000
    X2226     R1036                         -19269
    X2226     R1876                         1
    X2226     R1920                         10000
    X2227     R1037                         -19269
    X2227     R1877                         1
    X2227     R1920                         15000
    X2228     R1038                         -19269
    X2228     R1878                         1
    X2228     R1920                         30000
    X2229     R1039                         -19269
    X2229     R1879                         1
    X2229     R1920                         40000
    X2230     R1040                         -19269
    X2230     R1880                         1
    X2230     R1920                         5000
    X2231     R1041                         -19269
    X2231     R1881                         1
    X2231     R1920                         5000
    X2232     R1042                         -19269
    X2232     R1882                         1
    X2232     R1920                         40000
    X2233     R1043                         -19269
    X2233     R1883                         1
    X2233     R1920                         20000
    X2234     R1044                         -19269
    X2234     R1884                         1
    X2234     R1920                         30000
    X2235     R1045                         -19269
    X2235     R1885                         1
    X2235     R1920                         25000
    X2236     R1046                         -19269
    X2236     R1886                         1
    X2236     R1920                         15000
    X2237     R1047                         -19269
    X2237     R1887                         1
    X2237     R1920                         35000
    X2238     R1048                         -19269
    X2238     R1888                         1
    X2238     R1920                         35000
    X2239     R1049                         -19269
    X2239     R1889                         1
    X2239     R1920                         30000
    X2240     R1050                         -19269
    X2240     R1890                         1
    X2240     R1920                         15000
    X2241     R1051                         -19269
    X2241     R1891                         1
    X2241     R1920                         20000
    X2242     R1052                         -19269
    X2242     R1892                         1
    X2242     R1920                         35000
    X2243     R1053                         -19269
    X2243     R1893                         1
    X2243     R1920                         5000
    X2244     R1054                         -19269
    X2244     R1894                         1
    X2244     R1920                         15000
    X2245     R1055                         -19269
    X2245     R1895                         1
    X2245     R1920                         20000
    X2246     R1056                         -19269
    X2246     R1896                         1
    X2246     R1920                         30000
    X2247     R1057                         -19269
    X2247     R1897                         1
    X2247     R1920                         15000
    X2248     R1058                         -19269
    X2248     R1898                         1
    X2248     R1920                         40000
    X2249     R1059                         -19269
    X2249     R1899                         1
    X2249     R1920                         20000
    X2250     R1060                         -19269
    X2250     R1900                         1
    X2250     R1920                         25000
    X2251     R1061                         -19269
    X2251     R1901                         1
    X2251     R1920                         25000
    X2252     R1062                         -19269
    X2252     R1902                         1
    X2252     R1920                         5000
    X2253     R1063                         -19269
    X2253     R1903                         1
    X2253     R1920                         40000
    X2254     R1064                         -19269
    X2254     R1904                         1
    X2254     R1920                         20000
    X2255     R1065                         -19269
    X2255     R1905                         1
    X2255     R1920                         40000
    X2256     R1066                         -19269
    X2256     R1906                         1
    X2256     R1920                         5000
    X2257     R1067                         -19269
    X2257     R1907                         1
    X2257     R1920                         25000
    X2258     R1068                         -19269
    X2258     R1908                         1
    X2258     R1920                         25000
    X2259     R1069                         -19269
    X2259     R1909                         1
    X2259     R1920                         30000
    X2260     R1070                         -19269
    X2260     R1910                         1
    X2260     R1920                         5000
    X2261     R1071                         -19269
    X2261     R1911                         1
    X2261     R1920                         45000
    X2262     R1072                         -19269
    X2262     R1912                         1
    X2262     R1920                         15000
    X2263     R1073                         -19269
    X2263     R1913                         1
    X2263     R1920                         10000
    X2264     R1074                         -19269
    X2264     R1914                         1
    X2264     R1920                         20000
    X2265     R1075                         -19269
    X2265     R1915                         1
    X2265     R1920                         5000
    X2266     R1076                         -19269
    X2266     R1916                         1
    X2266     R1920                         45000
    X2267     R1077                         -19269
    X2267     R1917                         1
    X2267     R1920                         10000
    X2268     R1078                         -19269
    X2268     R1918                         1
    X2268     R1920                         5000
    X2269     R1079                         -19269
    X2269     R1919                         1
    X2269     R1920                         15000
    X2270     R1080                         -20019
    X2270     R1800                         1
    X2270     R1920                         30000
    X2271     R1081                         -20019
    X2271     R1801                         1
    X2271     R1920                         5000
    X2272     R1082                         -20019
    X2272     R1802                         1
    X2272     R1920                         5000
    X2273     R1083                         -20019
    X2273     R1803                         1
    X2273     R1920                         15000
    X2274     R1084                         -20019
    X2274     R1804                         1
    X2274     R1920                         5000
    X2275     R1085                         -20019
    X2275     R1805                         1
    X2275     R1920                         15000
    X2276     R1086                         -20019
    X2276     R1806                         1
    X2276     R1920                         20000
    X2277     R1087                         -20019
    X2277     R1807                         1
    X2277     R1920                         25000
    X2278     R1088                         -20019
    X2278     R1808                         1
    X2278     R1920                         35000
    X2279     R1089                         -20019
    X2279     R1809                         1
    X2279     R1920                         25000
    X2280     R1090                         -20019
    X2280     R1810                         1
    X2280     R1920                         20000
    X2281     R1091                         -20019
    X2281     R1811                         1
    X2281     R1920                         5000
    X2282     R1092                         -20019
    X2282     R1812                         1
    X2282     R1920                         15000
    X2283     R1093                         -20019
    X2283     R1813                         1
    X2283     R1920                         15000
    X2284     R1094                         -20019
    X2284     R1814                         1
    X2284     R1920                         25000
    X2285     R1095                         -20019
    X2285     R1815                         1
    X2285     R1920                         5000
    X2286     R1096                         -20019
    X2286     R1816                         1
    X2286     R1920                         5000
    X2287     R1097                         -20019
    X2287     R1817                         1
    X2287     R1920                         20000
    X2288     R1098                         -20019
    X2288     R1818                         1
    X2288     R1920                         30000
    X2289     R1099                         -20019
    X2289     R1819                         1
    X2289     R1920                         45000
    X2290     R1100                         -20019
    X2290     R1820                         1
    X2290     R1920                         40000
    X2291     R1101                         -20019
    X2291     R1821                         1
    X2291     R1920                         5000
    X2292     R1102                         -20019
    X2292     R1822                         1
    X2292     R1920                         15000
    X2293     R1103                         -20019
    X2293     R1823                         1
    X2293     R1920                         5000
    X2294     R1104                         -20019
    X2294     R1824                         1
    X2294     R1920                         25000
    X2295     R1105                         -20019
    X2295     R1825                         1
    X2295     R1920                         20000
    X2296     R1106                         -20019
    X2296     R1826                         1
    X2296     R1920                         35000
    X2297     R1107                         -20019
    X2297     R1827                         1
    X2297     R1920                         5000
    X2298     R1108                         -20019
    X2298     R1828                         1
    X2298     R1920                         35000
    X2299     R1109                         -20019
    X2299     R1829                         1
    X2299     R1920                         40000
    X2300     R1110                         -20019
    X2300     R1830                         1
    X2300     R1920                         5000
    X2301     R1111                         -20019
    X2301     R1831                         1
    X2301     R1920                         5000
    X2302     R1112                         -20019
    X2302     R1832                         1
    X2302     R1920                         40000
    X2303     R1113                         -20019
    X2303     R1833                         1
    X2303     R1920                         30000
    X2304     R1114                         -20019
    X2304     R1834                         1
    X2304     R1920                         45000
    X2305     R1115                         -20019
    X2305     R1835                         1
    X2305     R1920                         30000
    X2306     R1116                         -20019
    X2306     R1836                         1
    X2306     R1920                         40000
    X2307     R1117                         -20019
    X2307     R1837                         1
    X2307     R1920                         5000
    X2308     R1118                         -20019
    X2308     R1838                         1
    X2308     R1920                         45000
    X2309     R1119                         -20019
    X2309     R1839                         1
    X2309     R1920                         5000
    X2310     R1120                         -20019
    X2310     R1840                         1
    X2310     R1920                         25000
    X2311     R1121                         -20019
    X2311     R1841                         1
    X2311     R1920                         40000
    X2312     R1122                         -20019
    X2312     R1842                         1
    X2312     R1920                         40000
    X2313     R1123                         -20019
    X2313     R1843                         1
    X2313     R1920                         5000
    X2314     R1124                         -20019
    X2314     R1844                         1
    X2314     R1920                         30000
    X2315     R1125                         -20019
    X2315     R1845                         1
    X2315     R1920                         35000
    X2316     R1126                         -20019
    X2316     R1846                         1
    X2316     R1920                         35000
    X2317     R1127                         -20019
    X2317     R1847                         1
    X2317     R1920                         10000
    X2318     R1128                         -20019
    X2318     R1848                         1
    X2318     R1920                         10000
    X2319     R1129                         -20019
    X2319     R1849                         1
    X2319     R1920                         30000
    X2320     R1130                         -20019
    X2320     R1850                         1
    X2320     R1920                         40000
    X2321     R1131                         -20019
    X2321     R1851                         1
    X2321     R1920                         35000
    X2322     R1132                         -20019
    X2322     R1852                         1
    X2322     R1920                         5000
    X2323     R1133                         -20019
    X2323     R1853                         1
    X2323     R1920                         10000
    X2324     R1134                         -20019
    X2324     R1854                         1
    X2324     R1920                         5000
    X2325     R1135                         -20019
    X2325     R1855                         1
    X2325     R1920                         15000
    X2326     R1136                         -20019
    X2326     R1856                         1
    X2326     R1920                         30000
    X2327     R1137                         -20019
    X2327     R1857                         1
    X2327     R1920                         20000
    X2328     R1138                         -20019
    X2328     R1858                         1
    X2328     R1920                         25000
    X2329     R1139                         -20019
    X2329     R1859                         1
    X2329     R1920                         10000
    X2330     R1140                         -20019
    X2330     R1860                         1
    X2330     R1920                         15000
    X2331     R1141                         -20019
    X2331     R1861                         1
    X2331     R1920                         35000
    X2332     R1142                         -20019
    X2332     R1862                         1
    X2332     R1920                         15000
    X2333     R1143                         -20019
    X2333     R1863                         1
    X2333     R1920                         5000
    X2334     R1144                         -20019
    X2334     R1864                         1
    X2334     R1920                         5000
    X2335     R1145                         -20019
    X2335     R1865                         1
    X2335     R1920                         30000
    X2336     R1146                         -20019
    X2336     R1866                         1
    X2336     R1920                         40000
    X2337     R1147                         -20019
    X2337     R1867                         1
    X2337     R1920                         20000
    X2338     R1148                         -20019
    X2338     R1868                         1
    X2338     R1920                         35000
    X2339     R1149                         -20019
    X2339     R1869                         1
    X2339     R1920                         5000
    X2340     R1150                         -20019
    X2340     R1870                         1
    X2340     R1920                         10000
    X2341     R1151                         -20019
    X2341     R1871                         1
    X2341     R1920                         25000
    X2342     R1152                         -20019
    X2342     R1872                         1
    X2342     R1920                         15000
    X2343     R1153                         -20019
    X2343     R1873                         1
    X2343     R1920                         45000
    X2344     R1154                         -20019
    X2344     R1874                         1
    X2344     R1920                         10000
    X2345     R1155                         -20019
    X2345     R1875                         1
    X2345     R1920                         20000
    X2346     R1156                         -20019
    X2346     R1876                         1
    X2346     R1920                         5000
    X2347     R1157                         -20019
    X2347     R1877                         1
    X2347     R1920                         20000
    X2348     R1158                         -20019
    X2348     R1878                         1
    X2348     R1920                         15000
    X2349     R1159                         -20019
    X2349     R1879                         1
    X2349     R1920                         5000
    X2350     R1160                         -20019
    X2350     R1880                         1
    X2350     R1920                         20000
    X2351     R1161                         -20019
    X2351     R1881                         1
    X2351     R1920                         5000
    X2352     R1162                         -20019
    X2352     R1882                         1
    X2352     R1920                         30000
    X2353     R1163                         -20019
    X2353     R1883                         1
    X2353     R1920                         25000
    X2354     R1164                         -20019
    X2354     R1884                         1
    X2354     R1920                         15000
    X2355     R1165                         -20019
    X2355     R1885                         1
    X2355     R1920                         5000
    X2356     R1166                         -20019
    X2356     R1886                         1
    X2356     R1920                         35000
    X2357     R1167                         -20019
    X2357     R1887                         1
    X2357     R1920                         20000
    X2358     R1168                         -20019
    X2358     R1888                         1
    X2358     R1920                         35000
    X2359     R1169                         -20019
    X2359     R1889                         1
    X2359     R1920                         20000
    X2360     R1170                         -20019
    X2360     R1890                         1
    X2360     R1920                         15000
    X2361     R1171                         -20019
    X2361     R1891                         1
    X2361     R1920                         45000
    X2362     R1172                         -20019
    X2362     R1892                         1
    X2362     R1920                         25000
    X2363     R1173                         -20019
    X2363     R1893                         1
    X2363     R1920                         5000
    X2364     R1174                         -20019
    X2364     R1894                         1
    X2364     R1920                         10000
    X2365     R1175                         -20019
    X2365     R1895                         1
    X2365     R1920                         20000
    X2366     R1176                         -20019
    X2366     R1896                         1
    X2366     R1920                         5000
    X2367     R1177                         -20019
    X2367     R1897                         1
    X2367     R1920                         35000
    X2368     R1178                         -20019
    X2368     R1898                         1
    X2368     R1920                         15000
    X2369     R1179                         -20019
    X2369     R1899                         1
    X2369     R1920                         15000
    X2370     R1180                         -20019
    X2370     R1900                         1
    X2370     R1920                         10000
    X2371     R1181                         -20019
    X2371     R1901                         1
    X2371     R1920                         40000
    X2372     R1182                         -20019
    X2372     R1902                         1
    X2372     R1920                         45000
    X2373     R1183                         -20019
    X2373     R1903                         1
    X2373     R1920                         15000
    X2374     R1184                         -20019
    X2374     R1904                         1
    X2374     R1920                         40000
    X2375     R1185                         -20019
    X2375     R1905                         1
    X2375     R1920                         25000
    X2376     R1186                         -20019
    X2376     R1906                         1
    X2376     R1920                         20000
    X2377     R1187                         -20019
    X2377     R1907                         1
    X2377     R1920                         10000
    X2378     R1188                         -20019
    X2378     R1908                         1
    X2378     R1920                         40000
    X2379     R1189                         -20019
    X2379     R1909                         1
    X2379     R1920                         40000
    X2380     R1190                         -20019
    X2380     R1910                         1
    X2380     R1920                         5000
    X2381     R1191                         -20019
    X2381     R1911                         1
    X2381     R1920                         40000
    X2382     R1192                         -20019
    X2382     R1912                         1
    X2382     R1920                         25000
    X2383     R1193                         -20019
    X2383     R1913                         1
    X2383     R1920                         5000
    X2384     R1194                         -20019
    X2384     R1914                         1
    X2384     R1920                         30000
    X2385     R1195                         -20019
    X2385     R1915                         1
    X2385     R1920                         35000
    X2386     R1196                         -20019
    X2386     R1916                         1
    X2386     R1920                         30000
    X2387     R1197                         -20019
    X2387     R1917                         1
    X2387     R1920                         45000
    X2388     R1198                         -20019
    X2388     R1918                         1
    X2388     R1920                         30000
    X2389     R1199                         -20019
    X2389     R1919                         1
    X2389     R1920                         20000
    X2390     R1200                         -18298
    X2390     R1795                         1
    X2391     R1201                         -18298
    X2391     R1795                         1
    X2392     R1202                         -18298
    X2392     R1795                         1
    X2393     R1203                         -18298
    X2393     R1795                         1
    X2394     R1204                         -18298
    X2394     R1795                         1
    X2395     R1205                         -18298
    X2395     R1795                         1
    X2396     R1206                         -18298
    X2396     R1795                         1
    X2397     R1207                         -18298
    X2397     R1795                         1
    X2398     R1208                         -18298
    X2398     R1795                         1
    X2399     R1209                         -18298
    X2399     R1795                         1
    X2400     R1210                         -18298
    X2400     R1795                         1
    X2401     R1211                         -18298
    X2401     R1795                         1
    X2402     R1212                         -18298
    X2402     R1795                         1
    X2403     R1213                         -18298
    X2403     R1795                         1
    X2404     R1214                         -18298
    X2404     R1795                         1
    X2405     R1215                         -18298
    X2405     R1795                         1
    X2406     R1216                         -18298
    X2406     R1795                         1
    X2407     R1217                         -18298
    X2407     R1795                         1
    X2408     R1218                         -18298
    X2408     R1795                         1
    X2409     R1219                         -18298
    X2409     R1795                         1
    X2410     R1220                         -18298
    X2410     R1795                         1
    X2411     R1221                         -18298
    X2411     R1795                         1
    X2412     R1222                         -18298
    X2412     R1795                         1
    X2413     R1223                         -18298
    X2413     R1795                         1
    X2414     R1224                         -18298
    X2414     R1795                         1
    X2415     R1225                         -18298
    X2415     R1795                         1
    X2416     R1226                         -18298
    X2416     R1795                         1
    X2417     R1227                         -18298
    X2417     R1795                         1
    X2418     R1228                         -18298
    X2418     R1795                         1
    X2419     R1229                         -18298
    X2419     R1795                         1
    X2420     R1230                         -18298
    X2420     R1795                         1
    X2421     R1231                         -18298
    X2421     R1795                         1
    X2422     R1232                         -18298
    X2422     R1795                         1
    X2423     R1233                         -18298
    X2423     R1795                         1
    X2424     R1234                         -18298
    X2424     R1795                         1
    X2425     R1235                         -18298
    X2425     R1795                         1
    X2426     R1236                         -18298
    X2426     R1795                         1
    X2427     R1237                         -18298
    X2427     R1795                         1
    X2428     R1238                         -18298
    X2428     R1795                         1
    X2429     R1239                         -18298
    X2429     R1795                         1
    X2430     R1240                         -18298
    X2430     R1795                         1
    X2431     R1241                         -18298
    X2431     R1795                         1
    X2432     R1242                         -18298
    X2432     R1795                         1
    X2433     R1243                         -18298
    X2433     R1795                         1
    X2434     R1244                         -18298
    X2434     R1795                         1
    X2435     R1245                         -18298
    X2435     R1795                         1
    X2436     R1246                         -18298
    X2436     R1795                         1
    X2437     R1247                         -18298
    X2437     R1795                         1
    X2438     R1248                         -18298
    X2438     R1795                         1
    X2439     R1249                         -18298
    X2439     R1795                         1
    X2440     R1250                         -18298
    X2440     R1795                         1
    X2441     R1251                         -18298
    X2441     R1795                         1
    X2442     R1252                         -18298
    X2442     R1795                         1
    X2443     R1253                         -18298
    X2443     R1795                         1
    X2444     R1254                         -18298
    X2444     R1795                         1
    X2445     R1255                         -18298
    X2445     R1795                         1
    X2446     R1256                         -18298
    X2446     R1795                         1
    X2447     R1257                         -18298
    X2447     R1795                         1
    X2448     R1258                         -18298
    X2448     R1795                         1
    X2449     R1259                         -18298
    X2449     R1795                         1
    X2450     R1260                         -18298
    X2450     R1795                         1
    X2451     R1261                         -18298
    X2451     R1795                         1
    X2452     R1262                         -18298
    X2452     R1795                         1
    X2453     R1263                         -18298
    X2453     R1795                         1
    X2454     R1264                         -18298
    X2454     R1795                         1
    X2455     R1265                         -18298
    X2455     R1795                         1
    X2456     R1266                         -18298
    X2456     R1795                         1
    X2457     R1267                         -18298
    X2457     R1795                         1
    X2458     R1268                         -18298
    X2458     R1795                         1
    X2459     R1269                         -18298
    X2459     R1795                         1
    X2460     R1270                         -18298
    X2460     R1795                         1
    X2461     R1271                         -18298
    X2461     R1795                         1
    X2462     R1272                         -18298
    X2462     R1795                         1
    X2463     R1273                         -18298
    X2463     R1795                         1
    X2464     R1274                         -18298
    X2464     R1795                         1
    X2465     R1275                         -18298
    X2465     R1795                         1
    X2466     R1276                         -18298
    X2466     R1795                         1
    X2467     R1277                         -18298
    X2467     R1795                         1
    X2468     R1278                         -18298
    X2468     R1795                         1
    X2469     R1279                         -18298
    X2469     R1795                         1
    X2470     R1280                         -18298
    X2470     R1795                         1
    X2471     R1281                         -18298
    X2471     R1795                         1
    X2472     R1282                         -18298
    X2472     R1795                         1
    X2473     R1283                         -18298
    X2473     R1795                         1
    X2474     R1284                         -18298
    X2474     R1795                         1
    X2475     R1285                         -18298
    X2475     R1795                         1
    X2476     R1286                         -18298
    X2476     R1795                         1
    X2477     R1287                         -18298
    X2477     R1795                         1
    X2478     R1288                         -18298
    X2478     R1795                         1
    X2479     R1289                         -18298
    X2479     R1795                         1
    X2480     R1290                         -18298
    X2480     R1795                         1
    X2481     R1291                         -18298
    X2481     R1795                         1
    X2482     R1292                         -18298
    X2482     R1795                         1
    X2483     R1293                         -18298
    X2483     R1795                         1
    X2484     R1294                         -18298
    X2484     R1795                         1
    X2485     R1295                         -18298
    X2485     R1795                         1
    X2486     R1296                         -18298
    X2486     R1795                         1
    X2487     R1297                         -18298
    X2487     R1795                         1
    X2488     R1298                         -18298
    X2488     R1795                         1
    X2489     R1299                         -18298
    X2489     R1795                         1
    X2490     R1300                         -18298
    X2490     R1795                         1
    X2491     R1301                         -18298
    X2491     R1795                         1
    X2492     R1302                         -18298
    X2492     R1795                         1
    X2493     R1303                         -18298
    X2493     R1795                         1
    X2494     R1304                         -18298
    X2494     R1795                         1
    X2495     R1305                         -18298
    X2495     R1795                         1
    X2496     R1306                         -18298
    X2496     R1795                         1
    X2497     R1307                         -18298
    X2497     R1795                         1
    X2498     R1308                         -18298
    X2498     R1795                         1
    X2499     R1309                         -18298
    X2499     R1795                         1
    X2500     R1310                         -18298
    X2500     R1795                         1
    X2501     R1311                         -18298
    X2501     R1795                         1
    X2502     R1312                         -18298
    X2502     R1795                         1
    X2503     R1313                         -18298
    X2503     R1795                         1
    X2504     R1314                         -18298
    X2504     R1795                         1
    X2505     R1315                         -18298
    X2505     R1795                         1
    X2506     R1316                         -18298
    X2506     R1795                         1
    X2507     R1317                         -18298
    X2507     R1795                         1
    X2508     R1318                         -18298
    X2508     R1795                         1
    X2509     R1319                         -16531
    X2509     R1796                         1
    X2510     R1320                         -16531
    X2510     R1796                         1
    X2511     R1321                         -16531
    X2511     R1796                         1
    X2512     R1322                         -16531
    X2512     R1796                         1
    X2513     R1323                         -16531
    X2513     R1796                         1
    X2514     R1324                         -16531
    X2514     R1796                         1
    X2515     R1325                         -16531
    X2515     R1796                         1
    X2516     R1326                         -16531
    X2516     R1796                         1
    X2517     R1327                         -16531
    X2517     R1796                         1
    X2518     R1328                         -16531
    X2518     R1796                         1
    X2519     R1329                         -16531
    X2519     R1796                         1
    X2520     R1330                         -16531
    X2520     R1796                         1
    X2521     R1331                         -16531
    X2521     R1796                         1
    X2522     R1332                         -16531
    X2522     R1796                         1
    X2523     R1333                         -16531
    X2523     R1796                         1
    X2524     R1334                         -16531
    X2524     R1796                         1
    X2525     R1335                         -16531
    X2525     R1796                         1
    X2526     R1336                         -16531
    X2526     R1796                         1
    X2527     R1337                         -16531
    X2527     R1796                         1
    X2528     R1338                         -16531
    X2528     R1796                         1
    X2529     R1339                         -16531
    X2529     R1796                         1
    X2530     R1340                         -16531
    X2530     R1796                         1
    X2531     R1341                         -16531
    X2531     R1796                         1
    X2532     R1342                         -16531
    X2532     R1796                         1
    X2533     R1343                         -16531
    X2533     R1796                         1
    X2534     R1344                         -16531
    X2534     R1796                         1
    X2535     R1345                         -16531
    X2535     R1796                         1
    X2536     R1346                         -16531
    X2536     R1796                         1
    X2537     R1347                         -16531
    X2537     R1796                         1
    X2538     R1348                         -16531
    X2538     R1796                         1
    X2539     R1349                         -16531
    X2539     R1796                         1
    X2540     R1350                         -16531
    X2540     R1796                         1
    X2541     R1351                         -16531
    X2541     R1796                         1
    X2542     R1352                         -16531
    X2542     R1796                         1
    X2543     R1353                         -16531
    X2543     R1796                         1
    X2544     R1354                         -16531
    X2544     R1796                         1
    X2545     R1355                         -16531
    X2545     R1796                         1
    X2546     R1356                         -16531
    X2546     R1796                         1
    X2547     R1357                         -16531
    X2547     R1796                         1
    X2548     R1358                         -16531
    X2548     R1796                         1
    X2549     R1359                         -16531
    X2549     R1796                         1
    X2550     R1360                         -16531
    X2550     R1796                         1
    X2551     R1361                         -16531
    X2551     R1796                         1
    X2552     R1362                         -16531
    X2552     R1796                         1
    X2553     R1363                         -16531
    X2553     R1796                         1
    X2554     R1364                         -16531
    X2554     R1796                         1
    X2555     R1365                         -16531
    X2555     R1796                         1
    X2556     R1366                         -16531
    X2556     R1796                         1
    X2557     R1367                         -16531
    X2557     R1796                         1
    X2558     R1368                         -16531
    X2558     R1796                         1
    X2559     R1369                         -16531
    X2559     R1796                         1
    X2560     R1370                         -16531
    X2560     R1796                         1
    X2561     R1371                         -16531
    X2561     R1796                         1
    X2562     R1372                         -16531
    X2562     R1796                         1
    X2563     R1373                         -16531
    X2563     R1796                         1
    X2564     R1374                         -16531
    X2564     R1796                         1
    X2565     R1375                         -16531
    X2565     R1796                         1
    X2566     R1376                         -16531
    X2566     R1796                         1
    X2567     R1377                         -16531
    X2567     R1796                         1
    X2568     R1378                         -16531
    X2568     R1796                         1
    X2569     R1379                         -16531
    X2569     R1796                         1
    X2570     R1380                         -16531
    X2570     R1796                         1
    X2571     R1381                         -16531
    X2571     R1796                         1
    X2572     R1382                         -16531
    X2572     R1796                         1
    X2573     R1383                         -16531
    X2573     R1796                         1
    X2574     R1384                         -16531
    X2574     R1796                         1
    X2575     R1385                         -16531
    X2575     R1796                         1
    X2576     R1386                         -16531
    X2576     R1796                         1
    X2577     R1387                         -16531
    X2577     R1796                         1
    X2578     R1388                         -16531
    X2578     R1796                         1
    X2579     R1389                         -16531
    X2579     R1796                         1
    X2580     R1390                         -16531
    X2580     R1796                         1
    X2581     R1391                         -16531
    X2581     R1796                         1
    X2582     R1392                         -16531
    X2582     R1796                         1
    X2583     R1393                         -16531
    X2583     R1796                         1
    X2584     R1394                         -16531
    X2584     R1796                         1
    X2585     R1395                         -16531
    X2585     R1796                         1
    X2586     R1396                         -16531
    X2586     R1796                         1
    X2587     R1397                         -16531
    X2587     R1796                         1
    X2588     R1398                         -16531
    X2588     R1796                         1
    X2589     R1399                         -16531
    X2589     R1796                         1
    X2590     R1400                         -16531
    X2590     R1796                         1
    X2591     R1401                         -16531
    X2591     R1796                         1
    X2592     R1402                         -16531
    X2592     R1796                         1
    X2593     R1403                         -16531
    X2593     R1796                         1
    X2594     R1404                         -16531
    X2594     R1796                         1
    X2595     R1405                         -16531
    X2595     R1796                         1
    X2596     R1406                         -16531
    X2596     R1796                         1
    X2597     R1407                         -16531
    X2597     R1796                         1
    X2598     R1408                         -16531
    X2598     R1796                         1
    X2599     R1409                         -16531
    X2599     R1796                         1
    X2600     R1410                         -16531
    X2600     R1796                         1
    X2601     R1411                         -16531
    X2601     R1796                         1
    X2602     R1412                         -16531
    X2602     R1796                         1
    X2603     R1413                         -16531
    X2603     R1796                         1
    X2604     R1414                         -16531
    X2604     R1796                         1
    X2605     R1415                         -16531
    X2605     R1796                         1
    X2606     R1416                         -16531
    X2606     R1796                         1
    X2607     R1417                         -16531
    X2607     R1796                         1
    X2608     R1418                         -16531
    X2608     R1796                         1
    X2609     R1419                         -16531
    X2609     R1796                         1
    X2610     R1420                         -16531
    X2610     R1796                         1
    X2611     R1421                         -16531
    X2611     R1796                         1
    X2612     R1422                         -16531
    X2612     R1796                         1
    X2613     R1423                         -16531
    X2613     R1796                         1
    X2614     R1424                         -16531
    X2614     R1796                         1
    X2615     R1425                         -16531
    X2615     R1796                         1
    X2616     R1426                         -16531
    X2616     R1796                         1
    X2617     R1427                         -16531
    X2617     R1796                         1
    X2618     R1428                         -16531
    X2618     R1796                         1
    X2619     R1429                         -16531
    X2619     R1796                         1
    X2620     R1430                         -16531
    X2620     R1796                         1
    X2621     R1431                         -16531
    X2621     R1796                         1
    X2622     R1432                         -16531
    X2622     R1796                         1
    X2623     R1433                         -16531
    X2623     R1796                         1
    X2624     R1434                         -16531
    X2624     R1796                         1
    X2625     R1435                         -16531
    X2625     R1796                         1
    X2626     R1436                         -16531
    X2626     R1796                         1
    X2627     R1437                         -16531
    X2627     R1796                         1
    X2628     R1438                         -19386
    X2628     R1797                         1
    X2629     R1439                         -19386
    X2629     R1797                         1
    X2630     R1440                         -19386
    X2630     R1797                         1
    X2631     R1441                         -19386
    X2631     R1797                         1
    X2632     R1442                         -19386
    X2632     R1797                         1
    X2633     R1443                         -19386
    X2633     R1797                         1
    X2634     R1444                         -19386
    X2634     R1797                         1
    X2635     R1445                         -19386
    X2635     R1797                         1
    X2636     R1446                         -19386
    X2636     R1797                         1
    X2637     R1447                         -19386
    X2637     R1797                         1
    X2638     R1448                         -19386
    X2638     R1797                         1
    X2639     R1449                         -19386
    X2639     R1797                         1
    X2640     R1450                         -19386
    X2640     R1797                         1
    X2641     R1451                         -19386
    X2641     R1797                         1
    X2642     R1452                         -19386
    X2642     R1797                         1
    X2643     R1453                         -19386
    X2643     R1797                         1
    X2644     R1454                         -19386
    X2644     R1797                         1
    X2645     R1455                         -19386
    X2645     R1797                         1
    X2646     R1456                         -19386
    X2646     R1797                         1
    X2647     R1457                         -19386
    X2647     R1797                         1
    X2648     R1458                         -19386
    X2648     R1797                         1
    X2649     R1459                         -19386
    X2649     R1797                         1
    X2650     R1460                         -19386
    X2650     R1797                         1
    X2651     R1461                         -19386
    X2651     R1797                         1
    X2652     R1462                         -19386
    X2652     R1797                         1
    X2653     R1463                         -19386
    X2653     R1797                         1
    X2654     R1464                         -19386
    X2654     R1797                         1
    X2655     R1465                         -19386
    X2655     R1797                         1
    X2656     R1466                         -19386
    X2656     R1797                         1
    X2657     R1467                         -19386
    X2657     R1797                         1
    X2658     R1468                         -19386
    X2658     R1797                         1
    X2659     R1469                         -19386
    X2659     R1797                         1
    X2660     R1470                         -19386
    X2660     R1797                         1
    X2661     R1471                         -19386
    X2661     R1797                         1
    X2662     R1472                         -19386
    X2662     R1797                         1
    X2663     R1473                         -19386
    X2663     R1797                         1
    X2664     R1474                         -19386
    X2664     R1797                         1
    X2665     R1475                         -19386
    X2665     R1797                         1
    X2666     R1476                         -19386
    X2666     R1797                         1
    X2667     R1477                         -19386
    X2667     R1797                         1
    X2668     R1478                         -19386
    X2668     R1797                         1
    X2669     R1479                         -19386
    X2669     R1797                         1
    X2670     R1480                         -19386
    X2670     R1797                         1
    X2671     R1481                         -19386
    X2671     R1797                         1
    X2672     R1482                         -19386
    X2672     R1797                         1
    X2673     R1483                         -19386
    X2673     R1797                         1
    X2674     R1484                         -19386
    X2674     R1797                         1
    X2675     R1485                         -19386
    X2675     R1797                         1
    X2676     R1486                         -19386
    X2676     R1797                         1
    X2677     R1487                         -19386
    X2677     R1797                         1
    X2678     R1488                         -19386
    X2678     R1797                         1
    X2679     R1489                         -19386
    X2679     R1797                         1
    X2680     R1490                         -19386
    X2680     R1797                         1
    X2681     R1491                         -19386
    X2681     R1797                         1
    X2682     R1492                         -19386
    X2682     R1797                         1
    X2683     R1493                         -19386
    X2683     R1797                         1
    X2684     R1494                         -19386
    X2684     R1797                         1
    X2685     R1495                         -19386
    X2685     R1797                         1
    X2686     R1496                         -19386
    X2686     R1797                         1
    X2687     R1497                         -19386
    X2687     R1797                         1
    X2688     R1498                         -19386
    X2688     R1797                         1
    X2689     R1499                         -19386
    X2689     R1797                         1
    X2690     R1500                         -19386
    X2690     R1797                         1
    X2691     R1501                         -19386
    X2691     R1797                         1
    X2692     R1502                         -19386
    X2692     R1797                         1
    X2693     R1503                         -19386
    X2693     R1797                         1
    X2694     R1504                         -19386
    X2694     R1797                         1
    X2695     R1505                         -19386
    X2695     R1797                         1
    X2696     R1506                         -19386
    X2696     R1797                         1
    X2697     R1507                         -19386
    X2697     R1797                         1
    X2698     R1508                         -19386
    X2698     R1797                         1
    X2699     R1509                         -19386
    X2699     R1797                         1
    X2700     R1510                         -19386
    X2700     R1797                         1
    X2701     R1511                         -19386
    X2701     R1797                         1
    X2702     R1512                         -19386
    X2702     R1797                         1
    X2703     R1513                         -19386
    X2703     R1797                         1
    X2704     R1514                         -19386
    X2704     R1797                         1
    X2705     R1515                         -19386
    X2705     R1797                         1
    X2706     R1516                         -19386
    X2706     R1797                         1
    X2707     R1517                         -19386
    X2707     R1797                         1
    X2708     R1518                         -19386
    X2708     R1797                         1
    X2709     R1519                         -19386
    X2709     R1797                         1
    X2710     R1520                         -19386
    X2710     R1797                         1
    X2711     R1521                         -19386
    X2711     R1797                         1
    X2712     R1522                         -19386
    X2712     R1797                         1
    X2713     R1523                         -19386
    X2713     R1797                         1
    X2714     R1524                         -19386
    X2714     R1797                         1
    X2715     R1525                         -19386
    X2715     R1797                         1
    X2716     R1526                         -19386
    X2716     R1797                         1
    X2717     R1527                         -19386
    X2717     R1797                         1
    X2718     R1528                         -19386
    X2718     R1797                         1
    X2719     R1529                         -19386
    X2719     R1797                         1
    X2720     R1530                         -19386
    X2720     R1797                         1
    X2721     R1531                         -19386
    X2721     R1797                         1
    X2722     R1532                         -19386
    X2722     R1797                         1
    X2723     R1533                         -19386
    X2723     R1797                         1
    X2724     R1534                         -19386
    X2724     R1797                         1
    X2725     R1535                         -19386
    X2725     R1797                         1
    X2726     R1536                         -19386
    X2726     R1797                         1
    X2727     R1537                         -19386
    X2727     R1797                         1
    X2728     R1538                         -19386
    X2728     R1797                         1
    X2729     R1539                         -19386
    X2729     R1797                         1
    X2730     R1540                         -19386
    X2730     R1797                         1
    X2731     R1541                         -19386
    X2731     R1797                         1
    X2732     R1542                         -19386
    X2732     R1797                         1
    X2733     R1543                         -19386
    X2733     R1797                         1
    X2734     R1544                         -19386
    X2734     R1797                         1
    X2735     R1545                         -19386
    X2735     R1797                         1
    X2736     R1546                         -19386
    X2736     R1797                         1
    X2737     R1547                         -19386
    X2737     R1797                         1
    X2738     R1548                         -19386
    X2738     R1797                         1
    X2739     R1549                         -19386
    X2739     R1797                         1
    X2740     R1550                         -19386
    X2740     R1797                         1
    X2741     R1551                         -19386
    X2741     R1797                         1
    X2742     R1552                         -19386
    X2742     R1797                         1
    X2743     R1553                         -19386
    X2743     R1797                         1
    X2744     R1554                         -19386
    X2744     R1797                         1
    X2745     R1555                         -19386
    X2745     R1797                         1
    X2746     R1556                         -19386
    X2746     R1797                         1
    X2747     R1557                         -19269
    X2747     R1798                         1
    X2748     R1558                         -19269
    X2748     R1798                         1
    X2749     R1559                         -19269
    X2749     R1798                         1
    X2750     R1560                         -19269
    X2750     R1798                         1
    X2751     R1561                         -19269
    X2751     R1798                         1
    X2752     R1562                         -19269
    X2752     R1798                         1
    X2753     R1563                         -19269
    X2753     R1798                         1
    X2754     R1564                         -19269
    X2754     R1798                         1
    X2755     R1565                         -19269
    X2755     R1798                         1
    X2756     R1566                         -19269
    X2756     R1798                         1
    X2757     R1567                         -19269
    X2757     R1798                         1
    X2758     R1568                         -19269
    X2758     R1798                         1
    X2759     R1569                         -19269
    X2759     R1798                         1
    X2760     R1570                         -19269
    X2760     R1798                         1
    X2761     R1571                         -19269
    X2761     R1798                         1
    X2762     R1572                         -19269
    X2762     R1798                         1
    X2763     R1573                         -19269
    X2763     R1798                         1
    X2764     R1574                         -19269
    X2764     R1798                         1
    X2765     R1575                         -19269
    X2765     R1798                         1
    X2766     R1576                         -19269
    X2766     R1798                         1
    X2767     R1577                         -19269
    X2767     R1798                         1
    X2768     R1578                         -19269
    X2768     R1798                         1
    X2769     R1579                         -19269
    X2769     R1798                         1
    X2770     R1580                         -19269
    X2770     R1798                         1
    X2771     R1581                         -19269
    X2771     R1798                         1
    X2772     R1582                         -19269
    X2772     R1798                         1
    X2773     R1583                         -19269
    X2773     R1798                         1
    X2774     R1584                         -19269
    X2774     R1798                         1
    X2775     R1585                         -19269
    X2775     R1798                         1
    X2776     R1586                         -19269
    X2776     R1798                         1
    X2777     R1587                         -19269
    X2777     R1798                         1
    X2778     R1588                         -19269
    X2778     R1798                         1
    X2779     R1589                         -19269
    X2779     R1798                         1
    X2780     R1590                         -19269
    X2780     R1798                         1
    X2781     R1591                         -19269
    X2781     R1798                         1
    X2782     R1592                         -19269
    X2782     R1798                         1
    X2783     R1593                         -19269
    X2783     R1798                         1
    X2784     R1594                         -19269
    X2784     R1798                         1
    X2785     R1595                         -19269
    X2785     R1798                         1
    X2786     R1596                         -19269
    X2786     R1798                         1
    X2787     R1597                         -19269
    X2787     R1798                         1
    X2788     R1598                         -19269
    X2788     R1798                         1
    X2789     R1599                         -19269
    X2789     R1798                         1
    X2790     R1600                         -19269
    X2790     R1798                         1
    X2791     R1601                         -19269
    X2791     R1798                         1
    X2792     R1602                         -19269
    X2792     R1798                         1
    X2793     R1603                         -19269
    X2793     R1798                         1
    X2794     R1604                         -19269
    X2794     R1798                         1
    X2795     R1605                         -19269
    X2795     R1798                         1
    X2796     R1606                         -19269
    X2796     R1798                         1
    X2797     R1607                         -19269
    X2797     R1798                         1
    X2798     R1608                         -19269
    X2798     R1798                         1
    X2799     R1609                         -19269
    X2799     R1798                         1
    X2800     R1610                         -19269
    X2800     R1798                         1
    X2801     R1611                         -19269
    X2801     R1798                         1
    X2802     R1612                         -19269
    X2802     R1798                         1
    X2803     R1613                         -19269
    X2803     R1798                         1
    X2804     R1614                         -19269
    X2804     R1798                         1
    X2805     R1615                         -19269
    X2805     R1798                         1
    X2806     R1616                         -19269
    X2806     R1798                         1
    X2807     R1617                         -19269
    X2807     R1798                         1
    X2808     R1618                         -19269
    X2808     R1798                         1
    X2809     R1619                         -19269
    X2809     R1798                         1
    X2810     R1620                         -19269
    X2810     R1798                         1
    X2811     R1621                         -19269
    X2811     R1798                         1
    X2812     R1622                         -19269
    X2812     R1798                         1
    X2813     R1623                         -19269
    X2813     R1798                         1
    X2814     R1624                         -19269
    X2814     R1798                         1
    X2815     R1625                         -19269
    X2815     R1798                         1
    X2816     R1626                         -19269
    X2816     R1798                         1
    X2817     R1627                         -19269
    X2817     R1798                         1
    X2818     R1628                         -19269
    X2818     R1798                         1
    X2819     R1629                         -19269
    X2819     R1798                         1
    X2820     R1630                         -19269
    X2820     R1798                         1
    X2821     R1631                         -19269
    X2821     R1798                         1
    X2822     R1632                         -19269
    X2822     R1798                         1
    X2823     R1633                         -19269
    X2823     R1798                         1
    X2824     R1634                         -19269
    X2824     R1798                         1
    X2825     R1635                         -19269
    X2825     R1798                         1
    X2826     R1636                         -19269
    X2826     R1798                         1
    X2827     R1637                         -19269
    X2827     R1798                         1
    X2828     R1638                         -19269
    X2828     R1798                         1
    X2829     R1639                         -19269
    X2829     R1798                         1
    X2830     R1640                         -19269
    X2830     R1798                         1
    X2831     R1641                         -19269
    X2831     R1798                         1
    X2832     R1642                         -19269
    X2832     R1798                         1
    X2833     R1643                         -19269
    X2833     R1798                         1
    X2834     R1644                         -19269
    X2834     R1798                         1
    X2835     R1645                         -19269
    X2835     R1798                         1
    X2836     R1646                         -19269
    X2836     R1798                         1
    X2837     R1647                         -19269
    X2837     R1798                         1
    X2838     R1648                         -19269
    X2838     R1798                         1
    X2839     R1649                         -19269
    X2839     R1798                         1
    X2840     R1650                         -19269
    X2840     R1798                         1
    X2841     R1651                         -19269
    X2841     R1798                         1
    X2842     R1652                         -19269
    X2842     R1798                         1
    X2843     R1653                         -19269
    X2843     R1798                         1
    X2844     R1654                         -19269
    X2844     R1798                         1
    X2845     R1655                         -19269
    X2845     R1798                         1
    X2846     R1656                         -19269
    X2846     R1798                         1
    X2847     R1657                         -19269
    X2847     R1798                         1
    X2848     R1658                         -19269
    X2848     R1798                         1
    X2849     R1659                         -19269
    X2849     R1798                         1
    X2850     R1660                         -19269
    X2850     R1798                         1
    X2851     R1661                         -19269
    X2851     R1798                         1
    X2852     R1662                         -19269
    X2852     R1798                         1
    X2853     R1663                         -19269
    X2853     R1798                         1
    X2854     R1664                         -19269
    X2854     R1798                         1
    X2855     R1665                         -19269
    X2855     R1798                         1
    X2856     R1666                         -19269
    X2856     R1798                         1
    X2857     R1667                         -19269
    X2857     R1798                         1
    X2858     R1668                         -19269
    X2858     R1798                         1
    X2859     R1669                         -19269
    X2859     R1798                         1
    X2860     R1670                         -19269
    X2860     R1798                         1
    X2861     R1671                         -19269
    X2861     R1798                         1
    X2862     R1672                         -19269
    X2862     R1798                         1
    X2863     R1673                         -19269
    X2863     R1798                         1
    X2864     R1674                         -19269
    X2864     R1798                         1
    X2865     R1675                         -19269
    X2865     R1798                         1
    X2866     R1676                         -20019
    X2866     R1799                         1
    X2867     R1677                         -20019
    X2867     R1799                         1
    X2868     R1678                         -20019
    X2868     R1799                         1
    X2869     R1679                         -20019
    X2869     R1799                         1
    X2870     R1680                         -20019
    X2870     R1799                         1
    X2871     R1681                         -20019
    X2871     R1799                         1
    X2872     R1682                         -20019
    X2872     R1799                         1
    X2873     R1683                         -20019
    X2873     R1799                         1
    X2874     R1684                         -20019
    X2874     R1799                         1
    X2875     R1685                         -20019
    X2875     R1799                         1
    X2876     R1686                         -20019
    X2876     R1799                         1
    X2877     R1687                         -20019
    X2877     R1799                         1
    X2878     R1688                         -20019
    X2878     R1799                         1
    X2879     R1689                         -20019
    X2879     R1799                         1
    X2880     R1690                         -20019
    X2880     R1799                         1
    X2881     R1691                         -20019
    X2881     R1799                         1
    X2882     R1692                         -20019
    X2882     R1799                         1
    X2883     R1693                         -20019
    X2883     R1799                         1
    X2884     R1694                         -20019
    X2884     R1799                         1
    X2885     R1695                         -20019
    X2885     R1799                         1
    X2886     R1696                         -20019
    X2886     R1799                         1
    X2887     R1697                         -20019
    X2887     R1799                         1
    X2888     R1698                         -20019
    X2888     R1799                         1
    X2889     R1699                         -20019
    X2889     R1799                         1
    X2890     R1700                         -20019
    X2890     R1799                         1
    X2891     R1701                         -20019
    X2891     R1799                         1
    X2892     R1702                         -20019
    X2892     R1799                         1
    X2893     R1703                         -20019
    X2893     R1799                         1
    X2894     R1704                         -20019
    X2894     R1799                         1
    X2895     R1705                         -20019
    X2895     R1799                         1
    X2896     R1706                         -20019
    X2896     R1799                         1
    X2897     R1707                         -20019
    X2897     R1799                         1
    X2898     R1708                         -20019
    X2898     R1799                         1
    X2899     R1709                         -20019
    X2899     R1799                         1
    X2900     R1710                         -20019
    X2900     R1799                         1
    X2901     R1711                         -20019
    X2901     R1799                         1
    X2902     R1712                         -20019
    X2902     R1799                         1
    X2903     R1713                         -20019
    X2903     R1799                         1
    X2904     R1714                         -20019
    X2904     R1799                         1
    X2905     R1715                         -20019
    X2905     R1799                         1
    X2906     R1716                         -20019
    X2906     R1799                         1
    X2907     R1717                         -20019
    X2907     R1799                         1
    X2908     R1718                         -20019
    X2908     R1799                         1
    X2909     R1719                         -20019
    X2909     R1799                         1
    X2910     R1720                         -20019
    X2910     R1799                         1
    X2911     R1721                         -20019
    X2911     R1799                         1
    X2912     R1722                         -20019
    X2912     R1799                         1
    X2913     R1723                         -20019
    X2913     R1799                         1
    X2914     R1724                         -20019
    X2914     R1799                         1
    X2915     R1725                         -20019
    X2915     R1799                         1
    X2916     R1726                         -20019
    X2916     R1799                         1
    X2917     R1727                         -20019
    X2917     R1799                         1
    X2918     R1728                         -20019
    X2918     R1799                         1
    X2919     R1729                         -20019
    X2919     R1799                         1
    X2920     R1730                         -20019
    X2920     R1799                         1
    X2921     R1731                         -20019
    X2921     R1799                         1
    X2922     R1732                         -20019
    X2922     R1799                         1
    X2923     R1733                         -20019
    X2923     R1799                         1
    X2924     R1734                         -20019
    X2924     R1799                         1
    X2925     R1735                         -20019
    X2925     R1799                         1
    X2926     R1736                         -20019
    X2926     R1799                         1
    X2927     R1737                         -20019
    X2927     R1799                         1
    X2928     R1738                         -20019
    X2928     R1799                         1
    X2929     R1739                         -20019
    X2929     R1799                         1
    X2930     R1740                         -20019
    X2930     R1799                         1
    X2931     R1741                         -20019
    X2931     R1799                         1
    X2932     R1742                         -20019
    X2932     R1799                         1
    X2933     R1743                         -20019
    X2933     R1799                         1
    X2934     R1744                         -20019
    X2934     R1799                         1
    X2935     R1745                         -20019
    X2935     R1799                         1
    X2936     R1746                         -20019
    X2936     R1799                         1
    X2937     R1747                         -20019
    X2937     R1799                         1
    X2938     R1748                         -20019
    X2938     R1799                         1
    X2939     R1749                         -20019
    X2939     R1799                         1
    X2940     R1750                         -20019
    X2940     R1799                         1
    X2941     R1751                         -20019
    X2941     R1799                         1
    X2942     R1752                         -20019
    X2942     R1799                         1
    X2943     R1753                         -20019
    X2943     R1799                         1
    X2944     R1754                         -20019
    X2944     R1799                         1
    X2945     R1755                         -20019
    X2945     R1799                         1
    X2946     R1756                         -20019
    X2946     R1799                         1
    X2947     R1757                         -20019
    X2947     R1799                         1
    X2948     R1758                         -20019
    X2948     R1799                         1
    X2949     R1759                         -20019
    X2949     R1799                         1
    X2950     R1760                         -20019
    X2950     R1799                         1
    X2951     R1761                         -20019
    X2951     R1799                         1
    X2952     R1762                         -20019
    X2952     R1799                         1
    X2953     R1763                         -20019
    X2953     R1799                         1
    X2954     R1764                         -20019
    X2954     R1799                         1
    X2955     R1765                         -20019
    X2955     R1799                         1
    X2956     R1766                         -20019
    X2956     R1799                         1
    X2957     R1767                         -20019
    X2957     R1799                         1
    X2958     R1768                         -20019
    X2958     R1799                         1
    X2959     R1769                         -20019
    X2959     R1799                         1
    X2960     R1770                         -20019
    X2960     R1799                         1
    X2961     R1771                         -20019
    X2961     R1799                         1
    X2962     R1772                         -20019
    X2962     R1799                         1
    X2963     R1773                         -20019
    X2963     R1799                         1
    X2964     R1774                         -20019
    X2964     R1799                         1
    X2965     R1775                         -20019
    X2965     R1799                         1
    X2966     R1776                         -20019
    X2966     R1799                         1
    X2967     R1777                         -20019
    X2967     R1799                         1
    X2968     R1778                         -20019
    X2968     R1799                         1
    X2969     R1779                         -20019
    X2969     R1799                         1
    X2970     R1780                         -20019
    X2970     R1799                         1
    X2971     R1781                         -20019
    X2971     R1799                         1
    X2972     R1782                         -20019
    X2972     R1799                         1
    X2973     R1783                         -20019
    X2973     R1799                         1
    X2974     R1784                         -20019
    X2974     R1799                         1
    X2975     R1785                         -20019
    X2975     R1799                         1
    X2976     R1786                         -20019
    X2976     R1799                         1
    X2977     R1787                         -20019
    X2977     R1799                         1
    X2978     R1788                         -20019
    X2978     R1799                         1
    X2979     R1789                         -20019
    X2979     R1799                         1
    X2980     R1790                         -20019
    X2980     R1799                         1
    X2981     R1791                         -20019
    X2981     R1799                         1
    X2982     R1792                         -20019
    X2982     R1799                         1
    X2983     R1793                         -20019
    X2983     R1799                         1
    X2984     R1794                         -20019
    X2984     R1799                         1
RHS
    RHS       R0                            163
    RHS       R1                            144
    RHS       R2                            126
    RHS       R3                            196
    RHS       R4                            104
    RHS       R5                            201
    RHS       R6                            148
    RHS       R7                            274
    RHS       R8                            187
    RHS       R9                            21
    RHS       R10                           179
    RHS       R11                           207
    RHS       R12                           52
    RHS       R13                           207
    RHS       R14                           80
    RHS       R15                           282
    RHS       R16                           275
    RHS       R17                           234
    RHS       R18                           137
    RHS       R19                           77
    RHS       R20                           50
    RHS       R21                           155
    RHS       R22                           262
    RHS       R23                           23
    RHS       R24                           154
    RHS       R25                           233
    RHS       R26                           19
    RHS       R27                           17
    RHS       R28                           116
    RHS       R29                           167
    RHS       R30                           18
    RHS       R31                           131
    RHS       R32                           125
    RHS       R33                           222
    RHS       R34                           245
    RHS       R35                           251
    RHS       R36                           15
    RHS       R37                           38
    RHS       R38                           206
    RHS       R39                           237
    RHS       R40                           268
    RHS       R41                           293
    RHS       R42                           167
    RHS       R43                           141
    RHS       R44                           128
    RHS       R45                           165
    RHS       R46                           154
    RHS       R47                           216
    RHS       R48                           143
    RHS       R49                           290
    RHS       R50                           184
    RHS       R51                           262
    RHS       R52                           238
    RHS       R53                           61
    RHS       R54                           195
    RHS       R55                           142
    RHS       R56                           287
    RHS       R57                           167
    RHS       R58                           276
    RHS       R59                           27
    RHS       R60                           28
    RHS       R61                           241
    RHS       R62                           218
    RHS       R63                           147
    RHS       R64                           220
    RHS       R65                           140
    RHS       R66                           41
    RHS       R67                           107
    RHS       R68                           244
    RHS       R69                           259
    RHS       R70                           97
    RHS       R71                           40
    RHS       R72                           199
    RHS       R73                           264
    RHS       R74                           186
    RHS       R75                           100
    RHS       R76                           56
    RHS       R77                           262
    RHS       R78                           73
    RHS       R79                           53
    RHS       R80                           119
    RHS       R81                           31
    RHS       R82                           262
    RHS       R83                           239
    RHS       R84                           145
    RHS       R85                           167
    RHS       R86                           132
    RHS       R87                           77
    RHS       R88                           57
    RHS       R89                           83
    RHS       R90                           264
    RHS       R91                           66
    RHS       R92                           248
    RHS       R93                           190
    RHS       R94                           108
    RHS       R95                           76
    RHS       R96                           61
    RHS       R97                           115
    RHS       R98                           182
    RHS       R99                           105
    RHS       R100                          248
    RHS       R101                          159
    RHS       R102                          256
    RHS       R103                          55
    RHS       R104                          49
    RHS       R105                          148
    RHS       R106                          39
    RHS       R107                          180
    RHS       R108                          61
    RHS       R109                          61
    RHS       R110                          107
    RHS       R111                          90
    RHS       R112                          177
    RHS       R113                          234
    RHS       R114                          147
    RHS       R115                          283
    RHS       R116                          14
    RHS       R117                          244
    RHS       R118                          150
    RHS       R119                          112
    RHS       R120                          84
    RHS       R121                          145
    RHS       R122                          221
    RHS       R123                          87
    RHS       R124                          21
    RHS       R125                          108
    RHS       R126                          229
    RHS       R127                          85
    RHS       R128                          118
    RHS       R129                          44
    RHS       R130                          119
    RHS       R131                          254
    RHS       R132                          254
    RHS       R133                          240
    RHS       R134                          215
    RHS       R135                          126
    RHS       R136                          200
    RHS       R137                          56
    RHS       R138                          115
    RHS       R139                          48
    RHS       R140                          23
    RHS       R141                          290
    RHS       R142                          180
    RHS       R143                          209
    RHS       R144                          154
    RHS       R145                          187
    RHS       R146                          148
    RHS       R147                          58
    RHS       R148                          31
    RHS       R149                          13
    RHS       R150                          261
    RHS       R151                          284
    RHS       R152                          204
    RHS       R153                          94
    RHS       R154                          159
    RHS       R155                          30
    RHS       R156                          223
    RHS       R157                          266
    RHS       R158                          204
    RHS       R159                          27
    RHS       R160                          108
    RHS       R161                          13
    RHS       R162                          225
    RHS       R163                          196
    RHS       R164                          279
    RHS       R165                          226
    RHS       R166                          79
    RHS       R167                          76
    RHS       R168                          119
    RHS       R169                          168
    RHS       R170                          148
    RHS       R171                          10
    RHS       R172                          39
    RHS       R173                          226
    RHS       R174                          265
    RHS       R175                          36
    RHS       R176                          62
    RHS       R177                          123
    RHS       R178                          248
    RHS       R179                          202
    RHS       R180                          104
    RHS       R181                          249
    RHS       R182                          28
    RHS       R183                          202
    RHS       R184                          165
    RHS       R185                          174
    RHS       R186                          258
    RHS       R187                          192
    RHS       R188                          38
    RHS       R189                          128
    RHS       R190                          182
    RHS       R191                          86
    RHS       R192                          70
    RHS       R193                          14
    RHS       R194                          253
    RHS       R195                          98
    RHS       R196                          86
    RHS       R197                          60
    RHS       R198                          26
    RHS       R199                          289
    RHS       R200                          98
    RHS       R201                          104
    RHS       R202                          79
    RHS       R203                          107
    RHS       R204                          181
    RHS       R205                          88
    RHS       R206                          273
    RHS       R207                          54
    RHS       R208                          182
    RHS       R209                          251
    RHS       R210                          178
    RHS       R211                          222
    RHS       R212                          293
    RHS       R213                          185
    RHS       R214                          288
    RHS       R215                          101
    RHS       R216                          100
    RHS       R217                          111
    RHS       R218                          160
    RHS       R219                          230
    RHS       R220                          92
    RHS       R221                          50
    RHS       R222                          45
    RHS       R223                          33
    RHS       R224                          60
    RHS       R225                          29
    RHS       R226                          173
    RHS       R227                          178
    RHS       R228                          84
    RHS       R229                          103
    RHS       R230                          187
    RHS       R231                          45
    RHS       R232                          173
    RHS       R233                          107
    RHS       R234                          113
    RHS       R235                          171
    RHS       R236                          35
    RHS       R237                          18
    RHS       R238                          18
    RHS       R239                          168
    RHS       R240                          68
    RHS       R241                          141
    RHS       R242                          156
    RHS       R243                          219
    RHS       R244                          153
    RHS       R245                          213
    RHS       R246                          16
    RHS       R247                          229
    RHS       R248                          204
    RHS       R249                          183
    RHS       R250                          90
    RHS       R251                          251
    RHS       R252                          141
    RHS       R253                          157
    RHS       R254                          129
    RHS       R255                          293
    RHS       R256                          207
    RHS       R257                          171
    RHS       R258                          215
    RHS       R259                          295
    RHS       R260                          277
    RHS       R261                          236
    RHS       R262                          296
    RHS       R263                          275
    RHS       R264                          274
    RHS       R265                          271
    RHS       R266                          281
    RHS       R267                          227
    RHS       R268                          57
    RHS       R269                          295
    RHS       R270                          121
    RHS       R271                          87
    RHS       R272                          240
    RHS       R273                          220
    RHS       R274                          241
    RHS       R275                          89
    RHS       R276                          176
    RHS       R277                          10
    RHS       R278                          219
    RHS       R279                          298
    RHS       R280                          195
    RHS       R281                          51
    RHS       R282                          299
    RHS       R283                          246
    RHS       R284                          30
    RHS       R285                          157
    RHS       R286                          281
    RHS       R287                          192
    RHS       R288                          268
    RHS       R289                          47
    RHS       R290                          123
    RHS       R291                          198
    RHS       R292                          140
    RHS       R293                          207
    RHS       R294                          292
    RHS       R295                          13
    RHS       R296                          153
    RHS       R297                          128
    RHS       R298                          64
    RHS       R299                          108
    RHS       R300                          99
    RHS       R301                          170
    RHS       R302                          91
    RHS       R303                          73
    RHS       R304                          176
    RHS       R305                          143
    RHS       R306                          49
    RHS       R307                          238
    RHS       R308                          121
    RHS       R309                          222
    RHS       R310                          76
    RHS       R311                          182
    RHS       R312                          294
    RHS       R313                          267
    RHS       R314                          291
    RHS       R315                          174
    RHS       R316                          139
    RHS       R317                          96
    RHS       R318                          147
    RHS       R319                          42
    RHS       R320                          116
    RHS       R321                          208
    RHS       R322                          206
    RHS       R323                          131
    RHS       R324                          39
    RHS       R325                          42
    RHS       R326                          113
    RHS       R327                          162
    RHS       R328                          257
    RHS       R329                          52
    RHS       R330                          122
    RHS       R331                          298
    RHS       R332                          39
    RHS       R333                          260
    RHS       R334                          240
    RHS       R335                          15
    RHS       R336                          143
    RHS       R337                          145
    RHS       R338                          289
    RHS       R339                          52
    RHS       R340                          20
    RHS       R341                          160
    RHS       R342                          109
    RHS       R343                          96
    RHS       R344                          253
    RHS       R345                          89
    RHS       R346                          160
    RHS       R347                          114
    RHS       R348                          163
    RHS       R349                          34
    RHS       R350                          119
    RHS       R351                          110
    RHS       R352                          19
    RHS       R353                          200
    RHS       R354                          156
    RHS       R355                          70
    RHS       R356                          93
    RHS       R357                          244
    RHS       R358                          153
    RHS       R359                          92
    RHS       R360                          69
    RHS       R361                          122
    RHS       R362                          40
    RHS       R363                          241
    RHS       R364                          192
    RHS       R365                          75
    RHS       R366                          200
    RHS       R367                          25
    RHS       R368                          205
    RHS       R369                          135
    RHS       R370                          298
    RHS       R371                          207
    RHS       R372                          106
    RHS       R373                          207
    RHS       R374                          207
    RHS       R375                          269
    RHS       R376                          192
    RHS       R377                          296
    RHS       R378                          246
    RHS       R379                          208
    RHS       R380                          285
    RHS       R381                          75
    RHS       R382                          21
    RHS       R383                          237
    RHS       R384                          116
    RHS       R385                          163
    RHS       R386                          250
    RHS       R387                          179
    RHS       R388                          279
    RHS       R389                          28
    RHS       R390                          43
    RHS       R391                          106
    RHS       R392                          283
    RHS       R393                          216
    RHS       R394                          199
    RHS       R395                          197
    RHS       R396                          50
    RHS       R397                          266
    RHS       R398                          118
    RHS       R399                          248
    RHS       R400                          174
    RHS       R401                          34
    RHS       R402                          17
    RHS       R403                          130
    RHS       R404                          220
    RHS       R405                          235
    RHS       R406                          40
    RHS       R407                          116
    RHS       R408                          57
    RHS       R409                          274
    RHS       R410                          299
    RHS       R411                          86
    RHS       R412                          104
    RHS       R413                          181
    RHS       R414                          203
    RHS       R415                          111
    RHS       R416                          259
    RHS       R417                          187
    RHS       R418                          18
    RHS       R419                          191
    RHS       R420                          32
    RHS       R421                          273
    RHS       R422                          121
    RHS       R423                          207
    RHS       R424                          126
    RHS       R425                          186
    RHS       R426                          247
    RHS       R427                          276
    RHS       R428                          297
    RHS       R429                          299
    RHS       R430                          182
    RHS       R431                          151
    RHS       R432                          212
    RHS       R433                          175
    RHS       R434                          280
    RHS       R435                          159
    RHS       R436                          175
    RHS       R437                          133
    RHS       R438                          129
    RHS       R439                          85
    RHS       R440                          24
    RHS       R441                          107
    RHS       R442                          154
    RHS       R443                          113
    RHS       R444                          237
    RHS       R445                          66
    RHS       R446                          85
    RHS       R447                          197
    RHS       R448                          217
    RHS       R449                          26
    RHS       R450                          171
    RHS       R451                          18
    RHS       R452                          229
    RHS       R453                          169
    RHS       R454                          74
    RHS       R455                          103
    RHS       R456                          260
    RHS       R457                          95
    RHS       R458                          249
    RHS       R459                          121
    RHS       R460                          240
    RHS       R461                          267
    RHS       R462                          223
    RHS       R463                          210
    RHS       R464                          51
    RHS       R465                          42
    RHS       R466                          289
    RHS       R467                          18
    RHS       R468                          181
    RHS       R469                          109
    RHS       R470                          88
    RHS       R471                          102
    RHS       R472                          103
    RHS       R473                          133
    RHS       R474                          191
    RHS       R475                          92
    RHS       R476                          234
    RHS       R477                          20
    RHS       R478                          262
    RHS       R479                          119
    RHS       R480                          237
    RHS       R481                          48
    RHS       R482                          253
    RHS       R483                          137
    RHS       R484                          32
    RHS       R485                          21
    RHS       R486                          252
    RHS       R487                          147
    RHS       R488                          254
    RHS       R489                          241
    RHS       R490                          165
    RHS       R491                          117
    RHS       R492                          253
    RHS       R493                          159
    RHS       R494                          259
    RHS       R495                          192
    RHS       R496                          35
    RHS       R497                          271
    RHS       R498                          89
    RHS       R499                          258
    RHS       R500                          190
    RHS       R501                          195
    RHS       R502                          124
    RHS       R503                          115
    RHS       R504                          106
    RHS       R505                          274
    RHS       R506                          133
    RHS       R507                          76
    RHS       R508                          40
    RHS       R509                          76
    RHS       R510                          37
    RHS       R511                          27
    RHS       R512                          238
    RHS       R513                          223
    RHS       R514                          138
    RHS       R515                          28
    RHS       R516                          182
    RHS       R517                          67
    RHS       R518                          172
    RHS       R519                          34
    RHS       R520                          174
    RHS       R521                          96
    RHS       R522                          283
    RHS       R523                          55
    RHS       R524                          235
    RHS       R525                          79
    RHS       R526                          236
    RHS       R527                          116
    RHS       R528                          197
    RHS       R529                          80
    RHS       R530                          208
    RHS       R531                          291
    RHS       R532                          179
    RHS       R533                          123
    RHS       R534                          298
    RHS       R535                          131
    RHS       R536                          267
    RHS       R537                          27
    RHS       R538                          227
    RHS       R539                          80
    RHS       R540                          78
    RHS       R541                          115
    RHS       R542                          247
    RHS       R543                          285
    RHS       R544                          228
    RHS       R545                          61
    RHS       R546                          144
    RHS       R547                          156
    RHS       R548                          270
    RHS       R549                          240
    RHS       R550                          269
    RHS       R551                          183
    RHS       R552                          231
    RHS       R553                          214
    RHS       R554                          258
    RHS       R555                          200
    RHS       R556                          161
    RHS       R557                          237
    RHS       R558                          142
    RHS       R559                          127
    RHS       R560                          279
    RHS       R561                          284
    RHS       R562                          222
    RHS       R563                          268
    RHS       R564                          217
    RHS       R565                          131
    RHS       R566                          140
    RHS       R567                          36
    RHS       R568                          195
    RHS       R569                          266
    RHS       R570                          190
    RHS       R571                          176
    RHS       R572                          249
    RHS       R573                          43
    RHS       R574                          72
    RHS       R575                          81
    RHS       R576                          216
    RHS       R577                          63
    RHS       R578                          65
    RHS       R579                          266
    RHS       R580                          154
    RHS       R581                          291
    RHS       R582                          251
    RHS       R583                          285
    RHS       R584                          202
    RHS       R585                          151
    RHS       R586                          269
    RHS       R587                          103
    RHS       R588                          131
    RHS       R589                          152
    RHS       R590                          180
    RHS       R591                          153
    RHS       R592                          121
    RHS       R593                          294
    RHS       R594                          281
    RHS       R595                          129
    RHS       R596                          27
    RHS       R597                          114
    RHS       R598                          79
    RHS       R599                          70
    RHS       R1795                         12
    RHS       R1796                         12
    RHS       R1797                         12
    RHS       R1798                         12
    RHS       R1799                         12
    RHS       R1800                         1
    RHS       R1801                         1
    RHS       R1802                         1
    RHS       R1803                         1
    RHS       R1804                         1
    RHS       R1805                         1
    RHS       R1806                         1
    RHS       R1807                         1
    RHS       R1808                         1
    RHS       R1809                         1
    RHS       R1810                         1
    RHS       R1811                         1
    RHS       R1812                         1
    RHS       R1813                         1
    RHS       R1814                         1
    RHS       R1815                         1
    RHS       R1816                         1
    RHS       R1817                         1
    RHS       R1818                         1
    RHS       R1819                         1
    RHS       R1820                         1
    RHS       R1821                         1
    RHS       R1822                         1
    RHS       R1823                         1
    RHS       R1824                         1
    RHS       R1825                         1
    RHS       R1826                         1
    RHS       R1827                         1
    RHS       R1828                         1
    RHS       R1829                         1
    RHS       R1830                         1
    RHS       R1831                         1
    RHS       R1832                         1
    RHS       R1833                         1
    RHS       R1834                         1
    RHS       R1835                         1
    RHS       R1836                         1
    RHS       R1837                         1
    RHS       R1838                         1
    RHS       R1839                         1
    RHS       R1840                         1
    RHS       R1841                         1
    RHS       R1842                         1
    RHS       R1843                         1
    RHS       R1844                         1
    RHS       R1845                         1
    RHS       R1846                         1
    RHS       R1847                         1
    RHS       R1848                         1
    RHS       R1849                         1
    RHS       R1850                         1
    RHS       R1851                         1
    RHS       R1852                         1
    RHS       R1853                         1
    RHS       R1854                         1
    RHS       R1855                         1
    RHS       R1856                         1
    RHS       R1857                         1
    RHS       R1858                         1
    RHS       R1859                         1
    RHS       R1860                         1
    RHS       R1861                         1
    RHS       R1862                         1
    RHS       R1863                         1
    RHS       R1864                         1
    RHS       R1865                         1
    RHS       R1866                         1
    RHS       R1867                         1
    RHS       R1868                         1
    RHS       R1869                         1
    RHS       R1870                         1
    RHS       R1871                         1
    RHS       R1872                         1
    RHS       R1873                         1
    RHS       R1874                         1
    RHS       R1875                         1
    RHS       R1876                         1
    RHS       R1877                         1
    RHS       R1878                         1
    RHS       R1879                         1
    RHS       R1880                         1
    RHS       R1881                         1
    RHS       R1882                         1
    RHS       R1883                         1
    RHS       R1884                         1
    RHS       R1885                         1
    RHS       R1886                         1
    RHS       R1887                         1
    RHS       R1888                         1
    RHS       R1889                         1
    RHS       R1890                         1
    RHS       R1891                         1
    RHS       R1892                         1
    RHS       R1893                         1
    RHS       R1894                         1
    RHS       R1895                         1
    RHS       R1896                         1
    RHS       R1897                         1
    RHS       R1898                         1
    RHS       R1899                         1
    RHS       R1900                         1
    RHS       R1901                         1
    RHS       R1902                         1
    RHS       R1903                         1
    RHS       R1904                         1
    RHS       R1905                         1
    RHS       R1906                         1
    RHS       R1907                         1
    RHS       R1908                         1
    RHS       R1909                         1
    RHS       R1910                         1
    RHS       R1911                         1
    RHS       R1912                         1
    RHS       R1913                         1
    RHS       R1914                         1
    RHS       R1915                         1
    RHS       R1916                         1
    RHS       R1917                         1
    RHS       R1918                         1
    RHS       R1919                         1
BOUNDS
 UP BND       X1790                         1
 UP BND       X1791                         1
 UP BND       X1792                         1
 UP BND       X1793                         1
 UP BND       X1794                         1
 UP BND       X1795                         1
 UP BND       X1796                         1
 UP BND       X1797                         1
 UP BND       X1798                         1
 UP BND       X1799                         1
 UP BND       X1800                         1
 UP BND       X1801                         1
 UP BND       X1802                         1
 UP BND       X1803                         1
 UP BND       X1804                         1
 UP BND       X1805                         1
 UP BND       X1806                         1
 UP BND       X1807                         1
 UP BND       X1808                         1
 UP BND       X1809                         1
 UP BND       X1810                         1
 UP BND       X1811                         1
 UP BND       X1812                         1
 UP BND       X1813                         1
 UP BND       X1814                         1
 UP BND       X1815                         1
 UP BND       X1816                         1
 UP BND       X1817                         1
 UP BND       X1818                         1
 UP BND       X1819                         1
 UP BND       X1820                         1
 UP BND       X1821                         1
 UP BND       X1822                         1
 UP BND       X1823                         1
 UP BND       X1824                         1
 UP BND       X1825                         1
 UP BND       X1826                         1
 UP BND       X1827                         1
 UP BND       X1828                         1
 UP BND       X1829                         1
 UP BND       X1830                         1
 UP BND       X1831                         1
 UP BND       X1832                         1
 UP BND       X1833                         1
 UP BND       X1834                         1
 UP BND       X1835                         1
 UP BND       X1836                         1
 UP BND       X1837                         1
 UP BND       X1838                         1
 UP BND       X1839                         1
 UP BND       X1840                         1
 UP BND       X1841                         1
 UP BND       X1842                         1
 UP BND       X1843                         1
 UP BND       X1844                         1
 UP BND       X1845                         1
 UP BND       X1846                         1
 UP BND       X1847                         1
 UP BND       X1848                         1
 UP BND       X1849                         1
 UP BND       X1850                         1
 UP BND       X1851                         1
 UP BND       X1852                         1
 UP BND       X1853                         1
 UP BND       X1854                         1
 UP BND       X1855                         1
 UP BND       X1856                         1
 UP BND       X1857                         1
 UP BND       X1858                         1
 UP BND       X1859                         1
 UP BND       X1860                         1
 UP BND       X1861                         1
 UP BND       X1862                         1
 UP BND       X1863                         1
 UP BND       X1864                         1
 UP BND       X1865                         1
 UP BND       X1866                         1
 UP BND       X1867                         1
 UP BND       X1868                         1
 UP BND       X1869                         1
 UP BND       X1870                         1
 UP BND       X1871                         1
 UP BND       X1872                         1
 UP BND       X1873                         1
 UP BND       X1874                         1
 UP BND       X1875                         1
 UP BND       X1876                         1
 UP BND       X1877                         1
 UP BND       X1878                         1
 UP BND       X1879                         1
 UP BND       X1880                         1
 UP BND       X1881                         1
 UP BND       X1882                         1
 UP BND       X1883                         1
 UP BND       X1884                         1
 UP BND       X1885                         1
 UP BND       X1886                         1
 UP BND       X1887                         1
 UP BND       X1888                         1
 UP BND       X1889                         1
 UP BND       X1890                         1
 UP BND       X1891                         1
 UP BND       X1892                         1
 UP BND       X1893                         1
 UP BND       X1894                         1
 UP BND       X1895                         1
 UP BND       X1896                         1
 UP BND       X1897                         1
 UP BND       X1898                         1
 UP BND       X1899                         1
 UP BND       X1900                         1
 UP BND       X1901                         1
 UP BND       X1902                         1
 UP BND       X1903                         1
 UP BND       X1904                         1
 UP BND       X1905                         1
 UP BND       X1906                         1
 UP BND       X1907                         1
 UP BND       X1908                         1
 UP BND       X1909                         1
 UP BND       X1910                         1
 UP BND       X1911                         1
 UP BND       X1912                         1
 UP BND       X1913                         1
 UP BND       X1914                         1
 UP BND       X1915                         1
 UP BND       X1916                         1
 UP BND       X1917                         1
 UP BND       X1918                         1
 UP BND       X1919                         1
 UP BND       X1920                         1
 UP BND       X1921                         1
 UP BND       X1922                         1
 UP BND       X1923                         1
 UP BND       X1924                         1
 UP BND       X1925                         1
 UP BND       X1926                         1
 UP BND       X1927                         1
 UP BND       X1928                         1
 UP BND       X1929                         1
 UP BND       X1930                         1
 UP BND       X1931                         1
 UP BND       X1932                         1
 UP BND       X1933                         1
 UP BND       X1934                         1
 UP BND       X1935                         1
 UP BND       X1936                         1
 UP BND       X1937                         1
 UP BND       X1938                         1
 UP BND       X1939                         1
 UP BND       X1940                         1
 UP BND       X1941                         1
 UP BND       X1942                         1
 UP BND       X1943                         1
 UP BND       X1944                         1
 UP BND       X1945                         1
 UP BND       X1946                         1
 UP BND       X1947                         1
 UP BND       X1948                         1
 UP BND       X1949                         1
 UP BND       X1950                         1
 UP BND       X1951                         1
 UP BND       X1952                         1
 UP BND       X1953                         1
 UP BND       X1954                         1
 UP BND       X1955                         1
 UP BND       X1956                         1
 UP BND       X1957                         1
 UP BND       X1958                         1
 UP BND       X1959                         1
 UP BND       X1960                         1
 UP BND       X1961                         1
 UP BND       X1962                         1
 UP BND       X1963                         1
 UP BND       X1964                         1
 UP BND       X1965                         1
 UP BND       X1966                         1
 UP BND       X1967                         1
 UP BND       X1968                         1
 UP BND       X1969                         1
 UP BND       X1970                         1
 UP BND       X1971                         1
 UP BND       X1972                         1
 UP BND       X1973                         1
 UP BND       X1974                         1
 UP BND       X1975                         1
 UP BND       X1976                         1
 UP BND       X1977                         1
 UP BND       X1978                         1
 UP BND       X1979                         1
 UP BND       X1980                         1
 UP BND       X1981                         1
 UP BND       X1982                         1
 UP BND       X1983                         1
 UP BND       X1984                         1
 UP BND       X1985                         1
 UP BND       X1986                         1
 UP BND       X1987                         1
 UP BND       X1988                         1
 UP BND       X1989                         1
 UP BND       X1990                         1
 UP BND       X1991                         1
 UP BND       X1992                         1
 UP BND       X1993                         1
 UP BND       X1994                         1
 UP BND       X1995                         1
 UP BND       X1996                         1
 UP BND       X1997                         1
 UP BND       X1998                         1
 UP BND       X1999                         1
 UP BND       X2000                         1
 UP BND       X2001                         1
 UP BND       X2002                         1
 UP BND       X2003                         1
 UP BND       X2004                         1
 UP BND       X2005                         1
 UP BND       X2006                         1
 UP BND       X2007                         1
 UP BND       X2008                         1
 UP BND       X2009                         1
 UP BND       X2010                         1
 UP BND       X2011                         1
 UP BND       X2012                         1
 UP BND       X2013                         1
 UP BND       X2014                         1
 UP BND       X2015                         1
 UP BND       X2016                         1
 UP BND       X2017                         1
 UP BND       X2018                         1
 UP BND       X2019                         1
 UP BND       X2020                         1
 UP BND       X2021                         1
 UP BND       X2022                         1
 UP BND       X2023                         1
 UP BND       X2024                         1
 UP BND       X2025                         1
 UP BND       X2026                         1
 UP BND       X2027                         1
 UP BND       X2028                         1
 UP BND       X2029                         1
 UP BND       X2030                         1
 UP BND       X2031                         1
 UP BND       X2032                         1
 UP BND       X2033                         1
 UP BND       X2034                         1
 UP BND       X2035                         1
 UP BND       X2036                         1
 UP BND       X2037                         1
 UP BND       X2038                         1
 UP BND       X2039                         1
 UP BND       X2040                         1
 UP BND       X2041                         1
 UP BND       X2042                         1
 UP BND       X2043                         1
 UP BND       X2044                         1
 UP BND       X2045                         1
 UP BND       X2046                         1
 UP BND       X2047                         1
 UP BND       X2048                         1
 UP BND       X2049                         1
 UP BND       X2050                         1
 UP BND       X2051                         1
 UP BND       X2052                         1
 UP BND       X2053                         1
 UP BND       X2054                         1
 UP BND       X2055                         1
 UP BND       X2056                         1
 UP BND       X2057                         1
 UP BND       X2058                         1
 UP BND       X2059                         1
 UP BND       X2060                         1
 UP BND       X2061                         1
 UP BND       X2062                         1
 UP BND       X2063                         1
 UP BND       X2064                         1
 UP BND       X2065                         1
 UP BND       X2066                         1
 UP BND       X2067                         1
 UP BND       X2068                         1
 UP BND       X2069                         1
 UP BND       X2070                         1
 UP BND       X2071                         1
 UP BND       X2072                         1
 UP BND       X2073                         1
 UP BND       X2074                         1
 UP BND       X2075                         1
 UP BND       X2076                         1
 UP BND       X2077                         1
 UP BND       X2078                         1
 UP BND       X2079                         1
 UP BND       X2080                         1
 UP BND       X2081                         1
 UP BND       X2082                         1
 UP BND       X2083                         1
 UP BND       X2084                         1
 UP BND       X2085                         1
 UP BND       X2086                         1
 UP BND       X2087                         1
 UP BND       X2088                         1
 UP BND       X2089                         1
 UP BND       X2090                         1
 UP BND       X2091                         1
 UP BND       X2092                         1
 UP BND       X2093                         1
 UP BND       X2094                         1
 UP BND       X2095                         1
 UP BND       X2096                         1
 UP BND       X2097                         1
 UP BND       X2098                         1
 UP BND       X2099                         1
 UP BND       X2100                         1
 UP BND       X2101                         1
 UP BND       X2102                         1
 UP BND       X2103                         1
 UP BND       X2104                         1
 UP BND       X2105                         1
 UP BND       X2106                         1
 UP BND       X2107                         1
 UP BND       X2108                         1
 UP BND       X2109                         1
 UP BND       X2110                         1
 UP BND       X2111                         1
 UP BND       X2112                         1
 UP BND       X2113                         1
 UP BND       X2114                         1
 UP BND       X2115                         1
 UP BND       X2116                         1
 UP BND       X2117                         1
 UP BND       X2118                         1
 UP BND       X2119                         1
 UP BND       X2120                         1
 UP BND       X2121                         1
 UP BND       X2122                         1
 UP BND       X2123                         1
 UP BND       X2124                         1
 UP BND       X2125                         1
 UP BND       X2126                         1
 UP BND       X2127                         1
 UP BND       X2128                         1
 UP BND       X2129                         1
 UP BND       X2130                         1
 UP BND       X2131                         1
 UP BND       X2132                         1
 UP BND       X2133                         1
 UP BND       X2134                         1
 UP BND       X2135                         1
 UP BND       X2136                         1
 UP BND       X2137                         1
 UP BND       X2138                         1
 UP BND       X2139                         1
 UP BND       X2140                         1
 UP BND       X2141                         1
 UP BND       X2142                         1
 UP BND       X2143                         1
 UP BND       X2144                         1
 UP BND       X2145                         1
 UP BND       X2146                         1
 UP BND       X2147                         1
 UP BND       X2148                         1
 UP BND       X2149                         1
 UP BND       X2150                         1
 UP BND       X2151                         1
 UP BND       X2152                         1
 UP BND       X2153                         1
 UP BND       X2154                         1
 UP BND       X2155                         1
 UP BND       X2156                         1
 UP BND       X2157                         1
 UP BND       X2158                         1
 UP BND       X2159                         1
 UP BND       X2160                         1
 UP BND       X2161                         1
 UP BND       X2162                         1
 UP BND       X2163                         1
 UP BND       X2164                         1
 UP BND       X2165                         1
 UP BND       X2166                         1
 UP BND       X2167                         1
 UP BND       X2168                         1
 UP BND       X2169                         1
 UP BND       X2170                         1
 UP BND       X2171                         1
 UP BND       X2172                         1
 UP BND       X2173                         1
 UP BND       X2174                         1
 UP BND       X2175                         1
 UP BND       X2176                         1
 UP BND       X2177                         1
 UP BND       X2178                         1
 UP BND       X2179                         1
 UP BND       X2180                         1
 UP BND       X2181                         1
 UP BND       X2182                         1
 UP BND       X2183                         1
 UP BND       X2184                         1
 UP BND       X2185                         1
 UP BND       X2186                         1
 UP BND       X2187                         1
 UP BND       X2188                         1
 UP BND       X2189                         1
 UP BND       X2190                         1
 UP BND       X2191                         1
 UP BND       X2192                         1
 UP BND       X2193                         1
 UP BND       X2194                         1
 UP BND       X2195                         1
 UP BND       X2196                         1
 UP BND       X2197                         1
 UP BND       X2198                         1
 UP BND       X2199                         1
 UP BND       X2200                         1
 UP BND       X2201                         1
 UP BND       X2202                         1
 UP BND       X2203                         1
 UP BND       X2204                         1
 UP BND       X2205                         1
 UP BND       X2206                         1
 UP BND       X2207                         1
 UP BND       X2208                         1
 UP BND       X2209                         1
 UP BND       X2210                         1
 UP BND       X2211                         1
 UP BND       X2212                         1
 UP BND       X2213                         1
 UP BND       X2214                         1
 UP BND       X2215                         1
 UP BND       X2216                         1
 UP BND       X2217                         1
 UP BND       X2218                         1
 UP BND       X2219                         1
 UP BND       X2220                         1
 UP BND       X2221                         1
 UP BND       X2222                         1
 UP BND       X2223                         1
 UP BND       X2224                         1
 UP BND       X2225                         1
 UP BND       X2226                         1
 UP BND       X2227                         1
 UP BND       X2228                         1
 UP BND       X2229                         1
 UP BND       X2230                         1
 UP BND       X2231                         1
 UP BND       X2232                         1
 UP BND       X2233                         1
 UP BND       X2234                         1
 UP BND       X2235                         1
 UP BND       X2236                         1
 UP BND       X2237                         1
 UP BND       X2238                         1
 UP BND       X2239                         1
 UP BND       X2240                         1
 UP BND       X2241                         1
 UP BND       X2242                         1
 UP BND       X2243                         1
 UP BND       X2244                         1
 UP BND       X2245                         1
 UP BND       X2246                         1
 UP BND       X2247                         1
 UP BND       X2248                         1
 UP BND       X2249                         1
 UP BND       X2250                         1
 UP BND       X2251                         1
 UP BND       X2252                         1
 UP BND       X2253                         1
 UP BND       X2254                         1
 UP BND       X2255                         1
 UP BND       X2256                         1
 UP BND       X2257                         1
 UP BND       X2258                         1
 UP BND       X2259                         1
 UP BND       X2260                         1
 UP BND       X2261                         1
 UP BND       X2262                         1
 UP BND       X2263                         1
 UP BND       X2264                         1
 UP BND       X2265                         1
 UP BND       X2266                         1
 UP BND       X2267                         1
 UP BND       X2268                         1
 UP BND       X2269                         1
 UP BND       X2270                         1
 UP BND       X2271                         1
 UP BND       X2272                         1
 UP BND       X2273                         1
 UP BND       X2274                         1
 UP BND       X2275                         1
 UP BND       X2276                         1
 UP BND       X2277                         1
 UP BND       X2278                         1
 UP BND       X2279                         1
 UP BND       X2280                         1
 UP BND       X2281                         1
 UP BND       X2282                         1
 UP BND       X2283                         1
 UP BND       X2284                         1
 UP BND       X2285                         1
 UP BND       X2286                         1
 UP BND       X2287                         1
 UP BND       X2288                         1
 UP BND       X2289                         1
 UP BND       X2290                         1
 UP BND       X2291                         1
 UP BND       X2292                         1
 UP BND       X2293                         1
 UP BND       X2294                         1
 UP BND       X2295                         1
 UP BND       X2296                         1
 UP BND       X2297                         1
 UP BND       X2298                         1
 UP BND       X2299                         1
 UP BND       X2300                         1
 UP BND       X2301                         1
 UP BND       X2302                         1
 UP BND       X2303                         1
 UP BND       X2304                         1
 UP BND       X2305                         1
 UP BND       X2306                         1
 UP BND       X2307                         1
 UP BND       X2308                         1
 UP BND       X2309                         1
 UP BND       X2310                         1
 UP BND       X2311                         1
 UP BND       X2312                         1
 UP BND       X2313                         1
 UP BND       X2314                         1
 UP BND       X2315                         1
 UP BND       X2316                         1
 UP BND       X2317                         1
 UP BND       X2318                         1
 UP BND       X2319                         1
 UP BND       X2320                         1
 UP BND       X2321                         1
 UP BND       X2322                         1
 UP BND       X2323                         1
 UP BND       X2324                         1
 UP BND       X2325                         1
 UP BND       X2326                         1
 UP BND       X2327                         1
 UP BND       X2328                         1
 UP BND       X2329                         1
 UP BND       X2330                         1
 UP BND       X2331                         1
 UP BND       X2332                         1
 UP BND       X2333                         1
 UP BND       X2334                         1
 UP BND       X2335                         1
 UP BND       X2336                         1
 UP BND       X2337                         1
 UP BND       X2338                         1
 UP BND       X2339                         1
 UP BND       X2340                         1
 UP BND       X2341                         1
 UP BND       X2342                         1
 UP BND       X2343                         1
 UP BND       X2344                         1
 UP BND       X2345                         1
 UP BND       X2346                         1
 UP BND       X2347                         1
 UP BND       X2348                         1
 UP BND       X2349                         1
 UP BND       X2350                         1
 UP BND       X2351                         1
 UP BND       X2352                         1
 UP BND       X2353                         1
 UP BND       X2354                         1
 UP BND       X2355                         1
 UP BND       X2356                         1
 UP BND       X2357                         1
 UP BND       X2358                         1
 UP BND       X2359                         1
 UP BND       X2360                         1
 UP BND       X2361                         1
 UP BND       X2362                         1
 UP BND       X2363                         1
 UP BND       X2364                         1
 UP BND       X2365                         1
 UP BND       X2366                         1
 UP BND       X2367                         1
 UP BND       X2368                         1
 UP BND       X2369                         1
 UP BND       X2370                         1
 UP BND       X2371                         1
 UP BND       X2372                         1
 UP BND       X2373                         1
 UP BND       X2374                         1
 UP BND       X2375                         1
 UP BND       X2376                         1
 UP BND       X2377                         1
 UP BND       X2378                         1
 UP BND       X2379                         1
 UP BND       X2380                         1
 UP BND       X2381                         1
 UP BND       X2382                         1
 UP BND       X2383                         1
 UP BND       X2384                         1
 UP BND       X2385                         1
 UP BND       X2386                         1
 UP BND       X2387                         1
 UP BND       X2388                         1
 UP BND       X2389                         1
 UP BND       X2390                         1
 UP BND       X2391                         1
 UP BND       X2392                         1
 UP BND       X2393                         1
 UP BND       X2394                         1
 UP BND       X2395                         1
 UP BND       X2396                         1
 UP BND       X2397                         1
 UP BND       X2398                         1
 UP BND       X2399                         1
 UP BND       X2400                         1
 UP BND       X2401                         1
 UP BND       X2402                         1
 UP BND       X2403                         1
 UP BND       X2404                         1
 UP BND       X2405                         1
 UP BND       X2406                         1
 UP BND       X2407                         1
 UP BND       X2408                         1
 UP BND       X2409                         1
 UP BND       X2410                         1
 UP BND       X2411                         1
 UP BND       X2412                         1
 UP BND       X2413                         1
 UP BND       X2414                         1
 UP BND       X2415                         1
 UP BND       X2416                         1
 UP BND       X2417                         1
 UP BND       X2418                         1
 UP BND       X2419                         1
 UP BND       X2420                         1
 UP BND       X2421                         1
 UP BND       X2422                         1
 UP BND       X2423                         1
 UP BND       X2424                         1
 UP BND       X2425                         1
 UP BND       X2426                         1
 UP BND       X2427                         1
 UP BND       X2428                         1
 UP BND       X2429                         1
 UP BND       X2430                         1
 UP BND       X2431                         1
 UP BND       X2432                         1
 UP BND       X2433                         1
 UP BND       X2434                         1
 UP BND       X2435                         1
 UP BND       X2436                         1
 UP BND       X2437                         1
 UP BND       X2438                         1
 UP BND       X2439                         1
 UP BND       X2440                         1
 UP BND       X2441                         1
 UP BND       X2442                         1
 UP BND       X2443                         1
 UP BND       X2444                         1
 UP BND       X2445                         1
 UP BND       X2446                         1
 UP BND       X2447                         1
 UP BND       X2448                         1
 UP BND       X2449                         1
 UP BND       X2450                         1
 UP BND       X2451                         1
 UP BND       X2452                         1
 UP BND       X2453                         1
 UP BND       X2454                         1
 UP BND       X2455                         1
 UP BND       X2456                         1
 UP BND       X2457                         1
 UP BND       X2458                         1
 UP BND       X2459                         1
 UP BND       X2460                         1
 UP BND       X2461                         1
 UP BND       X2462                         1
 UP BND       X2463                         1
 UP BND       X2464                         1
 UP BND       X2465                         1
 UP BND       X2466                         1
 UP BND       X2467                         1
 UP BND       X2468                         1
 UP BND       X2469                         1
 UP BND       X2470                         1
 UP BND       X2471                         1
 UP BND       X2472                         1
 UP BND       X2473                         1
 UP BND       X2474                         1
 UP BND       X2475                         1
 UP BND       X2476                         1
 UP BND       X2477                         1
 UP BND       X2478                         1
 UP BND       X2479                         1
 UP BND       X2480                         1
 UP BND       X2481                         1
 UP BND       X2482                         1
 UP BND       X2483                         1
 UP BND       X2484                         1
 UP BND       X2485                         1
 UP BND       X2486                         1
 UP BND       X2487                         1
 UP BND       X2488                         1
 UP BND       X2489                         1
 UP BND       X2490                         1
 UP BND       X2491                         1
 UP BND       X2492                         1
 UP BND       X2493                         1
 UP BND       X2494                         1
 UP BND       X2495                         1
 UP BND       X2496                         1
 UP BND       X2497                         1
 UP BND       X2498                         1
 UP BND       X2499                         1
 UP BND       X2500                         1
 UP BND       X2501                         1
 UP BND       X2502                         1
 UP BND       X2503                         1
 UP BND       X2504                         1
 UP BND       X2505                         1
 UP BND       X2506                         1
 UP BND       X2507                         1
 UP BND       X2508                         1
 UP BND       X2509                         1
 UP BND       X2510                         1
 UP BND       X2511                         1
 UP BND       X2512                         1
 UP BND       X2513                         1
 UP BND       X2514                         1
 UP BND       X2515                         1
 UP BND       X2516                         1
 UP BND       X2517                         1
 UP BND       X2518                         1
 UP BND       X2519                         1
 UP BND       X2520                         1
 UP BND       X2521                         1
 UP BND       X2522                         1
 UP BND       X2523                         1
 UP BND       X2524                         1
 UP BND       X2525                         1
 UP BND       X2526                         1
 UP BND       X2527                         1
 UP BND       X2528                         1
 UP BND       X2529                         1
 UP BND       X2530                         1
 UP BND       X2531                         1
 UP BND       X2532                         1
 UP BND       X2533                         1
 UP BND       X2534                         1
 UP BND       X2535                         1
 UP BND       X2536                         1
 UP BND       X2537                         1
 UP BND       X2538                         1
 UP BND       X2539                         1
 UP BND       X2540                         1
 UP BND       X2541                         1
 UP BND       X2542                         1
 UP BND       X2543                         1
 UP BND       X2544                         1
 UP BND       X2545                         1
 UP BND       X2546                         1
 UP BND       X2547                         1
 UP BND       X2548                         1
 UP BND       X2549                         1
 UP BND       X2550                         1
 UP BND       X2551                         1
 UP BND       X2552                         1
 UP BND       X2553                         1
 UP BND       X2554                         1
 UP BND       X2555                         1
 UP BND       X2556                         1
 UP BND       X2557                         1
 UP BND       X2558                         1
 UP BND       X2559                         1
 UP BND       X2560                         1
 UP BND       X2561                         1
 UP BND       X2562                         1
 UP BND       X2563                         1
 UP BND       X2564                         1
 UP BND       X2565                         1
 UP BND       X2566                         1
 UP BND       X2567                         1
 UP BND       X2568                         1
 UP BND       X2569                         1
 UP BND       X2570                         1
 UP BND       X2571                         1
 UP BND       X2572                         1
 UP BND       X2573                         1
 UP BND       X2574                         1
 UP BND       X2575                         1
 UP BND       X2576                         1
 UP BND       X2577                         1
 UP BND       X2578                         1
 UP BND       X2579                         1
 UP BND       X2580                         1
 UP BND       X2581                         1
 UP BND       X2582                         1
 UP BND       X2583                         1
 UP BND       X2584                         1
 UP BND       X2585                         1
 UP BND       X2586                         1
 UP BND       X2587                         1
 UP BND       X2588                         1
 UP BND       X2589                         1
 UP BND       X2590                         1
 UP BND       X2591                         1
 UP BND       X2592                         1
 UP BND       X2593                         1
 UP BND       X2594                         1
 UP BND       X2595                         1
 UP BND       X2596                         1
 UP BND       X2597                         1
 UP BND       X2598                         1
 UP BND       X2599                         1
 UP BND       X2600                         1
 UP BND       X2601                         1
 UP BND       X2602                         1
 UP BND       X2603                         1
 UP BND       X2604                         1
 UP BND       X2605                         1
 UP BND       X2606                         1
 UP BND       X2607                         1
 UP BND       X2608                         1
 UP BND       X2609                         1
 UP BND       X2610                         1
 UP BND       X2611                         1
 UP BND       X2612                         1
 UP BND       X2613                         1
 UP BND       X2614                         1
 UP BND       X2615                         1
 UP BND       X2616                         1
 UP BND       X2617                         1
 UP BND       X2618                         1
 UP BND       X2619                         1
 UP BND       X2620                         1
 UP BND       X2621                         1
 UP BND       X2622                         1
 UP BND       X2623                         1
 UP BND       X2624                         1
 UP BND       X2625                         1
 UP BND       X2626                         1
 UP BND       X2627                         1
 UP BND       X2628                         1
 UP BND       X2629                         1
 UP BND       X2630                         1
 UP BND       X2631                         1
 UP BND       X2632                         1
 UP BND       X2633                         1
 UP BND       X2634                         1
 UP BND       X2635                         1
 UP BND       X2636                         1
 UP BND       X2637                         1
 UP BND       X2638                         1
 UP BND       X2639                         1
 UP BND       X2640                         1
 UP BND       X2641                         1
 UP BND       X2642                         1
 UP BND       X2643                         1
 UP BND       X2644                         1
 UP BND       X2645                         1
 UP BND       X2646                         1
 UP BND       X2647                         1
 UP BND       X2648                         1
 UP BND       X2649                         1
 UP BND       X2650                         1
 UP BND       X2651                         1
 UP BND       X2652                         1
 UP BND       X2653                         1
 UP BND       X2654                         1
 UP BND       X2655                         1
 UP BND       X2656                         1
 UP BND       X2657                         1
 UP BND       X2658                         1
 UP BND       X2659                         1
 UP BND       X2660                         1
 UP BND       X2661                         1
 UP BND       X2662                         1
 UP BND       X2663                         1
 UP BND       X2664                         1
 UP BND       X2665                         1
 UP BND       X2666                         1
 UP BND       X2667                         1
 UP BND       X2668                         1
 UP BND       X2669                         1
 UP BND       X2670                         1
 UP BND       X2671                         1
 UP BND       X2672                         1
 UP BND       X2673                         1
 UP BND       X2674                         1
 UP BND       X2675                         1
 UP BND       X2676                         1
 UP BND       X2677                         1
 UP BND       X2678                         1
 UP BND       X2679                         1
 UP BND       X2680                         1
 UP BND       X2681                         1
 UP BND       X2682                         1
 UP BND       X2683                         1
 UP BND       X2684                         1
 UP BND       X2685                         1
 UP BND       X2686                         1
 UP BND       X2687                         1
 UP BND       X2688                         1
 UP BND       X2689                         1
 UP BND       X2690                         1
 UP BND       X2691                         1
 UP BND       X2692                         1
 UP BND       X2693                         1
 UP BND       X2694                         1
 UP BND       X2695                         1
 UP BND       X2696                         1
 UP BND       X2697                         1
 UP BND       X2698                         1
 UP BND       X2699                         1
 UP BND       X2700                         1
 UP BND       X2701                         1
 UP BND       X2702                         1
 UP BND       X2703                         1
 UP BND       X2704                         1
 UP BND       X2705                         1
 UP BND       X2706                         1
 UP BND       X2707                         1
 UP BND       X2708                         1
 UP BND       X2709                         1
 UP BND       X2710                         1
 UP BND       X2711                         1
 UP BND       X2712                         1
 UP BND       X2713                         1
 UP BND       X2714                         1
 UP BND       X2715                         1
 UP BND       X2716                         1
 UP BND       X2717                         1
 UP BND       X2718                         1
 UP BND       X2719                         1
 UP BND       X2720                         1
 UP BND       X2721                         1
 UP BND       X2722                         1
 UP BND       X2723                         1
 UP BND       X2724                         1
 UP BND       X2725                         1
 UP BND       X2726                         1
 UP BND       X2727                         1
 UP BND       X2728                         1
 UP BND       X2729                         1
 UP BND       X2730                         1
 UP BND       X2731                         1
 UP BND       X2732                         1
 UP BND       X2733                         1
 UP BND       X2734                         1
 UP BND       X2735                         1
 UP BND       X2736                         1
 UP BND       X2737                         1
 UP BND       X2738                         1
 UP BND       X2739                         1
 UP BND       X2740                         1
 UP BND       X2741                         1
 UP BND       X2742                         1
 UP BND       X2743                         1
 UP BND       X2744                         1
 UP BND       X2745                         1
 UP BND       X2746                         1
 UP BND       X2747                         1
 UP BND       X2748                         1
 UP BND       X2749                         1
 UP BND       X2750                         1
 UP BND       X2751                         1
 UP BND       X2752                         1
 UP BND       X2753                         1
 UP BND       X2754                         1
 UP BND       X2755                         1
 UP BND       X2756                         1
 UP BND       X2757                         1
 UP BND       X2758                         1
 UP BND       X2759                         1
 UP BND       X2760                         1
 UP BND       X2761                         1
 UP BND       X2762                         1
 UP BND       X2763                         1
 UP BND       X2764                         1
 UP BND       X2765                         1
 UP BND       X2766                         1
 UP BND       X2767                         1
 UP BND       X2768                         1
 UP BND       X2769                         1
 UP BND       X2770                         1
 UP BND       X2771                         1
 UP BND       X2772                         1
 UP BND       X2773                         1
 UP BND       X2774                         1
 UP BND       X2775                         1
 UP BND       X2776                         1
 UP BND       X2777                         1
 UP BND       X2778                         1
 UP BND       X2779                         1
 UP BND       X2780                         1
 UP BND       X2781                         1
 UP BND       X2782                         1
 UP BND       X2783                         1
 UP BND       X2784                         1
 UP BND       X2785                         1
 UP BND       X2786                         1
 UP BND       X2787                         1
 UP BND       X2788                         1
 UP BND       X2789                         1
 UP BND       X2790                         1
 UP BND       X2791                         1
 UP BND       X2792                         1
 UP BND       X2793                         1
 UP BND       X2794                         1
 UP BND       X2795                         1
 UP BND       X2796                         1
 UP BND       X2797                         1
 UP BND       X2798                         1
 UP BND       X2799                         1
 UP BND       X2800                         1
 UP BND       X2801                         1
 UP BND       X2802                         1
 UP BND       X2803                         1
 UP BND       X2804                         1
 UP BND       X2805                         1
 UP BND       X2806                         1
 UP BND       X2807                         1
 UP BND       X2808                         1
 UP BND       X2809                         1
 UP BND       X2810                         1
 UP BND       X2811                         1
 UP BND       X2812                         1
 UP BND       X2813                         1
 UP BND       X2814                         1
 UP BND       X2815                         1
 UP BND       X2816                         1
 UP BND       X2817                         1
 UP BND       X2818                         1
 UP BND       X2819                         1
 UP BND       X2820                         1
 UP BND       X2821                         1
 UP BND       X2822                         1
 UP BND       X2823                         1
 UP BND       X2824                         1
 UP BND       X2825                         1
 UP BND       X2826                         1
 UP BND       X2827                         1
 UP BND       X2828                         1
 UP BND       X2829                         1
 UP BND       X2830                         1
 UP BND       X2831                         1
 UP BND       X2832                         1
 UP BND       X2833                         1
 UP BND       X2834                         1
 UP BND       X2835                         1
 UP BND       X2836                         1
 UP BND       X2837                         1
 UP BND       X2838                         1
 UP BND       X2839                         1
 UP BND       X2840                         1
 UP BND       X2841                         1
 UP BND       X2842                         1
 UP BND       X2843                         1
 UP BND       X2844                         1
 UP BND       X2845                         1
 UP BND       X2846                         1
 UP BND       X2847                         1
 UP BND       X2848                         1
 UP BND       X2849                         1
 UP BND       X2850                         1
 UP BND       X2851                         1
 UP BND       X2852                         1
 UP BND       X2853                         1
 UP BND       X2854                         1
 UP BND       X2855                         1
 UP BND       X2856                         1
 UP BND       X2857                         1
 UP BND       X2858                         1
 UP BND       X2859                         1
 UP BND       X2860                         1
 UP BND       X2861                         1
 UP BND       X2862                         1
 UP BND       X2863                         1
 UP BND       X2864                         1
 UP BND       X2865                         1
 UP BND       X2866                         1
 UP BND       X2867                         1
 UP BND       X2868                         1
 UP BND       X2869                         1
 UP BND       X2870                         1
 UP BND       X2871                         1
 UP BND       X2872                         1
 UP BND       X2873                         1
 UP BND       X2874                         1
 UP BND       X2875                         1
 UP BND       X2876                         1
 UP BND       X2877                         1
 UP BND       X2878                         1
 UP BND       X2879                         1
 UP BND       X2880                         1
 UP BND       X2881                         1
 UP BND       X2882                         1
 UP BND       X2883                         1
 UP BND       X2884                         1
 UP BND       X2885                         1
 UP BND       X2886                         1
 UP BND       X2887                         1
 UP BND       X2888                         1
 UP BND       X2889                         1
 UP BND       X2890                         1
 UP BND       X2891                         1
 UP BND       X2892                         1
 UP BND       X2893                         1
 UP BND       X2894                         1
 UP BND       X2895                         1
 UP BND       X2896                         1
 UP BND       X2897                         1
 UP BND       X2898                         1
 UP BND       X2899                         1
 UP BND       X2900                         1
 UP BND       X2901                         1
 UP BND       X2902                         1
 UP BND       X2903                         1
 UP BND       X2904                         1
 UP BND       X2905                         1
 UP BND       X2906                         1
 UP BND       X2907                         1
 UP BND       X2908                         1
 UP BND       X2909                         1
 UP BND       X2910                         1
 UP BND       X2911                         1
 UP BND       X2912                         1
 UP BND       X2913                         1
 UP BND       X2914                         1
 UP BND       X2915                         1
 UP BND       X2916                         1
 UP BND       X2917                         1
 UP BND       X2918                         1
 UP BND       X2919                         1
 UP BND       X2920                         1
 UP BND       X2921                         1
 UP BND       X2922                         1
 UP BND       X2923                         1
 UP BND       X2924                         1
 UP BND       X2925                         1
 UP BND       X2926                         1
 UP BND       X2927                         1
 UP BND       X2928                         1
 UP BND       X2929                         1
 UP BND       X2930                         1
 UP BND       X2931                         1
 UP BND       X2932                         1
 UP BND       X2933                         1
 UP BND       X2934                         1
 UP BND       X2935                         1
 UP BND       X2936                         1
 UP BND       X2937                         1
 UP BND       X2938                         1
 UP BND       X2939                         1
 UP BND       X2940                         1
 UP BND       X2941                         1
 UP BND       X2942                         1
 UP BND       X2943                         1
 UP BND       X2944                         1
 UP BND       X2945                         1
 UP BND       X2946                         1
 UP BND       X2947                         1
 UP BND       X2948                         1
 UP BND       X2949                         1
 UP BND       X2950                         1
 UP BND       X2951                         1
 UP BND       X2952                         1
 UP BND       X2953                         1
 UP BND       X2954                         1
 UP BND       X2955                         1
 UP BND       X2956                         1
 UP BND       X2957                         1
 UP BND       X2958                         1
 UP BND       X2959                         1
 UP BND       X2960                         1
 UP BND       X2961                         1
 UP BND       X2962                         1
 UP BND       X2963                         1
 UP BND       X2964                         1
 UP BND       X2965                         1
 UP BND       X2966                         1
 UP BND       X2967                         1
 UP BND       X2968                         1
 UP BND       X2969                         1
 UP BND       X2970                         1
 UP BND       X2971                         1
 UP BND       X2972                         1
 UP BND       X2973                         1
 UP BND       X2974                         1
 UP BND       X2975                         1
 UP BND       X2976                         1
 UP BND       X2977                         1
 UP BND       X2978                         1
 UP BND       X2979                         1
 UP BND       X2980                         1
 UP BND       X2981                         1
 UP BND       X2982                         1
 UP BND       X2983                         1
 UP BND       X2984                         1
ENDATA
