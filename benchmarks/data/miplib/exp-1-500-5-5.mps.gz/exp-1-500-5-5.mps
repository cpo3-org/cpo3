NAME          exp-1-500-5-5
ROWS
 N R0
 E R1
 E R2
 E R3
 E R4
 E R5
 E R6
 E R7
 E R8
 E R9
 E R10
 E R11
 E R12
 E R13
 E R14
 E R15
 E R16
 E R17
 E R18
 E R19
 E R20
 E R21
 E R22
 E R23
 E R24
 E R25
 E R26
 E R27
 E R28
 E R29
 E R30
 E R31
 E R32
 E R33
 E R34
 E R35
 E R36
 E R37
 E R38
 E R39
 E R40
 E R41
 E R42
 E R43
 E R44
 E R45
 E R46
 E R47
 E R48
 E R49
 E R50
 L R51
 L R52
 L R53
 L R54
 L R55
 L R56
 L R57
 L R58
 L R59
 L R60
 L R61
 L R62
 L R63
 L R64
 L R65
 L R66
 L R67
 L R68
 L R69
 L R70
 L R71
 L R72
 L R73
 L R74
 L R75
 L R76
 L R77
 L R78
 L R79
 L R80
 L R81
 L R82
 L R83
 L R84
 L R85
 L R86
 L R87
 L R88
 L R89
 L R90
 L R91
 L R92
 L R93
 L R94
 L R95
 L R96
 L R97
 L R98
 L R99
 L R100
 E R101
 E R102
 E R103
 E R104
 E R105
 E R106
 E R107
 E R108
 E R109
 E R110
 E R111
 E R112
 E R113
 E R114
 E R115
 E R116
 E R117
 E R118
 E R119
 E R120
 E R121
 E R122
 E R123
 E R124
 E R125
 E R126
 E R127
 E R128
 E R129
 E R130
 E R131
 E R132
 E R133
 E R134
 E R135
 E R136
 E R137
 E R138
 E R139
 E R140
 E R141
 E R142
 E R143
 E R144
 E R145
 E R146
 E R147
 E R148
 E R149
 E R150
 L R151
 L R152
 L R153
 L R154
 L R155
 L R156
 L R157
 L R158
 L R159
 L R160
 L R161
 L R162
 L R163
 L R164
 L R165
 L R166
 L R167
 L R168
 L R169
 L R170
 L R171
 L R172
 L R173
 L R174
 L R175
 L R176
 L R177
 L R178
 L R179
 L R180
 L R181
 L R182
 L R183
 L R184
 L R185
 L R186
 L R187
 L R188
 L R189
 L R190
 L R191
 L R192
 L R193
 L R194
 L R195
 L R196
 L R197
 L R198
 L R199
 L R200
 E R201
 E R202
 E R203
 E R204
 E R205
 E R206
 E R207
 E R208
 E R209
 E R210
 E R211
 E R212
 E R213
 E R214
 E R215
 E R216
 E R217
 E R218
 E R219
 E R220
 E R221
 E R222
 E R223
 E R224
 E R225
 E R226
 E R227
 E R228
 E R229
 E R230
 E R231
 E R232
 E R233
 E R234
 E R235
 E R236
 E R237
 E R238
 E R239
 E R240
 E R241
 E R242
 E R243
 E R244
 E R245
 E R246
 E R247
 E R248
 E R249
 E R250
 L R251
 L R252
 L R253
 L R254
 L R255
 L R256
 L R257
 L R258
 L R259
 L R260
 L R261
 L R262
 L R263
 L R264
 L R265
 L R266
 L R267
 L R268
 L R269
 L R270
 L R271
 L R272
 L R273
 L R274
 L R275
 L R276
 L R277
 L R278
 L R279
 L R280
 L R281
 L R282
 L R283
 L R284
 L R285
 L R286
 L R287
 L R288
 L R289
 L R290
 L R291
 L R292
 L R293
 L R294
 L R295
 L R296
 L R297
 L R298
 L R299
 L R300
 E R301
 E R302
 E R303
 E R304
 E R305
 E R306
 E R307
 E R308
 E R309
 E R310
 E R311
 E R312
 E R313
 E R314
 E R315
 E R316
 E R317
 E R318
 E R319
 E R320
 E R321
 E R322
 E R323
 E R324
 E R325
 E R326
 E R327
 E R328
 E R329
 E R330
 E R331
 E R332
 E R333
 E R334
 E R335
 E R336
 E R337
 E R338
 E R339
 E R340
 E R341
 E R342
 E R343
 E R344
 E R345
 E R346
 E R347
 E R348
 E R349
 E R350
 L R351
 L R352
 L R353
 L R354
 L R355
 L R356
 L R357
 L R358
 L R359
 L R360
 L R361
 L R362
 L R363
 L R364
 L R365
 L R366
 L R367
 L R368
 L R369
 L R370
 L R371
 L R372
 L R373
 L R374
 L R375
 L R376
 L R377
 L R378
 L R379
 L R380
 L R381
 L R382
 L R383
 L R384
 L R385
 L R386
 L R387
 L R388
 L R389
 L R390
 L R391
 L R392
 L R393
 L R394
 L R395
 L R396
 L R397
 L R398
 L R399
 L R400
 E R401
 E R402
 E R403
 E R404
 E R405
 E R406
 E R407
 E R408
 E R409
 E R410
 E R411
 E R412
 E R413
 E R414
 E R415
 E R416
 E R417
 E R418
 E R419
 E R420
 E R421
 E R422
 E R423
 E R424
 E R425
 E R426
 E R427
 E R428
 E R429
 E R430
 E R431
 E R432
 E R433
 E R434
 E R435
 E R436
 E R437
 E R438
 E R439
 E R440
 E R441
 E R442
 E R443
 E R444
 E R445
 E R446
 E R447
 E R448
 E R449
 E R450
 L R451
 L R452
 L R453
 L R454
 L R455
 L R456
 L R457
 L R458
 L R459
 L R460
 L R461
 L R462
 L R463
 L R464
 L R465
 L R466
 L R467
 L R468
 L R469
 L R470
 L R471
 L R472
 L R473
 L R474
 L R475
 L R476
 L R477
 L R478
 L R479
 L R480
 L R481
 L R482
 L R483
 L R484
 L R485
 L R486
 L R487
 L R488
 L R489
 L R490
 L R491
 L R492
 L R493
 L R494
 L R495
 L R496
 L R497
 L R498
 L R499
 L R500
 L R501
 L R502
 L R503
 L R504
 L R505
 L R506
 L R507
 L R508
 L R509
 L R510
 L R511
 L R512
 L R513
 L R514
 L R515
 L R516
 L R517
 L R518
 L R519
 L R520
 L R521
 L R522
 L R523
 L R524
 L R525
 L R526
 L R527
 L R528
 L R529
 L R530
 L R531
 L R532
 L R533
 L R534
 L R535
 L R536
 L R537
 L R538
 L R539
 L R540
 L R541
 L R542
 L R543
 L R544
 L R545
 L R546
 L R547
 L R548
 L R549
 L R550
COLUMNS
    X0        R0                            4
    X0        R1                            1
    X0        R51                           1
    X1        R0                            9
    X1        R2                            1
    X1        R52                           1
    X2        R0                            7
    X2        R3                            1
    X2        R53                           1
    X3        R0                            4
    X3        R4                            1
    X3        R54                           1
    X4        R0                            7
    X4        R5                            1
    X4        R55                           1
    X5        R0                            6
    X5        R6                            1
    X5        R56                           1
    X6        R0                            4
    X6        R7                            1
    X6        R57                           1
    X7        R0                            3
    X7        R8                            1
    X7        R58                           1
    X8        R0                            7
    X8        R9                            1
    X8        R59                           1
    X9        R0                            9
    X9        R10                           1
    X9        R60                           1
    X10       R0                            4
    X10       R11                           1
    X10       R61                           1
    X11       R0                            4
    X11       R12                           1
    X11       R62                           1
    X12       R0                            2
    X12       R13                           1
    X12       R63                           1
    X13       R0                            8
    X13       R14                           1
    X13       R64                           1
    X14       R0                            1
    X14       R15                           1
    X14       R65                           1
    X15       R0                            4
    X15       R16                           1
    X15       R66                           1
    X16       R0                            10
    X16       R17                           1
    X16       R67                           1
    X17       R0                            4
    X17       R18                           1
    X17       R68                           1
    X18       R0                            8
    X18       R19                           1
    X18       R69                           1
    X19       R0                            7
    X19       R20                           1
    X19       R70                           1
    X20       R0                            8
    X20       R21                           1
    X20       R71                           1
    X21       R0                            6
    X21       R22                           1
    X21       R72                           1
    X22       R0                            6
    X22       R23                           1
    X22       R73                           1
    X23       R0                            1
    X23       R24                           1
    X23       R74                           1
    X24       R0                            10
    X24       R25                           1
    X24       R75                           1
    X25       R0                            8
    X25       R26                           1
    X25       R76                           1
    X26       R0                            10
    X26       R27                           1
    X26       R77                           1
    X27       R0                            3
    X27       R28                           1
    X27       R78                           1
    X28       R0                            4
    X28       R29                           1
    X28       R79                           1
    X29       R0                            5
    X29       R30                           1
    X29       R80                           1
    X30       R0                            7
    X30       R31                           1
    X30       R81                           1
    X31       R0                            2
    X31       R32                           1
    X31       R82                           1
    X32       R0                            6
    X32       R33                           1
    X32       R83                           1
    X33       R0                            4
    X33       R34                           1
    X33       R84                           1
    X34       R0                            4
    X34       R35                           1
    X34       R85                           1
    X35       R0                            8
    X35       R36                           1
    X35       R86                           1
    X36       R0                            5
    X36       R37                           1
    X36       R87                           1
    X37       R0                            5
    X37       R38                           1
    X37       R88                           1
    X38       R0                            5
    X38       R39                           1
    X38       R89                           1
    X39       R0                            4
    X39       R40                           1
    X39       R90                           1
    X40       R0                            5
    X40       R41                           1
    X40       R91                           1
    X41       R0                            8
    X41       R42                           1
    X41       R92                           1
    X42       R0                            8
    X42       R43                           1
    X42       R93                           1
    X43       R0                            1
    X43       R44                           1
    X43       R94                           1
    X44       R0                            4
    X44       R45                           1
    X44       R95                           1
    X45       R0                            7
    X45       R46                           1
    X45       R96                           1
    X46       R0                            7
    X46       R47                           1
    X46       R97                           1
    X47       R0                            10
    X47       R48                           1
    X47       R98                           1
    X48       R0                            5
    X48       R49                           1
    X48       R99                           1
    X49       R0                            4
    X49       R50                           1
    X49       R100                          1
    X50       R0                            3000
    X50       R51                           -753
    X50       R501                          1
    X51       R0                            4000
    X51       R52                           -753
    X51       R502                          1
    X52       R0                            2000
    X52       R53                           -753
    X52       R503                          1
    X53       R0                            500
    X53       R54                           -753
    X53       R504                          1
    X54       R0                            4500
    X54       R55                           -753
    X54       R505                          1
    X55       R0                            500
    X55       R56                           -753
    X55       R506                          1
    X56       R0                            500
    X56       R57                           -753
    X56       R507                          1
    X57       R0                            3500
    X57       R58                           -753
    X57       R508                          1
    X58       R0                            4000
    X58       R59                           -753
    X58       R509                          1
    X59       R0                            3000
    X59       R60                           -753
    X59       R510                          1
    X60       R0                            1000
    X60       R61                           -753
    X60       R511                          1
    X61       R0                            500
    X61       R62                           -753
    X61       R512                          1
    X62       R0                            1000
    X62       R63                           -753
    X62       R513                          1
    X63       R0                            5000
    X63       R64                           -753
    X63       R514                          1
    X64       R0                            2500
    X64       R65                           -753
    X64       R515                          1
    X65       R0                            3000
    X65       R66                           -753
    X65       R516                          1
    X66       R0                            2000
    X66       R67                           -753
    X66       R517                          1
    X67       R0                            3000
    X67       R68                           -753
    X67       R518                          1
    X68       R0                            4500
    X68       R69                           -753
    X68       R519                          1
    X69       R0                            2000
    X69       R70                           -753
    X69       R520                          1
    X70       R0                            2000
    X70       R71                           -753
    X70       R521                          1
    X71       R0                            1500
    X71       R72                           -753
    X71       R522                          1
    X72       R0                            5000
    X72       R73                           -753
    X72       R523                          1
    X73       R0                            1500
    X73       R74                           -753
    X73       R524                          1
    X74       R0                            4500
    X74       R75                           -753
    X74       R525                          1
    X75       R0                            1500
    X75       R76                           -753
    X75       R526                          1
    X76       R0                            1500
    X76       R77                           -753
    X76       R527                          1
    X77       R0                            2000
    X77       R78                           -753
    X77       R528                          1
    X78       R0                            1500
    X78       R79                           -753
    X78       R529                          1
    X79       R0                            2500
    X79       R80                           -753
    X79       R530                          1
    X80       R0                            5000
    X80       R81                           -753
    X80       R531                          1
    X81       R0                            4000
    X81       R82                           -753
    X81       R532                          1
    X82       R0                            2500
    X82       R83                           -753
    X82       R533                          1
    X83       R0                            1500
    X83       R84                           -753
    X83       R534                          1
    X84       R0                            1000
    X84       R85                           -753
    X84       R535                          1
    X85       R0                            1500
    X85       R86                           -753
    X85       R536                          1
    X86       R0                            2500
    X86       R87                           -753
    X86       R537                          1
    X87       R0                            5000
    X87       R88                           -753
    X87       R538                          1
    X88       R0                            2500
    X88       R89                           -753
    X88       R539                          1
    X89       R0                            2000
    X89       R90                           -753
    X89       R540                          1
    X90       R0                            1500
    X90       R91                           -753
    X90       R541                          1
    X91       R0                            3000
    X91       R92                           -753
    X91       R542                          1
    X92       R0                            1000
    X92       R93                           -753
    X92       R543                          1
    X93       R0                            500
    X93       R94                           -753
    X93       R544                          1
    X94       R0                            2500
    X94       R95                           -753
    X94       R545                          1
    X95       R0                            1000
    X95       R96                           -753
    X95       R546                          1
    X96       R0                            4500
    X96       R97                           -753
    X96       R547                          1
    X97       R0                            1000
    X97       R98                           -753
    X97       R548                          1
    X98       R0                            2500
    X98       R99                           -753
    X98       R549                          1
    X99       R0                            4000
    X99       R100                          -753
    X99       R550                          1
    X100      R0                            1
    X100      R1                            -1
    X100      R2                            1
    X101      R0                            5
    X101      R2                            -1
    X101      R3                            1
    X102      R0                            4
    X102      R3                            -1
    X102      R4                            1
    X103      R0                            3
    X103      R4                            -1
    X103      R5                            1
    X104      R0                            2
    X104      R5                            -1
    X104      R6                            1
    X105      R0                            3
    X105      R6                            -1
    X105      R7                            1
    X106      R0                            3
    X106      R7                            -1
    X106      R8                            1
    X107      R0                            2
    X107      R8                            -1
    X107      R9                            1
    X108      R0                            2
    X108      R9                            -1
    X108      R10                           1
    X109      R0                            3
    X109      R10                           -1
    X109      R11                           1
    X110      R0                            4
    X110      R11                           -1
    X110      R12                           1
    X111      R0                            4
    X111      R12                           -1
    X111      R13                           1
    X112      R0                            1
    X112      R13                           -1
    X112      R14                           1
    X113      R0                            3
    X113      R14                           -1
    X113      R15                           1
    X114      R0                            4
    X114      R15                           -1
    X114      R16                           1
    X115      R0                            3
    X115      R16                           -1
    X115      R17                           1
    X116      R0                            5
    X116      R17                           -1
    X116      R18                           1
    X117      R0                            4
    X117      R18                           -1
    X117      R19                           1
    X118      R0                            5
    X118      R19                           -1
    X118      R20                           1
    X119      R0                            5
    X119      R20                           -1
    X119      R21                           1
    X120      R0                            1
    X120      R21                           -1
    X120      R22                           1
    X121      R0                            2
    X121      R22                           -1
    X121      R23                           1
    X122      R0                            4
    X122      R23                           -1
    X122      R24                           1
    X123      R0                            2
    X123      R24                           -1
    X123      R25                           1
    X124      R0                            4
    X124      R25                           -1
    X124      R26                           1
    X125      R0                            3
    X125      R26                           -1
    X125      R27                           1
    X126      R0                            2
    X126      R27                           -1
    X126      R28                           1
    X127      R0                            5
    X127      R28                           -1
    X127      R29                           1
    X128      R0                            2
    X128      R29                           -1
    X128      R30                           1
    X129      R0                            2
    X129      R30                           -1
    X129      R31                           1
    X130      R0                            1
    X130      R31                           -1
    X130      R32                           1
    X131      R0                            5
    X131      R32                           -1
    X131      R33                           1
    X132      R0                            1
    X132      R33                           -1
    X132      R34                           1
    X133      R0                            4
    X133      R34                           -1
    X133      R35                           1
    X134      R0                            1
    X134      R35                           -1
    X134      R36                           1
    X135      R0                            1
    X135      R36                           -1
    X135      R37                           1
    X136      R0                            2
    X136      R37                           -1
    X136      R38                           1
    X137      R0                            3
    X137      R38                           -1
    X137      R39                           1
    X138      R0                            4
    X138      R39                           -1
    X138      R40                           1
    X139      R0                            5
    X139      R40                           -1
    X139      R41                           1
    X140      R0                            5
    X140      R41                           -1
    X140      R42                           1
    X141      R0                            4
    X141      R42                           -1
    X141      R43                           1
    X142      R0                            2
    X142      R43                           -1
    X142      R44                           1
    X143      R0                            5
    X143      R44                           -1
    X143      R45                           1
    X144      R0                            1
    X144      R45                           -1
    X144      R46                           1
    X145      R0                            3
    X145      R46                           -1
    X145      R47                           1
    X146      R0                            4
    X146      R47                           -1
    X146      R48                           1
    X147      R0                            2
    X147      R48                           -1
    X147      R49                           1
    X148      R0                            2
    X148      R49                           -1
    X148      R50                           1
    X149      R0                            1
    X149      R1                            1
    X149      R2                            -1
    X150      R0                            6
    X150      R2                            1
    X150      R3                            -1
    X151      R0                            6
    X151      R3                            1
    X151      R4                            -1
    X152      R0                            1
    X152      R4                            1
    X152      R5                            -1
    X153      R0                            1
    X153      R5                            1
    X153      R6                            -1
    X154      R0                            6
    X154      R6                            1
    X154      R7                            -1
    X155      R0                            1
    X155      R7                            1
    X155      R8                            -1
    X156      R0                            6
    X156      R8                            1
    X156      R9                            -1
    X157      R0                            6
    X157      R9                            1
    X157      R10                           -1
    X158      R0                            6
    X158      R10                           1
    X158      R11                           -1
    X159      R0                            1
    X159      R11                           1
    X159      R12                           -1
    X160      R0                            1
    X160      R12                           1
    X160      R13                           -1
    X161      R0                            1
    X161      R13                           1
    X161      R14                           -1
    X162      R0                            6
    X162      R14                           1
    X162      R15                           -1
    X163      R0                            1
    X163      R15                           1
    X163      R16                           -1
    X164      R0                            6
    X164      R16                           1
    X164      R17                           -1
    X165      R0                            1
    X165      R17                           1
    X165      R18                           -1
    X166      R0                            1
    X166      R18                           1
    X166      R19                           -1
    X167      R0                            1
    X167      R19                           1
    X167      R20                           -1
    X168      R0                            6
    X168      R20                           1
    X168      R21                           -1
    X169      R0                            1
    X169      R21                           1
    X169      R22                           -1
    X170      R0                            6
    X170      R22                           1
    X170      R23                           -1
    X171      R0                            6
    X171      R23                           1
    X171      R24                           -1
    X172      R0                            6
    X172      R24                           1
    X172      R25                           -1
    X173      R0                            1
    X173      R25                           1
    X173      R26                           -1
    X174      R0                            6
    X174      R26                           1
    X174      R27                           -1
    X175      R0                            6
    X175      R27                           1
    X175      R28                           -1
    X176      R0                            6
    X176      R28                           1
    X176      R29                           -1
    X177      R0                            1
    X177      R29                           1
    X177      R30                           -1
    X178      R0                            6
    X178      R30                           1
    X178      R31                           -1
    X179      R0                            6
    X179      R31                           1
    X179      R32                           -1
    X180      R0                            1
    X180      R32                           1
    X180      R33                           -1
    X181      R0                            1
    X181      R33                           1
    X181      R34                           -1
    X182      R0                            1
    X182      R34                           1
    X182      R35                           -1
    X183      R0                            6
    X183      R35                           1
    X183      R36                           -1
    X184      R0                            6
    X184      R36                           1
    X184      R37                           -1
    X185      R0                            1
    X185      R37                           1
    X185      R38                           -1
    X186      R0                            6
    X186      R38                           1
    X186      R39                           -1
    X187      R0                            6
    X187      R39                           1
    X187      R40                           -1
    X188      R0                            1
    X188      R40                           1
    X188      R41                           -1
    X189      R0                            1
    X189      R41                           1
    X189      R42                           -1
    X190      R0                            1
    X190      R42                           1
    X190      R43                           -1
    X191      R0                            1
    X191      R43                           1
    X191      R44                           -1
    X192      R0                            6
    X192      R44                           1
    X192      R45                           -1
    X193      R0                            1
    X193      R45                           1
    X193      R46                           -1
    X194      R0                            1
    X194      R46                           1
    X194      R47                           -1
    X195      R0                            6
    X195      R47                           1
    X195      R48                           -1
    X196      R0                            1
    X196      R48                           1
    X196      R49                           -1
    X197      R0                            6
    X197      R49                           1
    X197      R50                           -1
    X198      R0                            6
    X198      R101                          1
    X198      R151                          1
    X199      R0                            7
    X199      R102                          1
    X199      R152                          1
    X200      R0                            9
    X200      R103                          1
    X200      R153                          1
    X201      R0                            7
    X201      R104                          1
    X201      R154                          1
    X202      R0                            8
    X202      R105                          1
    X202      R155                          1
    X203      R0                            3
    X203      R106                          1
    X203      R156                          1
    X204      R0                            3
    X204      R107                          1
    X204      R157                          1
    X205      R0                            1
    X205      R108                          1
    X205      R158                          1
    X206      R0                            7
    X206      R109                          1
    X206      R159                          1
    X207      R0                            1
    X207      R110                          1
    X207      R160                          1
    X208      R0                            4
    X208      R111                          1
    X208      R161                          1
    X209      R0                            5
    X209      R112                          1
    X209      R162                          1
    X210      R0                            6
    X210      R113                          1
    X210      R163                          1
    X211      R0                            7
    X211      R114                          1
    X211      R164                          1
    X212      R0                            1
    X212      R115                          1
    X212      R165                          1
    X213      R0                            4
    X213      R116                          1
    X213      R166                          1
    X214      R0                            4
    X214      R117                          1
    X214      R167                          1
    X215      R0                            9
    X215      R118                          1
    X215      R168                          1
    X216      R0                            7
    X216      R119                          1
    X216      R169                          1
    X217      R0                            7
    X217      R120                          1
    X217      R170                          1
    X218      R0                            7
    X218      R121                          1
    X218      R171                          1
    X219      R0                            6
    X219      R122                          1
    X219      R172                          1
    X220      R0                            5
    X220      R123                          1
    X220      R173                          1
    X221      R0                            8
    X221      R124                          1
    X221      R174                          1
    X222      R0                            4
    X222      R125                          1
    X222      R175                          1
    X223      R0                            5
    X223      R126                          1
    X223      R176                          1
    X224      R0                            1
    X224      R127                          1
    X224      R177                          1
    X225      R0                            2
    X225      R128                          1
    X225      R178                          1
    X226      R0                            1
    X226      R129                          1
    X226      R179                          1
    X227      R0                            3
    X227      R130                          1
    X227      R180                          1
    X228      R0                            10
    X228      R131                          1
    X228      R181                          1
    X229      R0                            7
    X229      R132                          1
    X229      R182                          1
    X230      R0                            7
    X230      R133                          1
    X230      R183                          1
    X231      R0                            10
    X231      R134                          1
    X231      R184                          1
    X232      R0                            2
    X232      R135                          1
    X232      R185                          1
    X233      R0                            1
    X233      R136                          1
    X233      R186                          1
    X234      R0                            9
    X234      R137                          1
    X234      R187                          1
    X235      R0                            9
    X235      R138                          1
    X235      R188                          1
    X236      R0                            5
    X236      R139                          1
    X236      R189                          1
    X237      R0                            5
    X237      R140                          1
    X237      R190                          1
    X238      R0                            6
    X238      R141                          1
    X238      R191                          1
    X239      R0                            6
    X239      R142                          1
    X239      R192                          1
    X240      R0                            10
    X240      R143                          1
    X240      R193                          1
    X241      R0                            6
    X241      R144                          1
    X241      R194                          1
    X242      R0                            6
    X242      R145                          1
    X242      R195                          1
    X243      R0                            1
    X243      R146                          1
    X243      R196                          1
    X244      R0                            5
    X244      R147                          1
    X244      R197                          1
    X245      R0                            3
    X245      R148                          1
    X245      R198                          1
    X246      R0                            4
    X246      R149                          1
    X246      R199                          1
    X247      R0                            8
    X247      R150                          1
    X247      R200                          1
    X248      R0                            1000
    X248      R151                          -763
    X248      R501                          1
    X249      R0                            500
    X249      R152                          -763
    X249      R502                          1
    X250      R0                            2500
    X250      R153                          -763
    X250      R503                          1
    X251      R0                            1000
    X251      R154                          -763
    X251      R504                          1
    X252      R0                            1500
    X252      R155                          -763
    X252      R505                          1
    X253      R0                            1000
    X253      R156                          -763
    X253      R506                          1
    X254      R0                            2000
    X254      R157                          -763
    X254      R507                          1
    X255      R0                            3500
    X255      R158                          -763
    X255      R508                          1
    X256      R0                            3500
    X256      R159                          -763
    X256      R509                          1
    X257      R0                            1500
    X257      R160                          -763
    X257      R510                          1
    X258      R0                            2000
    X258      R161                          -763
    X258      R511                          1
    X259      R0                            1500
    X259      R162                          -763
    X259      R512                          1
    X260      R0                            500
    X260      R163                          -763
    X260      R513                          1
    X261      R0                            2500
    X261      R164                          -763
    X261      R514                          1
    X262      R0                            1500
    X262      R165                          -763
    X262      R515                          1
    X263      R0                            3000
    X263      R166                          -763
    X263      R516                          1
    X264      R0                            1000
    X264      R167                          -763
    X264      R517                          1
    X265      R0                            2000
    X265      R168                          -763
    X265      R518                          1
    X266      R0                            2500
    X266      R169                          -763
    X266      R519                          1
    X267      R0                            2000
    X267      R170                          -763
    X267      R520                          1
    X268      R0                            500
    X268      R171                          -763
    X268      R521                          1
    X269      R0                            5000
    X269      R172                          -763
    X269      R522                          1
    X270      R0                            4000
    X270      R173                          -763
    X270      R523                          1
    X271      R0                            1500
    X271      R174                          -763
    X271      R524                          1
    X272      R0                            4000
    X272      R175                          -763
    X272      R525                          1
    X273      R0                            4500
    X273      R176                          -763
    X273      R526                          1
    X274      R0                            4500
    X274      R177                          -763
    X274      R527                          1
    X275      R0                            4500
    X275      R178                          -763
    X275      R528                          1
    X276      R0                            4000
    X276      R179                          -763
    X276      R529                          1
    X277      R0                            1000
    X277      R180                          -763
    X277      R530                          1
    X278      R0                            3000
    X278      R181                          -763
    X278      R531                          1
    X279      R0                            2500
    X279      R182                          -763
    X279      R532                          1
    X280      R0                            2500
    X280      R183                          -763
    X280      R533                          1
    X281      R0                            2500
    X281      R184                          -763
    X281      R534                          1
    X282      R0                            3500
    X282      R185                          -763
    X282      R535                          1
    X283      R0                            4000
    X283      R186                          -763
    X283      R536                          1
    X284      R0                            4000
    X284      R187                          -763
    X284      R537                          1
    X285      R0                            1500
    X285      R188                          -763
    X285      R538                          1
    X286      R0                            4000
    X286      R189                          -763
    X286      R539                          1
    X287      R0                            4000
    X287      R190                          -763
    X287      R540                          1
    X288      R0                            4500
    X288      R191                          -763
    X288      R541                          1
    X289      R0                            4000
    X289      R192                          -763
    X289      R542                          1
    X290      R0                            4500
    X290      R193                          -763
    X290      R543                          1
    X291      R0                            5000
    X291      R194                          -763
    X291      R544                          1
    X292      R0                            5000
    X292      R195                          -763
    X292      R545                          1
    X293      R0                            3500
    X293      R196                          -763
    X293      R546                          1
    X294      R0                            5000
    X294      R197                          -763
    X294      R547                          1
    X295      R0                            2000
    X295      R198                          -763
    X295      R548                          1
    X296      R0                            2500
    X296      R199                          -763
    X296      R549                          1
    X297      R0                            2500
    X297      R200                          -763
    X297      R550                          1
    X298      R0                            3
    X298      R101                          -1
    X298      R102                          1
    X299      R0                            5
    X299      R102                          -1
    X299      R103                          1
    X300      R0                            5
    X300      R103                          -1
    X300      R104                          1
    X301      R0                            4
    X301      R104                          -1
    X301      R105                          1
    X302      R0                            3
    X302      R105                          -1
    X302      R106                          1
    X303      R0                            3
    X303      R106                          -1
    X303      R107                          1
    X304      R0                            1
    X304      R107                          -1
    X304      R108                          1
    X305      R0                            4
    X305      R108                          -1
    X305      R109                          1
    X306      R0                            4
    X306      R109                          -1
    X306      R110                          1
    X307      R0                            1
    X307      R110                          -1
    X307      R111                          1
    X308      R0                            1
    X308      R111                          -1
    X308      R112                          1
    X309      R0                            3
    X309      R112                          -1
    X309      R113                          1
    X310      R0                            3
    X310      R113                          -1
    X310      R114                          1
    X311      R0                            1
    X311      R114                          -1
    X311      R115                          1
    X312      R0                            2
    X312      R115                          -1
    X312      R116                          1
    X313      R0                            5
    X313      R116                          -1
    X313      R117                          1
    X314      R0                            3
    X314      R117                          -1
    X314      R118                          1
    X315      R0                            4
    X315      R118                          -1
    X315      R119                          1
    X316      R0                            5
    X316      R119                          -1
    X316      R120                          1
    X317      R0                            5
    X317      R120                          -1
    X317      R121                          1
    X318      R0                            4
    X318      R121                          -1
    X318      R122                          1
    X319      R0                            3
    X319      R122                          -1
    X319      R123                          1
    X320      R0                            1
    X320      R123                          -1
    X320      R124                          1
    X321      R0                            2
    X321      R124                          -1
    X321      R125                          1
    X322      R0                            5
    X322      R125                          -1
    X322      R126                          1
    X323      R0                            1
    X323      R126                          -1
    X323      R127                          1
    X324      R0                            2
    X324      R127                          -1
    X324      R128                          1
    X325      R0                            2
    X325      R128                          -1
    X325      R129                          1
    X326      R0                            2
    X326      R129                          -1
    X326      R130                          1
    X327      R0                            1
    X327      R130                          -1
    X327      R131                          1
    X328      R0                            2
    X328      R131                          -1
    X328      R132                          1
    X329      R0                            3
    X329      R132                          -1
    X329      R133                          1
    X330      R0                            5
    X330      R133                          -1
    X330      R134                          1
    X331      R0                            1
    X331      R134                          -1
    X331      R135                          1
    X332      R0                            5
    X332      R135                          -1
    X332      R136                          1
    X333      R0                            3
    X333      R136                          -1
    X333      R137                          1
    X334      R0                            3
    X334      R137                          -1
    X334      R138                          1
    X335      R0                            5
    X335      R138                          -1
    X335      R139                          1
    X336      R0                            2
    X336      R139                          -1
    X336      R140                          1
    X337      R0                            2
    X337      R140                          -1
    X337      R141                          1
    X338      R0                            5
    X338      R141                          -1
    X338      R142                          1
    X339      R0                            1
    X339      R142                          -1
    X339      R143                          1
    X340      R0                            4
    X340      R143                          -1
    X340      R144                          1
    X341      R0                            1
    X341      R144                          -1
    X341      R145                          1
    X342      R0                            1
    X342      R145                          -1
    X342      R146                          1
    X343      R0                            5
    X343      R146                          -1
    X343      R147                          1
    X344      R0                            5
    X344      R147                          -1
    X344      R148                          1
    X345      R0                            4
    X345      R148                          -1
    X345      R149                          1
    X346      R0                            5
    X346      R149                          -1
    X346      R150                          1
    X347      R0                            6
    X347      R101                          1
    X347      R102                          -1
    X348      R0                            1
    X348      R102                          1
    X348      R103                          -1
    X349      R0                            1
    X349      R103                          1
    X349      R104                          -1
    X350      R0                            1
    X350      R104                          1
    X350      R105                          -1
    X351      R0                            6
    X351      R105                          1
    X351      R106                          -1
    X352      R0                            6
    X352      R106                          1
    X352      R107                          -1
    X353      R0                            6
    X353      R107                          1
    X353      R108                          -1
    X354      R0                            6
    X354      R108                          1
    X354      R109                          -1
    X355      R0                            1
    X355      R109                          1
    X355      R110                          -1
    X356      R0                            6
    X356      R110                          1
    X356      R111                          -1
    X357      R0                            6
    X357      R111                          1
    X357      R112                          -1
    X358      R0                            1
    X358      R112                          1
    X358      R113                          -1
    X359      R0                            1
    X359      R113                          1
    X359      R114                          -1
    X360      R0                            6
    X360      R114                          1
    X360      R115                          -1
    X361      R0                            1
    X361      R115                          1
    X361      R116                          -1
    X362      R0                            1
    X362      R116                          1
    X362      R117                          -1
    X363      R0                            1
    X363      R117                          1
    X363      R118                          -1
    X364      R0                            1
    X364      R118                          1
    X364      R119                          -1
    X365      R0                            6
    X365      R119                          1
    X365      R120                          -1
    X366      R0                            1
    X366      R120                          1
    X366      R121                          -1
    X367      R0                            1
    X367      R121                          1
    X367      R122                          -1
    X368      R0                            6
    X368      R122                          1
    X368      R123                          -1
    X369      R0                            1
    X369      R123                          1
    X369      R124                          -1
    X370      R0                            6
    X370      R124                          1
    X370      R125                          -1
    X371      R0                            1
    X371      R125                          1
    X371      R126                          -1
    X372      R0                            6
    X372      R126                          1
    X372      R127                          -1
    X373      R0                            6
    X373      R127                          1
    X373      R128                          -1
    X374      R0                            6
    X374      R128                          1
    X374      R129                          -1
    X375      R0                            1
    X375      R129                          1
    X375      R130                          -1
    X376      R0                            6
    X376      R130                          1
    X376      R131                          -1
    X377      R0                            6
    X377      R131                          1
    X377      R132                          -1
    X378      R0                            6
    X378      R132                          1
    X378      R133                          -1
    X379      R0                            1
    X379      R133                          1
    X379      R134                          -1
    X380      R0                            6
    X380      R134                          1
    X380      R135                          -1
    X381      R0                            1
    X381      R135                          1
    X381      R136                          -1
    X382      R0                            1
    X382      R136                          1
    X382      R137                          -1
    X383      R0                            6
    X383      R137                          1
    X383      R138                          -1
    X384      R0                            1
    X384      R138                          1
    X384      R139                          -1
    X385      R0                            6
    X385      R139                          1
    X385      R140                          -1
    X386      R0                            6
    X386      R140                          1
    X386      R141                          -1
    X387      R0                            6
    X387      R141                          1
    X387      R142                          -1
    X388      R0                            6
    X388      R142                          1
    X388      R143                          -1
    X389      R0                            1
    X389      R143                          1
    X389      R144                          -1
    X390      R0                            1
    X390      R144                          1
    X390      R145                          -1
    X391      R0                            1
    X391      R145                          1
    X391      R146                          -1
    X392      R0                            1
    X392      R146                          1
    X392      R147                          -1
    X393      R0                            6
    X393      R147                          1
    X393      R148                          -1
    X394      R0                            1
    X394      R148                          1
    X394      R149                          -1
    X395      R0                            1
    X395      R149                          1
    X395      R150                          -1
    X396      R0                            4
    X396      R201                          1
    X396      R251                          1
    X397      R0                            8
    X397      R202                          1
    X397      R252                          1
    X398      R0                            6
    X398      R203                          1
    X398      R253                          1
    X399      R0                            2
    X399      R204                          1
    X399      R254                          1
    X400      R0                            7
    X400      R205                          1
    X400      R255                          1
    X401      R0                            5
    X401      R206                          1
    X401      R256                          1
    X402      R0                            9
    X402      R207                          1
    X402      R257                          1
    X403      R0                            4
    X403      R208                          1
    X403      R258                          1
    X404      R0                            9
    X404      R209                          1
    X404      R259                          1
    X405      R0                            2
    X405      R210                          1
    X405      R260                          1
    X406      R0                            4
    X406      R211                          1
    X406      R261                          1
    X407      R0                            6
    X407      R212                          1
    X407      R262                          1
    X408      R0                            7
    X408      R213                          1
    X408      R263                          1
    X409      R0                            1
    X409      R214                          1
    X409      R264                          1
    X410      R0                            5
    X410      R215                          1
    X410      R265                          1
    X411      R0                            3
    X411      R216                          1
    X411      R266                          1
    X412      R0                            2
    X412      R217                          1
    X412      R267                          1
    X413      R0                            6
    X413      R218                          1
    X413      R268                          1
    X414      R0                            6
    X414      R219                          1
    X414      R269                          1
    X415      R0                            8
    X415      R220                          1
    X415      R270                          1
    X416      R0                            1
    X416      R221                          1
    X416      R271                          1
    X417      R0                            4
    X417      R222                          1
    X417      R272                          1
    X418      R0                            3
    X418      R223                          1
    X418      R273                          1
    X419      R0                            4
    X419      R224                          1
    X419      R274                          1
    X420      R0                            6
    X420      R225                          1
    X420      R275                          1
    X421      R0                            8
    X421      R226                          1
    X421      R276                          1
    X422      R0                            6
    X422      R227                          1
    X422      R277                          1
    X423      R0                            10
    X423      R228                          1
    X423      R278                          1
    X424      R0                            9
    X424      R229                          1
    X424      R279                          1
    X425      R0                            6
    X425      R230                          1
    X425      R280                          1
    X426      R0                            5
    X426      R231                          1
    X426      R281                          1
    X427      R0                            3
    X427      R232                          1
    X427      R282                          1
    X428      R0                            9
    X428      R233                          1
    X428      R283                          1
    X429      R0                            6
    X429      R234                          1
    X429      R284                          1
    X430      R0                            8
    X430      R235                          1
    X430      R285                          1
    X431      R0                            8
    X431      R236                          1
    X431      R286                          1
    X432      R0                            8
    X432      R237                          1
    X432      R287                          1
    X433      R0                            7
    X433      R238                          1
    X433      R288                          1
    X434      R0                            2
    X434      R239                          1
    X434      R289                          1
    X435      R0                            7
    X435      R240                          1
    X435      R290                          1
    X436      R0                            9
    X436      R241                          1
    X436      R291                          1
    X437      R0                            10
    X437      R242                          1
    X437      R292                          1
    X438      R0                            1
    X438      R243                          1
    X438      R293                          1
    X439      R0                            1
    X439      R244                          1
    X439      R294                          1
    X440      R0                            4
    X440      R245                          1
    X440      R295                          1
    X441      R0                            4
    X441      R246                          1
    X441      R296                          1
    X442      R0                            4
    X442      R247                          1
    X442      R297                          1
    X443      R0                            5
    X443      R248                          1
    X443      R298                          1
    X444      R0                            7
    X444      R249                          1
    X444      R299                          1
    X445      R0                            8
    X445      R250                          1
    X445      R300                          1
    X446      R0                            1000
    X446      R251                          -863
    X446      R501                          1
    X447      R0                            4000
    X447      R252                          -863
    X447      R502                          1
    X448      R0                            2500
    X448      R253                          -863
    X448      R503                          1
    X449      R0                            4000
    X449      R254                          -863
    X449      R504                          1
    X450      R0                            1500
    X450      R255                          -863
    X450      R505                          1
    X451      R0                            500
    X451      R256                          -863
    X451      R506                          1
    X452      R0                            500
    X452      R257                          -863
    X452      R507                          1
    X453      R0                            3000
    X453      R258                          -863
    X453      R508                          1
    X454      R0                            3500
    X454      R259                          -863
    X454      R509                          1
    X455      R0                            2000
    X455      R260                          -863
    X455      R510                          1
    X456      R0                            4500
    X456      R261                          -863
    X456      R511                          1
    X457      R0                            5000
    X457      R262                          -863
    X457      R512                          1
    X458      R0                            2500
    X458      R263                          -863
    X458      R513                          1
    X459      R0                            1000
    X459      R264                          -863
    X459      R514                          1
    X460      R0                            500
    X460      R265                          -863
    X460      R515                          1
    X461      R0                            4000
    X461      R266                          -863
    X461      R516                          1
    X462      R0                            5000
    X462      R267                          -863
    X462      R517                          1
    X463      R0                            4500
    X463      R268                          -863
    X463      R518                          1
    X464      R0                            3500
    X464      R269                          -863
    X464      R519                          1
    X465      R0                            2000
    X465      R270                          -863
    X465      R520                          1
    X466      R0                            1500
    X466      R271                          -863
    X466      R521                          1
    X467      R0                            4500
    X467      R272                          -863
    X467      R522                          1
    X468      R0                            5000
    X468      R273                          -863
    X468      R523                          1
    X469      R0                            1500
    X469      R274                          -863
    X469      R524                          1
    X470      R0                            4000
    X470      R275                          -863
    X470      R525                          1
    X471      R0                            500
    X471      R276                          -863
    X471      R526                          1
    X472      R0                            1500
    X472      R277                          -863
    X472      R527                          1
    X473      R0                            2500
    X473      R278                          -863
    X473      R528                          1
    X474      R0                            1500
    X474      R279                          -863
    X474      R529                          1
    X475      R0                            1500
    X475      R280                          -863
    X475      R530                          1
    X476      R0                            4000
    X476      R281                          -863
    X476      R531                          1
    X477      R0                            4000
    X477      R282                          -863
    X477      R532                          1
    X478      R0                            5000
    X478      R283                          -863
    X478      R533                          1
    X479      R0                            2000
    X479      R284                          -863
    X479      R534                          1
    X480      R0                            2000
    X480      R285                          -863
    X480      R535                          1
    X481      R0                            4000
    X481      R286                          -863
    X481      R536                          1
    X482      R0                            1500
    X482      R287                          -863
    X482      R537                          1
    X483      R0                            1000
    X483      R288                          -863
    X483      R538                          1
    X484      R0                            1000
    X484      R289                          -863
    X484      R539                          1
    X485      R0                            5000
    X485      R290                          -863
    X485      R540                          1
    X486      R0                            3000
    X486      R291                          -863
    X486      R541                          1
    X487      R0                            3500
    X487      R292                          -863
    X487      R542                          1
    X488      R0                            1000
    X488      R293                          -863
    X488      R543                          1
    X489      R0                            4500
    X489      R294                          -863
    X489      R544                          1
    X490      R0                            3000
    X490      R295                          -863
    X490      R545                          1
    X491      R0                            4000
    X491      R296                          -863
    X491      R546                          1
    X492      R0                            3000
    X492      R297                          -863
    X492      R547                          1
    X493      R0                            2000
    X493      R298                          -863
    X493      R548                          1
    X494      R0                            1000
    X494      R299                          -863
    X494      R549                          1
    X495      R0                            2000
    X495      R300                          -863
    X495      R550                          1
    X496      R0                            2
    X496      R201                          -1
    X496      R202                          1
    X497      R0                            1
    X497      R202                          -1
    X497      R203                          1
    X498      R0                            1
    X498      R203                          -1
    X498      R204                          1
    X499      R0                            1
    X499      R204                          -1
    X499      R205                          1
    X500      R0                            1
    X500      R205                          -1
    X500      R206                          1
    X501      R0                            2
    X501      R206                          -1
    X501      R207                          1
    X502      R0                            4
    X502      R207                          -1
    X502      R208                          1
    X503      R0                            2
    X503      R208                          -1
    X503      R209                          1
    X504      R0                            1
    X504      R209                          -1
    X504      R210                          1
    X505      R0                            3
    X505      R210                          -1
    X505      R211                          1
    X506      R0                            5
    X506      R211                          -1
    X506      R212                          1
    X507      R0                            3
    X507      R212                          -1
    X507      R213                          1
    X508      R0                            5
    X508      R213                          -1
    X508      R214                          1
    X509      R0                            3
    X509      R214                          -1
    X509      R215                          1
    X510      R0                            1
    X510      R215                          -1
    X510      R216                          1
    X511      R0                            4
    X511      R216                          -1
    X511      R217                          1
    X512      R0                            5
    X512      R217                          -1
    X512      R218                          1
    X513      R0                            3
    X513      R218                          -1
    X513      R219                          1
    X514      R0                            3
    X514      R219                          -1
    X514      R220                          1
    X515      R0                            5
    X515      R220                          -1
    X515      R221                          1
    X516      R0                            3
    X516      R221                          -1
    X516      R222                          1
    X517      R0                            5
    X517      R222                          -1
    X517      R223                          1
    X518      R0                            5
    X518      R223                          -1
    X518      R224                          1
    X519      R0                            5
    X519      R224                          -1
    X519      R225                          1
    X520      R0                            2
    X520      R225                          -1
    X520      R226                          1
    X521      R0                            1
    X521      R226                          -1
    X521      R227                          1
    X522      R0                            1
    X522      R227                          -1
    X522      R228                          1
    X523      R0                            4
    X523      R228                          -1
    X523      R229                          1
    X524      R0                            2
    X524      R229                          -1
    X524      R230                          1
    X525      R0                            2
    X525      R230                          -1
    X525      R231                          1
    X526      R0                            5
    X526      R231                          -1
    X526      R232                          1
    X527      R0                            1
    X527      R232                          -1
    X527      R233                          1
    X528      R0                            3
    X528      R233                          -1
    X528      R234                          1
    X529      R0                            2
    X529      R234                          -1
    X529      R235                          1
    X530      R0                            2
    X530      R235                          -1
    X530      R236                          1
    X531      R0                            1
    X531      R236                          -1
    X531      R237                          1
    X532      R0                            3
    X532      R237                          -1
    X532      R238                          1
    X533      R0                            1
    X533      R238                          -1
    X533      R239                          1
    X534      R0                            4
    X534      R239                          -1
    X534      R240                          1
    X535      R0                            1
    X535      R240                          -1
    X535      R241                          1
    X536      R0                            5
    X536      R241                          -1
    X536      R242                          1
    X537      R0                            5
    X537      R242                          -1
    X537      R243                          1
    X538      R0                            2
    X538      R243                          -1
    X538      R244                          1
    X539      R0                            1
    X539      R244                          -1
    X539      R245                          1
    X540      R0                            3
    X540      R245                          -1
    X540      R246                          1
    X541      R0                            2
    X541      R246                          -1
    X541      R247                          1
    X542      R0                            3
    X542      R247                          -1
    X542      R248                          1
    X543      R0                            4
    X543      R248                          -1
    X543      R249                          1
    X544      R0                            3
    X544      R249                          -1
    X544      R250                          1
    X545      R0                            1
    X545      R201                          1
    X545      R202                          -1
    X546      R0                            6
    X546      R202                          1
    X546      R203                          -1
    X547      R0                            1
    X547      R203                          1
    X547      R204                          -1
    X548      R0                            1
    X548      R204                          1
    X548      R205                          -1
    X549      R0                            6
    X549      R205                          1
    X549      R206                          -1
    X550      R0                            1
    X550      R206                          1
    X550      R207                          -1
    X551      R0                            1
    X551      R207                          1
    X551      R208                          -1
    X552      R0                            1
    X552      R208                          1
    X552      R209                          -1
    X553      R0                            1
    X553      R209                          1
    X553      R210                          -1
    X554      R0                            1
    X554      R210                          1
    X554      R211                          -1
    X555      R0                            1
    X555      R211                          1
    X555      R212                          -1
    X556      R0                            6
    X556      R212                          1
    X556      R213                          -1
    X557      R0                            6
    X557      R213                          1
    X557      R214                          -1
    X558      R0                            6
    X558      R214                          1
    X558      R215                          -1
    X559      R0                            6
    X559      R215                          1
    X559      R216                          -1
    X560      R0                            6
    X560      R216                          1
    X560      R217                          -1
    X561      R0                            1
    X561      R217                          1
    X561      R218                          -1
    X562      R0                            1
    X562      R218                          1
    X562      R219                          -1
    X563      R0                            1
    X563      R219                          1
    X563      R220                          -1
    X564      R0                            6
    X564      R220                          1
    X564      R221                          -1
    X565      R0                            6
    X565      R221                          1
    X565      R222                          -1
    X566      R0                            6
    X566      R222                          1
    X566      R223                          -1
    X567      R0                            1
    X567      R223                          1
    X567      R224                          -1
    X568      R0                            6
    X568      R224                          1
    X568      R225                          -1
    X569      R0                            6
    X569      R225                          1
    X569      R226                          -1
    X570      R0                            1
    X570      R226                          1
    X570      R227                          -1
    X571      R0                            6
    X571      R227                          1
    X571      R228                          -1
    X572      R0                            1
    X572      R228                          1
    X572      R229                          -1
    X573      R0                            1
    X573      R229                          1
    X573      R230                          -1
    X574      R0                            6
    X574      R230                          1
    X574      R231                          -1
    X575      R0                            6
    X575      R231                          1
    X575      R232                          -1
    X576      R0                            6
    X576      R232                          1
    X576      R233                          -1
    X577      R0                            1
    X577      R233                          1
    X577      R234                          -1
    X578      R0                            1
    X578      R234                          1
    X578      R235                          -1
    X579      R0                            6
    X579      R235                          1
    X579      R236                          -1
    X580      R0                            6
    X580      R236                          1
    X580      R237                          -1
    X581      R0                            6
    X581      R237                          1
    X581      R238                          -1
    X582      R0                            6
    X582      R238                          1
    X582      R239                          -1
    X583      R0                            1
    X583      R239                          1
    X583      R240                          -1
    X584      R0                            6
    X584      R240                          1
    X584      R241                          -1
    X585      R0                            1
    X585      R241                          1
    X585      R242                          -1
    X586      R0                            1
    X586      R242                          1
    X586      R243                          -1
    X587      R0                            6
    X587      R243                          1
    X587      R244                          -1
    X588      R0                            6
    X588      R244                          1
    X588      R245                          -1
    X589      R0                            6
    X589      R245                          1
    X589      R246                          -1
    X590      R0                            6
    X590      R246                          1
    X590      R247                          -1
    X591      R0                            1
    X591      R247                          1
    X591      R248                          -1
    X592      R0                            1
    X592      R248                          1
    X592      R249                          -1
    X593      R0                            6
    X593      R249                          1
    X593      R250                          -1
    X594      R0                            9
    X594      R301                          1
    X594      R351                          1
    X595      R0                            9
    X595      R302                          1
    X595      R352                          1
    X596      R0                            4
    X596      R303                          1
    X596      R353                          1
    X597      R0                            2
    X597      R304                          1
    X597      R354                          1
    X598      R0                            4
    X598      R305                          1
    X598      R355                          1
    X599      R0                            1
    X599      R306                          1
    X599      R356                          1
    X600      R0                            8
    X600      R307                          1
    X600      R357                          1
    X601      R0                            3
    X601      R308                          1
    X601      R358                          1
    X602      R0                            5
    X602      R309                          1
    X602      R359                          1
    X603      R0                            4
    X603      R310                          1
    X603      R360                          1
    X604      R0                            3
    X604      R311                          1
    X604      R361                          1
    X605      R0                            1
    X605      R312                          1
    X605      R362                          1
    X606      R0                            10
    X606      R313                          1
    X606      R363                          1
    X607      R0                            4
    X607      R314                          1
    X607      R364                          1
    X608      R0                            5
    X608      R315                          1
    X608      R365                          1
    X609      R0                            3
    X609      R316                          1
    X609      R366                          1
    X610      R0                            6
    X610      R317                          1
    X610      R367                          1
    X611      R0                            10
    X611      R318                          1
    X611      R368                          1
    X612      R0                            1
    X612      R319                          1
    X612      R369                          1
    X613      R0                            5
    X613      R320                          1
    X613      R370                          1
    X614      R0                            9
    X614      R321                          1
    X614      R371                          1
    X615      R0                            3
    X615      R322                          1
    X615      R372                          1
    X616      R0                            4
    X616      R323                          1
    X616      R373                          1
    X617      R0                            4
    X617      R324                          1
    X617      R374                          1
    X618      R0                            10
    X618      R325                          1
    X618      R375                          1
    X619      R0                            9
    X619      R326                          1
    X619      R376                          1
    X620      R0                            9
    X620      R327                          1
    X620      R377                          1
    X621      R0                            8
    X621      R328                          1
    X621      R378                          1
    X622      R0                            1
    X622      R329                          1
    X622      R379                          1
    X623      R0                            2
    X623      R330                          1
    X623      R380                          1
    X624      R0                            9
    X624      R331                          1
    X624      R381                          1
    X625      R0                            1
    X625      R332                          1
    X625      R382                          1
    X626      R0                            5
    X626      R333                          1
    X626      R383                          1
    X627      R0                            7
    X627      R334                          1
    X627      R384                          1
    X628      R0                            2
    X628      R335                          1
    X628      R385                          1
    X629      R0                            4
    X629      R336                          1
    X629      R386                          1
    X630      R0                            5
    X630      R337                          1
    X630      R387                          1
    X631      R0                            9
    X631      R338                          1
    X631      R388                          1
    X632      R0                            2
    X632      R339                          1
    X632      R389                          1
    X633      R0                            2
    X633      R340                          1
    X633      R390                          1
    X634      R0                            10
    X634      R341                          1
    X634      R391                          1
    X635      R0                            4
    X635      R342                          1
    X635      R392                          1
    X636      R0                            8
    X636      R343                          1
    X636      R393                          1
    X637      R0                            1
    X637      R344                          1
    X637      R394                          1
    X638      R0                            4
    X638      R345                          1
    X638      R395                          1
    X639      R0                            5
    X639      R346                          1
    X639      R396                          1
    X640      R0                            8
    X640      R347                          1
    X640      R397                          1
    X641      R0                            1
    X641      R348                          1
    X641      R398                          1
    X642      R0                            8
    X642      R349                          1
    X642      R399                          1
    X643      R0                            2
    X643      R350                          1
    X643      R400                          1
    X644      R0                            4500
    X644      R351                          -712
    X644      R501                          1
    X645      R0                            2500
    X645      R352                          -712
    X645      R502                          1
    X646      R0                            500
    X646      R353                          -712
    X646      R503                          1
    X647      R0                            2000
    X647      R354                          -712
    X647      R504                          1
    X648      R0                            3500
    X648      R355                          -712
    X648      R505                          1
    X649      R0                            2500
    X649      R356                          -712
    X649      R506                          1
    X650      R0                            5000
    X650      R357                          -712
    X650      R507                          1
    X651      R0                            2000
    X651      R358                          -712
    X651      R508                          1
    X652      R0                            2000
    X652      R359                          -712
    X652      R509                          1
    X653      R0                            3500
    X653      R360                          -712
    X653      R510                          1
    X654      R0                            500
    X654      R361                          -712
    X654      R511                          1
    X655      R0                            3000
    X655      R362                          -712
    X655      R512                          1
    X656      R0                            1500
    X656      R363                          -712
    X656      R513                          1
    X657      R0                            5000
    X657      R364                          -712
    X657      R514                          1
    X658      R0                            3000
    X658      R365                          -712
    X658      R515                          1
    X659      R0                            2000
    X659      R366                          -712
    X659      R516                          1
    X660      R0                            500
    X660      R367                          -712
    X660      R517                          1
    X661      R0                            4500
    X661      R368                          -712
    X661      R518                          1
    X662      R0                            1500
    X662      R369                          -712
    X662      R519                          1
    X663      R0                            3500
    X663      R370                          -712
    X663      R520                          1
    X664      R0                            2500
    X664      R371                          -712
    X664      R521                          1
    X665      R0                            4000
    X665      R372                          -712
    X665      R522                          1
    X666      R0                            2500
    X666      R373                          -712
    X666      R523                          1
    X667      R0                            5000
    X667      R374                          -712
    X667      R524                          1
    X668      R0                            3500
    X668      R375                          -712
    X668      R525                          1
    X669      R0                            1000
    X669      R376                          -712
    X669      R526                          1
    X670      R0                            4500
    X670      R377                          -712
    X670      R527                          1
    X671      R0                            500
    X671      R378                          -712
    X671      R528                          1
    X672      R0                            1500
    X672      R379                          -712
    X672      R529                          1
    X673      R0                            3000
    X673      R380                          -712
    X673      R530                          1
    X674      R0                            2500
    X674      R381                          -712
    X674      R531                          1
    X675      R0                            3000
    X675      R382                          -712
    X675      R532                          1
    X676      R0                            5000
    X676      R383                          -712
    X676      R533                          1
    X677      R0                            4000
    X677      R384                          -712
    X677      R534                          1
    X678      R0                            500
    X678      R385                          -712
    X678      R535                          1
    X679      R0                            1000
    X679      R386                          -712
    X679      R536                          1
    X680      R0                            4000
    X680      R387                          -712
    X680      R537                          1
    X681      R0                            5000
    X681      R388                          -712
    X681      R538                          1
    X682      R0                            1000
    X682      R389                          -712
    X682      R539                          1
    X683      R0                            500
    X683      R390                          -712
    X683      R540                          1
    X684      R0                            5000
    X684      R391                          -712
    X684      R541                          1
    X685      R0                            500
    X685      R392                          -712
    X685      R542                          1
    X686      R0                            500
    X686      R393                          -712
    X686      R543                          1
    X687      R0                            5000
    X687      R394                          -712
    X687      R544                          1
    X688      R0                            1000
    X688      R395                          -712
    X688      R545                          1
    X689      R0                            2000
    X689      R396                          -712
    X689      R546                          1
    X690      R0                            3500
    X690      R397                          -712
    X690      R547                          1
    X691      R0                            1500
    X691      R398                          -712
    X691      R548                          1
    X692      R0                            3500
    X692      R399                          -712
    X692      R549                          1
    X693      R0                            4500
    X693      R400                          -712
    X693      R550                          1
    X694      R0                            2
    X694      R301                          -1
    X694      R302                          1
    X695      R0                            2
    X695      R302                          -1
    X695      R303                          1
    X696      R0                            4
    X696      R303                          -1
    X696      R304                          1
    X697      R0                            5
    X697      R304                          -1
    X697      R305                          1
    X698      R0                            4
    X698      R305                          -1
    X698      R306                          1
    X699      R0                            4
    X699      R306                          -1
    X699      R307                          1
    X700      R0                            5
    X700      R307                          -1
    X700      R308                          1
    X701      R0                            1
    X701      R308                          -1
    X701      R309                          1
    X702      R0                            5
    X702      R309                          -1
    X702      R310                          1
    X703      R0                            3
    X703      R310                          -1
    X703      R311                          1
    X704      R0                            1
    X704      R311                          -1
    X704      R312                          1
    X705      R0                            3
    X705      R312                          -1
    X705      R313                          1
    X706      R0                            1
    X706      R313                          -1
    X706      R314                          1
    X707      R0                            3
    X707      R314                          -1
    X707      R315                          1
    X708      R0                            2
    X708      R315                          -1
    X708      R316                          1
    X709      R0                            4
    X709      R316                          -1
    X709      R317                          1
    X710      R0                            5
    X710      R317                          -1
    X710      R318                          1
    X711      R0                            3
    X711      R318                          -1
    X711      R319                          1
    X712      R0                            3
    X712      R319                          -1
    X712      R320                          1
    X713      R0                            4
    X713      R320                          -1
    X713      R321                          1
    X714      R0                            2
    X714      R321                          -1
    X714      R322                          1
    X715      R0                            3
    X715      R322                          -1
    X715      R323                          1
    X716      R0                            5
    X716      R323                          -1
    X716      R324                          1
    X717      R0                            1
    X717      R324                          -1
    X717      R325                          1
    X718      R0                            4
    X718      R325                          -1
    X718      R326                          1
    X719      R0                            3
    X719      R326                          -1
    X719      R327                          1
    X720      R0                            4
    X720      R327                          -1
    X720      R328                          1
    X721      R0                            5
    X721      R328                          -1
    X721      R329                          1
    X722      R0                            2
    X722      R329                          -1
    X722      R330                          1
    X723      R0                            2
    X723      R330                          -1
    X723      R331                          1
    X724      R0                            2
    X724      R331                          -1
    X724      R332                          1
    X725      R0                            2
    X725      R332                          -1
    X725      R333                          1
    X726      R0                            4
    X726      R333                          -1
    X726      R334                          1
    X727      R0                            5
    X727      R334                          -1
    X727      R335                          1
    X728      R0                            5
    X728      R335                          -1
    X728      R336                          1
    X729      R0                            4
    X729      R336                          -1
    X729      R337                          1
    X730      R0                            3
    X730      R337                          -1
    X730      R338                          1
    X731      R0                            5
    X731      R338                          -1
    X731      R339                          1
    X732      R0                            3
    X732      R339                          -1
    X732      R340                          1
    X733      R0                            3
    X733      R340                          -1
    X733      R341                          1
    X734      R0                            2
    X734      R341                          -1
    X734      R342                          1
    X735      R0                            2
    X735      R342                          -1
    X735      R343                          1
    X736      R0                            1
    X736      R343                          -1
    X736      R344                          1
    X737      R0                            3
    X737      R344                          -1
    X737      R345                          1
    X738      R0                            4
    X738      R345                          -1
    X738      R346                          1
    X739      R0                            1
    X739      R346                          -1
    X739      R347                          1
    X740      R0                            3
    X740      R347                          -1
    X740      R348                          1
    X741      R0                            2
    X741      R348                          -1
    X741      R349                          1
    X742      R0                            3
    X742      R349                          -1
    X742      R350                          1
    X743      R0                            1
    X743      R301                          1
    X743      R302                          -1
    X744      R0                            1
    X744      R302                          1
    X744      R303                          -1
    X745      R0                            1
    X745      R303                          1
    X745      R304                          -1
    X746      R0                            1
    X746      R304                          1
    X746      R305                          -1
    X747      R0                            6
    X747      R305                          1
    X747      R306                          -1
    X748      R0                            6
    X748      R306                          1
    X748      R307                          -1
    X749      R0                            6
    X749      R307                          1
    X749      R308                          -1
    X750      R0                            6
    X750      R308                          1
    X750      R309                          -1
    X751      R0                            6
    X751      R309                          1
    X751      R310                          -1
    X752      R0                            6
    X752      R310                          1
    X752      R311                          -1
    X753      R0                            6
    X753      R311                          1
    X753      R312                          -1
    X754      R0                            1
    X754      R312                          1
    X754      R313                          -1
    X755      R0                            1
    X755      R313                          1
    X755      R314                          -1
    X756      R0                            6
    X756      R314                          1
    X756      R315                          -1
    X757      R0                            6
    X757      R315                          1
    X757      R316                          -1
    X758      R0                            6
    X758      R316                          1
    X758      R317                          -1
    X759      R0                            6
    X759      R317                          1
    X759      R318                          -1
    X760      R0                            1
    X760      R318                          1
    X760      R319                          -1
    X761      R0                            1
    X761      R319                          1
    X761      R320                          -1
    X762      R0                            1
    X762      R320                          1
    X762      R321                          -1
    X763      R0                            1
    X763      R321                          1
    X763      R322                          -1
    X764      R0                            6
    X764      R322                          1
    X764      R323                          -1
    X765      R0                            1
    X765      R323                          1
    X765      R324                          -1
    X766      R0                            6
    X766      R324                          1
    X766      R325                          -1
    X767      R0                            1
    X767      R325                          1
    X767      R326                          -1
    X768      R0                            1
    X768      R326                          1
    X768      R327                          -1
    X769      R0                            1
    X769      R327                          1
    X769      R328                          -1
    X770      R0                            6
    X770      R328                          1
    X770      R329                          -1
    X771      R0                            1
    X771      R329                          1
    X771      R330                          -1
    X772      R0                            1
    X772      R330                          1
    X772      R331                          -1
    X773      R0                            6
    X773      R331                          1
    X773      R332                          -1
    X774      R0                            1
    X774      R332                          1
    X774      R333                          -1
    X775      R0                            6
    X775      R333                          1
    X775      R334                          -1
    X776      R0                            6
    X776      R334                          1
    X776      R335                          -1
    X777      R0                            1
    X777      R335                          1
    X777      R336                          -1
    X778      R0                            1
    X778      R336                          1
    X778      R337                          -1
    X779      R0                            6
    X779      R337                          1
    X779      R338                          -1
    X780      R0                            6
    X780      R338                          1
    X780      R339                          -1
    X781      R0                            6
    X781      R339                          1
    X781      R340                          -1
    X782      R0                            6
    X782      R340                          1
    X782      R341                          -1
    X783      R0                            6
    X783      R341                          1
    X783      R342                          -1
    X784      R0                            6
    X784      R342                          1
    X784      R343                          -1
    X785      R0                            6
    X785      R343                          1
    X785      R344                          -1
    X786      R0                            6
    X786      R344                          1
    X786      R345                          -1
    X787      R0                            1
    X787      R345                          1
    X787      R346                          -1
    X788      R0                            1
    X788      R346                          1
    X788      R347                          -1
    X789      R0                            1
    X789      R347                          1
    X789      R348                          -1
    X790      R0                            1
    X790      R348                          1
    X790      R349                          -1
    X791      R0                            1
    X791      R349                          1
    X791      R350                          -1
    X792      R0                            9
    X792      R401                          1
    X792      R451                          1
    X793      R0                            5
    X793      R402                          1
    X793      R452                          1
    X794      R0                            5
    X794      R403                          1
    X794      R453                          1
    X795      R0                            6
    X795      R404                          1
    X795      R454                          1
    X796      R0                            1
    X796      R405                          1
    X796      R455                          1
    X797      R0                            8
    X797      R406                          1
    X797      R456                          1
    X798      R0                            8
    X798      R407                          1
    X798      R457                          1
    X799      R0                            1
    X799      R408                          1
    X799      R458                          1
    X800      R0                            5
    X800      R409                          1
    X800      R459                          1
    X801      R0                            7
    X801      R410                          1
    X801      R460                          1
    X802      R0                            4
    X802      R411                          1
    X802      R461                          1
    X803      R0                            10
    X803      R412                          1
    X803      R462                          1
    X804      R0                            7
    X804      R413                          1
    X804      R463                          1
    X805      R0                            8
    X805      R414                          1
    X805      R464                          1
    X806      R0                            7
    X806      R415                          1
    X806      R465                          1
    X807      R0                            6
    X807      R416                          1
    X807      R466                          1
    X808      R0                            3
    X808      R417                          1
    X808      R467                          1
    X809      R0                            3
    X809      R418                          1
    X809      R468                          1
    X810      R0                            1
    X810      R419                          1
    X810      R469                          1
    X811      R0                            5
    X811      R420                          1
    X811      R470                          1
    X812      R0                            10
    X812      R421                          1
    X812      R471                          1
    X813      R0                            2
    X813      R422                          1
    X813      R472                          1
    X814      R0                            7
    X814      R423                          1
    X814      R473                          1
    X815      R0                            9
    X815      R424                          1
    X815      R474                          1
    X816      R0                            5
    X816      R425                          1
    X816      R475                          1
    X817      R0                            2
    X817      R426                          1
    X817      R476                          1
    X818      R0                            1
    X818      R427                          1
    X818      R477                          1
    X819      R0                            9
    X819      R428                          1
    X819      R478                          1
    X820      R0                            9
    X820      R429                          1
    X820      R479                          1
    X821      R0                            3
    X821      R430                          1
    X821      R480                          1
    X822      R0                            9
    X822      R431                          1
    X822      R481                          1
    X823      R0                            9
    X823      R432                          1
    X823      R482                          1
    X824      R0                            2
    X824      R433                          1
    X824      R483                          1
    X825      R0                            2
    X825      R434                          1
    X825      R484                          1
    X826      R0                            3
    X826      R435                          1
    X826      R485                          1
    X827      R0                            6
    X827      R436                          1
    X827      R486                          1
    X828      R0                            1
    X828      R437                          1
    X828      R487                          1
    X829      R0                            4
    X829      R438                          1
    X829      R488                          1
    X830      R0                            2
    X830      R439                          1
    X830      R489                          1
    X831      R0                            1
    X831      R440                          1
    X831      R490                          1
    X832      R0                            1
    X832      R441                          1
    X832      R491                          1
    X833      R0                            8
    X833      R442                          1
    X833      R492                          1
    X834      R0                            8
    X834      R443                          1
    X834      R493                          1
    X835      R0                            1
    X835      R444                          1
    X835      R494                          1
    X836      R0                            5
    X836      R445                          1
    X836      R495                          1
    X837      R0                            3
    X837      R446                          1
    X837      R496                          1
    X838      R0                            5
    X838      R447                          1
    X838      R497                          1
    X839      R0                            5
    X839      R448                          1
    X839      R498                          1
    X840      R0                            6
    X840      R449                          1
    X840      R499                          1
    X841      R0                            9
    X841      R450                          1
    X841      R500                          1
    X842      R0                            1000
    X842      R451                          -786
    X842      R501                          1
    X843      R0                            4500
    X843      R452                          -786
    X843      R502                          1
    X844      R0                            4500
    X844      R453                          -786
    X844      R503                          1
    X845      R0                            3000
    X845      R454                          -786
    X845      R504                          1
    X846      R0                            5000
    X846      R455                          -786
    X846      R505                          1
    X847      R0                            5000
    X847      R456                          -786
    X847      R506                          1
    X848      R0                            2000
    X848      R457                          -786
    X848      R507                          1
    X849      R0                            500
    X849      R458                          -786
    X849      R508                          1
    X850      R0                            500
    X850      R459                          -786
    X850      R509                          1
    X851      R0                            5000
    X851      R460                          -786
    X851      R510                          1
    X852      R0                            1000
    X852      R461                          -786
    X852      R511                          1
    X853      R0                            4500
    X853      R462                          -786
    X853      R512                          1
    X854      R0                            2000
    X854      R463                          -786
    X854      R513                          1
    X855      R0                            2500
    X855      R464                          -786
    X855      R514                          1
    X856      R0                            5000
    X856      R465                          -786
    X856      R515                          1
    X857      R0                            2500
    X857      R466                          -786
    X857      R516                          1
    X858      R0                            1000
    X858      R467                          -786
    X858      R517                          1
    X859      R0                            4500
    X859      R468                          -786
    X859      R518                          1
    X860      R0                            5000
    X860      R469                          -786
    X860      R519                          1
    X861      R0                            1500
    X861      R470                          -786
    X861      R520                          1
    X862      R0                            1000
    X862      R471                          -786
    X862      R521                          1
    X863      R0                            4500
    X863      R472                          -786
    X863      R522                          1
    X864      R0                            2000
    X864      R473                          -786
    X864      R523                          1
    X865      R0                            1500
    X865      R474                          -786
    X865      R524                          1
    X866      R0                            3500
    X866      R475                          -786
    X866      R525                          1
    X867      R0                            5000
    X867      R476                          -786
    X867      R526                          1
    X868      R0                            2000
    X868      R477                          -786
    X868      R527                          1
    X869      R0                            4500
    X869      R478                          -786
    X869      R528                          1
    X870      R0                            4000
    X870      R479                          -786
    X870      R529                          1
    X871      R0                            2500
    X871      R480                          -786
    X871      R530                          1
    X872      R0                            5000
    X872      R481                          -786
    X872      R531                          1
    X873      R0                            500
    X873      R482                          -786
    X873      R532                          1
    X874      R0                            1500
    X874      R483                          -786
    X874      R533                          1
    X875      R0                            2000
    X875      R484                          -786
    X875      R534                          1
    X876      R0                            4000
    X876      R485                          -786
    X876      R535                          1
    X877      R0                            2000
    X877      R486                          -786
    X877      R536                          1
    X878      R0                            4500
    X878      R487                          -786
    X878      R537                          1
    X879      R0                            3500
    X879      R488                          -786
    X879      R538                          1
    X880      R0                            2000
    X880      R489                          -786
    X880      R539                          1
    X881      R0                            4000
    X881      R490                          -786
    X881      R540                          1
    X882      R0                            2500
    X882      R491                          -786
    X882      R541                          1
    X883      R0                            1500
    X883      R492                          -786
    X883      R542                          1
    X884      R0                            4000
    X884      R493                          -786
    X884      R543                          1
    X885      R0                            4000
    X885      R494                          -786
    X885      R544                          1
    X886      R0                            1500
    X886      R495                          -786
    X886      R545                          1
    X887      R0                            1500
    X887      R496                          -786
    X887      R546                          1
    X888      R0                            500
    X888      R497                          -786
    X888      R547                          1
    X889      R0                            3000
    X889      R498                          -786
    X889      R548                          1
    X890      R0                            4000
    X890      R499                          -786
    X890      R549                          1
    X891      R0                            4000
    X891      R500                          -786
    X891      R550                          1
    X892      R0                            5
    X892      R401                          -1
    X892      R402                          1
    X893      R0                            1
    X893      R402                          -1
    X893      R403                          1
    X894      R0                            4
    X894      R403                          -1
    X894      R404                          1
    X895      R0                            3
    X895      R404                          -1
    X895      R405                          1
    X896      R0                            2
    X896      R405                          -1
    X896      R406                          1
    X897      R0                            3
    X897      R406                          -1
    X897      R407                          1
    X898      R0                            3
    X898      R407                          -1
    X898      R408                          1
    X899      R0                            3
    X899      R408                          -1
    X899      R409                          1
    X900      R0                            4
    X900      R409                          -1
    X900      R410                          1
    X901      R0                            4
    X901      R410                          -1
    X901      R411                          1
    X902      R0                            3
    X902      R411                          -1
    X902      R412                          1
    X903      R0                            4
    X903      R412                          -1
    X903      R413                          1
    X904      R0                            4
    X904      R413                          -1
    X904      R414                          1
    X905      R0                            4
    X905      R414                          -1
    X905      R415                          1
    X906      R0                            3
    X906      R415                          -1
    X906      R416                          1
    X907      R0                            3
    X907      R416                          -1
    X907      R417                          1
    X908      R0                            4
    X908      R417                          -1
    X908      R418                          1
    X909      R0                            4
    X909      R418                          -1
    X909      R419                          1
    X910      R0                            3
    X910      R419                          -1
    X910      R420                          1
    X911      R0                            3
    X911      R420                          -1
    X911      R421                          1
    X912      R0                            1
    X912      R421                          -1
    X912      R422                          1
    X913      R0                            2
    X913      R422                          -1
    X913      R423                          1
    X914      R0                            3
    X914      R423                          -1
    X914      R424                          1
    X915      R0                            4
    X915      R424                          -1
    X915      R425                          1
    X916      R0                            4
    X916      R425                          -1
    X916      R426                          1
    X917      R0                            5
    X917      R426                          -1
    X917      R427                          1
    X918      R0                            5
    X918      R427                          -1
    X918      R428                          1
    X919      R0                            4
    X919      R428                          -1
    X919      R429                          1
    X920      R0                            3
    X920      R429                          -1
    X920      R430                          1
    X921      R0                            3
    X921      R430                          -1
    X921      R431                          1
    X922      R0                            5
    X922      R431                          -1
    X922      R432                          1
    X923      R0                            5
    X923      R432                          -1
    X923      R433                          1
    X924      R0                            1
    X924      R433                          -1
    X924      R434                          1
    X925      R0                            4
    X925      R434                          -1
    X925      R435                          1
    X926      R0                            1
    X926      R435                          -1
    X926      R436                          1
    X927      R0                            1
    X927      R436                          -1
    X927      R437                          1
    X928      R0                            3
    X928      R437                          -1
    X928      R438                          1
    X929      R0                            4
    X929      R438                          -1
    X929      R439                          1
    X930      R0                            4
    X930      R439                          -1
    X930      R440                          1
    X931      R0                            3
    X931      R440                          -1
    X931      R441                          1
    X932      R0                            3
    X932      R441                          -1
    X932      R442                          1
    X933      R0                            4
    X933      R442                          -1
    X933      R443                          1
    X934      R0                            4
    X934      R443                          -1
    X934      R444                          1
    X935      R0                            4
    X935      R444                          -1
    X935      R445                          1
    X936      R0                            5
    X936      R445                          -1
    X936      R446                          1
    X937      R0                            4
    X937      R446                          -1
    X937      R447                          1
    X938      R0                            5
    X938      R447                          -1
    X938      R448                          1
    X939      R0                            3
    X939      R448                          -1
    X939      R449                          1
    X940      R0                            3
    X940      R449                          -1
    X940      R450                          1
    X941      R0                            6
    X941      R401                          1
    X941      R402                          -1
    X942      R0                            1
    X942      R402                          1
    X942      R403                          -1
    X943      R0                            6
    X943      R403                          1
    X943      R404                          -1
    X944      R0                            1
    X944      R404                          1
    X944      R405                          -1
    X945      R0                            6
    X945      R405                          1
    X945      R406                          -1
    X946      R0                            1
    X946      R406                          1
    X946      R407                          -1
    X947      R0                            6
    X947      R407                          1
    X947      R408                          -1
    X948      R0                            1
    X948      R408                          1
    X948      R409                          -1
    X949      R0                            1
    X949      R409                          1
    X949      R410                          -1
    X950      R0                            1
    X950      R410                          1
    X950      R411                          -1
    X951      R0                            6
    X951      R411                          1
    X951      R412                          -1
    X952      R0                            6
    X952      R412                          1
    X952      R413                          -1
    X953      R0                            1
    X953      R413                          1
    X953      R414                          -1
    X954      R0                            6
    X954      R414                          1
    X954      R415                          -1
    X955      R0                            1
    X955      R415                          1
    X955      R416                          -1
    X956      R0                            1
    X956      R416                          1
    X956      R417                          -1
    X957      R0                            1
    X957      R417                          1
    X957      R418                          -1
    X958      R0                            1
    X958      R418                          1
    X958      R419                          -1
    X959      R0                            6
    X959      R419                          1
    X959      R420                          -1
    X960      R0                            6
    X960      R420                          1
    X960      R421                          -1
    X961      R0                            1
    X961      R421                          1
    X961      R422                          -1
    X962      R0                            6
    X962      R422                          1
    X962      R423                          -1
    X963      R0                            1
    X963      R423                          1
    X963      R424                          -1
    X964      R0                            6
    X964      R424                          1
    X964      R425                          -1
    X965      R0                            6
    X965      R425                          1
    X965      R426                          -1
    X966      R0                            1
    X966      R426                          1
    X966      R427                          -1
    X967      R0                            6
    X967      R427                          1
    X967      R428                          -1
    X968      R0                            1
    X968      R428                          1
    X968      R429                          -1
    X969      R0                            6
    X969      R429                          1
    X969      R430                          -1
    X970      R0                            1
    X970      R430                          1
    X970      R431                          -1
    X971      R0                            6
    X971      R431                          1
    X971      R432                          -1
    X972      R0                            1
    X972      R432                          1
    X972      R433                          -1
    X973      R0                            6
    X973      R433                          1
    X973      R434                          -1
    X974      R0                            1
    X974      R434                          1
    X974      R435                          -1
    X975      R0                            1
    X975      R435                          1
    X975      R436                          -1
    X976      R0                            6
    X976      R436                          1
    X976      R437                          -1
    X977      R0                            1
    X977      R437                          1
    X977      R438                          -1
    X978      R0                            1
    X978      R438                          1
    X978      R439                          -1
    X979      R0                            1
    X979      R439                          1
    X979      R440                          -1
    X980      R0                            6
    X980      R440                          1
    X980      R441                          -1
    X981      R0                            6
    X981      R441                          1
    X981      R442                          -1
    X982      R0                            1
    X982      R442                          1
    X982      R443                          -1
    X983      R0                            1
    X983      R443                          1
    X983      R444                          -1
    X984      R0                            6
    X984      R444                          1
    X984      R445                          -1
    X985      R0                            1
    X985      R445                          1
    X985      R446                          -1
    X986      R0                            1
    X986      R446                          1
    X986      R447                          -1
    X987      R0                            6
    X987      R447                          1
    X987      R448                          -1
    X988      R0                            6
    X988      R448                          1
    X988      R449                          -1
    X989      R0                            1
    X989      R449                          1
    X989      R450                          -1
RHS
    RHS       R1                            16
    RHS       R2                            17
    RHS       R3                            7
    RHS       R4                            18
    RHS       R5                            5
    RHS       R6                            22
    RHS       R7                            6
    RHS       R8                            29
    RHS       R9                            29
    RHS       R10                           17
    RHS       R11                           5
    RHS       R12                           16
    RHS       R13                           20
    RHS       R14                           6
    RHS       R15                           26
    RHS       R16                           12
    RHS       R17                           4
    RHS       R18                           2
    RHS       R19                           1
    RHS       R20                           19
    RHS       R21                           19
    RHS       R22                           12
    RHS       R23                           17
    RHS       R24                           3
    RHS       R25                           13
    RHS       R26                           11
    RHS       R27                           25
    RHS       R28                           14
    RHS       R29                           8
    RHS       R30                           5
    RHS       R31                           22
    RHS       R32                           23
    RHS       R33                           14
    RHS       R34                           29
    RHS       R35                           2
    RHS       R36                           18
    RHS       R37                           20
    RHS       R38                           30
    RHS       R39                           8
    RHS       R40                           10
    RHS       R41                           16
    RHS       R42                           4
    RHS       R43                           25
    RHS       R44                           27
    RHS       R45                           9
    RHS       R46                           13
    RHS       R47                           30
    RHS       R48                           5
    RHS       R49                           14
    RHS       R50                           30
    RHS       R101                          23
    RHS       R102                          3
    RHS       R103                          3
    RHS       R104                          2
    RHS       R105                          27
    RHS       R106                          15
    RHS       R107                          12
    RHS       R108                          13
    RHS       R109                          21
    RHS       R110                          19
    RHS       R111                          18
    RHS       R112                          12
    RHS       R113                          4
    RHS       R114                          23
    RHS       R115                          10
    RHS       R116                          5
    RHS       R117                          2
    RHS       R118                          21
    RHS       R119                          4
    RHS       R120                          9
    RHS       R121                          30
    RHS       R122                          11
    RHS       R123                          4
    RHS       R124                          17
    RHS       R125                          30
    RHS       R126                          4
    RHS       R127                          29
    RHS       R128                          29
    RHS       R129                          8
    RHS       R130                          12
    RHS       R131                          21
    RHS       R132                          1
    RHS       R133                          6
    RHS       R134                          23
    RHS       R135                          2
    RHS       R136                          2
    RHS       R137                          30
    RHS       R138                          13
    RHS       R139                          15
    RHS       R140                          20
    RHS       R141                          23
    RHS       R142                          24
    RHS       R143                          23
    RHS       R144                          26
    RHS       R145                          16
    RHS       R146                          25
    RHS       R147                          23
    RHS       R148                          9
    RHS       R149                          15
    RHS       R150                          26
    RHS       R201                          9
    RHS       R202                          7
    RHS       R203                          29
    RHS       R204                          12
    RHS       R205                          23
    RHS       R206                          28
    RHS       R207                          15
    RHS       R208                          21
    RHS       R209                          26
    RHS       R210                          23
    RHS       R211                          24
    RHS       R212                          16
    RHS       R213                          15
    RHS       R214                          22
    RHS       R215                          1
    RHS       R216                          16
    RHS       R217                          15
    RHS       R218                          22
    RHS       R219                          20
    RHS       R220                          29
    RHS       R221                          11
    RHS       R222                          4
    RHS       R223                          14
    RHS       R224                          25
    RHS       R225                          30
    RHS       R226                          21
    RHS       R227                          19
    RHS       R228                          22
    RHS       R229                          29
    RHS       R230                          26
    RHS       R231                          9
    RHS       R232                          7
    RHS       R233                          2
    RHS       R234                          7
    RHS       R235                          18
    RHS       R236                          16
    RHS       R237                          26
    RHS       R238                          3
    RHS       R239                          28
    RHS       R240                          22
    RHS       R241                          17
    RHS       R242                          21
    RHS       R243                          29
    RHS       R244                          1
    RHS       R245                          4
    RHS       R246                          21
    RHS       R247                          8
    RHS       R248                          19
    RHS       R249                          12
    RHS       R250                          19
    RHS       R301                          9
    RHS       R302                          14
    RHS       R303                          22
    RHS       R304                          23
    RHS       R305                          9
    RHS       R306                          21
    RHS       R307                          5
    RHS       R308                          19
    RHS       R309                          4
    RHS       R310                          4
    RHS       R311                          14
    RHS       R312                          13
    RHS       R313                          2
    RHS       R314                          7
    RHS       R315                          11
    RHS       R316                          20
    RHS       R317                          22
    RHS       R318                          7
    RHS       R319                          14
    RHS       R320                          19
    RHS       R321                          20
    RHS       R322                          22
    RHS       R323                          2
    RHS       R324                          10
    RHS       R325                          22
    RHS       R326                          27
    RHS       R327                          1
    RHS       R328                          21
    RHS       R329                          15
    RHS       R330                          12
    RHS       R331                          9
    RHS       R332                          24
    RHS       R333                          26
    RHS       R334                          30
    RHS       R335                          8
    RHS       R336                          4
    RHS       R337                          13
    RHS       R338                          12
    RHS       R339                          22
    RHS       R340                          8
    RHS       R341                          7
    RHS       R342                          28
    RHS       R343                          12
    RHS       R344                          9
    RHS       R345                          4
    RHS       R346                          23
    RHS       R347                          20
    RHS       R348                          18
    RHS       R349                          21
    RHS       R350                          3
    RHS       R401                          28
    RHS       R402                          10
    RHS       R403                          24
    RHS       R404                          21
    RHS       R405                          19
    RHS       R406                          7
    RHS       R407                          18
    RHS       R408                          11
    RHS       R409                          27
    RHS       R410                          2
    RHS       R411                          23
    RHS       R412                          5
    RHS       R413                          17
    RHS       R414                          18
    RHS       R415                          26
    RHS       R416                          16
    RHS       R417                          13
    RHS       R418                          30
    RHS       R419                          28
    RHS       R420                          4
    RHS       R421                          8
    RHS       R422                          4
    RHS       R423                          23
    RHS       R424                          11
    RHS       R425                          4
    RHS       R426                          27
    RHS       R427                          3
    RHS       R428                          23
    RHS       R429                          6
    RHS       R430                          15
    RHS       R431                          25
    RHS       R432                          3
    RHS       R433                          16
    RHS       R434                          10
    RHS       R435                          24
    RHS       R436                          27
    RHS       R437                          16
    RHS       R438                          11
    RHS       R439                          7
    RHS       R440                          4
    RHS       R441                          4
    RHS       R442                          29
    RHS       R443                          8
    RHS       R444                          21
    RHS       R445                          16
    RHS       R446                          26
    RHS       R447                          6
    RHS       R448                          20
    RHS       R449                          17
    RHS       R450                          25
    RHS       R501                          1
    RHS       R502                          1
    RHS       R503                          1
    RHS       R504                          1
    RHS       R505                          1
    RHS       R506                          1
    RHS       R507                          1
    RHS       R508                          1
    RHS       R509                          1
    RHS       R510                          1
    RHS       R511                          1
    RHS       R512                          1
    RHS       R513                          1
    RHS       R514                          1
    RHS       R515                          1
    RHS       R516                          1
    RHS       R517                          1
    RHS       R518                          1
    RHS       R519                          1
    RHS       R520                          1
    RHS       R521                          1
    RHS       R522                          1
    RHS       R523                          1
    RHS       R524                          1
    RHS       R525                          1
    RHS       R526                          1
    RHS       R527                          1
    RHS       R528                          1
    RHS       R529                          1
    RHS       R530                          1
    RHS       R531                          1
    RHS       R532                          1
    RHS       R533                          1
    RHS       R534                          1
    RHS       R535                          1
    RHS       R536                          1
    RHS       R537                          1
    RHS       R538                          1
    RHS       R539                          1
    RHS       R540                          1
    RHS       R541                          1
    RHS       R542                          1
    RHS       R543                          1
    RHS       R544                          1
    RHS       R545                          1
    RHS       R546                          1
    RHS       R547                          1
    RHS       R548                          1
    RHS       R549                          1
    RHS       R550                          1
BOUNDS
 UP BND       X0                            753
 UP BND       X1                            753
 UP BND       X2                            753
 UP BND       X3                            753
 UP BND       X4                            753
 UP BND       X5                            753
 UP BND       X6                            753
 UP BND       X7                            753
 UP BND       X8                            753
 UP BND       X9                            753
 UP BND       X10                           753
 UP BND       X11                           753
 UP BND       X12                           753
 UP BND       X13                           753
 UP BND       X14                           753
 UP BND       X15                           753
 UP BND       X16                           753
 UP BND       X17                           753
 UP BND       X18                           753
 UP BND       X19                           753
 UP BND       X20                           753
 UP BND       X21                           753
 UP BND       X22                           753
 UP BND       X23                           753
 UP BND       X24                           753
 UP BND       X25                           753
 UP BND       X26                           753
 UP BND       X27                           753
 UP BND       X28                           753
 UP BND       X29                           753
 UP BND       X30                           753
 UP BND       X31                           753
 UP BND       X32                           753
 UP BND       X33                           753
 UP BND       X34                           753
 UP BND       X35                           753
 UP BND       X36                           753
 UP BND       X37                           753
 UP BND       X38                           753
 UP BND       X39                           753
 UP BND       X40                           753
 UP BND       X41                           753
 UP BND       X42                           753
 UP BND       X43                           753
 UP BND       X44                           753
 UP BND       X45                           753
 UP BND       X46                           753
 UP BND       X47                           753
 UP BND       X48                           753
 UP BND       X49                           753
 UP BND       X50                           1
 UP BND       X51                           1
 UP BND       X52                           1
 UP BND       X53                           1
 UP BND       X54                           1
 UP BND       X55                           1
 UP BND       X56                           1
 UP BND       X57                           1
 UP BND       X58                           1
 UP BND       X59                           1
 UP BND       X60                           1
 UP BND       X61                           1
 UP BND       X62                           1
 UP BND       X63                           1
 UP BND       X64                           1
 UP BND       X65                           1
 UP BND       X66                           1
 UP BND       X67                           1
 UP BND       X68                           1
 UP BND       X69                           1
 UP BND       X70                           1
 UP BND       X71                           1
 UP BND       X72                           1
 UP BND       X73                           1
 UP BND       X74                           1
 UP BND       X75                           1
 UP BND       X76                           1
 UP BND       X77                           1
 UP BND       X78                           1
 UP BND       X79                           1
 UP BND       X80                           1
 UP BND       X81                           1
 UP BND       X82                           1
 UP BND       X83                           1
 UP BND       X84                           1
 UP BND       X85                           1
 UP BND       X86                           1
 UP BND       X87                           1
 UP BND       X88                           1
 UP BND       X89                           1
 UP BND       X90                           1
 UP BND       X91                           1
 UP BND       X92                           1
 UP BND       X93                           1
 UP BND       X94                           1
 UP BND       X95                           1
 UP BND       X96                           1
 UP BND       X97                           1
 UP BND       X98                           1
 UP BND       X99                           1
 UP BND       X100                          753
 UP BND       X101                          753
 UP BND       X102                          753
 UP BND       X103                          753
 UP BND       X104                          753
 UP BND       X105                          753
 UP BND       X106                          753
 UP BND       X107                          753
 UP BND       X108                          753
 UP BND       X109                          753
 UP BND       X110                          753
 UP BND       X111                          753
 UP BND       X112                          753
 UP BND       X113                          753
 UP BND       X114                          753
 UP BND       X115                          753
 UP BND       X116                          753
 UP BND       X117                          753
 UP BND       X118                          753
 UP BND       X119                          753
 UP BND       X120                          753
 UP BND       X121                          753
 UP BND       X122                          753
 UP BND       X123                          753
 UP BND       X124                          753
 UP BND       X125                          753
 UP BND       X126                          753
 UP BND       X127                          753
 UP BND       X128                          753
 UP BND       X129                          753
 UP BND       X130                          753
 UP BND       X131                          753
 UP BND       X132                          753
 UP BND       X133                          753
 UP BND       X134                          753
 UP BND       X135                          753
 UP BND       X136                          753
 UP BND       X137                          753
 UP BND       X138                          753
 UP BND       X139                          753
 UP BND       X140                          753
 UP BND       X141                          753
 UP BND       X142                          753
 UP BND       X143                          753
 UP BND       X144                          753
 UP BND       X145                          753
 UP BND       X146                          753
 UP BND       X147                          753
 UP BND       X148                          753
 UP BND       X149                          753
 UP BND       X150                          753
 UP BND       X151                          753
 UP BND       X152                          753
 UP BND       X153                          753
 UP BND       X154                          753
 UP BND       X155                          753
 UP BND       X156                          753
 UP BND       X157                          753
 UP BND       X158                          753
 UP BND       X159                          753
 UP BND       X160                          753
 UP BND       X161                          753
 UP BND       X162                          753
 UP BND       X163                          753
 UP BND       X164                          753
 UP BND       X165                          753
 UP BND       X166                          753
 UP BND       X167                          753
 UP BND       X168                          753
 UP BND       X169                          753
 UP BND       X170                          753
 UP BND       X171                          753
 UP BND       X172                          753
 UP BND       X173                          753
 UP BND       X174                          753
 UP BND       X175                          753
 UP BND       X176                          753
 UP BND       X177                          753
 UP BND       X178                          753
 UP BND       X179                          753
 UP BND       X180                          753
 UP BND       X181                          753
 UP BND       X182                          753
 UP BND       X183                          753
 UP BND       X184                          753
 UP BND       X185                          753
 UP BND       X186                          753
 UP BND       X187                          753
 UP BND       X188                          753
 UP BND       X189                          753
 UP BND       X190                          753
 UP BND       X191                          753
 UP BND       X192                          753
 UP BND       X193                          753
 UP BND       X194                          753
 UP BND       X195                          753
 UP BND       X196                          753
 UP BND       X197                          753
 UP BND       X198                          763
 UP BND       X199                          763
 UP BND       X200                          763
 UP BND       X201                          763
 UP BND       X202                          763
 UP BND       X203                          763
 UP BND       X204                          763
 UP BND       X205                          763
 UP BND       X206                          763
 UP BND       X207                          763
 UP BND       X208                          763
 UP BND       X209                          763
 UP BND       X210                          763
 UP BND       X211                          763
 UP BND       X212                          763
 UP BND       X213                          763
 UP BND       X214                          763
 UP BND       X215                          763
 UP BND       X216                          763
 UP BND       X217                          763
 UP BND       X218                          763
 UP BND       X219                          763
 UP BND       X220                          763
 UP BND       X221                          763
 UP BND       X222                          763
 UP BND       X223                          763
 UP BND       X224                          763
 UP BND       X225                          763
 UP BND       X226                          763
 UP BND       X227                          763
 UP BND       X228                          763
 UP BND       X229                          763
 UP BND       X230                          763
 UP BND       X231                          763
 UP BND       X232                          763
 UP BND       X233                          763
 UP BND       X234                          763
 UP BND       X235                          763
 UP BND       X236                          763
 UP BND       X237                          763
 UP BND       X238                          763
 UP BND       X239                          763
 UP BND       X240                          763
 UP BND       X241                          763
 UP BND       X242                          763
 UP BND       X243                          763
 UP BND       X244                          763
 UP BND       X245                          763
 UP BND       X246                          763
 UP BND       X247                          763
 UP BND       X248                          1
 UP BND       X249                          1
 UP BND       X250                          1
 UP BND       X251                          1
 UP BND       X252                          1
 UP BND       X253                          1
 UP BND       X254                          1
 UP BND       X255                          1
 UP BND       X256                          1
 UP BND       X257                          1
 UP BND       X258                          1
 UP BND       X259                          1
 UP BND       X260                          1
 UP BND       X261                          1
 UP BND       X262                          1
 UP BND       X263                          1
 UP BND       X264                          1
 UP BND       X265                          1
 UP BND       X266                          1
 UP BND       X267                          1
 UP BND       X268                          1
 UP BND       X269                          1
 UP BND       X270                          1
 UP BND       X271                          1
 UP BND       X272                          1
 UP BND       X273                          1
 UP BND       X274                          1
 UP BND       X275                          1
 UP BND       X276                          1
 UP BND       X277                          1
 UP BND       X278                          1
 UP BND       X279                          1
 UP BND       X280                          1
 UP BND       X281                          1
 UP BND       X282                          1
 UP BND       X283                          1
 UP BND       X284                          1
 UP BND       X285                          1
 UP BND       X286                          1
 UP BND       X287                          1
 UP BND       X288                          1
 UP BND       X289                          1
 UP BND       X290                          1
 UP BND       X291                          1
 UP BND       X292                          1
 UP BND       X293                          1
 UP BND       X294                          1
 UP BND       X295                          1
 UP BND       X296                          1
 UP BND       X297                          1
 UP BND       X298                          763
 UP BND       X299                          763
 UP BND       X300                          763
 UP BND       X301                          763
 UP BND       X302                          763
 UP BND       X303                          763
 UP BND       X304                          763
 UP BND       X305                          763
 UP BND       X306                          763
 UP BND       X307                          763
 UP BND       X308                          763
 UP BND       X309                          763
 UP BND       X310                          763
 UP BND       X311                          763
 UP BND       X312                          763
 UP BND       X313                          763
 UP BND       X314                          763
 UP BND       X315                          763
 UP BND       X316                          763
 UP BND       X317                          763
 UP BND       X318                          763
 UP BND       X319                          763
 UP BND       X320                          763
 UP BND       X321                          763
 UP BND       X322                          763
 UP BND       X323                          763
 UP BND       X324                          763
 UP BND       X325                          763
 UP BND       X326                          763
 UP BND       X327                          763
 UP BND       X328                          763
 UP BND       X329                          763
 UP BND       X330                          763
 UP BND       X331                          763
 UP BND       X332                          763
 UP BND       X333                          763
 UP BND       X334                          763
 UP BND       X335                          763
 UP BND       X336                          763
 UP BND       X337                          763
 UP BND       X338                          763
 UP BND       X339                          763
 UP BND       X340                          763
 UP BND       X341                          763
 UP BND       X342                          763
 UP BND       X343                          763
 UP BND       X344                          763
 UP BND       X345                          763
 UP BND       X346                          763
 UP BND       X347                          763
 UP BND       X348                          763
 UP BND       X349                          763
 UP BND       X350                          763
 UP BND       X351                          763
 UP BND       X352                          763
 UP BND       X353                          763
 UP BND       X354                          763
 UP BND       X355                          763
 UP BND       X356                          763
 UP BND       X357                          763
 UP BND       X358                          763
 UP BND       X359                          763
 UP BND       X360                          763
 UP BND       X361                          763
 UP BND       X362                          763
 UP BND       X363                          763
 UP BND       X364                          763
 UP BND       X365                          763
 UP BND       X366                          763
 UP BND       X367                          763
 UP BND       X368                          763
 UP BND       X369                          763
 UP BND       X370                          763
 UP BND       X371                          763
 UP BND       X372                          763
 UP BND       X373                          763
 UP BND       X374                          763
 UP BND       X375                          763
 UP BND       X376                          763
 UP BND       X377                          763
 UP BND       X378                          763
 UP BND       X379                          763
 UP BND       X380                          763
 UP BND       X381                          763
 UP BND       X382                          763
 UP BND       X383                          763
 UP BND       X384                          763
 UP BND       X385                          763
 UP BND       X386                          763
 UP BND       X387                          763
 UP BND       X388                          763
 UP BND       X389                          763
 UP BND       X390                          763
 UP BND       X391                          763
 UP BND       X392                          763
 UP BND       X393                          763
 UP BND       X394                          763
 UP BND       X395                          763
 UP BND       X396                          863
 UP BND       X397                          863
 UP BND       X398                          863
 UP BND       X399                          863
 UP BND       X400                          863
 UP BND       X401                          863
 UP BND       X402                          863
 UP BND       X403                          863
 UP BND       X404                          863
 UP BND       X405                          863
 UP BND       X406                          863
 UP BND       X407                          863
 UP BND       X408                          863
 UP BND       X409                          863
 UP BND       X410                          863
 UP BND       X411                          863
 UP BND       X412                          863
 UP BND       X413                          863
 UP BND       X414                          863
 UP BND       X415                          863
 UP BND       X416                          863
 UP BND       X417                          863
 UP BND       X418                          863
 UP BND       X419                          863
 UP BND       X420                          863
 UP BND       X421                          863
 UP BND       X422                          863
 UP BND       X423                          863
 UP BND       X424                          863
 UP BND       X425                          863
 UP BND       X426                          863
 UP BND       X427                          863
 UP BND       X428                          863
 UP BND       X429                          863
 UP BND       X430                          863
 UP BND       X431                          863
 UP BND       X432                          863
 UP BND       X433                          863
 UP BND       X434                          863
 UP BND       X435                          863
 UP BND       X436                          863
 UP BND       X437                          863
 UP BND       X438                          863
 UP BND       X439                          863
 UP BND       X440                          863
 UP BND       X441                          863
 UP BND       X442                          863
 UP BND       X443                          863
 UP BND       X444                          863
 UP BND       X445                          863
 UP BND       X446                          1
 UP BND       X447                          1
 UP BND       X448                          1
 UP BND       X449                          1
 UP BND       X450                          1
 UP BND       X451                          1
 UP BND       X452                          1
 UP BND       X453                          1
 UP BND       X454                          1
 UP BND       X455                          1
 UP BND       X456                          1
 UP BND       X457                          1
 UP BND       X458                          1
 UP BND       X459                          1
 UP BND       X460                          1
 UP BND       X461                          1
 UP BND       X462                          1
 UP BND       X463                          1
 UP BND       X464                          1
 UP BND       X465                          1
 UP BND       X466                          1
 UP BND       X467                          1
 UP BND       X468                          1
 UP BND       X469                          1
 UP BND       X470                          1
 UP BND       X471                          1
 UP BND       X472                          1
 UP BND       X473                          1
 UP BND       X474                          1
 UP BND       X475                          1
 UP BND       X476                          1
 UP BND       X477                          1
 UP BND       X478                          1
 UP BND       X479                          1
 UP BND       X480                          1
 UP BND       X481                          1
 UP BND       X482                          1
 UP BND       X483                          1
 UP BND       X484                          1
 UP BND       X485                          1
 UP BND       X486                          1
 UP BND       X487                          1
 UP BND       X488                          1
 UP BND       X489                          1
 UP BND       X490                          1
 UP BND       X491                          1
 UP BND       X492                          1
 UP BND       X493                          1
 UP BND       X494                          1
 UP BND       X495                          1
 UP BND       X496                          863
 UP BND       X497                          863
 UP BND       X498                          863
 UP BND       X499                          863
 UP BND       X500                          863
 UP BND       X501                          863
 UP BND       X502                          863
 UP BND       X503                          863
 UP BND       X504                          863
 UP BND       X505                          863
 UP BND       X506                          863
 UP BND       X507                          863
 UP BND       X508                          863
 UP BND       X509                          863
 UP BND       X510                          863
 UP BND       X511                          863
 UP BND       X512                          863
 UP BND       X513                          863
 UP BND       X514                          863
 UP BND       X515                          863
 UP BND       X516                          863
 UP BND       X517                          863
 UP BND       X518                          863
 UP BND       X519                          863
 UP BND       X520                          863
 UP BND       X521                          863
 UP BND       X522                          863
 UP BND       X523                          863
 UP BND       X524                          863
 UP BND       X525                          863
 UP BND       X526                          863
 UP BND       X527                          863
 UP BND       X528                          863
 UP BND       X529                          863
 UP BND       X530                          863
 UP BND       X531                          863
 UP BND       X532                          863
 UP BND       X533                          863
 UP BND       X534                          863
 UP BND       X535                          863
 UP BND       X536                          863
 UP BND       X537                          863
 UP BND       X538                          863
 UP BND       X539                          863
 UP BND       X540                          863
 UP BND       X541                          863
 UP BND       X542                          863
 UP BND       X543                          863
 UP BND       X544                          863
 UP BND       X545                          863
 UP BND       X546                          863
 UP BND       X547                          863
 UP BND       X548                          863
 UP BND       X549                          863
 UP BND       X550                          863
 UP BND       X551                          863
 UP BND       X552                          863
 UP BND       X553                          863
 UP BND       X554                          863
 UP BND       X555                          863
 UP BND       X556                          863
 UP BND       X557                          863
 UP BND       X558                          863
 UP BND       X559                          863
 UP BND       X560                          863
 UP BND       X561                          863
 UP BND       X562                          863
 UP BND       X563                          863
 UP BND       X564                          863
 UP BND       X565                          863
 UP BND       X566                          863
 UP BND       X567                          863
 UP BND       X568                          863
 UP BND       X569                          863
 UP BND       X570                          863
 UP BND       X571                          863
 UP BND       X572                          863
 UP BND       X573                          863
 UP BND       X574                          863
 UP BND       X575                          863
 UP BND       X576                          863
 UP BND       X577                          863
 UP BND       X578                          863
 UP BND       X579                          863
 UP BND       X580                          863
 UP BND       X581                          863
 UP BND       X582                          863
 UP BND       X583                          863
 UP BND       X584                          863
 UP BND       X585                          863
 UP BND       X586                          863
 UP BND       X587                          863
 UP BND       X588                          863
 UP BND       X589                          863
 UP BND       X590                          863
 UP BND       X591                          863
 UP BND       X592                          863
 UP BND       X593                          863
 UP BND       X594                          712
 UP BND       X595                          712
 UP BND       X596                          712
 UP BND       X597                          712
 UP BND       X598                          712
 UP BND       X599                          712
 UP BND       X600                          712
 UP BND       X601                          712
 UP BND       X602                          712
 UP BND       X603                          712
 UP BND       X604                          712
 UP BND       X605                          712
 UP BND       X606                          712
 UP BND       X607                          712
 UP BND       X608                          712
 UP BND       X609                          712
 UP BND       X610                          712
 UP BND       X611                          712
 UP BND       X612                          712
 UP BND       X613                          712
 UP BND       X614                          712
 UP BND       X615                          712
 UP BND       X616                          712
 UP BND       X617                          712
 UP BND       X618                          712
 UP BND       X619                          712
 UP BND       X620                          712
 UP BND       X621                          712
 UP BND       X622                          712
 UP BND       X623                          712
 UP BND       X624                          712
 UP BND       X625                          712
 UP BND       X626                          712
 UP BND       X627                          712
 UP BND       X628                          712
 UP BND       X629                          712
 UP BND       X630                          712
 UP BND       X631                          712
 UP BND       X632                          712
 UP BND       X633                          712
 UP BND       X634                          712
 UP BND       X635                          712
 UP BND       X636                          712
 UP BND       X637                          712
 UP BND       X638                          712
 UP BND       X639                          712
 UP BND       X640                          712
 UP BND       X641                          712
 UP BND       X642                          712
 UP BND       X643                          712
 UP BND       X644                          1
 UP BND       X645                          1
 UP BND       X646                          1
 UP BND       X647                          1
 UP BND       X648                          1
 UP BND       X649                          1
 UP BND       X650                          1
 UP BND       X651                          1
 UP BND       X652                          1
 UP BND       X653                          1
 UP BND       X654                          1
 UP BND       X655                          1
 UP BND       X656                          1
 UP BND       X657                          1
 UP BND       X658                          1
 UP BND       X659                          1
 UP BND       X660                          1
 UP BND       X661                          1
 UP BND       X662                          1
 UP BND       X663                          1
 UP BND       X664                          1
 UP BND       X665                          1
 UP BND       X666                          1
 UP BND       X667                          1
 UP BND       X668                          1
 UP BND       X669                          1
 UP BND       X670                          1
 UP BND       X671                          1
 UP BND       X672                          1
 UP BND       X673                          1
 UP BND       X674                          1
 UP BND       X675                          1
 UP BND       X676                          1
 UP BND       X677                          1
 UP BND       X678                          1
 UP BND       X679                          1
 UP BND       X680                          1
 UP BND       X681                          1
 UP BND       X682                          1
 UP BND       X683                          1
 UP BND       X684                          1
 UP BND       X685                          1
 UP BND       X686                          1
 UP BND       X687                          1
 UP BND       X688                          1
 UP BND       X689                          1
 UP BND       X690                          1
 UP BND       X691                          1
 UP BND       X692                          1
 UP BND       X693                          1
 UP BND       X694                          712
 UP BND       X695                          712
 UP BND       X696                          712
 UP BND       X697                          712
 UP BND       X698                          712
 UP BND       X699                          712
 UP BND       X700                          712
 UP BND       X701                          712
 UP BND       X702                          712
 UP BND       X703                          712
 UP BND       X704                          712
 UP BND       X705                          712
 UP BND       X706                          712
 UP BND       X707                          712
 UP BND       X708                          712
 UP BND       X709                          712
 UP BND       X710                          712
 UP BND       X711                          712
 UP BND       X712                          712
 UP BND       X713                          712
 UP BND       X714                          712
 UP BND       X715                          712
 UP BND       X716                          712
 UP BND       X717                          712
 UP BND       X718                          712
 UP BND       X719                          712
 UP BND       X720                          712
 UP BND       X721                          712
 UP BND       X722                          712
 UP BND       X723                          712
 UP BND       X724                          712
 UP BND       X725                          712
 UP BND       X726                          712
 UP BND       X727                          712
 UP BND       X728                          712
 UP BND       X729                          712
 UP BND       X730                          712
 UP BND       X731                          712
 UP BND       X732                          712
 UP BND       X733                          712
 UP BND       X734                          712
 UP BND       X735                          712
 UP BND       X736                          712
 UP BND       X737                          712
 UP BND       X738                          712
 UP BND       X739                          712
 UP BND       X740                          712
 UP BND       X741                          712
 UP BND       X742                          712
 UP BND       X743                          712
 UP BND       X744                          712
 UP BND       X745                          712
 UP BND       X746                          712
 UP BND       X747                          712
 UP BND       X748                          712
 UP BND       X749                          712
 UP BND       X750                          712
 UP BND       X751                          712
 UP BND       X752                          712
 UP BND       X753                          712
 UP BND       X754                          712
 UP BND       X755                          712
 UP BND       X756                          712
 UP BND       X757                          712
 UP BND       X758                          712
 UP BND       X759                          712
 UP BND       X760                          712
 UP BND       X761                          712
 UP BND       X762                          712
 UP BND       X763                          712
 UP BND       X764                          712
 UP BND       X765                          712
 UP BND       X766                          712
 UP BND       X767                          712
 UP BND       X768                          712
 UP BND       X769                          712
 UP BND       X770                          712
 UP BND       X771                          712
 UP BND       X772                          712
 UP BND       X773                          712
 UP BND       X774                          712
 UP BND       X775                          712
 UP BND       X776                          712
 UP BND       X777                          712
 UP BND       X778                          712
 UP BND       X779                          712
 UP BND       X780                          712
 UP BND       X781                          712
 UP BND       X782                          712
 UP BND       X783                          712
 UP BND       X784                          712
 UP BND       X785                          712
 UP BND       X786                          712
 UP BND       X787                          712
 UP BND       X788                          712
 UP BND       X789                          712
 UP BND       X790                          712
 UP BND       X791                          712
 UP BND       X792                          786
 UP BND       X793                          786
 UP BND       X794                          786
 UP BND       X795                          786
 UP BND       X796                          786
 UP BND       X797                          786
 UP BND       X798                          786
 UP BND       X799                          786
 UP BND       X800                          786
 UP BND       X801                          786
 UP BND       X802                          786
 UP BND       X803                          786
 UP BND       X804                          786
 UP BND       X805                          786
 UP BND       X806                          786
 UP BND       X807                          786
 UP BND       X808                          786
 UP BND       X809                          786
 UP BND       X810                          786
 UP BND       X811                          786
 UP BND       X812                          786
 UP BND       X813                          786
 UP BND       X814                          786
 UP BND       X815                          786
 UP BND       X816                          786
 UP BND       X817                          786
 UP BND       X818                          786
 UP BND       X819                          786
 UP BND       X820                          786
 UP BND       X821                          786
 UP BND       X822                          786
 UP BND       X823                          786
 UP BND       X824                          786
 UP BND       X825                          786
 UP BND       X826                          786
 UP BND       X827                          786
 UP BND       X828                          786
 UP BND       X829                          786
 UP BND       X830                          786
 UP BND       X831                          786
 UP BND       X832                          786
 UP BND       X833                          786
 UP BND       X834                          786
 UP BND       X835                          786
 UP BND       X836                          786
 UP BND       X837                          786
 UP BND       X838                          786
 UP BND       X839                          786
 UP BND       X840                          786
 UP BND       X841                          786
 UP BND       X842                          1
 UP BND       X843                          1
 UP BND       X844                          1
 UP BND       X845                          1
 UP BND       X846                          1
 UP BND       X847                          1
 UP BND       X848                          1
 UP BND       X849                          1
 UP BND       X850                          1
 UP BND       X851                          1
 UP BND       X852                          1
 UP BND       X853                          1
 UP BND       X854                          1
 UP BND       X855                          1
 UP BND       X856                          1
 UP BND       X857                          1
 UP BND       X858                          1
 UP BND       X859                          1
 UP BND       X860                          1
 UP BND       X861                          1
 UP BND       X862                          1
 UP BND       X863                          1
 UP BND       X864                          1
 UP BND       X865                          1
 UP BND       X866                          1
 UP BND       X867                          1
 UP BND       X868                          1
 UP BND       X869                          1
 UP BND       X870                          1
 UP BND       X871                          1
 UP BND       X872                          1
 UP BND       X873                          1
 UP BND       X874                          1
 UP BND       X875                          1
 UP BND       X876                          1
 UP BND       X877                          1
 UP BND       X878                          1
 UP BND       X879                          1
 UP BND       X880                          1
 UP BND       X881                          1
 UP BND       X882                          1
 UP BND       X883                          1
 UP BND       X884                          1
 UP BND       X885                          1
 UP BND       X886                          1
 UP BND       X887                          1
 UP BND       X888                          1
 UP BND       X889                          1
 UP BND       X890                          1
 UP BND       X891                          1
 UP BND       X892                          786
 UP BND       X893                          786
 UP BND       X894                          786
 UP BND       X895                          786
 UP BND       X896                          786
 UP BND       X897                          786
 UP BND       X898                          786
 UP BND       X899                          786
 UP BND       X900                          786
 UP BND       X901                          786
 UP BND       X902                          786
 UP BND       X903                          786
 UP BND       X904                          786
 UP BND       X905                          786
 UP BND       X906                          786
 UP BND       X907                          786
 UP BND       X908                          786
 UP BND       X909                          786
 UP BND       X910                          786
 UP BND       X911                          786
 UP BND       X912                          786
 UP BND       X913                          786
 UP BND       X914                          786
 UP BND       X915                          786
 UP BND       X916                          786
 UP BND       X917                          786
 UP BND       X918                          786
 UP BND       X919                          786
 UP BND       X920                          786
 UP BND       X921                          786
 UP BND       X922                          786
 UP BND       X923                          786
 UP BND       X924                          786
 UP BND       X925                          786
 UP BND       X926                          786
 UP BND       X927                          786
 UP BND       X928                          786
 UP BND       X929                          786
 UP BND       X930                          786
 UP BND       X931                          786
 UP BND       X932                          786
 UP BND       X933                          786
 UP BND       X934                          786
 UP BND       X935                          786
 UP BND       X936                          786
 UP BND       X937                          786
 UP BND       X938                          786
 UP BND       X939                          786
 UP BND       X940                          786
 UP BND       X941                          786
 UP BND       X942                          786
 UP BND       X943                          786
 UP BND       X944                          786
 UP BND       X945                          786
 UP BND       X946                          786
 UP BND       X947                          786
 UP BND       X948                          786
 UP BND       X949                          786
 UP BND       X950                          786
 UP BND       X951                          786
 UP BND       X952                          786
 UP BND       X953                          786
 UP BND       X954                          786
 UP BND       X955                          786
 UP BND       X956                          786
 UP BND       X957                          786
 UP BND       X958                          786
 UP BND       X959                          786
 UP BND       X960                          786
 UP BND       X961                          786
 UP BND       X962                          786
 UP BND       X963                          786
 UP BND       X964                          786
 UP BND       X965                          786
 UP BND       X966                          786
 UP BND       X967                          786
 UP BND       X968                          786
 UP BND       X969                          786
 UP BND       X970                          786
 UP BND       X971                          786
 UP BND       X972                          786
 UP BND       X973                          786
 UP BND       X974                          786
 UP BND       X975                          786
 UP BND       X976                          786
 UP BND       X977                          786
 UP BND       X978                          786
 UP BND       X979                          786
 UP BND       X980                          786
 UP BND       X981                          786
 UP BND       X982                          786
 UP BND       X983                          786
 UP BND       X984                          786
 UP BND       X985                          786
 UP BND       X986                          786
 UP BND       X987                          786
 UP BND       X988                          786
 UP BND       X989                          786
ENDATA
