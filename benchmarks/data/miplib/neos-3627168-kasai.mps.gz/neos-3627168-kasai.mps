NAME          neos-3627168-kasai
ROWS
 E R0
 E R1
 E R2
 L R3
 L R4
 L R5
 L R6
 L R7
 L R8
 L R9
 L R10
 L R11
 L R12
 L R13
 L R14
 L R15
 L R16
 L R17
 L R18
 L R19
 L R20
 L R21
 L R22
 L R23
 L R24
 L R25
 L R26
 L R27
 L R28
 L R29
 L R30
 L R31
 L R32
 L R33
 L R34
 L R35
 L R36
 L R37
 L R38
 L R39
 L R40
 L R41
 L R42
 L R43
 L R44
 L R45
 L R46
 L R47
 L R48
 L R49
 L R50
 L R51
 L R52
 L R53
 L R54
 L R55
 L R56
 L R57
 L R58
 L R59
 L R60
 L R61
 L R62
 L R63
 L R64
 L R65
 L R66
 L R67
 L R68
 L R69
 L R70
 L R71
 L R72
 L R73
 L R74
 L R75
 L R76
 L R77
 L R78
 L R79
 L R80
 L R81
 L R82
 L R83
 L R84
 L R85
 L R86
 L R87
 L R88
 L R89
 L R90
 L R91
 L R92
 L R93
 L R94
 L R95
 L R96
 L R97
 L R98
 L R99
 L R100
 L R101
 L R102
 L R103
 L R104
 L R105
 L R106
 L R107
 L R108
 L R109
 L R110
 L R111
 L R112
 L R113
 L R114
 L R115
 L R116
 L R117
 L R118
 L R119
 L R120
 L R121
 L R122
 L R123
 L R124
 L R125
 L R126
 L R127
 L R128
 L R129
 L R130
 L R131
 L R132
 L R133
 L R134
 L R135
 L R136
 L R137
 L R138
 L R139
 L R140
 L R141
 L R142
 L R143
 L R144
 L R145
 L R146
 L R147
 L R148
 L R149
 L R150
 L R151
 L R152
 L R153
 L R154
 L R155
 L R156
 L R157
 L R158
 L R159
 L R160
 L R161
 L R162
 L R163
 L R164
 L R165
 L R166
 L R167
 L R168
 L R169
 L R170
 L R171
 L R172
 L R173
 L R174
 L R175
 L R176
 L R177
 L R178
 L R179
 L R180
 L R181
 L R182
 L R183
 L R184
 L R185
 L R186
 L R187
 L R188
 L R189
 L R190
 L R191
 L R192
 L R193
 L R194
 L R195
 L R196
 L R197
 L R198
 L R199
 L R200
 L R201
 L R202
 L R203
 L R204
 L R205
 L R206
 L R207
 L R208
 L R209
 L R210
 L R211
 L R212
 L R213
 L R214
 L R215
 L R216
 L R217
 L R218
 L R219
 L R220
 L R221
 L R222
 L R223
 L R224
 L R225
 L R226
 L R227
 L R228
 L R229
 L R230
 L R231
 L R232
 L R233
 L R234
 L R235
 L R236
 L R237
 L R238
 L R239
 L R240
 L R241
 L R242
 L R243
 L R244
 L R245
 L R246
 L R247
 L R248
 L R249
 L R250
 L R251
 L R252
 L R253
 L R254
 L R255
 L R256
 L R257
 L R258
 L R259
 L R260
 L R261
 L R262
 L R263
 L R264
 L R265
 L R266
 L R267
 L R268
 L R269
 L R270
 L R271
 L R272
 L R273
 L R274
 L R275
 L R276
 L R277
 L R278
 L R279
 L R280
 L R281
 L R282
 L R283
 L R284
 L R285
 L R286
 L R287
 L R288
 L R289
 L R290
 L R291
 L R292
 L R293
 L R294
 L R295
 L R296
 L R297
 L R298
 L R299
 L R300
 L R301
 L R302
 L R303
 L R304
 L R305
 L R306
 L R307
 L R308
 L R309
 L R310
 L R311
 L R312
 L R313
 L R314
 L R315
 L R316
 L R317
 L R318
 L R319
 L R320
 L R321
 L R322
 L R323
 L R324
 L R325
 L R326
 L R327
 L R328
 L R329
 L R330
 L R331
 L R332
 L R333
 L R334
 L R335
 L R336
 L R337
 L R338
 L R339
 L R340
 L R341
 L R342
 L R343
 L R344
 L R345
 L R346
 L R347
 L R348
 L R349
 L R350
 L R351
 L R352
 L R353
 L R354
 L R355
 L R356
 L R357
 L R358
 L R359
 L R360
 L R361
 L R362
 L R363
 L R364
 L R365
 L R366
 L R367
 L R368
 L R369
 L R370
 L R371
 L R372
 L R373
 L R374
 L R375
 L R376
 L R377
 L R378
 L R379
 L R380
 L R381
 L R382
 L R383
 L R384
 L R385
 L R386
 L R387
 L R388
 L R389
 L R390
 L R391
 L R392
 L R393
 L R394
 L R395
 L R396
 L R397
 L R398
 L R399
 L R400
 L R401
 L R402
 L R403
 L R404
 L R405
 L R406
 L R407
 L R408
 L R409
 L R410
 L R411
 L R412
 L R413
 L R414
 L R415
 L R416
 L R417
 L R418
 L R419
 L R420
 L R421
 L R422
 L R423
 L R424
 L R425
 L R426
 L R427
 L R428
 L R429
 L R430
 L R431
 L R432
 L R433
 L R434
 L R435
 L R436
 L R437
 L R438
 L R439
 L R440
 L R441
 L R442
 L R443
 L R444
 L R445
 L R446
 L R447
 L R448
 L R449
 L R450
 L R451
 L R452
 L R453
 L R454
 L R455
 L R456
 L R457
 L R458
 L R459
 L R460
 L R461
 L R462
 L R463
 L R464
 L R465
 L R466
 L R467
 L R468
 L R469
 L R470
 L R471
 L R472
 L R473
 L R474
 L R475
 L R476
 L R477
 L R478
 L R479
 L R480
 L R481
 L R482
 L R483
 L R484
 L R485
 L R486
 L R487
 L R488
 L R489
 L R490
 L R491
 L R492
 L R493
 L R494
 L R495
 L R496
 L R497
 L R498
 L R499
 L R500
 L R501
 L R502
 L R503
 L R504
 L R505
 L R506
 L R507
 L R508
 L R509
 L R510
 L R511
 L R512
 L R513
 L R514
 L R515
 L R516
 L R517
 L R518
 L R519
 L R520
 L R521
 L R522
 L R523
 L R524
 L R525
 L R526
 L R527
 L R528
 L R529
 L R530
 L R531
 L R532
 L R533
 L R534
 L R535
 L R536
 L R537
 L R538
 L R539
 L R540
 L R541
 L R542
 L R543
 L R544
 L R545
 L R546
 L R547
 L R548
 L R549
 L R550
 L R551
 L R552
 L R553
 L R554
 L R555
 L R556
 L R557
 L R558
 L R559
 L R560
 L R561
 L R562
 L R563
 L R564
 L R565
 L R566
 L R567
 L R568
 L R569
 L R570
 L R571
 L R572
 L R573
 L R574
 L R575
 L R576
 L R577
 L R578
 L R579
 L R580
 L R581
 L R582
 L R583
 L R584
 L R585
 L R586
 L R587
 L R588
 L R589
 L R590
 L R591
 L R592
 L R593
 L R594
 L R595
 L R596
 L R597
 L R598
 L R599
 L R600
 L R601
 L R602
 L R603
 L R604
 L R605
 L R606
 L R607
 L R608
 L R609
 L R610
 L R611
 L R612
 L R613
 L R614
 L R615
 L R616
 L R617
 L R618
 L R619
 L R620
 L R621
 L R622
 L R623
 L R624
 L R625
 L R626
 L R627
 L R628
 L R629
 L R630
 L R631
 L R632
 L R633
 L R634
 L R635
 L R636
 L R637
 L R638
 L R639
 L R640
 L R641
 L R642
 L R643
 L R644
 L R645
 L R646
 L R647
 L R648
 L R649
 L R650
 L R651
 L R652
 L R653
 L R654
 L R655
 L R656
 L R657
 L R658
 L R659
 L R660
 L R661
 L R662
 L R663
 L R664
 L R665
 L R666
 L R667
 L R668
 L R669
 L R670
 L R671
 L R672
 L R673
 L R674
 L R675
 L R676
 L R677
 L R678
 L R679
 L R680
 L R681
 L R682
 L R683
 L R684
 L R685
 L R686
 L R687
 L R688
 L R689
 L R690
 L R691
 L R692
 L R693
 L R694
 L R695
 L R696
 L R697
 L R698
 L R699
 L R700
 L R701
 L R702
 L R703
 L R704
 L R705
 L R706
 L R707
 L R708
 L R709
 L R710
 L R711
 L R712
 L R713
 L R714
 L R715
 L R716
 L R717
 L R718
 L R719
 L R720
 L R721
 L R722
 L R723
 L R724
 L R725
 L R726
 L R727
 L R728
 L R729
 L R730
 L R731
 L R732
 L R733
 L R734
 L R735
 L R736
 L R737
 L R738
 L R739
 L R740
 L R741
 L R742
 L R743
 L R744
 L R745
 L R746
 L R747
 L R748
 L R749
 L R750
 L R751
 L R752
 L R753
 L R754
 L R755
 L R756
 L R757
 L R758
 L R759
 L R760
 L R761
 L R762
 L R763
 L R764
 L R765
 L R766
 L R767
 L R768
 L R769
 L R770
 L R771
 L R772
 L R773
 L R774
 L R775
 L R776
 L R777
 L R778
 L R779
 L R780
 L R781
 L R782
 L R783
 L R784
 L R785
 L R786
 L R787
 L R788
 L R789
 L R790
 L R791
 L R792
 L R793
 L R794
 L R795
 L R796
 L R797
 L R798
 L R799
 L R800
 L R801
 L R802
 L R803
 L R804
 L R805
 L R806
 L R807
 L R808
 L R809
 L R810
 L R811
 L R812
 L R813
 L R814
 L R815
 L R816
 L R817
 L R818
 L R819
 L R820
 L R821
 L R822
 L R823
 L R824
 L R825
 L R826
 L R827
 L R828
 L R829
 L R830
 L R831
 L R832
 L R833
 L R834
 L R835
 L R836
 L R837
 L R838
 L R839
 L R840
 L R841
 L R842
 L R843
 L R844
 L R845
 L R846
 L R847
 L R848
 L R849
 L R850
 L R851
 L R852
 L R853
 L R854
 L R855
 L R856
 L R857
 L R858
 L R859
 L R860
 L R861
 L R862
 L R863
 L R864
 L R865
 L R866
 L R867
 L R868
 L R869
 L R870
 L R871
 L R872
 L R873
 L R874
 L R875
 L R876
 L R877
 L R878
 L R879
 L R880
 L R881
 L R882
 L R883
 L R884
 L R885
 L R886
 L R887
 L R888
 L R889
 L R890
 L R891
 L R892
 L R893
 L R894
 L R895
 L R896
 L R897
 L R898
 L R899
 L R900
 L R901
 L R902
 L R903
 L R904
 L R905
 L R906
 L R907
 L R908
 L R909
 L R910
 L R911
 L R912
 L R913
 L R914
 L R915
 L R916
 L R917
 L R918
 L R919
 L R920
 L R921
 L R922
 L R923
 L R924
 L R925
 L R926
 L R927
 L R928
 L R929
 L R930
 L R931
 L R932
 L R933
 L R934
 L R935
 L R936
 L R937
 L R938
 L R939
 L R940
 L R941
 L R942
 L R943
 L R944
 L R945
 L R946
 L R947
 L R948
 L R949
 L R950
 L R951
 L R952
 L R953
 L R954
 L R955
 L R956
 L R957
 L R958
 L R959
 L R960
 L R961
 L R962
 L R963
 L R964
 L R965
 L R966
 L R967
 L R968
 L R969
 L R970
 L R971
 L R972
 L R973
 L R974
 L R975
 L R976
 L R977
 L R978
 L R979
 L R980
 L R981
 L R982
 L R983
 L R984
 L R985
 L R986
 L R987
 L R988
 L R989
 L R990
 L R991
 L R992
 L R993
 L R994
 L R995
 L R996
 L R997
 L R998
 L R999
 L R1000
 L R1001
 L R1002
 L R1003
 L R1004
 L R1005
 L R1006
 L R1007
 L R1008
 L R1009
 L R1010
 L R1011
 L R1012
 L R1013
 L R1014
 L R1015
 L R1016
 L R1017
 L R1018
 L R1019
 L R1020
 L R1021
 L R1022
 L R1023
 L R1024
 L R1025
 L R1026
 L R1027
 L R1028
 L R1029
 L R1030
 L R1031
 L R1032
 L R1033
 L R1034
 L R1035
 L R1036
 L R1037
 L R1038
 L R1039
 L R1040
 L R1041
 L R1042
 L R1043
 L R1044
 L R1045
 L R1046
 L R1047
 L R1048
 L R1049
 L R1050
 L R1051
 L R1052
 L R1053
 L R1054
 L R1055
 L R1056
 L R1057
 L R1058
 L R1059
 L R1060
 L R1061
 L R1062
 L R1063
 L R1064
 L R1065
 L R1066
 L R1067
 L R1068
 L R1069
 L R1070
 L R1071
 L R1072
 L R1073
 L R1074
 L R1075
 L R1076
 L R1077
 L R1078
 L R1079
 L R1080
 L R1081
 L R1082
 L R1083
 L R1084
 L R1085
 L R1086
 L R1087
 L R1088
 L R1089
 L R1090
 L R1091
 L R1092
 L R1093
 L R1094
 L R1095
 L R1096
 L R1097
 L R1098
 L R1099
 L R1100
 L R1101
 L R1102
 L R1103
 L R1104
 L R1105
 L R1106
 L R1107
 L R1108
 L R1109
 L R1110
 L R1111
 L R1112
 L R1113
 L R1114
 L R1115
 L R1116
 L R1117
 L R1118
 L R1119
 L R1120
 L R1121
 L R1122
 L R1123
 L R1124
 L R1125
 L R1126
 L R1127
 L R1128
 L R1129
 L R1130
 L R1131
 L R1132
 L R1133
 L R1134
 L R1135
 L R1136
 L R1137
 L R1138
 L R1139
 L R1140
 L R1141
 L R1142
 L R1143
 L R1144
 L R1145
 L R1146
 L R1147
 L R1148
 L R1149
 L R1150
 L R1151
 L R1152
 L R1153
 L R1154
 L R1155
 L R1156
 L R1157
 L R1158
 L R1159
 L R1160
 L R1161
 L R1162
 L R1163
 L R1164
 L R1165
 L R1166
 L R1167
 L R1168
 L R1169
 L R1170
 L R1171
 L R1172
 L R1173
 L R1174
 L R1175
 L R1176
 L R1177
 L R1178
 L R1179
 L R1180
 L R1181
 L R1182
 L R1183
 L R1184
 L R1185
 L R1186
 L R1187
 L R1188
 L R1189
 L R1190
 L R1191
 L R1192
 E R1193
 E R1194
 E R1195
 E R1196
 E R1197
 E R1198
 E R1199
 E R1200
 E R1201
 E R1202
 E R1203
 E R1204
 E R1205
 E R1206
 E R1207
 E R1208
 E R1209
 E R1210
 E R1211
 E R1212
 E R1213
 E R1214
 E R1215
 E R1216
 E R1217
 E R1218
 E R1219
 E R1220
 E R1221
 E R1222
 E R1223
 E R1224
 E R1225
 E R1226
 E R1227
 E R1228
 E R1229
 E R1230
 E R1231
 E R1232
 E R1233
 E R1234
 E R1235
 E R1236
 E R1237
 E R1238
 E R1239
 E R1240
 E R1241
 E R1242
 E R1243
 E R1244
 E R1245
 E R1246
 E R1247
 E R1248
 E R1249
 E R1250
 E R1251
 E R1252
 E R1253
 E R1254
 E R1255
 E R1256
 E R1257
 E R1258
 E R1259
 E R1260
 E R1261
 E R1262
 E R1263
 E R1264
 E R1265
 E R1266
 E R1267
 E R1268
 E R1269
 E R1270
 E R1271
 E R1272
 E R1273
 E R1274
 E R1275
 E R1276
 E R1277
 E R1278
 E R1279
 E R1280
 E R1281
 E R1282
 E R1283
 E R1284
 E R1285
 E R1286
 E R1287
 E R1288
 E R1289
 E R1290
 E R1291
 E R1292
 E R1293
 E R1294
 E R1295
 E R1296
 E R1297
 E R1298
 E R1299
 E R1300
 E R1301
 E R1302
 E R1303
 E R1304
 E R1305
 E R1306
 E R1307
 E R1308
 E R1309
 E R1310
 E R1311
 E R1312
 E R1313
 E R1314
 E R1315
 E R1316
 E R1317
 E R1318
 E R1319
 E R1320
 E R1321
 E R1322
 E R1323
 E R1324
 E R1325
 E R1326
 E R1327
 E R1328
 E R1329
 E R1330
 E R1331
 E R1332
 E R1333
 E R1334
 E R1335
 E R1336
 E R1337
 E R1338
 E R1339
 E R1340
 E R1341
 E R1342
 E R1343
 E R1344
 E R1345
 E R1346
 E R1347
 E R1348
 E R1349
 E R1350
 E R1351
 E R1352
 E R1353
 E R1354
 E R1355
 E R1356
 E R1357
 E R1358
 E R1359
 E R1360
 E R1361
 E R1362
 E R1363
 E R1364
 E R1365
 E R1366
 E R1367
 E R1368
 E R1369
 E R1370
 E R1371
 E R1372
 E R1373
 E R1374
 E R1375
 E R1376
 E R1377
 E R1378
 E R1379
 E R1380
 E R1381
 E R1382
 E R1383
 E R1384
 E R1385
 E R1386
 E R1387
 E R1388
 E R1389
 E R1390
 E R1391
 E R1392
 E R1393
 E R1394
 E R1395
 E R1396
 E R1397
 E R1398
 E R1399
 E R1400
 E R1401
 E R1402
 E R1403
 E R1404
 E R1405
 E R1406
 E R1407
 E R1408
 E R1409
 E R1410
 E R1411
 E R1412
 E R1413
 E R1414
 E R1415
 E R1416
 E R1417
 E R1418
 E R1419
 E R1420
 E R1421
 E R1422
 E R1423
 E R1424
 E R1425
 E R1426
 E R1427
 E R1428
 E R1429
 E R1430
 E R1431
 E R1432
 E R1433
 E R1434
 E R1435
 E R1436
 E R1437
 E R1438
 E R1439
 E R1440
 E R1441
 E R1442
 E R1443
 E R1444
 E R1445
 E R1446
 E R1447
 E R1448
 E R1449
 E R1450
 E R1451
 E R1452
 E R1453
 E R1454
 E R1455
 E R1456
 E R1457
 E R1458
 E R1459
 E R1460
 E R1461
 E R1462
 E R1463
 E R1464
 E R1465
 E R1466
 E R1467
 E R1468
 E R1469
 E R1470
 E R1471
 E R1472
 E R1473
 E R1474
 E R1475
 E R1476
 E R1477
 E R1478
 E R1479
 E R1480
 E R1481
 E R1482
 E R1483
 E R1484
 E R1485
 E R1486
 E R1487
 E R1488
 E R1489
 E R1490
 E R1491
 E R1492
 E R1493
 E R1494
 E R1495
 E R1496
 E R1497
 E R1498
 E R1499
 E R1500
 E R1501
 E R1502
 E R1503
 E R1504
 E R1505
 E R1506
 E R1507
 E R1508
 E R1509
 E R1510
 E R1511
 E R1512
 E R1513
 E R1514
 E R1515
 E R1516
 E R1517
 E R1518
 E R1519
 E R1520
 E R1521
 E R1522
 E R1523
 E R1524
 E R1525
 E R1526
 E R1527
 E R1528
 E R1529
 E R1530
 E R1531
 E R1532
 E R1533
 E R1534
 E R1535
 E R1536
 E R1537
 E R1538
 E R1539
 E R1540
 E R1541
 E R1542
 E R1543
 E R1544
 E R1545
 E R1546
 E R1547
 E R1548
 E R1549
 E R1550
 E R1551
 E R1552
 E R1553
 E R1554
 E R1555
 E R1556
 E R1557
 E R1558
 E R1559
 E R1560
 E R1561
 E R1562
 E R1563
 E R1564
 E R1565
 E R1566
 E R1567
 E R1568
 E R1569
 E R1570
 E R1571
 E R1572
 E R1573
 E R1574
 E R1575
 E R1576
 E R1577
 E R1578
 E R1579
 E R1580
 E R1581
 E R1582
 E R1583
 E R1584
 E R1585
 E R1586
 E R1587
 E R1588
 E R1589
 E R1590
 E R1591
 E R1592
 E R1593
 E R1594
 E R1595
 E R1596
 E R1597
 E R1598
 E R1599
 E R1600
 E R1601
 E R1602
 E R1603
 E R1604
 E R1605
 E R1606
 E R1607
 E R1608
 E R1609
 E R1610
 E R1611
 E R1612
 E R1613
 E R1614
 E R1615
 E R1616
 E R1617
 E R1618
 E R1619
 E R1620
 E R1621
 E R1622
 E R1623
 E R1624
 E R1625
 E R1626
 E R1627
 E R1628
 E R1629
 E R1630
 E R1631
 E R1632
 E R1633
 E R1634
 E R1635
 E R1636
 E R1637
 E R1638
 E R1639
 E R1640
 E R1641
 E R1642
 E R1643
 E R1644
 E R1645
 E R1646
 E R1647
 E R1648
 E R1649
 E R1650
 E R1651
 E R1652
 E R1653
 E R1654
 N R1655
COLUMNS
    X0        R2                            -2.96
    X0        R73                           1
    X0        R535                          1
    X0        R1067                         1
    X0        R1193                         -1
    X1        R2                            -3.04
    X1        R74                           1
    X1        R536                          1
    X1        R1026                         1
    X1        R1194                         -1
    X2        R2                            -2.96
    X2        R75                           1
    X2        R537                          1
    X2        R1069                         1
    X2        R1195                         -1
    X3        R2                            -3.04
    X3        R76                           1
    X3        R538                          1
    X3        R1028                         1
    X3        R1196                         -1
    X4        R2                            -2.96
    X4        R77                           1
    X4        R539                          1
    X4        R1071                         1
    X4        R1197                         -1
    X5        R2                            -3.04
    X5        R78                           1
    X5        R540                          1
    X5        R1030                         1
    X5        R1198                         -1
    X6        R2                            -2.96
    X6        R79                           1
    X6        R541                          1
    X6        R1073                         1
    X6        R1199                         -1
    X7        R2                            -3.04
    X7        R80                           1
    X7        R542                          1
    X7        R1032                         1
    X7        R1200                         -1
    X8        R2                            -2.96
    X8        R81                           1
    X8        R543                          1
    X8        R1075                         1
    X8        R1201                         -1
    X9        R2                            -3.04
    X9        R82                           1
    X9        R544                          1
    X9        R1034                         1
    X9        R1202                         -1
    X10       R2                            -2.96
    X10       R83                           1
    X10       R545                          1
    X10       R1077                         1
    X10       R1203                         -1
    X11       R2                            -3.04
    X11       R84                           1
    X11       R546                          1
    X11       R1036                         1
    X11       R1204                         -1
    X12       R2                            -2.96
    X12       R85                           1
    X12       R547                          1
    X12       R1079                         1
    X12       R1205                         -1
    X13       R2                            -3.04
    X13       R86                           1
    X13       R548                          1
    X13       R1038                         1
    X13       R1639                         -1
    X14       R2                            -3.04
    X14       R87                           1
    X14       R549                          1
    X14       R1025                         1
    X14       R1206                         -1
    X15       R2                            -2.96
    X15       R88                           1
    X15       R550                          1
    X15       R1068                         1
    X15       R1207                         -1
    X16       R2                            -3.04
    X16       R89                           1
    X16       R551                          1
    X16       R1027                         1
    X16       R1208                         -1
    X17       R2                            -2.96
    X17       R90                           1
    X17       R552                          1
    X17       R1070                         1
    X17       R1209                         -1
    X18       R2                            -3.04
    X18       R91                           1
    X18       R553                          1
    X18       R1029                         1
    X18       R1210                         -1
    X19       R2                            -2.96
    X19       R92                           1
    X19       R554                          1
    X19       R1072                         1
    X19       R1211                         -1
    X20       R2                            -3.04
    X20       R93                           1
    X20       R555                          1
    X20       R1031                         1
    X20       R1212                         -1
    X21       R2                            -2.96
    X21       R94                           1
    X21       R556                          1
    X21       R1074                         1
    X21       R1213                         -1
    X22       R2                            -3.04
    X22       R95                           1
    X22       R557                          1
    X22       R1033                         1
    X22       R1214                         -1
    X23       R2                            -2.96
    X23       R96                           1
    X23       R558                          1
    X23       R1076                         1
    X23       R1215                         -1
    X24       R2                            -3.04
    X24       R97                           1
    X24       R559                          1
    X24       R1035                         1
    X24       R1216                         -1
    X25       R2                            -2.96
    X25       R98                           1
    X25       R560                          1
    X25       R1078                         1
    X25       R1217                         -1
    X26       R2                            -3.04
    X26       R99                           1
    X26       R561                          1
    X26       R1037                         1
    X26       R1218                         -1
    X27       R2                            -2.96
    X27       R100                          1
    X27       R562                          1
    X27       R1080                         1
    X27       R1640                         -1
    X28       R2                            -2.98
    X28       R101                          1
    X28       R563                          1
    X28       R1165                         1
    X28       R1219                         -1
    X29       R2                            -3.04
    X29       R102                          1
    X29       R564                          1
    X29       R1025                         1
    X29       R1220                         -1
    X30       R2                            -2.94
    X30       R103                          1
    X30       R565                          1
    X30       R1096                         1
    X30       R1221                         -1
    X31       R2                            -3.04
    X31       R104                          1
    X31       R566                          1
    X31       R1027                         1
    X31       R1222                         -1
    X32       R2                            -2.98
    X32       R105                          1
    X32       R567                          1
    X32       R1167                         1
    X32       R1223                         -1
    X33       R2                            -3.04
    X33       R106                          1
    X33       R568                          1
    X33       R1027                         1
    X33       R1224                         -1
    X34       R2                            -2.94
    X34       R107                          1
    X34       R569                          1
    X34       R1098                         1
    X34       R1225                         -1
    X35       R2                            -3.04
    X35       R108                          1
    X35       R570                          1
    X35       R1029                         1
    X35       R1226                         -1
    X36       R2                            -2.98
    X36       R109                          1
    X36       R571                          1
    X36       R1169                         1
    X36       R1227                         -1
    X37       R2                            -3.04
    X37       R110                          1
    X37       R572                          1
    X37       R1029                         1
    X37       R1228                         -1
    X38       R2                            -2.94
    X38       R111                          1
    X38       R573                          1
    X38       R1100                         1
    X38       R1229                         -1
    X39       R2                            -3.04
    X39       R112                          1
    X39       R574                          1
    X39       R1031                         1
    X39       R1230                         -1
    X40       R2                            -2.98
    X40       R113                          1
    X40       R575                          1
    X40       R1171                         1
    X40       R1231                         -1
    X41       R2                            -3.04
    X41       R114                          1
    X41       R576                          1
    X41       R1031                         1
    X41       R1232                         -1
    X42       R2                            -2.94
    X42       R115                          1
    X42       R577                          1
    X42       R1102                         1
    X42       R1233                         -1
    X43       R2                            -3.04
    X43       R116                          1
    X43       R578                          1
    X43       R1033                         1
    X43       R1234                         -1
    X44       R2                            -2.98
    X44       R117                          1
    X44       R579                          1
    X44       R1173                         1
    X44       R1235                         -1
    X45       R2                            -3.04
    X45       R118                          1
    X45       R580                          1
    X45       R1033                         1
    X45       R1236                         -1
    X46       R2                            -2.94
    X46       R119                          1
    X46       R581                          1
    X46       R1104                         1
    X46       R1237                         -1
    X47       R2                            -3.04
    X47       R120                          1
    X47       R582                          1
    X47       R1035                         1
    X47       R1238                         -1
    X48       R2                            -2.98
    X48       R121                          1
    X48       R583                          1
    X48       R1175                         1
    X48       R1239                         -1
    X49       R2                            -3.04
    X49       R122                          1
    X49       R584                          1
    X49       R1035                         1
    X49       R1240                         -1
    X50       R2                            -2.94
    X50       R123                          1
    X50       R585                          1
    X50       R1106                         1
    X50       R1241                         -1
    X51       R2                            -3.04
    X51       R124                          1
    X51       R586                          1
    X51       R1037                         1
    X51       R1242                         -1
    X52       R2                            -2.98
    X52       R125                          1
    X52       R587                          1
    X52       R1177                         1
    X52       R1243                         -1
    X53       R2                            -3.04
    X53       R126                          1
    X53       R588                          1
    X53       R1037                         1
    X53       R1244                         -1
    X54       R2                            -2.94
    X54       R127                          1
    X54       R589                          1
    X54       R1108                         1
    X54       R1245                         -1
    X55       R2                            -3.04
    X55       R128                          1
    X55       R590                          1
    X55       R1025                         1
    X55       R1641                         -1
    X56       R2                            -2.94
    X56       R129                          1
    X56       R591                          1
    X56       R1095                         1
    X56       R1246                         -1
    X57       R2                            -3.04
    X57       R130                          1
    X57       R592                          1
    X57       R1026                         1
    X57       R1247                         -1
    X58       R2                            -2.98
    X58       R131                          1
    X58       R593                          1
    X58       R1166                         1
    X58       R1248                         -1
    X59       R2                            -3.04
    X59       R132                          1
    X59       R594                          1
    X59       R1026                         1
    X59       R1249                         -1
    X60       R2                            -2.94
    X60       R133                          1
    X60       R595                          1
    X60       R1097                         1
    X60       R1250                         -1
    X61       R2                            -3.04
    X61       R134                          1
    X61       R596                          1
    X61       R1028                         1
    X61       R1251                         -1
    X62       R2                            -2.98
    X62       R135                          1
    X62       R597                          1
    X62       R1168                         1
    X62       R1252                         -1
    X63       R2                            -3.04
    X63       R136                          1
    X63       R598                          1
    X63       R1028                         1
    X63       R1253                         -1
    X64       R2                            -2.94
    X64       R137                          1
    X64       R599                          1
    X64       R1099                         1
    X64       R1254                         -1
    X65       R2                            -3.04
    X65       R138                          1
    X65       R600                          1
    X65       R1030                         1
    X65       R1255                         -1
    X66       R2                            -2.98
    X66       R139                          1
    X66       R601                          1
    X66       R1170                         1
    X66       R1256                         -1
    X67       R2                            -3.04
    X67       R140                          1
    X67       R602                          1
    X67       R1030                         1
    X67       R1257                         -1
    X68       R2                            -2.94
    X68       R141                          1
    X68       R603                          1
    X68       R1101                         1
    X68       R1258                         -1
    X69       R2                            -3.04
    X69       R142                          1
    X69       R604                          1
    X69       R1032                         1
    X69       R1259                         -1
    X70       R2                            -2.98
    X70       R143                          1
    X70       R605                          1
    X70       R1172                         1
    X70       R1260                         -1
    X71       R2                            -3.04
    X71       R144                          1
    X71       R606                          1
    X71       R1032                         1
    X71       R1261                         -1
    X72       R2                            -2.94
    X72       R145                          1
    X72       R607                          1
    X72       R1103                         1
    X72       R1262                         -1
    X73       R2                            -3.04
    X73       R146                          1
    X73       R608                          1
    X73       R1034                         1
    X73       R1263                         -1
    X74       R2                            -2.98
    X74       R147                          1
    X74       R609                          1
    X74       R1174                         1
    X74       R1264                         -1
    X75       R2                            -3.04
    X75       R148                          1
    X75       R610                          1
    X75       R1034                         1
    X75       R1265                         -1
    X76       R2                            -2.94
    X76       R149                          1
    X76       R611                          1
    X76       R1105                         1
    X76       R1266                         -1
    X77       R2                            -3.04
    X77       R150                          1
    X77       R612                          1
    X77       R1036                         1
    X77       R1267                         -1
    X78       R2                            -2.98
    X78       R151                          1
    X78       R613                          1
    X78       R1176                         1
    X78       R1268                         -1
    X79       R2                            -3.04
    X79       R152                          1
    X79       R614                          1
    X79       R1036                         1
    X79       R1269                         -1
    X80       R2                            -2.94
    X80       R153                          1
    X80       R615                          1
    X80       R1107                         1
    X80       R1270                         -1
    X81       R2                            -3.04
    X81       R154                          1
    X81       R616                          1
    X81       R1038                         1
    X81       R1271                         -1
    X82       R2                            -2.98
    X82       R155                          1
    X82       R617                          1
    X82       R1178                         1
    X82       R1272                         -1
    X83       R2                            -3.04
    X83       R156                          1
    X83       R618                          1
    X83       R1038                         1
    X83       R1642                         -1
    X84       R2                            -2.94
    X84       R157                          1
    X84       R619                          1
    X84       R1123                         1
    X84       R1273                         -1
    X85       R2                            -3.04
    X85       R158                          1
    X85       R620                          1
    X85       R1026                         1
    X85       R1274                         -1
    X86       R2                            -2.96
    X86       R159                          1
    X86       R621                          1
    X86       R998                          1
    X86       R1275                         -1
    X87       R2                            -2.92
    X87       R160                          1
    X87       R622                          1
    X87       R1111                         1
    X87       R1276                         -1
    X88       R2                            -2.94
    X88       R161                          1
    X88       R623                          1
    X88       R1125                         1
    X88       R1277                         -1
    X89       R2                            -3.04
    X89       R162                          1
    X89       R624                          1
    X89       R1028                         1
    X89       R1278                         -1
    X90       R2                            -2.96
    X90       R163                          1
    X90       R625                          1
    X90       R1000                         1
    X90       R1279                         -1
    X91       R2                            -2.92
    X91       R164                          1
    X91       R626                          1
    X91       R1113                         1
    X91       R1280                         -1
    X92       R2                            -2.94
    X92       R165                          1
    X92       R627                          1
    X92       R1127                         1
    X92       R1281                         -1
    X93       R2                            -3.04
    X93       R166                          1
    X93       R628                          1
    X93       R1030                         1
    X93       R1282                         -1
    X94       R2                            -2.96
    X94       R167                          1
    X94       R629                          1
    X94       R1002                         1
    X94       R1283                         -1
    X95       R2                            -2.92
    X95       R168                          1
    X95       R630                          1
    X95       R1115                         1
    X95       R1284                         -1
    X96       R2                            -2.94
    X96       R169                          1
    X96       R631                          1
    X96       R1129                         1
    X96       R1285                         -1
    X97       R2                            -3.04
    X97       R170                          1
    X97       R632                          1
    X97       R1032                         1
    X97       R1286                         -1
    X98       R2                            -2.96
    X98       R171                          1
    X98       R633                          1
    X98       R1004                         1
    X98       R1287                         -1
    X99       R2                            -2.92
    X99       R172                          1
    X99       R634                          1
    X99       R1117                         1
    X99       R1288                         -1
    X100      R2                            -2.94
    X100      R173                          1
    X100      R635                          1
    X100      R1131                         1
    X100      R1289                         -1
    X101      R2                            -3.04
    X101      R174                          1
    X101      R636                          1
    X101      R1034                         1
    X101      R1290                         -1
    X102      R2                            -2.96
    X102      R175                          1
    X102      R637                          1
    X102      R1006                         1
    X102      R1291                         -1
    X103      R2                            -2.92
    X103      R176                          1
    X103      R638                          1
    X103      R1119                         1
    X103      R1292                         -1
    X104      R2                            -2.94
    X104      R177                          1
    X104      R639                          1
    X104      R1133                         1
    X104      R1293                         -1
    X105      R2                            -3.04
    X105      R178                          1
    X105      R640                          1
    X105      R1036                         1
    X105      R1294                         -1
    X106      R2                            -2.96
    X106      R179                          1
    X106      R641                          1
    X106      R1008                         1
    X106      R1295                         -1
    X107      R2                            -2.92
    X107      R180                          1
    X107      R642                          1
    X107      R1121                         1
    X107      R1296                         -1
    X108      R2                            -2.94
    X108      R181                          1
    X108      R643                          1
    X108      R1135                         1
    X108      R1297                         -1
    X109      R2                            -3.04
    X109      R182                          1
    X109      R644                          1
    X109      R1038                         1
    X109      R1298                         -1
    X110      R2                            -2.96
    X110      R183                          1
    X110      R645                          1
    X110      R1010                         1
    X110      R1299                         -1
    X111      R2                            -2.92
    X111      R184                          1
    X111      R646                          1
    X111      R1109                         1
    X111      R1643                         -1
    X112      R2                            -3.04
    X112      R185                          1
    X112      R647                          1
    X112      R1025                         1
    X112      R1300                         -1
    X113      R2                            -2.96
    X113      R186                          1
    X113      R648                          1
    X113      R997                          1
    X113      R1301                         -1
    X114      R2                            -2.92
    X114      R187                          1
    X114      R649                          1
    X114      R1110                         1
    X114      R1302                         -1
    X115      R2                            -2.94
    X115      R188                          1
    X115      R650                          1
    X115      R1124                         1
    X115      R1303                         -1
    X116      R2                            -3.04
    X116      R189                          1
    X116      R651                          1
    X116      R1027                         1
    X116      R1304                         -1
    X117      R2                            -2.96
    X117      R190                          1
    X117      R652                          1
    X117      R999                          1
    X117      R1305                         -1
    X118      R2                            -2.92
    X118      R191                          1
    X118      R653                          1
    X118      R1112                         1
    X118      R1306                         -1
    X119      R2                            -2.94
    X119      R192                          1
    X119      R654                          1
    X119      R1126                         1
    X119      R1307                         -1
    X120      R2                            -3.04
    X120      R193                          1
    X120      R655                          1
    X120      R1029                         1
    X120      R1308                         -1
    X121      R2                            -2.96
    X121      R194                          1
    X121      R656                          1
    X121      R1001                         1
    X121      R1309                         -1
    X122      R2                            -2.92
    X122      R195                          1
    X122      R657                          1
    X122      R1114                         1
    X122      R1310                         -1
    X123      R2                            -2.94
    X123      R196                          1
    X123      R658                          1
    X123      R1128                         1
    X123      R1311                         -1
    X124      R2                            -3.04
    X124      R197                          1
    X124      R659                          1
    X124      R1031                         1
    X124      R1312                         -1
    X125      R2                            -2.96
    X125      R198                          1
    X125      R660                          1
    X125      R1003                         1
    X125      R1313                         -1
    X126      R2                            -2.92
    X126      R199                          1
    X126      R661                          1
    X126      R1116                         1
    X126      R1314                         -1
    X127      R2                            -2.94
    X127      R200                          1
    X127      R662                          1
    X127      R1130                         1
    X127      R1315                         -1
    X128      R2                            -3.04
    X128      R201                          1
    X128      R663                          1
    X128      R1033                         1
    X128      R1316                         -1
    X129      R2                            -2.96
    X129      R202                          1
    X129      R664                          1
    X129      R1005                         1
    X129      R1317                         -1
    X130      R2                            -2.92
    X130      R203                          1
    X130      R665                          1
    X130      R1118                         1
    X130      R1318                         -1
    X131      R2                            -2.94
    X131      R204                          1
    X131      R666                          1
    X131      R1132                         1
    X131      R1319                         -1
    X132      R2                            -3.04
    X132      R205                          1
    X132      R667                          1
    X132      R1035                         1
    X132      R1320                         -1
    X133      R2                            -2.96
    X133      R206                          1
    X133      R668                          1
    X133      R1007                         1
    X133      R1321                         -1
    X134      R2                            -2.92
    X134      R207                          1
    X134      R669                          1
    X134      R1120                         1
    X134      R1322                         -1
    X135      R2                            -2.94
    X135      R208                          1
    X135      R670                          1
    X135      R1134                         1
    X135      R1323                         -1
    X136      R2                            -3.04
    X136      R209                          1
    X136      R671                          1
    X136      R1037                         1
    X136      R1324                         -1
    X137      R2                            -2.96
    X137      R210                          1
    X137      R672                          1
    X137      R1009                         1
    X137      R1325                         -1
    X138      R2                            -2.92
    X138      R211                          1
    X138      R673                          1
    X138      R1122                         1
    X138      R1326                         -1
    X139      R2                            -2.94
    X139      R212                          1
    X139      R674                          1
    X139      R1136                         1
    X139      R1644                         -1
    X140      R2                            -2.94
    X140      R213                          1
    X140      R675                          1
    X140      R1095                         1
    X140      R1327                         -1
    X141      R2                            -2.92
    X141      R214                          1
    X141      R676                          1
    X141      R1081                         1
    X141      R1328                         -1
    X142      R2                            -3.04
    X142      R215                          1
    X142      R677                          1
    X142      R1026                         1
    X142      R1329                         -1
    X143      R2                            -2.94
    X143      R216                          1
    X143      R678                          1
    X143      R1097                         1
    X143      R1330                         -1
    X144      R2                            -2.92
    X144      R217                          1
    X144      R679                          1
    X144      R1083                         1
    X144      R1331                         -1
    X145      R2                            -3.04
    X145      R218                          1
    X145      R680                          1
    X145      R1028                         1
    X145      R1332                         -1
    X146      R2                            -2.94
    X146      R219                          1
    X146      R681                          1
    X146      R1099                         1
    X146      R1333                         -1
    X147      R2                            -2.92
    X147      R220                          1
    X147      R682                          1
    X147      R1085                         1
    X147      R1334                         -1
    X148      R2                            -3.04
    X148      R221                          1
    X148      R683                          1
    X148      R1030                         1
    X148      R1335                         -1
    X149      R2                            -2.94
    X149      R222                          1
    X149      R684                          1
    X149      R1101                         1
    X149      R1336                         -1
    X150      R2                            -2.92
    X150      R223                          1
    X150      R685                          1
    X150      R1087                         1
    X150      R1337                         -1
    X151      R2                            -3.04
    X151      R224                          1
    X151      R686                          1
    X151      R1032                         1
    X151      R1338                         -1
    X152      R2                            -2.94
    X152      R225                          1
    X152      R687                          1
    X152      R1103                         1
    X152      R1339                         -1
    X153      R2                            -2.92
    X153      R226                          1
    X153      R688                          1
    X153      R1089                         1
    X153      R1340                         -1
    X154      R2                            -3.04
    X154      R227                          1
    X154      R689                          1
    X154      R1034                         1
    X154      R1341                         -1
    X155      R2                            -2.94
    X155      R228                          1
    X155      R690                          1
    X155      R1105                         1
    X155      R1342                         -1
    X156      R2                            -2.92
    X156      R229                          1
    X156      R691                          1
    X156      R1091                         1
    X156      R1343                         -1
    X157      R2                            -3.04
    X157      R230                          1
    X157      R692                          1
    X157      R1036                         1
    X157      R1344                         -1
    X158      R2                            -2.94
    X158      R231                          1
    X158      R693                          1
    X158      R1107                         1
    X158      R1345                         -1
    X159      R2                            -2.92
    X159      R232                          1
    X159      R694                          1
    X159      R1093                         1
    X159      R1346                         -1
    X160      R2                            -3.04
    X160      R233                          1
    X160      R695                          1
    X160      R1038                         1
    X160      R1645                         -1
    X161      R2                            -3.04
    X161      R234                          1
    X161      R696                          1
    X161      R1025                         1
    X161      R1347                         -1
    X162      R2                            -2.94
    X162      R235                          1
    X162      R697                          1
    X162      R1096                         1
    X162      R1348                         -1
    X163      R2                            -2.92
    X163      R236                          1
    X163      R698                          1
    X163      R1082                         1
    X163      R1349                         -1
    X164      R2                            -3.04
    X164      R237                          1
    X164      R699                          1
    X164      R1027                         1
    X164      R1350                         -1
    X165      R2                            -2.94
    X165      R238                          1
    X165      R700                          1
    X165      R1098                         1
    X165      R1351                         -1
    X166      R2                            -2.92
    X166      R239                          1
    X166      R701                          1
    X166      R1084                         1
    X166      R1352                         -1
    X167      R2                            -3.04
    X167      R240                          1
    X167      R702                          1
    X167      R1029                         1
    X167      R1353                         -1
    X168      R2                            -2.94
    X168      R241                          1
    X168      R703                          1
    X168      R1100                         1
    X168      R1354                         -1
    X169      R2                            -2.92
    X169      R242                          1
    X169      R704                          1
    X169      R1086                         1
    X169      R1355                         -1
    X170      R2                            -3.04
    X170      R243                          1
    X170      R705                          1
    X170      R1031                         1
    X170      R1356                         -1
    X171      R2                            -2.94
    X171      R244                          1
    X171      R706                          1
    X171      R1102                         1
    X171      R1357                         -1
    X172      R2                            -2.92
    X172      R245                          1
    X172      R707                          1
    X172      R1088                         1
    X172      R1358                         -1
    X173      R2                            -3.04
    X173      R246                          1
    X173      R708                          1
    X173      R1033                         1
    X173      R1359                         -1
    X174      R2                            -2.94
    X174      R247                          1
    X174      R709                          1
    X174      R1104                         1
    X174      R1360                         -1
    X175      R2                            -2.92
    X175      R248                          1
    X175      R710                          1
    X175      R1090                         1
    X175      R1361                         -1
    X176      R2                            -3.04
    X176      R249                          1
    X176      R711                          1
    X176      R1035                         1
    X176      R1362                         -1
    X177      R2                            -2.94
    X177      R250                          1
    X177      R712                          1
    X177      R1106                         1
    X177      R1363                         -1
    X178      R2                            -2.92
    X178      R251                          1
    X178      R713                          1
    X178      R1092                         1
    X178      R1364                         -1
    X179      R2                            -3.04
    X179      R252                          1
    X179      R714                          1
    X179      R1037                         1
    X179      R1365                         -1
    X180      R2                            -2.94
    X180      R253                          1
    X180      R715                          1
    X180      R1108                         1
    X180      R1366                         -1
    X181      R2                            -2.92
    X181      R254                          1
    X181      R716                          1
    X181      R1094                         1
    X181      R1646                         -1
    X182      R2                            -2.98
    X182      R255                          1
    X182      R717                          1
    X182      R1165                         1
    X182      R1367                         -1
    X183      R2                            -3.04
    X183      R256                          1
    X183      R718                          1
    X183      R1025                         1
    X183      R1368                         -1
    X184      R2                            -2.94
    X184      R257                          1
    X184      R719                          1
    X184      R1124                         1
    X184      R1369                         -1
    X185      R2                            -3.52
    X185      R258                          1
    X185      R720                          1
    X185      R1138                         1
    X185      R1370                         -1
    X186      R2                            -2.94
    X186      R259                          1
    X186      R721                          1
    X186      R1124                         1
    X186      R1371                         -1
    X187      R2                            -3.04
    X187      R260                          1
    X187      R722                          1
    X187      R1027                         1
    X187      R1372                         -1
    X188      R2                            -2.98
    X188      R261                          1
    X188      R723                          1
    X188      R1167                         1
    X188      R1373                         -1
    X189      R2                            -3.04
    X189      R262                          1
    X189      R724                          1
    X189      R1027                         1
    X189      R1374                         -1
    X190      R2                            -2.94
    X190      R263                          1
    X190      R725                          1
    X190      R1126                         1
    X190      R1375                         -1
    X191      R2                            -3.52
    X191      R264                          1
    X191      R726                          1
    X191      R1140                         1
    X191      R1376                         -1
    X192      R2                            -2.94
    X192      R265                          1
    X192      R727                          1
    X192      R1126                         1
    X192      R1377                         -1
    X193      R2                            -3.04
    X193      R266                          1
    X193      R728                          1
    X193      R1029                         1
    X193      R1378                         -1
    X194      R2                            -2.98
    X194      R267                          1
    X194      R729                          1
    X194      R1169                         1
    X194      R1379                         -1
    X195      R2                            -3.04
    X195      R268                          1
    X195      R730                          1
    X195      R1029                         1
    X195      R1380                         -1
    X196      R2                            -2.94
    X196      R269                          1
    X196      R731                          1
    X196      R1128                         1
    X196      R1381                         -1
    X197      R2                            -3.52
    X197      R270                          1
    X197      R732                          1
    X197      R1142                         1
    X197      R1382                         -1
    X198      R2                            -2.94
    X198      R271                          1
    X198      R733                          1
    X198      R1128                         1
    X198      R1383                         -1
    X199      R2                            -3.04
    X199      R272                          1
    X199      R734                          1
    X199      R1031                         1
    X199      R1384                         -1
    X200      R2                            -2.98
    X200      R273                          1
    X200      R735                          1
    X200      R1171                         1
    X200      R1385                         -1
    X201      R2                            -3.04
    X201      R274                          1
    X201      R736                          1
    X201      R1031                         1
    X201      R1386                         -1
    X202      R2                            -2.94
    X202      R275                          1
    X202      R737                          1
    X202      R1130                         1
    X202      R1387                         -1
    X203      R2                            -3.52
    X203      R276                          1
    X203      R738                          1
    X203      R1144                         1
    X203      R1388                         -1
    X204      R2                            -2.94
    X204      R277                          1
    X204      R739                          1
    X204      R1130                         1
    X204      R1389                         -1
    X205      R2                            -3.04
    X205      R278                          1
    X205      R740                          1
    X205      R1033                         1
    X205      R1390                         -1
    X206      R2                            -2.98
    X206      R279                          1
    X206      R741                          1
    X206      R1173                         1
    X206      R1391                         -1
    X207      R2                            -3.04
    X207      R280                          1
    X207      R742                          1
    X207      R1033                         1
    X207      R1392                         -1
    X208      R2                            -2.94
    X208      R281                          1
    X208      R743                          1
    X208      R1132                         1
    X208      R1393                         -1
    X209      R2                            -3.52
    X209      R282                          1
    X209      R744                          1
    X209      R1146                         1
    X209      R1394                         -1
    X210      R2                            -2.94
    X210      R283                          1
    X210      R745                          1
    X210      R1132                         1
    X210      R1395                         -1
    X211      R2                            -3.04
    X211      R284                          1
    X211      R746                          1
    X211      R1035                         1
    X211      R1396                         -1
    X212      R2                            -2.98
    X212      R285                          1
    X212      R747                          1
    X212      R1175                         1
    X212      R1397                         -1
    X213      R2                            -3.04
    X213      R286                          1
    X213      R748                          1
    X213      R1035                         1
    X213      R1398                         -1
    X214      R2                            -2.94
    X214      R287                          1
    X214      R749                          1
    X214      R1134                         1
    X214      R1399                         -1
    X215      R2                            -3.52
    X215      R288                          1
    X215      R750                          1
    X215      R1148                         1
    X215      R1400                         -1
    X216      R2                            -2.94
    X216      R289                          1
    X216      R751                          1
    X216      R1134                         1
    X216      R1401                         -1
    X217      R2                            -3.04
    X217      R290                          1
    X217      R752                          1
    X217      R1037                         1
    X217      R1402                         -1
    X218      R2                            -2.98
    X218      R291                          1
    X218      R753                          1
    X218      R1177                         1
    X218      R1403                         -1
    X219      R2                            -3.04
    X219      R292                          1
    X219      R754                          1
    X219      R1037                         1
    X219      R1404                         -1
    X220      R2                            -2.94
    X220      R293                          1
    X220      R755                          1
    X220      R1136                         1
    X220      R1405                         -1
    X221      R2                            -3.52
    X221      R294                          1
    X221      R756                          1
    X221      R1150                         1
    X221      R1406                         -1
    X222      R2                            -2.94
    X222      R295                          1
    X222      R757                          1
    X222      R1136                         1
    X222      R1407                         -1
    X223      R2                            -3.04
    X223      R296                          1
    X223      R758                          1
    X223      R1025                         1
    X223      R1647                         -1
    X224      R2                            -3.52
    X224      R297                          1
    X224      R759                          1
    X224      R1137                         1
    X224      R1408                         -1
    X225      R2                            -2.94
    X225      R298                          1
    X225      R760                          1
    X225      R1123                         1
    X225      R1409                         -1
    X226      R2                            -3.04
    X226      R299                          1
    X226      R761                          1
    X226      R1026                         1
    X226      R1410                         -1
    X227      R2                            -2.98
    X227      R300                          1
    X227      R762                          1
    X227      R1166                         1
    X227      R1411                         -1
    X228      R2                            -3.04
    X228      R301                          1
    X228      R763                          1
    X228      R1026                         1
    X228      R1412                         -1
    X229      R2                            -2.94
    X229      R302                          1
    X229      R764                          1
    X229      R1125                         1
    X229      R1413                         -1
    X230      R2                            -3.52
    X230      R303                          1
    X230      R765                          1
    X230      R1139                         1
    X230      R1414                         -1
    X231      R2                            -2.94
    X231      R304                          1
    X231      R766                          1
    X231      R1125                         1
    X231      R1415                         -1
    X232      R2                            -3.04
    X232      R305                          1
    X232      R767                          1
    X232      R1028                         1
    X232      R1416                         -1
    X233      R2                            -2.98
    X233      R306                          1
    X233      R768                          1
    X233      R1168                         1
    X233      R1417                         -1
    X234      R2                            -3.04
    X234      R307                          1
    X234      R769                          1
    X234      R1028                         1
    X234      R1418                         -1
    X235      R2                            -2.94
    X235      R308                          1
    X235      R770                          1
    X235      R1127                         1
    X235      R1419                         -1
    X236      R2                            -3.52
    X236      R309                          1
    X236      R771                          1
    X236      R1141                         1
    X236      R1420                         -1
    X237      R2                            -2.94
    X237      R310                          1
    X237      R772                          1
    X237      R1127                         1
    X237      R1421                         -1
    X238      R2                            -3.04
    X238      R311                          1
    X238      R773                          1
    X238      R1030                         1
    X238      R1422                         -1
    X239      R2                            -2.98
    X239      R312                          1
    X239      R774                          1
    X239      R1170                         1
    X239      R1423                         -1
    X240      R2                            -3.04
    X240      R313                          1
    X240      R775                          1
    X240      R1030                         1
    X240      R1424                         -1
    X241      R2                            -2.94
    X241      R314                          1
    X241      R776                          1
    X241      R1129                         1
    X241      R1425                         -1
    X242      R2                            -3.52
    X242      R315                          1
    X242      R777                          1
    X242      R1143                         1
    X242      R1426                         -1
    X243      R2                            -2.94
    X243      R316                          1
    X243      R778                          1
    X243      R1129                         1
    X243      R1427                         -1
    X244      R2                            -3.04
    X244      R317                          1
    X244      R779                          1
    X244      R1032                         1
    X244      R1428                         -1
    X245      R2                            -2.98
    X245      R318                          1
    X245      R780                          1
    X245      R1172                         1
    X245      R1429                         -1
    X246      R2                            -3.04
    X246      R319                          1
    X246      R781                          1
    X246      R1032                         1
    X246      R1430                         -1
    X247      R2                            -2.94
    X247      R320                          1
    X247      R782                          1
    X247      R1131                         1
    X247      R1431                         -1
    X248      R2                            -3.52
    X248      R321                          1
    X248      R783                          1
    X248      R1145                         1
    X248      R1432                         -1
    X249      R2                            -2.94
    X249      R322                          1
    X249      R784                          1
    X249      R1131                         1
    X249      R1433                         -1
    X250      R2                            -3.04
    X250      R323                          1
    X250      R785                          1
    X250      R1034                         1
    X250      R1434                         -1
    X251      R2                            -2.98
    X251      R324                          1
    X251      R786                          1
    X251      R1174                         1
    X251      R1435                         -1
    X252      R2                            -3.04
    X252      R325                          1
    X252      R787                          1
    X252      R1034                         1
    X252      R1436                         -1
    X253      R2                            -2.94
    X253      R326                          1
    X253      R788                          1
    X253      R1133                         1
    X253      R1437                         -1
    X254      R2                            -3.52
    X254      R327                          1
    X254      R789                          1
    X254      R1147                         1
    X254      R1438                         -1
    X255      R2                            -2.94
    X255      R328                          1
    X255      R790                          1
    X255      R1133                         1
    X255      R1439                         -1
    X256      R2                            -3.04
    X256      R329                          1
    X256      R791                          1
    X256      R1036                         1
    X256      R1440                         -1
    X257      R2                            -2.98
    X257      R330                          1
    X257      R792                          1
    X257      R1176                         1
    X257      R1441                         -1
    X258      R2                            -3.04
    X258      R331                          1
    X258      R793                          1
    X258      R1036                         1
    X258      R1442                         -1
    X259      R2                            -2.94
    X259      R332                          1
    X259      R794                          1
    X259      R1135                         1
    X259      R1443                         -1
    X260      R2                            -3.52
    X260      R333                          1
    X260      R795                          1
    X260      R1149                         1
    X260      R1444                         -1
    X261      R2                            -2.94
    X261      R334                          1
    X261      R796                          1
    X261      R1135                         1
    X261      R1445                         -1
    X262      R2                            -3.04
    X262      R335                          1
    X262      R797                          1
    X262      R1038                         1
    X262      R1446                         -1
    X263      R2                            -2.98
    X263      R336                          1
    X263      R798                          1
    X263      R1178                         1
    X263      R1447                         -1
    X264      R2                            -3.04
    X264      R337                          1
    X264      R799                          1
    X264      R1038                         1
    X264      R1448                         -1
    X265      R2                            -2.94
    X265      R338                          1
    X265      R800                          1
    X265      R1123                         1
    X265      R1648                         -1
    X266      R2                            -2.98
    X266      R339                          1
    X266      R801                          1
    X266      R1165                         1
    X266      R1449                         -1
    X267      R2                            -3.04
    X267      R340                          1
    X267      R802                          1
    X267      R1026                         1
    X267      R1450                         -1
    X268      R2                            -2.98
    X268      R341                          1
    X268      R803                          1
    X268      R1167                         1
    X268      R1451                         -1
    X269      R2                            -3.04
    X269      R342                          1
    X269      R804                          1
    X269      R1028                         1
    X269      R1452                         -1
    X270      R2                            -2.98
    X270      R343                          1
    X270      R805                          1
    X270      R1169                         1
    X270      R1453                         -1
    X271      R2                            -3.04
    X271      R344                          1
    X271      R806                          1
    X271      R1030                         1
    X271      R1454                         -1
    X272      R2                            -2.98
    X272      R345                          1
    X272      R807                          1
    X272      R1171                         1
    X272      R1455                         -1
    X273      R2                            -3.04
    X273      R346                          1
    X273      R808                          1
    X273      R1032                         1
    X273      R1456                         -1
    X274      R2                            -2.98
    X274      R347                          1
    X274      R809                          1
    X274      R1173                         1
    X274      R1457                         -1
    X275      R2                            -3.04
    X275      R348                          1
    X275      R810                          1
    X275      R1034                         1
    X275      R1458                         -1
    X276      R2                            -2.98
    X276      R349                          1
    X276      R811                          1
    X276      R1175                         1
    X276      R1459                         -1
    X277      R2                            -3.04
    X277      R350                          1
    X277      R812                          1
    X277      R1036                         1
    X277      R1460                         -1
    X278      R2                            -2.98
    X278      R351                          1
    X278      R813                          1
    X278      R1177                         1
    X278      R1461                         -1
    X279      R2                            -3.04
    X279      R352                          1
    X279      R814                          1
    X279      R1038                         1
    X279      R1649                         -1
    X280      R2                            -3.04
    X280      R353                          1
    X280      R815                          1
    X280      R1025                         1
    X280      R1462                         -1
    X281      R2                            -2.98
    X281      R354                          1
    X281      R816                          1
    X281      R1166                         1
    X281      R1463                         -1
    X282      R2                            -3.04
    X282      R355                          1
    X282      R817                          1
    X282      R1027                         1
    X282      R1464                         -1
    X283      R2                            -2.98
    X283      R356                          1
    X283      R818                          1
    X283      R1168                         1
    X283      R1465                         -1
    X284      R2                            -3.04
    X284      R357                          1
    X284      R819                          1
    X284      R1029                         1
    X284      R1466                         -1
    X285      R2                            -2.98
    X285      R358                          1
    X285      R820                          1
    X285      R1170                         1
    X285      R1467                         -1
    X286      R2                            -3.04
    X286      R359                          1
    X286      R821                          1
    X286      R1031                         1
    X286      R1468                         -1
    X287      R2                            -2.98
    X287      R360                          1
    X287      R822                          1
    X287      R1172                         1
    X287      R1469                         -1
    X288      R2                            -3.04
    X288      R361                          1
    X288      R823                          1
    X288      R1033                         1
    X288      R1470                         -1
    X289      R2                            -2.98
    X289      R362                          1
    X289      R824                          1
    X289      R1174                         1
    X289      R1471                         -1
    X290      R2                            -3.04
    X290      R363                          1
    X290      R825                          1
    X290      R1035                         1
    X290      R1472                         -1
    X291      R2                            -2.98
    X291      R364                          1
    X291      R826                          1
    X291      R1176                         1
    X291      R1473                         -1
    X292      R2                            -3.04
    X292      R365                          1
    X292      R827                          1
    X292      R1037                         1
    X292      R1474                         -1
    X293      R2                            -2.98
    X293      R366                          1
    X293      R828                          1
    X293      R1178                         1
    X293      R1650                         -1
    X294      R2                            -3.1
    X294      R367                          1
    X294      R829                          1
    X294      R1179                         1
    X294      R1475                         -1
    X295      R2                            -3.14
    X295      R368                          1
    X295      R830                          1
    X295      R1054                         1
    X295      R1476                         -1
    X296      R2                            -2.94
    X296      R369                          1
    X296      R831                          1
    X296      R1040                         1
    X296      R1477                         -1
    X297      R2                            -3.04
    X297      R370                          1
    X297      R832                          1
    X297      R1026                         1
    X297      R1478                         -1
    X298      R2                            -2.96
    X298      R371                          1
    X298      R833                          1
    X298      R998                          1
    X298      R1479                         -1
    X299      R2                            -2.94
    X299      R372                          1
    X299      R834                          1
    X299      R1124                         1
    X299      R1480                         -1
    X300      R2                            -3.12
    X300      R373                          1
    X300      R835                          1
    X300      R1152                         1
    X300      R1481                         -1
    X301      R2                            -2.96
    X301      R374                          1
    X301      R836                          1
    X301      R999                          1
    X301      R1482                         -1
    X302      R2                            -3.04
    X302      R375                          1
    X302      R837                          1
    X302      R1027                         1
    X302      R1483                         -1
    X303      R2                            -2.94
    X303      R376                          1
    X303      R838                          1
    X303      R1041                         1
    X303      R1484                         -1
    X304      R2                            -3.1
    X304      R377                          1
    X304      R839                          1
    X304      R1181                         1
    X304      R1485                         -1
    X305      R2                            -3.14
    X305      R378                          1
    X305      R840                          1
    X305      R1056                         1
    X305      R1486                         -1
    X306      R2                            -2.94
    X306      R379                          1
    X306      R841                          1
    X306      R1042                         1
    X306      R1487                         -1
    X307      R2                            -3.04
    X307      R380                          1
    X307      R842                          1
    X307      R1028                         1
    X307      R1488                         -1
    X308      R2                            -2.96
    X308      R381                          1
    X308      R843                          1
    X308      R1000                         1
    X308      R1489                         -1
    X309      R2                            -2.94
    X309      R382                          1
    X309      R844                          1
    X309      R1126                         1
    X309      R1490                         -1
    X310      R2                            -3.12
    X310      R383                          1
    X310      R845                          1
    X310      R1154                         1
    X310      R1491                         -1
    X311      R2                            -2.96
    X311      R384                          1
    X311      R846                          1
    X311      R1001                         1
    X311      R1492                         -1
    X312      R2                            -3.04
    X312      R385                          1
    X312      R847                          1
    X312      R1029                         1
    X312      R1493                         -1
    X313      R2                            -2.94
    X313      R386                          1
    X313      R848                          1
    X313      R1043                         1
    X313      R1494                         -1
    X314      R2                            -3.1
    X314      R387                          1
    X314      R849                          1
    X314      R1183                         1
    X314      R1495                         -1
    X315      R2                            -3.14
    X315      R388                          1
    X315      R850                          1
    X315      R1058                         1
    X315      R1496                         -1
    X316      R2                            -2.94
    X316      R389                          1
    X316      R851                          1
    X316      R1044                         1
    X316      R1497                         -1
    X317      R2                            -3.04
    X317      R390                          1
    X317      R852                          1
    X317      R1030                         1
    X317      R1498                         -1
    X318      R2                            -2.96
    X318      R391                          1
    X318      R853                          1
    X318      R1002                         1
    X318      R1499                         -1
    X319      R2                            -2.94
    X319      R392                          1
    X319      R854                          1
    X319      R1128                         1
    X319      R1500                         -1
    X320      R2                            -3.12
    X320      R393                          1
    X320      R855                          1
    X320      R1156                         1
    X320      R1501                         -1
    X321      R2                            -2.96
    X321      R394                          1
    X321      R856                          1
    X321      R1003                         1
    X321      R1502                         -1
    X322      R2                            -3.04
    X322      R395                          1
    X322      R857                          1
    X322      R1031                         1
    X322      R1503                         -1
    X323      R2                            -2.94
    X323      R396                          1
    X323      R858                          1
    X323      R1045                         1
    X323      R1504                         -1
    X324      R2                            -3.1
    X324      R397                          1
    X324      R859                          1
    X324      R1185                         1
    X324      R1505                         -1
    X325      R2                            -3.14
    X325      R398                          1
    X325      R860                          1
    X325      R1060                         1
    X325      R1506                         -1
    X326      R2                            -2.94
    X326      R399                          1
    X326      R861                          1
    X326      R1046                         1
    X326      R1507                         -1
    X327      R2                            -3.04
    X327      R400                          1
    X327      R862                          1
    X327      R1032                         1
    X327      R1508                         -1
    X328      R2                            -2.96
    X328      R401                          1
    X328      R863                          1
    X328      R1004                         1
    X328      R1509                         -1
    X329      R2                            -2.94
    X329      R402                          1
    X329      R864                          1
    X329      R1130                         1
    X329      R1510                         -1
    X330      R2                            -3.12
    X330      R403                          1
    X330      R865                          1
    X330      R1158                         1
    X330      R1511                         -1
    X331      R2                            -2.96
    X331      R404                          1
    X331      R866                          1
    X331      R1005                         1
    X331      R1512                         -1
    X332      R2                            -3.04
    X332      R405                          1
    X332      R867                          1
    X332      R1033                         1
    X332      R1513                         -1
    X333      R2                            -2.94
    X333      R406                          1
    X333      R868                          1
    X333      R1047                         1
    X333      R1514                         -1
    X334      R2                            -3.1
    X334      R407                          1
    X334      R869                          1
    X334      R1187                         1
    X334      R1515                         -1
    X335      R2                            -3.14
    X335      R408                          1
    X335      R870                          1
    X335      R1062                         1
    X335      R1516                         -1
    X336      R2                            -2.94
    X336      R409                          1
    X336      R871                          1
    X336      R1048                         1
    X336      R1517                         -1
    X337      R2                            -3.04
    X337      R410                          1
    X337      R872                          1
    X337      R1034                         1
    X337      R1518                         -1
    X338      R2                            -2.96
    X338      R411                          1
    X338      R873                          1
    X338      R1006                         1
    X338      R1519                         -1
    X339      R2                            -2.94
    X339      R412                          1
    X339      R874                          1
    X339      R1132                         1
    X339      R1520                         -1
    X340      R2                            -3.12
    X340      R413                          1
    X340      R875                          1
    X340      R1160                         1
    X340      R1521                         -1
    X341      R2                            -2.96
    X341      R414                          1
    X341      R876                          1
    X341      R1007                         1
    X341      R1522                         -1
    X342      R2                            -3.04
    X342      R415                          1
    X342      R877                          1
    X342      R1035                         1
    X342      R1523                         -1
    X343      R2                            -2.94
    X343      R416                          1
    X343      R878                          1
    X343      R1049                         1
    X343      R1524                         -1
    X344      R2                            -3.1
    X344      R417                          1
    X344      R879                          1
    X344      R1189                         1
    X344      R1525                         -1
    X345      R2                            -3.14
    X345      R418                          1
    X345      R880                          1
    X345      R1064                         1
    X345      R1526                         -1
    X346      R2                            -2.94
    X346      R419                          1
    X346      R881                          1
    X346      R1050                         1
    X346      R1527                         -1
    X347      R2                            -3.04
    X347      R420                          1
    X347      R882                          1
    X347      R1036                         1
    X347      R1528                         -1
    X348      R2                            -2.96
    X348      R421                          1
    X348      R883                          1
    X348      R1008                         1
    X348      R1529                         -1
    X349      R2                            -2.94
    X349      R422                          1
    X349      R884                          1
    X349      R1134                         1
    X349      R1530                         -1
    X350      R2                            -3.12
    X350      R423                          1
    X350      R885                          1
    X350      R1162                         1
    X350      R1531                         -1
    X351      R2                            -2.96
    X351      R424                          1
    X351      R886                          1
    X351      R1009                         1
    X351      R1532                         -1
    X352      R2                            -3.04
    X352      R425                          1
    X352      R887                          1
    X352      R1037                         1
    X352      R1533                         -1
    X353      R2                            -2.94
    X353      R426                          1
    X353      R888                          1
    X353      R1051                         1
    X353      R1534                         -1
    X354      R2                            -3.1
    X354      R427                          1
    X354      R889                          1
    X354      R1191                         1
    X354      R1535                         -1
    X355      R2                            -3.14
    X355      R428                          1
    X355      R890                          1
    X355      R1066                         1
    X355      R1536                         -1
    X356      R2                            -2.94
    X356      R429                          1
    X356      R891                          1
    X356      R1052                         1
    X356      R1537                         -1
    X357      R2                            -3.04
    X357      R430                          1
    X357      R892                          1
    X357      R1038                         1
    X357      R1538                         -1
    X358      R2                            -2.96
    X358      R431                          1
    X358      R893                          1
    X358      R1010                         1
    X358      R1539                         -1
    X359      R2                            -2.94
    X359      R432                          1
    X359      R894                          1
    X359      R1136                         1
    X359      R1540                         -1
    X360      R2                            -3.12
    X360      R433                          1
    X360      R895                          1
    X360      R1164                         1
    X360      R1541                         -1
    X361      R2                            -2.96
    X361      R434                          1
    X361      R896                          1
    X361      R997                          1
    X361      R1542                         -1
    X362      R2                            -3.04
    X362      R435                          1
    X362      R897                          1
    X362      R1025                         1
    X362      R1543                         -1
    X363      R2                            -2.94
    X363      R436                          1
    X363      R898                          1
    X363      R1039                         1
    X363      R1651                         -1
    X364      R2                            -3.12
    X364      R437                          1
    X364      R899                          1
    X364      R1151                         1
    X364      R1544                         -1
    X365      R2                            -2.96
    X365      R438                          1
    X365      R900                          1
    X365      R998                          1
    X365      R1545                         -1
    X366      R2                            -3.04
    X366      R439                          1
    X366      R901                          1
    X366      R1026                         1
    X366      R1546                         -1
    X367      R2                            -2.94
    X367      R440                          1
    X367      R902                          1
    X367      R1040                         1
    X367      R1547                         -1
    X368      R2                            -3.1
    X368      R441                          1
    X368      R903                          1
    X368      R1180                         1
    X368      R1548                         -1
    X369      R2                            -3.14
    X369      R442                          1
    X369      R904                          1
    X369      R1055                         1
    X369      R1549                         -1
    X370      R2                            -2.94
    X370      R443                          1
    X370      R905                          1
    X370      R1041                         1
    X370      R1550                         -1
    X371      R2                            -3.04
    X371      R444                          1
    X371      R906                          1
    X371      R1027                         1
    X371      R1551                         -1
    X372      R2                            -2.96
    X372      R445                          1
    X372      R907                          1
    X372      R999                          1
    X372      R1552                         -1
    X373      R2                            -2.94
    X373      R446                          1
    X373      R908                          1
    X373      R1125                         1
    X373      R1553                         -1
    X374      R2                            -3.12
    X374      R447                          1
    X374      R909                          1
    X374      R1153                         1
    X374      R1554                         -1
    X375      R2                            -2.96
    X375      R448                          1
    X375      R910                          1
    X375      R1000                         1
    X375      R1555                         -1
    X376      R2                            -3.04
    X376      R449                          1
    X376      R911                          1
    X376      R1028                         1
    X376      R1556                         -1
    X377      R2                            -2.94
    X377      R450                          1
    X377      R912                          1
    X377      R1042                         1
    X377      R1557                         -1
    X378      R2                            -3.1
    X378      R451                          1
    X378      R913                          1
    X378      R1182                         1
    X378      R1558                         -1
    X379      R2                            -3.14
    X379      R452                          1
    X379      R914                          1
    X379      R1057                         1
    X379      R1559                         -1
    X380      R2                            -2.94
    X380      R453                          1
    X380      R915                          1
    X380      R1043                         1
    X380      R1560                         -1
    X381      R2                            -3.04
    X381      R454                          1
    X381      R916                          1
    X381      R1029                         1
    X381      R1561                         -1
    X382      R2                            -2.96
    X382      R455                          1
    X382      R917                          1
    X382      R1001                         1
    X382      R1562                         -1
    X383      R2                            -2.94
    X383      R456                          1
    X383      R918                          1
    X383      R1127                         1
    X383      R1563                         -1
    X384      R2                            -3.12
    X384      R457                          1
    X384      R919                          1
    X384      R1155                         1
    X384      R1564                         -1
    X385      R2                            -2.96
    X385      R458                          1
    X385      R920                          1
    X385      R1002                         1
    X385      R1565                         -1
    X386      R2                            -3.04
    X386      R459                          1
    X386      R921                          1
    X386      R1030                         1
    X386      R1566                         -1
    X387      R2                            -2.94
    X387      R460                          1
    X387      R922                          1
    X387      R1044                         1
    X387      R1567                         -1
    X388      R2                            -3.1
    X388      R461                          1
    X388      R923                          1
    X388      R1184                         1
    X388      R1568                         -1
    X389      R2                            -3.14
    X389      R462                          1
    X389      R924                          1
    X389      R1059                         1
    X389      R1569                         -1
    X390      R2                            -2.94
    X390      R463                          1
    X390      R925                          1
    X390      R1045                         1
    X390      R1570                         -1
    X391      R2                            -3.04
    X391      R464                          1
    X391      R926                          1
    X391      R1031                         1
    X391      R1571                         -1
    X392      R2                            -2.96
    X392      R465                          1
    X392      R927                          1
    X392      R1003                         1
    X392      R1572                         -1
    X393      R2                            -2.94
    X393      R466                          1
    X393      R928                          1
    X393      R1129                         1
    X393      R1573                         -1
    X394      R2                            -3.12
    X394      R467                          1
    X394      R929                          1
    X394      R1157                         1
    X394      R1574                         -1
    X395      R2                            -2.96
    X395      R468                          1
    X395      R930                          1
    X395      R1004                         1
    X395      R1575                         -1
    X396      R2                            -3.04
    X396      R469                          1
    X396      R931                          1
    X396      R1032                         1
    X396      R1576                         -1
    X397      R2                            -2.94
    X397      R470                          1
    X397      R932                          1
    X397      R1046                         1
    X397      R1577                         -1
    X398      R2                            -3.1
    X398      R471                          1
    X398      R933                          1
    X398      R1186                         1
    X398      R1578                         -1
    X399      R2                            -3.14
    X399      R472                          1
    X399      R934                          1
    X399      R1061                         1
    X399      R1579                         -1
    X400      R2                            -2.94
    X400      R473                          1
    X400      R935                          1
    X400      R1047                         1
    X400      R1580                         -1
    X401      R2                            -3.04
    X401      R474                          1
    X401      R936                          1
    X401      R1033                         1
    X401      R1581                         -1
    X402      R2                            -2.96
    X402      R475                          1
    X402      R937                          1
    X402      R1005                         1
    X402      R1582                         -1
    X403      R2                            -2.94
    X403      R476                          1
    X403      R938                          1
    X403      R1131                         1
    X403      R1583                         -1
    X404      R2                            -3.12
    X404      R477                          1
    X404      R939                          1
    X404      R1159                         1
    X404      R1584                         -1
    X405      R2                            -2.96
    X405      R478                          1
    X405      R940                          1
    X405      R1006                         1
    X405      R1585                         -1
    X406      R2                            -3.04
    X406      R479                          1
    X406      R941                          1
    X406      R1034                         1
    X406      R1586                         -1
    X407      R2                            -2.94
    X407      R480                          1
    X407      R942                          1
    X407      R1048                         1
    X407      R1587                         -1
    X408      R2                            -3.1
    X408      R481                          1
    X408      R943                          1
    X408      R1188                         1
    X408      R1588                         -1
    X409      R2                            -3.14
    X409      R482                          1
    X409      R944                          1
    X409      R1063                         1
    X409      R1589                         -1
    X410      R2                            -2.94
    X410      R483                          1
    X410      R945                          1
    X410      R1049                         1
    X410      R1590                         -1
    X411      R2                            -3.04
    X411      R484                          1
    X411      R946                          1
    X411      R1035                         1
    X411      R1591                         -1
    X412      R2                            -2.96
    X412      R485                          1
    X412      R947                          1
    X412      R1007                         1
    X412      R1592                         -1
    X413      R2                            -2.94
    X413      R486                          1
    X413      R948                          1
    X413      R1133                         1
    X413      R1593                         -1
    X414      R2                            -3.12
    X414      R487                          1
    X414      R949                          1
    X414      R1161                         1
    X414      R1594                         -1
    X415      R2                            -2.96
    X415      R488                          1
    X415      R950                          1
    X415      R1008                         1
    X415      R1595                         -1
    X416      R2                            -3.04
    X416      R489                          1
    X416      R951                          1
    X416      R1036                         1
    X416      R1596                         -1
    X417      R2                            -2.94
    X417      R490                          1
    X417      R952                          1
    X417      R1050                         1
    X417      R1597                         -1
    X418      R2                            -3.1
    X418      R491                          1
    X418      R953                          1
    X418      R1190                         1
    X418      R1598                         -1
    X419      R2                            -3.14
    X419      R492                          1
    X419      R954                          1
    X419      R1065                         1
    X419      R1599                         -1
    X420      R2                            -2.94
    X420      R493                          1
    X420      R955                          1
    X420      R1051                         1
    X420      R1600                         -1
    X421      R2                            -3.04
    X421      R494                          1
    X421      R956                          1
    X421      R1037                         1
    X421      R1601                         -1
    X422      R2                            -2.96
    X422      R495                          1
    X422      R957                          1
    X422      R1009                         1
    X422      R1602                         -1
    X423      R2                            -2.94
    X423      R496                          1
    X423      R958                          1
    X423      R1135                         1
    X423      R1603                         -1
    X424      R2                            -3.12
    X424      R497                          1
    X424      R959                          1
    X424      R1163                         1
    X424      R1604                         -1
    X425      R2                            -2.96
    X425      R498                          1
    X425      R960                          1
    X425      R1010                         1
    X425      R1605                         -1
    X426      R2                            -3.04
    X426      R499                          1
    X426      R961                          1
    X426      R1038                         1
    X426      R1606                         -1
    X427      R2                            -2.94
    X427      R500                          1
    X427      R962                          1
    X427      R1052                         1
    X427      R1607                         -1
    X428      R2                            -3.1
    X428      R501                          1
    X428      R963                          1
    X428      R1192                         1
    X428      R1608                         -1
    X429      R2                            -3.14
    X429      R502                          1
    X429      R964                          1
    X429      R1053                         1
    X429      R1609                         -1
    X430      R2                            -2.94
    X430      R503                          1
    X430      R965                          1
    X430      R1039                         1
    X430      R1610                         -1
    X431      R2                            -3.04
    X431      R504                          1
    X431      R966                          1
    X431      R1025                         1
    X431      R1611                         -1
    X432      R2                            -2.96
    X432      R505                          1
    X432      R967                          1
    X432      R997                          1
    X432      R1612                         -1
    X433      R2                            -2.94
    X433      R506                          1
    X433      R968                          1
    X433      R1123                         1
    X433      R1652                         -1
    X434      R2                            -2.96
    X434      R507                          1
    X434      R969                          1
    X434      R1011                         1
    X434      R1613                         -1
    X435      R2                            -2.96
    X435      R508                          1
    X435      R970                          1
    X435      R1068                         1
    X435      R1614                         -1
    X436      R2                            -2.96
    X436      R509                          1
    X436      R971                          1
    X436      R1013                         1
    X436      R1615                         -1
    X437      R2                            -2.96
    X437      R510                          1
    X437      R972                          1
    X437      R1070                         1
    X437      R1616                         -1
    X438      R2                            -2.96
    X438      R511                          1
    X438      R973                          1
    X438      R1015                         1
    X438      R1617                         -1
    X439      R2                            -2.96
    X439      R512                          1
    X439      R974                          1
    X439      R1072                         1
    X439      R1618                         -1
    X440      R2                            -2.96
    X440      R513                          1
    X440      R975                          1
    X440      R1017                         1
    X440      R1619                         -1
    X441      R2                            -2.96
    X441      R514                          1
    X441      R976                          1
    X441      R1074                         1
    X441      R1620                         -1
    X442      R2                            -2.96
    X442      R515                          1
    X442      R977                          1
    X442      R1019                         1
    X442      R1621                         -1
    X443      R2                            -2.96
    X443      R516                          1
    X443      R978                          1
    X443      R1076                         1
    X443      R1622                         -1
    X444      R2                            -2.96
    X444      R517                          1
    X444      R979                          1
    X444      R1021                         1
    X444      R1623                         -1
    X445      R2                            -2.96
    X445      R518                          1
    X445      R980                          1
    X445      R1078                         1
    X445      R1624                         -1
    X446      R2                            -2.96
    X446      R519                          1
    X446      R981                          1
    X446      R1023                         1
    X446      R1625                         -1
    X447      R2                            -2.96
    X447      R520                          1
    X447      R982                          1
    X447      R1080                         1
    X447      R1653                         -1
    X448      R2                            -2.96
    X448      R521                          1
    X448      R983                          1
    X448      R1067                         1
    X448      R1626                         -1
    X449      R2                            -2.96
    X449      R522                          1
    X449      R984                          1
    X449      R1012                         1
    X449      R1627                         -1
    X450      R2                            -2.96
    X450      R523                          1
    X450      R985                          1
    X450      R1069                         1
    X450      R1628                         -1
    X451      R2                            -2.96
    X451      R524                          1
    X451      R986                          1
    X451      R1014                         1
    X451      R1629                         -1
    X452      R2                            -2.96
    X452      R525                          1
    X452      R987                          1
    X452      R1071                         1
    X452      R1630                         -1
    X453      R2                            -2.96
    X453      R526                          1
    X453      R988                          1
    X453      R1016                         1
    X453      R1631                         -1
    X454      R2                            -2.96
    X454      R527                          1
    X454      R989                          1
    X454      R1073                         1
    X454      R1632                         -1
    X455      R2                            -2.96
    X455      R528                          1
    X455      R990                          1
    X455      R1018                         1
    X455      R1633                         -1
    X456      R2                            -2.96
    X456      R529                          1
    X456      R991                          1
    X456      R1075                         1
    X456      R1634                         -1
    X457      R2                            -2.96
    X457      R530                          1
    X457      R992                          1
    X457      R1020                         1
    X457      R1635                         -1
    X458      R2                            -2.96
    X458      R531                          1
    X458      R993                          1
    X458      R1077                         1
    X458      R1636                         -1
    X459      R2                            -2.96
    X459      R532                          1
    X459      R994                          1
    X459      R1022                         1
    X459      R1637                         -1
    X460      R2                            -2.96
    X460      R533                          1
    X460      R995                          1
    X460      R1079                         1
    X460      R1638                         -1
    X461      R2                            -2.96
    X461      R534                          1
    X461      R996                          1
    X461      R1024                         1
    X461      R1654                         -1
    X462      R73                           1
    X462      R1193                         -1
    X462      R1639                         1
    X463      R74                           1
    X463      R1193                         1
    X463      R1194                         -1
    X464      R75                           1
    X464      R1194                         1
    X464      R1195                         -1
    X465      R76                           1
    X465      R1195                         1
    X465      R1196                         -1
    X466      R77                           1
    X466      R1196                         1
    X466      R1197                         -1
    X467      R78                           1
    X467      R1197                         1
    X467      R1198                         -1
    X468      R79                           1
    X468      R1198                         1
    X468      R1199                         -1
    X469      R80                           1
    X469      R1199                         1
    X469      R1200                         -1
    X470      R81                           1
    X470      R1200                         1
    X470      R1201                         -1
    X471      R82                           1
    X471      R1201                         1
    X471      R1202                         -1
    X472      R83                           1
    X472      R1202                         1
    X472      R1203                         -1
    X473      R84                           1
    X473      R1203                         1
    X473      R1204                         -1
    X474      R85                           1
    X474      R1204                         1
    X474      R1205                         -1
    X475      R86                           1
    X475      R1205                         1
    X475      R1639                         -1
    X476      R87                           1
    X476      R1206                         -1
    X476      R1640                         1
    X477      R88                           1
    X477      R1206                         1
    X477      R1207                         -1
    X478      R89                           1
    X478      R1207                         1
    X478      R1208                         -1
    X479      R90                           1
    X479      R1208                         1
    X479      R1209                         -1
    X480      R91                           1
    X480      R1209                         1
    X480      R1210                         -1
    X481      R92                           1
    X481      R1210                         1
    X481      R1211                         -1
    X482      R93                           1
    X482      R1211                         1
    X482      R1212                         -1
    X483      R94                           1
    X483      R1212                         1
    X483      R1213                         -1
    X484      R95                           1
    X484      R1213                         1
    X484      R1214                         -1
    X485      R96                           1
    X485      R1214                         1
    X485      R1215                         -1
    X486      R97                           1
    X486      R1215                         1
    X486      R1216                         -1
    X487      R98                           1
    X487      R1216                         1
    X487      R1217                         -1
    X488      R99                           1
    X488      R1217                         1
    X488      R1218                         -1
    X489      R100                          1
    X489      R1218                         1
    X489      R1640                         -1
    X490      R101                          1
    X490      R1219                         -1
    X490      R1641                         1
    X491      R102                          1
    X491      R1219                         1
    X491      R1220                         -1
    X492      R103                          1
    X492      R1220                         1
    X492      R1221                         -1
    X493      R104                          1
    X493      R1221                         1
    X493      R1222                         -1
    X494      R105                          1
    X494      R1222                         1
    X494      R1223                         -1
    X495      R106                          1
    X495      R1223                         1
    X495      R1224                         -1
    X496      R107                          1
    X496      R1224                         1
    X496      R1225                         -1
    X497      R108                          1
    X497      R1225                         1
    X497      R1226                         -1
    X498      R109                          1
    X498      R1226                         1
    X498      R1227                         -1
    X499      R110                          1
    X499      R1227                         1
    X499      R1228                         -1
    X500      R111                          1
    X500      R1228                         1
    X500      R1229                         -1
    X501      R112                          1
    X501      R1229                         1
    X501      R1230                         -1
    X502      R113                          1
    X502      R1230                         1
    X502      R1231                         -1
    X503      R114                          1
    X503      R1231                         1
    X503      R1232                         -1
    X504      R115                          1
    X504      R1232                         1
    X504      R1233                         -1
    X505      R116                          1
    X505      R1233                         1
    X505      R1234                         -1
    X506      R117                          1
    X506      R1234                         1
    X506      R1235                         -1
    X507      R118                          1
    X507      R1235                         1
    X507      R1236                         -1
    X508      R119                          1
    X508      R1236                         1
    X508      R1237                         -1
    X509      R120                          1
    X509      R1237                         1
    X509      R1238                         -1
    X510      R121                          1
    X510      R1238                         1
    X510      R1239                         -1
    X511      R122                          1
    X511      R1239                         1
    X511      R1240                         -1
    X512      R123                          1
    X512      R1240                         1
    X512      R1241                         -1
    X513      R124                          1
    X513      R1241                         1
    X513      R1242                         -1
    X514      R125                          1
    X514      R1242                         1
    X514      R1243                         -1
    X515      R126                          1
    X515      R1243                         1
    X515      R1244                         -1
    X516      R127                          1
    X516      R1244                         1
    X516      R1245                         -1
    X517      R128                          1
    X517      R1245                         1
    X517      R1641                         -1
    X518      R129                          1
    X518      R1246                         -1
    X518      R1642                         1
    X519      R130                          1
    X519      R1246                         1
    X519      R1247                         -1
    X520      R131                          1
    X520      R1247                         1
    X520      R1248                         -1
    X521      R132                          1
    X521      R1248                         1
    X521      R1249                         -1
    X522      R133                          1
    X522      R1249                         1
    X522      R1250                         -1
    X523      R134                          1
    X523      R1250                         1
    X523      R1251                         -1
    X524      R135                          1
    X524      R1251                         1
    X524      R1252                         -1
    X525      R136                          1
    X525      R1252                         1
    X525      R1253                         -1
    X526      R137                          1
    X526      R1253                         1
    X526      R1254                         -1
    X527      R138                          1
    X527      R1254                         1
    X527      R1255                         -1
    X528      R139                          1
    X528      R1255                         1
    X528      R1256                         -1
    X529      R140                          1
    X529      R1256                         1
    X529      R1257                         -1
    X530      R141                          1
    X530      R1257                         1
    X530      R1258                         -1
    X531      R142                          1
    X531      R1258                         1
    X531      R1259                         -1
    X532      R143                          1
    X532      R1259                         1
    X532      R1260                         -1
    X533      R144                          1
    X533      R1260                         1
    X533      R1261                         -1
    X534      R145                          1
    X534      R1261                         1
    X534      R1262                         -1
    X535      R146                          1
    X535      R1262                         1
    X535      R1263                         -1
    X536      R147                          1
    X536      R1263                         1
    X536      R1264                         -1
    X537      R148                          1
    X537      R1264                         1
    X537      R1265                         -1
    X538      R149                          1
    X538      R1265                         1
    X538      R1266                         -1
    X539      R150                          1
    X539      R1266                         1
    X539      R1267                         -1
    X540      R151                          1
    X540      R1267                         1
    X540      R1268                         -1
    X541      R152                          1
    X541      R1268                         1
    X541      R1269                         -1
    X542      R153                          1
    X542      R1269                         1
    X542      R1270                         -1
    X543      R154                          1
    X543      R1270                         1
    X543      R1271                         -1
    X544      R155                          1
    X544      R1271                         1
    X544      R1272                         -1
    X545      R156                          1
    X545      R1272                         1
    X545      R1642                         -1
    X546      R157                          1
    X546      R1273                         -1
    X546      R1643                         1
    X547      R158                          1
    X547      R1273                         1
    X547      R1274                         -1
    X548      R159                          1
    X548      R1274                         1
    X548      R1275                         -1
    X549      R160                          1
    X549      R1275                         1
    X549      R1276                         -1
    X550      R161                          1
    X550      R1276                         1
    X550      R1277                         -1
    X551      R162                          1
    X551      R1277                         1
    X551      R1278                         -1
    X552      R163                          1
    X552      R1278                         1
    X552      R1279                         -1
    X553      R164                          1
    X553      R1279                         1
    X553      R1280                         -1
    X554      R165                          1
    X554      R1280                         1
    X554      R1281                         -1
    X555      R166                          1
    X555      R1281                         1
    X555      R1282                         -1
    X556      R167                          1
    X556      R1282                         1
    X556      R1283                         -1
    X557      R168                          1
    X557      R1283                         1
    X557      R1284                         -1
    X558      R169                          1
    X558      R1284                         1
    X558      R1285                         -1
    X559      R170                          1
    X559      R1285                         1
    X559      R1286                         -1
    X560      R171                          1
    X560      R1286                         1
    X560      R1287                         -1
    X561      R172                          1
    X561      R1287                         1
    X561      R1288                         -1
    X562      R173                          1
    X562      R1288                         1
    X562      R1289                         -1
    X563      R174                          1
    X563      R1289                         1
    X563      R1290                         -1
    X564      R175                          1
    X564      R1290                         1
    X564      R1291                         -1
    X565      R176                          1
    X565      R1291                         1
    X565      R1292                         -1
    X566      R177                          1
    X566      R1292                         1
    X566      R1293                         -1
    X567      R178                          1
    X567      R1293                         1
    X567      R1294                         -1
    X568      R179                          1
    X568      R1294                         1
    X568      R1295                         -1
    X569      R180                          1
    X569      R1295                         1
    X569      R1296                         -1
    X570      R181                          1
    X570      R1296                         1
    X570      R1297                         -1
    X571      R182                          1
    X571      R1297                         1
    X571      R1298                         -1
    X572      R183                          1
    X572      R1298                         1
    X572      R1299                         -1
    X573      R184                          1
    X573      R1299                         1
    X573      R1643                         -1
    X574      R185                          1
    X574      R1300                         -1
    X574      R1644                         1
    X575      R186                          1
    X575      R1300                         1
    X575      R1301                         -1
    X576      R187                          1
    X576      R1301                         1
    X576      R1302                         -1
    X577      R188                          1
    X577      R1302                         1
    X577      R1303                         -1
    X578      R189                          1
    X578      R1303                         1
    X578      R1304                         -1
    X579      R190                          1
    X579      R1304                         1
    X579      R1305                         -1
    X580      R191                          1
    X580      R1305                         1
    X580      R1306                         -1
    X581      R192                          1
    X581      R1306                         1
    X581      R1307                         -1
    X582      R193                          1
    X582      R1307                         1
    X582      R1308                         -1
    X583      R194                          1
    X583      R1308                         1
    X583      R1309                         -1
    X584      R195                          1
    X584      R1309                         1
    X584      R1310                         -1
    X585      R196                          1
    X585      R1310                         1
    X585      R1311                         -1
    X586      R197                          1
    X586      R1311                         1
    X586      R1312                         -1
    X587      R198                          1
    X587      R1312                         1
    X587      R1313                         -1
    X588      R199                          1
    X588      R1313                         1
    X588      R1314                         -1
    X589      R200                          1
    X589      R1314                         1
    X589      R1315                         -1
    X590      R201                          1
    X590      R1315                         1
    X590      R1316                         -1
    X591      R202                          1
    X591      R1316                         1
    X591      R1317                         -1
    X592      R203                          1
    X592      R1317                         1
    X592      R1318                         -1
    X593      R204                          1
    X593      R1318                         1
    X593      R1319                         -1
    X594      R205                          1
    X594      R1319                         1
    X594      R1320                         -1
    X595      R206                          1
    X595      R1320                         1
    X595      R1321                         -1
    X596      R207                          1
    X596      R1321                         1
    X596      R1322                         -1
    X597      R208                          1
    X597      R1322                         1
    X597      R1323                         -1
    X598      R209                          1
    X598      R1323                         1
    X598      R1324                         -1
    X599      R210                          1
    X599      R1324                         1
    X599      R1325                         -1
    X600      R211                          1
    X600      R1325                         1
    X600      R1326                         -1
    X601      R212                          1
    X601      R1326                         1
    X601      R1644                         -1
    X602      R213                          1
    X602      R1327                         -1
    X602      R1645                         1
    X603      R214                          1
    X603      R1327                         1
    X603      R1328                         -1
    X604      R215                          1
    X604      R1328                         1
    X604      R1329                         -1
    X605      R216                          1
    X605      R1329                         1
    X605      R1330                         -1
    X606      R217                          1
    X606      R1330                         1
    X606      R1331                         -1
    X607      R218                          1
    X607      R1331                         1
    X607      R1332                         -1
    X608      R219                          1
    X608      R1332                         1
    X608      R1333                         -1
    X609      R220                          1
    X609      R1333                         1
    X609      R1334                         -1
    X610      R221                          1
    X610      R1334                         1
    X610      R1335                         -1
    X611      R222                          1
    X611      R1335                         1
    X611      R1336                         -1
    X612      R223                          1
    X612      R1336                         1
    X612      R1337                         -1
    X613      R224                          1
    X613      R1337                         1
    X613      R1338                         -1
    X614      R225                          1
    X614      R1338                         1
    X614      R1339                         -1
    X615      R226                          1
    X615      R1339                         1
    X615      R1340                         -1
    X616      R227                          1
    X616      R1340                         1
    X616      R1341                         -1
    X617      R228                          1
    X617      R1341                         1
    X617      R1342                         -1
    X618      R229                          1
    X618      R1342                         1
    X618      R1343                         -1
    X619      R230                          1
    X619      R1343                         1
    X619      R1344                         -1
    X620      R231                          1
    X620      R1344                         1
    X620      R1345                         -1
    X621      R232                          1
    X621      R1345                         1
    X621      R1346                         -1
    X622      R233                          1
    X622      R1346                         1
    X622      R1645                         -1
    X623      R234                          1
    X623      R1347                         -1
    X623      R1646                         1
    X624      R235                          1
    X624      R1347                         1
    X624      R1348                         -1
    X625      R236                          1
    X625      R1348                         1
    X625      R1349                         -1
    X626      R237                          1
    X626      R1349                         1
    X626      R1350                         -1
    X627      R238                          1
    X627      R1350                         1
    X627      R1351                         -1
    X628      R239                          1
    X628      R1351                         1
    X628      R1352                         -1
    X629      R240                          1
    X629      R1352                         1
    X629      R1353                         -1
    X630      R241                          1
    X630      R1353                         1
    X630      R1354                         -1
    X631      R242                          1
    X631      R1354                         1
    X631      R1355                         -1
    X632      R243                          1
    X632      R1355                         1
    X632      R1356                         -1
    X633      R244                          1
    X633      R1356                         1
    X633      R1357                         -1
    X634      R245                          1
    X634      R1357                         1
    X634      R1358                         -1
    X635      R246                          1
    X635      R1358                         1
    X635      R1359                         -1
    X636      R247                          1
    X636      R1359                         1
    X636      R1360                         -1
    X637      R248                          1
    X637      R1360                         1
    X637      R1361                         -1
    X638      R249                          1
    X638      R1361                         1
    X638      R1362                         -1
    X639      R250                          1
    X639      R1362                         1
    X639      R1363                         -1
    X640      R251                          1
    X640      R1363                         1
    X640      R1364                         -1
    X641      R252                          1
    X641      R1364                         1
    X641      R1365                         -1
    X642      R253                          1
    X642      R1365                         1
    X642      R1366                         -1
    X643      R254                          1
    X643      R1366                         1
    X643      R1646                         -1
    X644      R255                          1
    X644      R1367                         -1
    X644      R1647                         1
    X645      R256                          1
    X645      R1367                         1
    X645      R1368                         -1
    X646      R257                          1
    X646      R1368                         1
    X646      R1369                         -1
    X647      R258                          1
    X647      R1369                         1
    X647      R1370                         -1
    X648      R259                          1
    X648      R1370                         1
    X648      R1371                         -1
    X649      R260                          1
    X649      R1371                         1
    X649      R1372                         -1
    X650      R261                          1
    X650      R1372                         1
    X650      R1373                         -1
    X651      R262                          1
    X651      R1373                         1
    X651      R1374                         -1
    X652      R263                          1
    X652      R1374                         1
    X652      R1375                         -1
    X653      R264                          1
    X653      R1375                         1
    X653      R1376                         -1
    X654      R265                          1
    X654      R1376                         1
    X654      R1377                         -1
    X655      R266                          1
    X655      R1377                         1
    X655      R1378                         -1
    X656      R267                          1
    X656      R1378                         1
    X656      R1379                         -1
    X657      R268                          1
    X657      R1379                         1
    X657      R1380                         -1
    X658      R269                          1
    X658      R1380                         1
    X658      R1381                         -1
    X659      R270                          1
    X659      R1381                         1
    X659      R1382                         -1
    X660      R271                          1
    X660      R1382                         1
    X660      R1383                         -1
    X661      R272                          1
    X661      R1383                         1
    X661      R1384                         -1
    X662      R273                          1
    X662      R1384                         1
    X662      R1385                         -1
    X663      R274                          1
    X663      R1385                         1
    X663      R1386                         -1
    X664      R275                          1
    X664      R1386                         1
    X664      R1387                         -1
    X665      R276                          1
    X665      R1387                         1
    X665      R1388                         -1
    X666      R277                          1
    X666      R1388                         1
    X666      R1389                         -1
    X667      R278                          1
    X667      R1389                         1
    X667      R1390                         -1
    X668      R279                          1
    X668      R1390                         1
    X668      R1391                         -1
    X669      R280                          1
    X669      R1391                         1
    X669      R1392                         -1
    X670      R281                          1
    X670      R1392                         1
    X670      R1393                         -1
    X671      R282                          1
    X671      R1393                         1
    X671      R1394                         -1
    X672      R283                          1
    X672      R1394                         1
    X672      R1395                         -1
    X673      R284                          1
    X673      R1395                         1
    X673      R1396                         -1
    X674      R285                          1
    X674      R1396                         1
    X674      R1397                         -1
    X675      R286                          1
    X675      R1397                         1
    X675      R1398                         -1
    X676      R287                          1
    X676      R1398                         1
    X676      R1399                         -1
    X677      R288                          1
    X677      R1399                         1
    X677      R1400                         -1
    X678      R289                          1
    X678      R1400                         1
    X678      R1401                         -1
    X679      R290                          1
    X679      R1401                         1
    X679      R1402                         -1
    X680      R291                          1
    X680      R1402                         1
    X680      R1403                         -1
    X681      R292                          1
    X681      R1403                         1
    X681      R1404                         -1
    X682      R293                          1
    X682      R1404                         1
    X682      R1405                         -1
    X683      R294                          1
    X683      R1405                         1
    X683      R1406                         -1
    X684      R295                          1
    X684      R1406                         1
    X684      R1407                         -1
    X685      R296                          1
    X685      R1407                         1
    X685      R1647                         -1
    X686      R297                          1
    X686      R1408                         -1
    X686      R1648                         1
    X687      R298                          1
    X687      R1408                         1
    X687      R1409                         -1
    X688      R299                          1
    X688      R1409                         1
    X688      R1410                         -1
    X689      R300                          1
    X689      R1410                         1
    X689      R1411                         -1
    X690      R301                          1
    X690      R1411                         1
    X690      R1412                         -1
    X691      R302                          1
    X691      R1412                         1
    X691      R1413                         -1
    X692      R303                          1
    X692      R1413                         1
    X692      R1414                         -1
    X693      R304                          1
    X693      R1414                         1
    X693      R1415                         -1
    X694      R305                          1
    X694      R1415                         1
    X694      R1416                         -1
    X695      R306                          1
    X695      R1416                         1
    X695      R1417                         -1
    X696      R307                          1
    X696      R1417                         1
    X696      R1418                         -1
    X697      R308                          1
    X697      R1418                         1
    X697      R1419                         -1
    X698      R309                          1
    X698      R1419                         1
    X698      R1420                         -1
    X699      R310                          1
    X699      R1420                         1
    X699      R1421                         -1
    X700      R311                          1
    X700      R1421                         1
    X700      R1422                         -1
    X701      R312                          1
    X701      R1422                         1
    X701      R1423                         -1
    X702      R313                          1
    X702      R1423                         1
    X702      R1424                         -1
    X703      R314                          1
    X703      R1424                         1
    X703      R1425                         -1
    X704      R315                          1
    X704      R1425                         1
    X704      R1426                         -1
    X705      R316                          1
    X705      R1426                         1
    X705      R1427                         -1
    X706      R317                          1
    X706      R1427                         1
    X706      R1428                         -1
    X707      R318                          1
    X707      R1428                         1
    X707      R1429                         -1
    X708      R319                          1
    X708      R1429                         1
    X708      R1430                         -1
    X709      R320                          1
    X709      R1430                         1
    X709      R1431                         -1
    X710      R321                          1
    X710      R1431                         1
    X710      R1432                         -1
    X711      R322                          1
    X711      R1432                         1
    X711      R1433                         -1
    X712      R323                          1
    X712      R1433                         1
    X712      R1434                         -1
    X713      R324                          1
    X713      R1434                         1
    X713      R1435                         -1
    X714      R325                          1
    X714      R1435                         1
    X714      R1436                         -1
    X715      R326                          1
    X715      R1436                         1
    X715      R1437                         -1
    X716      R327                          1
    X716      R1437                         1
    X716      R1438                         -1
    X717      R328                          1
    X717      R1438                         1
    X717      R1439                         -1
    X718      R329                          1
    X718      R1439                         1
    X718      R1440                         -1
    X719      R330                          1
    X719      R1440                         1
    X719      R1441                         -1
    X720      R331                          1
    X720      R1441                         1
    X720      R1442                         -1
    X721      R332                          1
    X721      R1442                         1
    X721      R1443                         -1
    X722      R333                          1
    X722      R1443                         1
    X722      R1444                         -1
    X723      R334                          1
    X723      R1444                         1
    X723      R1445                         -1
    X724      R335                          1
    X724      R1445                         1
    X724      R1446                         -1
    X725      R336                          1
    X725      R1446                         1
    X725      R1447                         -1
    X726      R337                          1
    X726      R1447                         1
    X726      R1448                         -1
    X727      R338                          1
    X727      R1448                         1
    X727      R1648                         -1
    X728      R339                          1
    X728      R1449                         -1
    X728      R1649                         1
    X729      R340                          1
    X729      R1449                         1
    X729      R1450                         -1
    X730      R341                          1
    X730      R1450                         1
    X730      R1451                         -1
    X731      R342                          1
    X731      R1451                         1
    X731      R1452                         -1
    X732      R343                          1
    X732      R1452                         1
    X732      R1453                         -1
    X733      R344                          1
    X733      R1453                         1
    X733      R1454                         -1
    X734      R345                          1
    X734      R1454                         1
    X734      R1455                         -1
    X735      R346                          1
    X735      R1455                         1
    X735      R1456                         -1
    X736      R347                          1
    X736      R1456                         1
    X736      R1457                         -1
    X737      R348                          1
    X737      R1457                         1
    X737      R1458                         -1
    X738      R349                          1
    X738      R1458                         1
    X738      R1459                         -1
    X739      R350                          1
    X739      R1459                         1
    X739      R1460                         -1
    X740      R351                          1
    X740      R1460                         1
    X740      R1461                         -1
    X741      R352                          1
    X741      R1461                         1
    X741      R1649                         -1
    X742      R353                          1
    X742      R1462                         -1
    X742      R1650                         1
    X743      R354                          1
    X743      R1462                         1
    X743      R1463                         -1
    X744      R355                          1
    X744      R1463                         1
    X744      R1464                         -1
    X745      R356                          1
    X745      R1464                         1
    X745      R1465                         -1
    X746      R357                          1
    X746      R1465                         1
    X746      R1466                         -1
    X747      R358                          1
    X747      R1466                         1
    X747      R1467                         -1
    X748      R359                          1
    X748      R1467                         1
    X748      R1468                         -1
    X749      R360                          1
    X749      R1468                         1
    X749      R1469                         -1
    X750      R361                          1
    X750      R1469                         1
    X750      R1470                         -1
    X751      R362                          1
    X751      R1470                         1
    X751      R1471                         -1
    X752      R363                          1
    X752      R1471                         1
    X752      R1472                         -1
    X753      R364                          1
    X753      R1472                         1
    X753      R1473                         -1
    X754      R365                          1
    X754      R1473                         1
    X754      R1474                         -1
    X755      R366                          1
    X755      R1474                         1
    X755      R1650                         -1
    X756      R367                          1
    X756      R1475                         -1
    X756      R1651                         1
    X757      R368                          1
    X757      R1475                         1
    X757      R1476                         -1
    X758      R369                          1
    X758      R1476                         1
    X758      R1477                         -1
    X759      R370                          1
    X759      R1477                         1
    X759      R1478                         -1
    X760      R371                          1
    X760      R1478                         1
    X760      R1479                         -1
    X761      R372                          1
    X761      R1479                         1
    X761      R1480                         -1
    X762      R373                          1
    X762      R1480                         1
    X762      R1481                         -1
    X763      R374                          1
    X763      R1481                         1
    X763      R1482                         -1
    X764      R375                          1
    X764      R1482                         1
    X764      R1483                         -1
    X765      R376                          1
    X765      R1483                         1
    X765      R1484                         -1
    X766      R377                          1
    X766      R1484                         1
    X766      R1485                         -1
    X767      R378                          1
    X767      R1485                         1
    X767      R1486                         -1
    X768      R379                          1
    X768      R1486                         1
    X768      R1487                         -1
    X769      R380                          1
    X769      R1487                         1
    X769      R1488                         -1
    X770      R381                          1
    X770      R1488                         1
    X770      R1489                         -1
    X771      R382                          1
    X771      R1489                         1
    X771      R1490                         -1
    X772      R383                          1
    X772      R1490                         1
    X772      R1491                         -1
    X773      R384                          1
    X773      R1491                         1
    X773      R1492                         -1
    X774      R385                          1
    X774      R1492                         1
    X774      R1493                         -1
    X775      R386                          1
    X775      R1493                         1
    X775      R1494                         -1
    X776      R387                          1
    X776      R1494                         1
    X776      R1495                         -1
    X777      R388                          1
    X777      R1495                         1
    X777      R1496                         -1
    X778      R389                          1
    X778      R1496                         1
    X778      R1497                         -1
    X779      R390                          1
    X779      R1497                         1
    X779      R1498                         -1
    X780      R391                          1
    X780      R1498                         1
    X780      R1499                         -1
    X781      R392                          1
    X781      R1499                         1
    X781      R1500                         -1
    X782      R393                          1
    X782      R1500                         1
    X782      R1501                         -1
    X783      R394                          1
    X783      R1501                         1
    X783      R1502                         -1
    X784      R395                          1
    X784      R1502                         1
    X784      R1503                         -1
    X785      R396                          1
    X785      R1503                         1
    X785      R1504                         -1
    X786      R397                          1
    X786      R1504                         1
    X786      R1505                         -1
    X787      R398                          1
    X787      R1505                         1
    X787      R1506                         -1
    X788      R399                          1
    X788      R1506                         1
    X788      R1507                         -1
    X789      R400                          1
    X789      R1507                         1
    X789      R1508                         -1
    X790      R401                          1
    X790      R1508                         1
    X790      R1509                         -1
    X791      R402                          1
    X791      R1509                         1
    X791      R1510                         -1
    X792      R403                          1
    X792      R1510                         1
    X792      R1511                         -1
    X793      R404                          1
    X793      R1511                         1
    X793      R1512                         -1
    X794      R405                          1
    X794      R1512                         1
    X794      R1513                         -1
    X795      R406                          1
    X795      R1513                         1
    X795      R1514                         -1
    X796      R407                          1
    X796      R1514                         1
    X796      R1515                         -1
    X797      R408                          1
    X797      R1515                         1
    X797      R1516                         -1
    X798      R409                          1
    X798      R1516                         1
    X798      R1517                         -1
    X799      R410                          1
    X799      R1517                         1
    X799      R1518                         -1
    X800      R411                          1
    X800      R1518                         1
    X800      R1519                         -1
    X801      R412                          1
    X801      R1519                         1
    X801      R1520                         -1
    X802      R413                          1
    X802      R1520                         1
    X802      R1521                         -1
    X803      R414                          1
    X803      R1521                         1
    X803      R1522                         -1
    X804      R415                          1
    X804      R1522                         1
    X804      R1523                         -1
    X805      R416                          1
    X805      R1523                         1
    X805      R1524                         -1
    X806      R417                          1
    X806      R1524                         1
    X806      R1525                         -1
    X807      R418                          1
    X807      R1525                         1
    X807      R1526                         -1
    X808      R419                          1
    X808      R1526                         1
    X808      R1527                         -1
    X809      R420                          1
    X809      R1527                         1
    X809      R1528                         -1
    X810      R421                          1
    X810      R1528                         1
    X810      R1529                         -1
    X811      R422                          1
    X811      R1529                         1
    X811      R1530                         -1
    X812      R423                          1
    X812      R1530                         1
    X812      R1531                         -1
    X813      R424                          1
    X813      R1531                         1
    X813      R1532                         -1
    X814      R425                          1
    X814      R1532                         1
    X814      R1533                         -1
    X815      R426                          1
    X815      R1533                         1
    X815      R1534                         -1
    X816      R427                          1
    X816      R1534                         1
    X816      R1535                         -1
    X817      R428                          1
    X817      R1535                         1
    X817      R1536                         -1
    X818      R429                          1
    X818      R1536                         1
    X818      R1537                         -1
    X819      R430                          1
    X819      R1537                         1
    X819      R1538                         -1
    X820      R431                          1
    X820      R1538                         1
    X820      R1539                         -1
    X821      R432                          1
    X821      R1539                         1
    X821      R1540                         -1
    X822      R433                          1
    X822      R1540                         1
    X822      R1541                         -1
    X823      R434                          1
    X823      R1541                         1
    X823      R1542                         -1
    X824      R435                          1
    X824      R1542                         1
    X824      R1543                         -1
    X825      R436                          1
    X825      R1543                         1
    X825      R1651                         -1
    X826      R437                          1
    X826      R1544                         -1
    X826      R1652                         1
    X827      R438                          1
    X827      R1544                         1
    X827      R1545                         -1
    X828      R439                          1
    X828      R1545                         1
    X828      R1546                         -1
    X829      R440                          1
    X829      R1546                         1
    X829      R1547                         -1
    X830      R441                          1
    X830      R1547                         1
    X830      R1548                         -1
    X831      R442                          1
    X831      R1548                         1
    X831      R1549                         -1
    X832      R443                          1
    X832      R1549                         1
    X832      R1550                         -1
    X833      R444                          1
    X833      R1550                         1
    X833      R1551                         -1
    X834      R445                          1
    X834      R1551                         1
    X834      R1552                         -1
    X835      R446                          1
    X835      R1552                         1
    X835      R1553                         -1
    X836      R447                          1
    X836      R1553                         1
    X836      R1554                         -1
    X837      R448                          1
    X837      R1554                         1
    X837      R1555                         -1
    X838      R449                          1
    X838      R1555                         1
    X838      R1556                         -1
    X839      R450                          1
    X839      R1556                         1
    X839      R1557                         -1
    X840      R451                          1
    X840      R1557                         1
    X840      R1558                         -1
    X841      R452                          1
    X841      R1558                         1
    X841      R1559                         -1
    X842      R453                          1
    X842      R1559                         1
    X842      R1560                         -1
    X843      R454                          1
    X843      R1560                         1
    X843      R1561                         -1
    X844      R455                          1
    X844      R1561                         1
    X844      R1562                         -1
    X845      R456                          1
    X845      R1562                         1
    X845      R1563                         -1
    X846      R457                          1
    X846      R1563                         1
    X846      R1564                         -1
    X847      R458                          1
    X847      R1564                         1
    X847      R1565                         -1
    X848      R459                          1
    X848      R1565                         1
    X848      R1566                         -1
    X849      R460                          1
    X849      R1566                         1
    X849      R1567                         -1
    X850      R461                          1
    X850      R1567                         1
    X850      R1568                         -1
    X851      R462                          1
    X851      R1568                         1
    X851      R1569                         -1
    X852      R463                          1
    X852      R1569                         1
    X852      R1570                         -1
    X853      R464                          1
    X853      R1570                         1
    X853      R1571                         -1
    X854      R465                          1
    X854      R1571                         1
    X854      R1572                         -1
    X855      R466                          1
    X855      R1572                         1
    X855      R1573                         -1
    X856      R467                          1
    X856      R1573                         1
    X856      R1574                         -1
    X857      R468                          1
    X857      R1574                         1
    X857      R1575                         -1
    X858      R469                          1
    X858      R1575                         1
    X858      R1576                         -1
    X859      R470                          1
    X859      R1576                         1
    X859      R1577                         -1
    X860      R471                          1
    X860      R1577                         1
    X860      R1578                         -1
    X861      R472                          1
    X861      R1578                         1
    X861      R1579                         -1
    X862      R473                          1
    X862      R1579                         1
    X862      R1580                         -1
    X863      R474                          1
    X863      R1580                         1
    X863      R1581                         -1
    X864      R475                          1
    X864      R1581                         1
    X864      R1582                         -1
    X865      R476                          1
    X865      R1582                         1
    X865      R1583                         -1
    X866      R477                          1
    X866      R1583                         1
    X866      R1584                         -1
    X867      R478                          1
    X867      R1584                         1
    X867      R1585                         -1
    X868      R479                          1
    X868      R1585                         1
    X868      R1586                         -1
    X869      R480                          1
    X869      R1586                         1
    X869      R1587                         -1
    X870      R481                          1
    X870      R1587                         1
    X870      R1588                         -1
    X871      R482                          1
    X871      R1588                         1
    X871      R1589                         -1
    X872      R483                          1
    X872      R1589                         1
    X872      R1590                         -1
    X873      R484                          1
    X873      R1590                         1
    X873      R1591                         -1
    X874      R485                          1
    X874      R1591                         1
    X874      R1592                         -1
    X875      R486                          1
    X875      R1592                         1
    X875      R1593                         -1
    X876      R487                          1
    X876      R1593                         1
    X876      R1594                         -1
    X877      R488                          1
    X877      R1594                         1
    X877      R1595                         -1
    X878      R489                          1
    X878      R1595                         1
    X878      R1596                         -1
    X879      R490                          1
    X879      R1596                         1
    X879      R1597                         -1
    X880      R491                          1
    X880      R1597                         1
    X880      R1598                         -1
    X881      R492                          1
    X881      R1598                         1
    X881      R1599                         -1
    X882      R493                          1
    X882      R1599                         1
    X882      R1600                         -1
    X883      R494                          1
    X883      R1600                         1
    X883      R1601                         -1
    X884      R495                          1
    X884      R1601                         1
    X884      R1602                         -1
    X885      R496                          1
    X885      R1602                         1
    X885      R1603                         -1
    X886      R497                          1
    X886      R1603                         1
    X886      R1604                         -1
    X887      R498                          1
    X887      R1604                         1
    X887      R1605                         -1
    X888      R499                          1
    X888      R1605                         1
    X888      R1606                         -1
    X889      R500                          1
    X889      R1606                         1
    X889      R1607                         -1
    X890      R501                          1
    X890      R1607                         1
    X890      R1608                         -1
    X891      R502                          1
    X891      R1608                         1
    X891      R1609                         -1
    X892      R503                          1
    X892      R1609                         1
    X892      R1610                         -1
    X893      R504                          1
    X893      R1610                         1
    X893      R1611                         -1
    X894      R505                          1
    X894      R1611                         1
    X894      R1612                         -1
    X895      R506                          1
    X895      R1612                         1
    X895      R1652                         -1
    X896      R507                          1
    X896      R1613                         -1
    X896      R1653                         1
    X897      R508                          1
    X897      R1613                         1
    X897      R1614                         -1
    X898      R509                          1
    X898      R1614                         1
    X898      R1615                         -1
    X899      R510                          1
    X899      R1615                         1
    X899      R1616                         -1
    X900      R511                          1
    X900      R1616                         1
    X900      R1617                         -1
    X901      R512                          1
    X901      R1617                         1
    X901      R1618                         -1
    X902      R513                          1
    X902      R1618                         1
    X902      R1619                         -1
    X903      R514                          1
    X903      R1619                         1
    X903      R1620                         -1
    X904      R515                          1
    X904      R1620                         1
    X904      R1621                         -1
    X905      R516                          1
    X905      R1621                         1
    X905      R1622                         -1
    X906      R517                          1
    X906      R1622                         1
    X906      R1623                         -1
    X907      R518                          1
    X907      R1623                         1
    X907      R1624                         -1
    X908      R519                          1
    X908      R1624                         1
    X908      R1625                         -1
    X909      R520                          1
    X909      R1625                         1
    X909      R1653                         -1
    X910      R521                          1
    X910      R1626                         -1
    X910      R1654                         1
    X911      R522                          1
    X911      R1626                         1
    X911      R1627                         -1
    X912      R523                          1
    X912      R1627                         1
    X912      R1628                         -1
    X913      R524                          1
    X913      R1628                         1
    X913      R1629                         -1
    X914      R525                          1
    X914      R1629                         1
    X914      R1630                         -1
    X915      R526                          1
    X915      R1630                         1
    X915      R1631                         -1
    X916      R527                          1
    X916      R1631                         1
    X916      R1632                         -1
    X917      R528                          1
    X917      R1632                         1
    X917      R1633                         -1
    X918      R529                          1
    X918      R1633                         1
    X918      R1634                         -1
    X919      R530                          1
    X919      R1634                         1
    X919      R1635                         -1
    X920      R531                          1
    X920      R1635                         1
    X920      R1636                         -1
    X921      R532                          1
    X921      R1636                         1
    X921      R1637                         -1
    X922      R533                          1
    X922      R1637                         1
    X922      R1638                         -1
    X923      R534                          1
    X923      R1638                         1
    X923      R1654                         -1
    X924      R0                            1
    X924      R1655                         1
    X925      R1                            1
    X925      R1655                         1
    X926      R2                            1
    X926      R1655                         1
    X927      R1                            -250
    X927      R535                          -4500
    X928      R1                            -250
    X928      R536                          -4500
    X929      R1                            -250
    X929      R537                          -4500
    X930      R1                            -250
    X930      R538                          -4500
    X931      R1                            -250
    X931      R539                          -4500
    X932      R1                            -250
    X932      R540                          -4500
    X933      R1                            -250
    X933      R541                          -4500
    X934      R1                            -250
    X934      R542                          -4500
    X935      R1                            -250
    X935      R543                          -4500
    X936      R1                            -250
    X936      R544                          -4500
    X937      R1                            -250
    X937      R545                          -4500
    X938      R1                            -250
    X938      R546                          -4500
    X939      R1                            -250
    X939      R547                          -4500
    X940      R1                            -250
    X940      R548                          -4500
    X941      R1                            -250
    X941      R549                          -4500
    X942      R1                            -250
    X942      R550                          -4500
    X943      R1                            -250
    X943      R551                          -4500
    X944      R1                            -250
    X944      R552                          -4500
    X945      R1                            -250
    X945      R553                          -4500
    X946      R1                            -250
    X946      R554                          -4500
    X947      R1                            -250
    X947      R555                          -4500
    X948      R1                            -250
    X948      R556                          -4500
    X949      R1                            -250
    X949      R557                          -4500
    X950      R1                            -250
    X950      R558                          -4500
    X951      R1                            -250
    X951      R559                          -4500
    X952      R1                            -250
    X952      R560                          -4500
    X953      R1                            -250
    X953      R561                          -4500
    X954      R1                            -250
    X954      R562                          -4500
    X955      R1                            -250
    X955      R563                          -4500
    X956      R1                            -250
    X956      R564                          -4500
    X957      R1                            -250
    X957      R565                          -4500
    X958      R1                            -250
    X958      R566                          -4500
    X959      R1                            -250
    X959      R567                          -4500
    X960      R1                            -250
    X960      R568                          -4500
    X961      R1                            -250
    X961      R569                          -4500
    X962      R1                            -250
    X962      R570                          -4500
    X963      R1                            -250
    X963      R571                          -4500
    X964      R1                            -250
    X964      R572                          -4500
    X965      R1                            -250
    X965      R573                          -4500
    X966      R1                            -250
    X966      R574                          -4500
    X967      R1                            -250
    X967      R575                          -4500
    X968      R1                            -250
    X968      R576                          -4500
    X969      R1                            -250
    X969      R577                          -4500
    X970      R1                            -250
    X970      R578                          -4500
    X971      R1                            -250
    X971      R579                          -4500
    X972      R1                            -250
    X972      R580                          -4500
    X973      R1                            -250
    X973      R581                          -4500
    X974      R1                            -250
    X974      R582                          -4500
    X975      R1                            -250
    X975      R583                          -4500
    X976      R1                            -250
    X976      R584                          -4500
    X977      R1                            -250
    X977      R585                          -4500
    X978      R1                            -250
    X978      R586                          -4500
    X979      R1                            -250
    X979      R587                          -4500
    X980      R1                            -250
    X980      R588                          -4500
    X981      R1                            -250
    X981      R589                          -4500
    X982      R1                            -250
    X982      R590                          -4500
    X983      R1                            -250
    X983      R591                          -4500
    X984      R1                            -250
    X984      R592                          -4500
    X985      R1                            -250
    X985      R593                          -4500
    X986      R1                            -250
    X986      R594                          -4500
    X987      R1                            -250
    X987      R595                          -4500
    X988      R1                            -250
    X988      R596                          -4500
    X989      R1                            -250
    X989      R597                          -4500
    X990      R1                            -250
    X990      R598                          -4500
    X991      R1                            -250
    X991      R599                          -4500
    X992      R1                            -250
    X992      R600                          -4500
    X993      R1                            -250
    X993      R601                          -4500
    X994      R1                            -250
    X994      R602                          -4500
    X995      R1                            -250
    X995      R603                          -4500
    X996      R1                            -250
    X996      R604                          -4500
    X997      R1                            -250
    X997      R605                          -4500
    X998      R1                            -250
    X998      R606                          -4500
    X999      R1                            -250
    X999      R607                          -4500
    X1000     R1                            -250
    X1000     R608                          -4500
    X1001     R1                            -250
    X1001     R609                          -4500
    X1002     R1                            -250
    X1002     R610                          -4500
    X1003     R1                            -250
    X1003     R611                          -4500
    X1004     R1                            -250
    X1004     R612                          -4500
    X1005     R1                            -250
    X1005     R613                          -4500
    X1006     R1                            -250
    X1006     R614                          -4500
    X1007     R1                            -250
    X1007     R615                          -4500
    X1008     R1                            -250
    X1008     R616                          -4500
    X1009     R1                            -250
    X1009     R617                          -4500
    X1010     R1                            -250
    X1010     R618                          -4500
    X1011     R1                            -250
    X1011     R619                          -4500
    X1012     R1                            -250
    X1012     R3                            1
    X1012     R620                          -4500
    X1013     R1                            -250
    X1013     R3                            1
    X1013     R621                          -4500
    X1014     R1                            -250
    X1014     R3                            1
    X1014     R622                          -4500
    X1015     R1                            -250
    X1015     R623                          -4500
    X1016     R1                            -250
    X1016     R4                            1
    X1016     R624                          -4500
    X1017     R1                            -250
    X1017     R4                            1
    X1017     R625                          -4500
    X1018     R1                            -250
    X1018     R4                            1
    X1018     R626                          -4500
    X1019     R1                            -250
    X1019     R627                          -4500
    X1020     R1                            -250
    X1020     R5                            1
    X1020     R628                          -4500
    X1021     R1                            -250
    X1021     R5                            1
    X1021     R629                          -4500
    X1022     R1                            -250
    X1022     R5                            1
    X1022     R630                          -4500
    X1023     R1                            -250
    X1023     R631                          -4500
    X1024     R1                            -250
    X1024     R6                            1
    X1024     R632                          -4500
    X1025     R1                            -250
    X1025     R6                            1
    X1025     R633                          -4500
    X1026     R1                            -250
    X1026     R6                            1
    X1026     R634                          -4500
    X1027     R1                            -250
    X1027     R635                          -4500
    X1028     R1                            -250
    X1028     R7                            1
    X1028     R636                          -4500
    X1029     R1                            -250
    X1029     R7                            1
    X1029     R637                          -4500
    X1030     R1                            -250
    X1030     R7                            1
    X1030     R638                          -4500
    X1031     R1                            -250
    X1031     R639                          -4500
    X1032     R1                            -250
    X1032     R8                            1
    X1032     R640                          -4500
    X1033     R1                            -250
    X1033     R8                            1
    X1033     R641                          -4500
    X1034     R1                            -250
    X1034     R8                            1
    X1034     R642                          -4500
    X1035     R1                            -250
    X1035     R643                          -4500
    X1036     R1                            -250
    X1036     R9                            1
    X1036     R644                          -4500
    X1037     R1                            -250
    X1037     R9                            1
    X1037     R645                          -4500
    X1038     R1                            -250
    X1038     R9                            1
    X1038     R646                          -4500
    X1039     R1                            -250
    X1039     R10                           1
    X1039     R647                          -4500
    X1040     R1                            -250
    X1040     R10                           1
    X1040     R648                          -4500
    X1041     R1                            -250
    X1041     R10                           1
    X1041     R649                          -4500
    X1042     R1                            -250
    X1042     R650                          -4500
    X1043     R1                            -250
    X1043     R11                           1
    X1043     R651                          -4500
    X1044     R1                            -250
    X1044     R11                           1
    X1044     R652                          -4500
    X1045     R1                            -250
    X1045     R11                           1
    X1045     R653                          -4500
    X1046     R1                            -250
    X1046     R654                          -4500
    X1047     R1                            -250
    X1047     R12                           1
    X1047     R655                          -4500
    X1048     R1                            -250
    X1048     R12                           1
    X1048     R656                          -4500
    X1049     R1                            -250
    X1049     R12                           1
    X1049     R657                          -4500
    X1050     R1                            -250
    X1050     R658                          -4500
    X1051     R1                            -250
    X1051     R13                           1
    X1051     R659                          -4500
    X1052     R1                            -250
    X1052     R13                           1
    X1052     R660                          -4500
    X1053     R1                            -250
    X1053     R13                           1
    X1053     R661                          -4500
    X1054     R1                            -250
    X1054     R662                          -4500
    X1055     R1                            -250
    X1055     R14                           1
    X1055     R663                          -4500
    X1056     R1                            -250
    X1056     R14                           1
    X1056     R664                          -4500
    X1057     R1                            -250
    X1057     R14                           1
    X1057     R665                          -4500
    X1058     R1                            -250
    X1058     R666                          -4500
    X1059     R1                            -250
    X1059     R15                           1
    X1059     R667                          -4500
    X1060     R1                            -250
    X1060     R15                           1
    X1060     R668                          -4500
    X1061     R1                            -250
    X1061     R15                           1
    X1061     R669                          -4500
    X1062     R1                            -250
    X1062     R670                          -4500
    X1063     R1                            -250
    X1063     R16                           1
    X1063     R671                          -4500
    X1064     R1                            -250
    X1064     R16                           1
    X1064     R672                          -4500
    X1065     R1                            -250
    X1065     R16                           1
    X1065     R673                          -4500
    X1066     R1                            -250
    X1066     R674                          -4500
    X1067     R1                            -250
    X1067     R675                          -4500
    X1068     R1                            -250
    X1068     R676                          -4500
    X1069     R1                            -250
    X1069     R677                          -4500
    X1070     R1                            -250
    X1070     R678                          -4500
    X1071     R1                            -250
    X1071     R679                          -4500
    X1072     R1                            -250
    X1072     R680                          -4500
    X1073     R1                            -250
    X1073     R681                          -4500
    X1074     R1                            -250
    X1074     R682                          -4500
    X1075     R1                            -250
    X1075     R683                          -4500
    X1076     R1                            -250
    X1076     R684                          -4500
    X1077     R1                            -250
    X1077     R685                          -4500
    X1078     R1                            -250
    X1078     R686                          -4500
    X1079     R1                            -250
    X1079     R687                          -4500
    X1080     R1                            -250
    X1080     R688                          -4500
    X1081     R1                            -250
    X1081     R689                          -4500
    X1082     R1                            -250
    X1082     R690                          -4500
    X1083     R1                            -250
    X1083     R691                          -4500
    X1084     R1                            -250
    X1084     R692                          -4500
    X1085     R1                            -250
    X1085     R693                          -4500
    X1086     R1                            -250
    X1086     R694                          -4500
    X1087     R1                            -250
    X1087     R695                          -4500
    X1088     R1                            -250
    X1088     R696                          -4500
    X1089     R1                            -250
    X1089     R697                          -4500
    X1090     R1                            -250
    X1090     R698                          -4500
    X1091     R1                            -250
    X1091     R699                          -4500
    X1092     R1                            -250
    X1092     R700                          -4500
    X1093     R1                            -250
    X1093     R701                          -4500
    X1094     R1                            -250
    X1094     R702                          -4500
    X1095     R1                            -250
    X1095     R703                          -4500
    X1096     R1                            -250
    X1096     R704                          -4500
    X1097     R1                            -250
    X1097     R705                          -4500
    X1098     R1                            -250
    X1098     R706                          -4500
    X1099     R1                            -250
    X1099     R707                          -4500
    X1100     R1                            -250
    X1100     R708                          -4500
    X1101     R1                            -250
    X1101     R709                          -4500
    X1102     R1                            -250
    X1102     R710                          -4500
    X1103     R1                            -250
    X1103     R711                          -4500
    X1104     R1                            -250
    X1104     R712                          -4500
    X1105     R1                            -250
    X1105     R713                          -4500
    X1106     R1                            -250
    X1106     R714                          -4500
    X1107     R1                            -250
    X1107     R715                          -4500
    X1108     R1                            -250
    X1108     R716                          -4500
    X1109     R1                            -250
    X1109     R17                           1
    X1109     R717                          -4500
    X1110     R1                            -250
    X1110     R17                           1
    X1110     R718                          -4500
    X1111     R1                            -250
    X1111     R17                           1
    X1111     R719                          -4500
    X1112     R1                            -250
    X1112     R18                           1
    X1112     R720                          -4500
    X1113     R1                            -250
    X1113     R18                           1
    X1113     R721                          -4500
    X1114     R1                            -250
    X1114     R18                           1
    X1114     R722                          -4500
    X1115     R1                            -250
    X1115     R19                           1
    X1115     R723                          -4500
    X1116     R1                            -250
    X1116     R19                           1
    X1116     R724                          -4500
    X1117     R1                            -250
    X1117     R19                           1
    X1117     R725                          -4500
    X1118     R1                            -250
    X1118     R20                           1
    X1118     R726                          -4500
    X1119     R1                            -250
    X1119     R20                           1
    X1119     R727                          -4500
    X1120     R1                            -250
    X1120     R20                           1
    X1120     R728                          -4500
    X1121     R1                            -250
    X1121     R21                           1
    X1121     R729                          -4500
    X1122     R1                            -250
    X1122     R21                           1
    X1122     R730                          -4500
    X1123     R1                            -250
    X1123     R21                           1
    X1123     R731                          -4500
    X1124     R1                            -250
    X1124     R22                           1
    X1124     R732                          -4500
    X1125     R1                            -250
    X1125     R22                           1
    X1125     R733                          -4500
    X1126     R1                            -250
    X1126     R22                           1
    X1126     R734                          -4500
    X1127     R1                            -250
    X1127     R23                           1
    X1127     R735                          -4500
    X1128     R1                            -250
    X1128     R23                           1
    X1128     R736                          -4500
    X1129     R1                            -250
    X1129     R23                           1
    X1129     R737                          -4500
    X1130     R1                            -250
    X1130     R24                           1
    X1130     R738                          -4500
    X1131     R1                            -250
    X1131     R24                           1
    X1131     R739                          -4500
    X1132     R1                            -250
    X1132     R24                           1
    X1132     R740                          -4500
    X1133     R1                            -250
    X1133     R25                           1
    X1133     R741                          -4500
    X1134     R1                            -250
    X1134     R25                           1
    X1134     R742                          -4500
    X1135     R1                            -250
    X1135     R25                           1
    X1135     R743                          -4500
    X1136     R1                            -250
    X1136     R26                           1
    X1136     R744                          -4500
    X1137     R1                            -250
    X1137     R26                           1
    X1137     R745                          -4500
    X1138     R1                            -250
    X1138     R26                           1
    X1138     R746                          -4500
    X1139     R1                            -250
    X1139     R27                           1
    X1139     R747                          -4500
    X1140     R1                            -250
    X1140     R27                           1
    X1140     R748                          -4500
    X1141     R1                            -250
    X1141     R27                           1
    X1141     R749                          -4500
    X1142     R1                            -250
    X1142     R28                           1
    X1142     R750                          -4500
    X1143     R1                            -250
    X1143     R28                           1
    X1143     R751                          -4500
    X1144     R1                            -250
    X1144     R28                           1
    X1144     R752                          -4500
    X1145     R1                            -250
    X1145     R29                           1
    X1145     R753                          -4500
    X1146     R1                            -250
    X1146     R29                           1
    X1146     R754                          -4500
    X1147     R1                            -250
    X1147     R29                           1
    X1147     R755                          -4500
    X1148     R1                            -250
    X1148     R30                           1
    X1148     R756                          -4500
    X1149     R1                            -250
    X1149     R30                           1
    X1149     R757                          -4500
    X1150     R1                            -250
    X1150     R30                           1
    X1150     R758                          -4500
    X1151     R1                            -250
    X1151     R31                           1
    X1151     R759                          -4500
    X1152     R1                            -250
    X1152     R31                           1
    X1152     R760                          -4500
    X1153     R1                            -250
    X1153     R31                           1
    X1153     R761                          -4500
    X1154     R1                            -250
    X1154     R32                           1
    X1154     R762                          -4500
    X1155     R1                            -250
    X1155     R32                           1
    X1155     R763                          -4500
    X1156     R1                            -250
    X1156     R32                           1
    X1156     R764                          -4500
    X1157     R1                            -250
    X1157     R33                           1
    X1157     R765                          -4500
    X1158     R1                            -250
    X1158     R33                           1
    X1158     R766                          -4500
    X1159     R1                            -250
    X1159     R33                           1
    X1159     R767                          -4500
    X1160     R1                            -250
    X1160     R34                           1
    X1160     R768                          -4500
    X1161     R1                            -250
    X1161     R34                           1
    X1161     R769                          -4500
    X1162     R1                            -250
    X1162     R34                           1
    X1162     R770                          -4500
    X1163     R1                            -250
    X1163     R35                           1
    X1163     R771                          -4500
    X1164     R1                            -250
    X1164     R35                           1
    X1164     R772                          -4500
    X1165     R1                            -250
    X1165     R35                           1
    X1165     R773                          -4500
    X1166     R1                            -250
    X1166     R36                           1
    X1166     R774                          -4500
    X1167     R1                            -250
    X1167     R36                           1
    X1167     R775                          -4500
    X1168     R1                            -250
    X1168     R36                           1
    X1168     R776                          -4500
    X1169     R1                            -250
    X1169     R37                           1
    X1169     R777                          -4500
    X1170     R1                            -250
    X1170     R37                           1
    X1170     R778                          -4500
    X1171     R1                            -250
    X1171     R37                           1
    X1171     R779                          -4500
    X1172     R1                            -250
    X1172     R38                           1
    X1172     R780                          -4500
    X1173     R1                            -250
    X1173     R38                           1
    X1173     R781                          -4500
    X1174     R1                            -250
    X1174     R38                           1
    X1174     R782                          -4500
    X1175     R1                            -250
    X1175     R39                           1
    X1175     R783                          -4500
    X1176     R1                            -250
    X1176     R39                           1
    X1176     R784                          -4500
    X1177     R1                            -250
    X1177     R39                           1
    X1177     R785                          -4500
    X1178     R1                            -250
    X1178     R40                           1
    X1178     R786                          -4500
    X1179     R1                            -250
    X1179     R40                           1
    X1179     R787                          -4500
    X1180     R1                            -250
    X1180     R40                           1
    X1180     R788                          -4500
    X1181     R1                            -250
    X1181     R41                           1
    X1181     R789                          -4500
    X1182     R1                            -250
    X1182     R41                           1
    X1182     R790                          -4500
    X1183     R1                            -250
    X1183     R41                           1
    X1183     R791                          -4500
    X1184     R1                            -250
    X1184     R42                           1
    X1184     R792                          -4500
    X1185     R1                            -250
    X1185     R42                           1
    X1185     R793                          -4500
    X1186     R1                            -250
    X1186     R42                           1
    X1186     R794                          -4500
    X1187     R1                            -250
    X1187     R43                           1
    X1187     R795                          -4500
    X1188     R1                            -250
    X1188     R43                           1
    X1188     R796                          -4500
    X1189     R1                            -250
    X1189     R43                           1
    X1189     R797                          -4500
    X1190     R1                            -250
    X1190     R44                           1
    X1190     R798                          -4500
    X1191     R1                            -250
    X1191     R44                           1
    X1191     R799                          -4500
    X1192     R1                            -250
    X1192     R44                           1
    X1192     R800                          -4500
    X1193     R1                            -250
    X1193     R801                          -4500
    X1194     R1                            -250
    X1194     R802                          -4500
    X1195     R1                            -250
    X1195     R803                          -4500
    X1196     R1                            -250
    X1196     R804                          -4500
    X1197     R1                            -250
    X1197     R805                          -4500
    X1198     R1                            -250
    X1198     R806                          -4500
    X1199     R1                            -250
    X1199     R807                          -4500
    X1200     R1                            -250
    X1200     R808                          -4500
    X1201     R1                            -250
    X1201     R809                          -4500
    X1202     R1                            -250
    X1202     R810                          -4500
    X1203     R1                            -250
    X1203     R811                          -4500
    X1204     R1                            -250
    X1204     R812                          -4500
    X1205     R1                            -250
    X1205     R813                          -4500
    X1206     R1                            -250
    X1206     R814                          -4500
    X1207     R1                            -250
    X1207     R815                          -4500
    X1208     R1                            -250
    X1208     R816                          -4500
    X1209     R1                            -250
    X1209     R817                          -4500
    X1210     R1                            -250
    X1210     R818                          -4500
    X1211     R1                            -250
    X1211     R819                          -4500
    X1212     R1                            -250
    X1212     R820                          -4500
    X1213     R1                            -250
    X1213     R821                          -4500
    X1214     R1                            -250
    X1214     R822                          -4500
    X1215     R1                            -250
    X1215     R823                          -4500
    X1216     R1                            -250
    X1216     R824                          -4500
    X1217     R1                            -250
    X1217     R825                          -4500
    X1218     R1                            -250
    X1218     R826                          -4500
    X1219     R1                            -250
    X1219     R827                          -4500
    X1220     R1                            -250
    X1220     R828                          -4500
    X1221     R1                            -250
    X1221     R45                           1
    X1221     R829                          -4500
    X1222     R1                            -250
    X1222     R45                           1
    X1222     R830                          -4500
    X1223     R1                            -250
    X1223     R45                           1
    X1223     R831                          -4500
    X1224     R1                            -250
    X1224     R45                           1
    X1224     R832                          -4500
    X1225     R1                            -250
    X1225     R45                           1
    X1225     R833                          -4500
    X1226     R1                            -250
    X1226     R45                           1
    X1226     R834                          -4500
    X1227     R1                            -250
    X1227     R46                           1
    X1227     R835                          -4500
    X1228     R1                            -250
    X1228     R46                           1
    X1228     R836                          -4500
    X1229     R1                            -250
    X1229     R46                           1
    X1229     R837                          -4500
    X1230     R1                            -250
    X1230     R46                           1
    X1230     R838                          -4500
    X1231     R1                            -250
    X1231     R47                           1
    X1231     R839                          -4500
    X1232     R1                            -250
    X1232     R47                           1
    X1232     R840                          -4500
    X1233     R1                            -250
    X1233     R47                           1
    X1233     R841                          -4500
    X1234     R1                            -250
    X1234     R47                           1
    X1234     R842                          -4500
    X1235     R1                            -250
    X1235     R47                           1
    X1235     R843                          -4500
    X1236     R1                            -250
    X1236     R47                           1
    X1236     R844                          -4500
    X1237     R1                            -250
    X1237     R48                           1
    X1237     R845                          -4500
    X1238     R1                            -250
    X1238     R48                           1
    X1238     R846                          -4500
    X1239     R1                            -250
    X1239     R48                           1
    X1239     R847                          -4500
    X1240     R1                            -250
    X1240     R48                           1
    X1240     R848                          -4500
    X1241     R1                            -250
    X1241     R49                           1
    X1241     R849                          -4500
    X1242     R1                            -250
    X1242     R49                           1
    X1242     R850                          -4500
    X1243     R1                            -250
    X1243     R49                           1
    X1243     R851                          -4500
    X1244     R1                            -250
    X1244     R49                           1
    X1244     R852                          -4500
    X1245     R1                            -250
    X1245     R49                           1
    X1245     R853                          -4500
    X1246     R1                            -250
    X1246     R49                           1
    X1246     R854                          -4500
    X1247     R1                            -250
    X1247     R50                           1
    X1247     R855                          -4500
    X1248     R1                            -250
    X1248     R50                           1
    X1248     R856                          -4500
    X1249     R1                            -250
    X1249     R50                           1
    X1249     R857                          -4500
    X1250     R1                            -250
    X1250     R50                           1
    X1250     R858                          -4500
    X1251     R1                            -250
    X1251     R51                           1
    X1251     R859                          -4500
    X1252     R1                            -250
    X1252     R51                           1
    X1252     R860                          -4500
    X1253     R1                            -250
    X1253     R51                           1
    X1253     R861                          -4500
    X1254     R1                            -250
    X1254     R51                           1
    X1254     R862                          -4500
    X1255     R1                            -250
    X1255     R51                           1
    X1255     R863                          -4500
    X1256     R1                            -250
    X1256     R51                           1
    X1256     R864                          -4500
    X1257     R1                            -250
    X1257     R52                           1
    X1257     R865                          -4500
    X1258     R1                            -250
    X1258     R52                           1
    X1258     R866                          -4500
    X1259     R1                            -250
    X1259     R52                           1
    X1259     R867                          -4500
    X1260     R1                            -250
    X1260     R52                           1
    X1260     R868                          -4500
    X1261     R1                            -250
    X1261     R53                           1
    X1261     R869                          -4500
    X1262     R1                            -250
    X1262     R53                           1
    X1262     R870                          -4500
    X1263     R1                            -250
    X1263     R53                           1
    X1263     R871                          -4500
    X1264     R1                            -250
    X1264     R53                           1
    X1264     R872                          -4500
    X1265     R1                            -250
    X1265     R53                           1
    X1265     R873                          -4500
    X1266     R1                            -250
    X1266     R53                           1
    X1266     R874                          -4500
    X1267     R1                            -250
    X1267     R54                           1
    X1267     R875                          -4500
    X1268     R1                            -250
    X1268     R54                           1
    X1268     R876                          -4500
    X1269     R1                            -250
    X1269     R54                           1
    X1269     R877                          -4500
    X1270     R1                            -250
    X1270     R54                           1
    X1270     R878                          -4500
    X1271     R1                            -250
    X1271     R55                           1
    X1271     R879                          -4500
    X1272     R1                            -250
    X1272     R55                           1
    X1272     R880                          -4500
    X1273     R1                            -250
    X1273     R55                           1
    X1273     R881                          -4500
    X1274     R1                            -250
    X1274     R55                           1
    X1274     R882                          -4500
    X1275     R1                            -250
    X1275     R55                           1
    X1275     R883                          -4500
    X1276     R1                            -250
    X1276     R55                           1
    X1276     R884                          -4500
    X1277     R1                            -250
    X1277     R56                           1
    X1277     R885                          -4500
    X1278     R1                            -250
    X1278     R56                           1
    X1278     R886                          -4500
    X1279     R1                            -250
    X1279     R56                           1
    X1279     R887                          -4500
    X1280     R1                            -250
    X1280     R56                           1
    X1280     R888                          -4500
    X1281     R1                            -250
    X1281     R57                           1
    X1281     R889                          -4500
    X1282     R1                            -250
    X1282     R57                           1
    X1282     R890                          -4500
    X1283     R1                            -250
    X1283     R57                           1
    X1283     R891                          -4500
    X1284     R1                            -250
    X1284     R57                           1
    X1284     R892                          -4500
    X1285     R1                            -250
    X1285     R57                           1
    X1285     R893                          -4500
    X1286     R1                            -250
    X1286     R57                           1
    X1286     R894                          -4500
    X1287     R1                            -250
    X1287     R58                           1
    X1287     R895                          -4500
    X1288     R1                            -250
    X1288     R58                           1
    X1288     R896                          -4500
    X1289     R1                            -250
    X1289     R58                           1
    X1289     R897                          -4500
    X1290     R1                            -250
    X1290     R58                           1
    X1290     R898                          -4500
    X1291     R1                            -250
    X1291     R59                           1
    X1291     R899                          -4500
    X1292     R1                            -250
    X1292     R59                           1
    X1292     R900                          -4500
    X1293     R1                            -250
    X1293     R59                           1
    X1293     R901                          -4500
    X1294     R1                            -250
    X1294     R59                           1
    X1294     R902                          -4500
    X1295     R1                            -250
    X1295     R60                           1
    X1295     R903                          -4500
    X1296     R1                            -250
    X1296     R60                           1
    X1296     R904                          -4500
    X1297     R1                            -250
    X1297     R60                           1
    X1297     R905                          -4500
    X1298     R1                            -250
    X1298     R60                           1
    X1298     R906                          -4500
    X1299     R1                            -250
    X1299     R60                           1
    X1299     R907                          -4500
    X1300     R1                            -250
    X1300     R60                           1
    X1300     R908                          -4500
    X1301     R1                            -250
    X1301     R61                           1
    X1301     R909                          -4500
    X1302     R1                            -250
    X1302     R61                           1
    X1302     R910                          -4500
    X1303     R1                            -250
    X1303     R61                           1
    X1303     R911                          -4500
    X1304     R1                            -250
    X1304     R61                           1
    X1304     R912                          -4500
    X1305     R1                            -250
    X1305     R62                           1
    X1305     R913                          -4500
    X1306     R1                            -250
    X1306     R62                           1
    X1306     R914                          -4500
    X1307     R1                            -250
    X1307     R62                           1
    X1307     R915                          -4500
    X1308     R1                            -250
    X1308     R62                           1
    X1308     R916                          -4500
    X1309     R1                            -250
    X1309     R62                           1
    X1309     R917                          -4500
    X1310     R1                            -250
    X1310     R62                           1
    X1310     R918                          -4500
    X1311     R1                            -250
    X1311     R63                           1
    X1311     R919                          -4500
    X1312     R1                            -250
    X1312     R63                           1
    X1312     R920                          -4500
    X1313     R1                            -250
    X1313     R63                           1
    X1313     R921                          -4500
    X1314     R1                            -250
    X1314     R63                           1
    X1314     R922                          -4500
    X1315     R1                            -250
    X1315     R64                           1
    X1315     R923                          -4500
    X1316     R1                            -250
    X1316     R64                           1
    X1316     R924                          -4500
    X1317     R1                            -250
    X1317     R64                           1
    X1317     R925                          -4500
    X1318     R1                            -250
    X1318     R64                           1
    X1318     R926                          -4500
    X1319     R1                            -250
    X1319     R64                           1
    X1319     R927                          -4500
    X1320     R1                            -250
    X1320     R64                           1
    X1320     R928                          -4500
    X1321     R1                            -250
    X1321     R65                           1
    X1321     R929                          -4500
    X1322     R1                            -250
    X1322     R65                           1
    X1322     R930                          -4500
    X1323     R1                            -250
    X1323     R65                           1
    X1323     R931                          -4500
    X1324     R1                            -250
    X1324     R65                           1
    X1324     R932                          -4500
    X1325     R1                            -250
    X1325     R66                           1
    X1325     R933                          -4500
    X1326     R1                            -250
    X1326     R66                           1
    X1326     R934                          -4500
    X1327     R1                            -250
    X1327     R66                           1
    X1327     R935                          -4500
    X1328     R1                            -250
    X1328     R66                           1
    X1328     R936                          -4500
    X1329     R1                            -250
    X1329     R66                           1
    X1329     R937                          -4500
    X1330     R1                            -250
    X1330     R66                           1
    X1330     R938                          -4500
    X1331     R1                            -250
    X1331     R67                           1
    X1331     R939                          -4500
    X1332     R1                            -250
    X1332     R67                           1
    X1332     R940                          -4500
    X1333     R1                            -250
    X1333     R67                           1
    X1333     R941                          -4500
    X1334     R1                            -250
    X1334     R67                           1
    X1334     R942                          -4500
    X1335     R1                            -250
    X1335     R68                           1
    X1335     R943                          -4500
    X1336     R1                            -250
    X1336     R68                           1
    X1336     R944                          -4500
    X1337     R1                            -250
    X1337     R68                           1
    X1337     R945                          -4500
    X1338     R1                            -250
    X1338     R68                           1
    X1338     R946                          -4500
    X1339     R1                            -250
    X1339     R68                           1
    X1339     R947                          -4500
    X1340     R1                            -250
    X1340     R68                           1
    X1340     R948                          -4500
    X1341     R1                            -250
    X1341     R69                           1
    X1341     R949                          -4500
    X1342     R1                            -250
    X1342     R69                           1
    X1342     R950                          -4500
    X1343     R1                            -250
    X1343     R69                           1
    X1343     R951                          -4500
    X1344     R1                            -250
    X1344     R69                           1
    X1344     R952                          -4500
    X1345     R1                            -250
    X1345     R70                           1
    X1345     R953                          -4500
    X1346     R1                            -250
    X1346     R70                           1
    X1346     R954                          -4500
    X1347     R1                            -250
    X1347     R70                           1
    X1347     R955                          -4500
    X1348     R1                            -250
    X1348     R70                           1
    X1348     R956                          -4500
    X1349     R1                            -250
    X1349     R70                           1
    X1349     R957                          -4500
    X1350     R1                            -250
    X1350     R70                           1
    X1350     R958                          -4500
    X1351     R1                            -250
    X1351     R71                           1
    X1351     R959                          -4500
    X1352     R1                            -250
    X1352     R71                           1
    X1352     R960                          -4500
    X1353     R1                            -250
    X1353     R71                           1
    X1353     R961                          -4500
    X1354     R1                            -250
    X1354     R71                           1
    X1354     R962                          -4500
    X1355     R1                            -250
    X1355     R72                           1
    X1355     R963                          -4500
    X1356     R1                            -250
    X1356     R72                           1
    X1356     R964                          -4500
    X1357     R1                            -250
    X1357     R72                           1
    X1357     R965                          -4500
    X1358     R1                            -250
    X1358     R72                           1
    X1358     R966                          -4500
    X1359     R1                            -250
    X1359     R72                           1
    X1359     R967                          -4500
    X1360     R1                            -250
    X1360     R72                           1
    X1360     R968                          -4500
    X1361     R1                            -250
    X1361     R969                          -4500
    X1362     R1                            -250
    X1362     R970                          -4500
    X1363     R1                            -250
    X1363     R971                          -4500
    X1364     R1                            -250
    X1364     R972                          -4500
    X1365     R1                            -250
    X1365     R973                          -4500
    X1366     R1                            -250
    X1366     R974                          -4500
    X1367     R1                            -250
    X1367     R975                          -4500
    X1368     R1                            -250
    X1368     R976                          -4500
    X1369     R1                            -250
    X1369     R977                          -4500
    X1370     R1                            -250
    X1370     R978                          -4500
    X1371     R1                            -250
    X1371     R979                          -4500
    X1372     R1                            -250
    X1372     R980                          -4500
    X1373     R1                            -250
    X1373     R981                          -4500
    X1374     R1                            -250
    X1374     R982                          -4500
    X1375     R1                            -250
    X1375     R983                          -4500
    X1376     R1                            -250
    X1376     R984                          -4500
    X1377     R1                            -250
    X1377     R985                          -4500
    X1378     R1                            -250
    X1378     R986                          -4500
    X1379     R1                            -250
    X1379     R987                          -4500
    X1380     R1                            -250
    X1380     R988                          -4500
    X1381     R1                            -250
    X1381     R989                          -4500
    X1382     R1                            -250
    X1382     R990                          -4500
    X1383     R1                            -250
    X1383     R991                          -4500
    X1384     R1                            -250
    X1384     R992                          -4500
    X1385     R1                            -250
    X1385     R993                          -4500
    X1386     R1                            -250
    X1386     R994                          -4500
    X1387     R1                            -250
    X1387     R995                          -4500
    X1388     R1                            -250
    X1388     R996                          -4500
    X1389     R0                            -8000
    X1390     R0                            -8000
    X1391     R0                            -8000
    X1392     R0                            -8000
    X1393     R0                            -8000
    X1394     R0                            -8000
    X1395     R0                            -8000
    X1396     R0                            -8000
    X1397     R0                            -8000
    X1398     R0                            -8000
    X1399     R0                            -8000
    X1400     R0                            -8000
    X1401     R0                            -8000
    X1402     R0                            -8000
    X1403     R0                            -8000
    X1404     R0                            -8000
    X1405     R0                            -8000
    X1405     R997                          -25000
    X1405     R998                          -25000
    X1405     R999                          -25000
    X1405     R1000                         -25000
    X1405     R1001                         -25000
    X1405     R1002                         -25000
    X1405     R1003                         -25000
    X1405     R1004                         -25000
    X1405     R1005                         -25000
    X1405     R1006                         -25000
    X1405     R1007                         -25000
    X1405     R1008                         -25000
    X1405     R1009                         -25000
    X1405     R1010                         -25000
    X1406     R0                            -8000
    X1406     R1011                         -25000
    X1406     R1012                         -25000
    X1406     R1013                         -25000
    X1406     R1014                         -25000
    X1406     R1015                         -25000
    X1406     R1016                         -25000
    X1406     R1017                         -25000
    X1406     R1018                         -25000
    X1406     R1019                         -25000
    X1406     R1020                         -25000
    X1406     R1021                         -25000
    X1406     R1022                         -25000
    X1406     R1023                         -25000
    X1406     R1024                         -25000
    X1407     R0                            -8000
    X1407     R1025                         -25000
    X1407     R1026                         -25000
    X1407     R1027                         -25000
    X1407     R1028                         -25000
    X1407     R1029                         -25000
    X1407     R1030                         -25000
    X1407     R1031                         -25000
    X1407     R1032                         -25000
    X1407     R1033                         -25000
    X1407     R1034                         -25000
    X1407     R1035                         -25000
    X1407     R1036                         -25000
    X1407     R1037                         -25000
    X1407     R1038                         -25000
    X1408     R0                            -8000
    X1408     R1039                         -25000
    X1408     R1040                         -25000
    X1408     R1041                         -25000
    X1408     R1042                         -25000
    X1408     R1043                         -25000
    X1408     R1044                         -25000
    X1408     R1045                         -25000
    X1408     R1046                         -25000
    X1408     R1047                         -25000
    X1408     R1048                         -25000
    X1408     R1049                         -25000
    X1408     R1050                         -25000
    X1408     R1051                         -25000
    X1408     R1052                         -25000
    X1409     R0                            -8000
    X1410     R0                            -8000
    X1410     R1053                         -25000
    X1410     R1054                         -25000
    X1410     R1055                         -25000
    X1410     R1056                         -25000
    X1410     R1057                         -25000
    X1410     R1058                         -25000
    X1410     R1059                         -25000
    X1410     R1060                         -25000
    X1410     R1061                         -25000
    X1410     R1062                         -25000
    X1410     R1063                         -25000
    X1410     R1064                         -25000
    X1410     R1065                         -25000
    X1410     R1066                         -25000
    X1411     R0                            -8000
    X1412     R0                            -8000
    X1413     R0                            -8000
    X1413     R1067                         -25000
    X1413     R1068                         -25000
    X1413     R1069                         -25000
    X1413     R1070                         -25000
    X1413     R1071                         -25000
    X1413     R1072                         -25000
    X1413     R1073                         -25000
    X1413     R1074                         -25000
    X1413     R1075                         -25000
    X1413     R1076                         -25000
    X1413     R1077                         -25000
    X1413     R1078                         -25000
    X1413     R1079                         -25000
    X1413     R1080                         -25000
    X1414     R0                            -8000
    X1415     R0                            -8000
    X1416     R0                            -8000
    X1417     R0                            -8000
    X1418     R0                            -8000
    X1419     R0                            -8000
    X1419     R1081                         -25000
    X1419     R1082                         -25000
    X1419     R1083                         -25000
    X1419     R1084                         -25000
    X1419     R1085                         -25000
    X1419     R1086                         -25000
    X1419     R1087                         -25000
    X1419     R1088                         -25000
    X1419     R1089                         -25000
    X1419     R1090                         -25000
    X1419     R1091                         -25000
    X1419     R1092                         -25000
    X1419     R1093                         -25000
    X1419     R1094                         -25000
    X1420     R0                            -8000
    X1420     R1095                         -25000
    X1420     R1096                         -25000
    X1420     R1097                         -25000
    X1420     R1098                         -25000
    X1420     R1099                         -25000
    X1420     R1100                         -25000
    X1420     R1101                         -25000
    X1420     R1102                         -25000
    X1420     R1103                         -25000
    X1420     R1104                         -25000
    X1420     R1105                         -25000
    X1420     R1106                         -25000
    X1420     R1107                         -25000
    X1420     R1108                         -25000
    X1421     R0                            -8000
    X1421     R1109                         -25000
    X1421     R1110                         -25000
    X1421     R1111                         -25000
    X1421     R1112                         -25000
    X1421     R1113                         -25000
    X1421     R1114                         -25000
    X1421     R1115                         -25000
    X1421     R1116                         -25000
    X1421     R1117                         -25000
    X1421     R1118                         -25000
    X1421     R1119                         -25000
    X1421     R1120                         -25000
    X1421     R1121                         -25000
    X1421     R1122                         -25000
    X1422     R0                            -8000
    X1422     R1123                         -25000
    X1422     R1124                         -25000
    X1422     R1125                         -25000
    X1422     R1126                         -25000
    X1422     R1127                         -25000
    X1422     R1128                         -25000
    X1422     R1129                         -25000
    X1422     R1130                         -25000
    X1422     R1131                         -25000
    X1422     R1132                         -25000
    X1422     R1133                         -25000
    X1422     R1134                         -25000
    X1422     R1135                         -25000
    X1422     R1136                         -25000
    X1423     R0                            -8000
    X1424     R0                            -8000
    X1425     R0                            -8000
    X1426     R0                            -8000
    X1427     R0                            -8000
    X1428     R0                            -8000
    X1429     R0                            -8000
    X1430     R0                            -8000
    X1431     R0                            -8000
    X1432     R0                            -8000
    X1433     R0                            -8000
    X1434     R0                            -8000
    X1435     R0                            -8000
    X1436     R0                            -8000
    X1437     R0                            -8000
    X1438     R0                            -8000
    X1439     R0                            -8000
    X1440     R0                            -8000
    X1441     R0                            -8000
    X1442     R0                            -8000
    X1443     R0                            -8000
    X1444     R0                            -8000
    X1445     R0                            -8000
    X1445     R1137                         -25000
    X1445     R1138                         -25000
    X1445     R1139                         -25000
    X1445     R1140                         -25000
    X1445     R1141                         -25000
    X1445     R1142                         -25000
    X1445     R1143                         -25000
    X1445     R1144                         -25000
    X1445     R1145                         -25000
    X1445     R1146                         -25000
    X1445     R1147                         -25000
    X1445     R1148                         -25000
    X1445     R1149                         -25000
    X1445     R1150                         -25000
    X1446     R0                            -8000
    X1447     R0                            -8000
    X1447     R1151                         -25000
    X1447     R1152                         -25000
    X1447     R1153                         -25000
    X1447     R1154                         -25000
    X1447     R1155                         -25000
    X1447     R1156                         -25000
    X1447     R1157                         -25000
    X1447     R1158                         -25000
    X1447     R1159                         -25000
    X1447     R1160                         -25000
    X1447     R1161                         -25000
    X1447     R1162                         -25000
    X1447     R1163                         -25000
    X1447     R1164                         -25000
    X1448     R0                            -8000
    X1449     R0                            -8000
    X1450     R0                            -8000
    X1451     R0                            -8000
    X1452     R0                            -8000
    X1452     R1165                         -25000
    X1452     R1166                         -25000
    X1452     R1167                         -25000
    X1452     R1168                         -25000
    X1452     R1169                         -25000
    X1452     R1170                         -25000
    X1452     R1171                         -25000
    X1452     R1172                         -25000
    X1452     R1173                         -25000
    X1452     R1174                         -25000
    X1452     R1175                         -25000
    X1452     R1176                         -25000
    X1452     R1177                         -25000
    X1452     R1178                         -25000
    X1453     R0                            -8000
    X1454     R0                            -8000
    X1454     R1179                         -25000
    X1454     R1180                         -25000
    X1454     R1181                         -25000
    X1454     R1182                         -25000
    X1454     R1183                         -25000
    X1454     R1184                         -25000
    X1454     R1185                         -25000
    X1454     R1186                         -25000
    X1454     R1187                         -25000
    X1454     R1188                         -25000
    X1454     R1189                         -25000
    X1454     R1190                         -25000
    X1454     R1191                         -25000
    X1454     R1192                         -25000
    X1455     R0                            -8000
    X1456     R0                            -8000
    X1457     R0                            -8000
    X1458     R0                            -8000
    X1459     R0                            -8000
    X1460     R0                            -8000
    X1461     R0                            -8000
RHS
    RHS       R3                            2
    RHS       R4                            2
    RHS       R5                            2
    RHS       R6                            2
    RHS       R7                            2
    RHS       R8                            2
    RHS       R9                            2
    RHS       R10                           2
    RHS       R11                           2
    RHS       R12                           2
    RHS       R13                           2
    RHS       R14                           2
    RHS       R15                           2
    RHS       R16                           2
    RHS       R17                           2
    RHS       R18                           2
    RHS       R19                           2
    RHS       R20                           2
    RHS       R21                           2
    RHS       R22                           2
    RHS       R23                           2
    RHS       R24                           2
    RHS       R25                           2
    RHS       R26                           2
    RHS       R27                           2
    RHS       R28                           2
    RHS       R29                           2
    RHS       R30                           2
    RHS       R31                           2
    RHS       R32                           2
    RHS       R33                           2
    RHS       R34                           2
    RHS       R35                           2
    RHS       R36                           2
    RHS       R37                           2
    RHS       R38                           2
    RHS       R39                           2
    RHS       R40                           2
    RHS       R41                           2
    RHS       R42                           2
    RHS       R43                           2
    RHS       R44                           2
    RHS       R45                           2
    RHS       R46                           2
    RHS       R47                           2
    RHS       R48                           2
    RHS       R49                           2
    RHS       R50                           2
    RHS       R51                           2
    RHS       R52                           2
    RHS       R53                           2
    RHS       R54                           2
    RHS       R55                           2
    RHS       R56                           2
    RHS       R57                           2
    RHS       R58                           2
    RHS       R59                           2
    RHS       R60                           2
    RHS       R61                           2
    RHS       R62                           2
    RHS       R63                           2
    RHS       R64                           2
    RHS       R65                           2
    RHS       R66                           2
    RHS       R67                           2
    RHS       R68                           2
    RHS       R69                           2
    RHS       R70                           2
    RHS       R71                           2
    RHS       R72                           2
    RHS       R73                           4500
    RHS       R74                           4500
    RHS       R75                           4500
    RHS       R76                           4500
    RHS       R77                           4500
    RHS       R78                           4500
    RHS       R79                           4500
    RHS       R80                           4500
    RHS       R81                           4500
    RHS       R82                           4500
    RHS       R83                           4500
    RHS       R84                           4500
    RHS       R85                           4500
    RHS       R86                           4500
    RHS       R87                           4500
    RHS       R88                           4500
    RHS       R89                           4500
    RHS       R90                           4500
    RHS       R91                           4500
    RHS       R92                           4500
    RHS       R93                           4500
    RHS       R94                           4500
    RHS       R95                           4500
    RHS       R96                           4500
    RHS       R97                           4500
    RHS       R98                           4500
    RHS       R99                           4500
    RHS       R100                          4500
    RHS       R101                          4500
    RHS       R102                          4500
    RHS       R103                          4500
    RHS       R104                          4500
    RHS       R105                          4500
    RHS       R106                          4500
    RHS       R107                          4500
    RHS       R108                          4500
    RHS       R109                          4500
    RHS       R110                          4500
    RHS       R111                          4500
    RHS       R112                          4500
    RHS       R113                          4500
    RHS       R114                          4500
    RHS       R115                          4500
    RHS       R116                          4500
    RHS       R117                          4500
    RHS       R118                          4500
    RHS       R119                          4500
    RHS       R120                          4500
    RHS       R121                          4500
    RHS       R122                          4500
    RHS       R123                          4500
    RHS       R124                          4500
    RHS       R125                          4500
    RHS       R126                          4500
    RHS       R127                          4500
    RHS       R128                          4500
    RHS       R129                          4500
    RHS       R130                          4500
    RHS       R131                          4500
    RHS       R132                          4500
    RHS       R133                          4500
    RHS       R134                          4500
    RHS       R135                          4500
    RHS       R136                          4500
    RHS       R137                          4500
    RHS       R138                          4500
    RHS       R139                          4500
    RHS       R140                          4500
    RHS       R141                          4500
    RHS       R142                          4500
    RHS       R143                          4500
    RHS       R144                          4500
    RHS       R145                          4500
    RHS       R146                          4500
    RHS       R147                          4500
    RHS       R148                          4500
    RHS       R149                          4500
    RHS       R150                          4500
    RHS       R151                          4500
    RHS       R152                          4500
    RHS       R153                          4500
    RHS       R154                          4500
    RHS       R155                          4500
    RHS       R156                          4500
    RHS       R157                          4500
    RHS       R158                          4500
    RHS       R159                          4500
    RHS       R160                          4500
    RHS       R161                          4500
    RHS       R162                          4500
    RHS       R163                          4500
    RHS       R164                          4500
    RHS       R165                          4500
    RHS       R166                          4500
    RHS       R167                          4500
    RHS       R168                          4500
    RHS       R169                          4500
    RHS       R170                          4500
    RHS       R171                          4500
    RHS       R172                          4500
    RHS       R173                          4500
    RHS       R174                          4500
    RHS       R175                          4500
    RHS       R176                          4500
    RHS       R177                          4500
    RHS       R178                          4500
    RHS       R179                          4500
    RHS       R180                          4500
    RHS       R181                          4500
    RHS       R182                          4500
    RHS       R183                          4500
    RHS       R184                          4500
    RHS       R185                          4500
    RHS       R186                          4500
    RHS       R187                          4500
    RHS       R188                          4500
    RHS       R189                          4500
    RHS       R190                          4500
    RHS       R191                          4500
    RHS       R192                          4500
    RHS       R193                          4500
    RHS       R194                          4500
    RHS       R195                          4500
    RHS       R196                          4500
    RHS       R197                          4500
    RHS       R198                          4500
    RHS       R199                          4500
    RHS       R200                          4500
    RHS       R201                          4500
    RHS       R202                          4500
    RHS       R203                          4500
    RHS       R204                          4500
    RHS       R205                          4500
    RHS       R206                          4500
    RHS       R207                          4500
    RHS       R208                          4500
    RHS       R209                          4500
    RHS       R210                          4500
    RHS       R211                          4500
    RHS       R212                          4500
    RHS       R213                          4500
    RHS       R214                          4500
    RHS       R215                          4500
    RHS       R216                          4500
    RHS       R217                          4500
    RHS       R218                          4500
    RHS       R219                          4500
    RHS       R220                          4500
    RHS       R221                          4500
    RHS       R222                          4500
    RHS       R223                          4500
    RHS       R224                          4500
    RHS       R225                          4500
    RHS       R226                          4500
    RHS       R227                          4500
    RHS       R228                          4500
    RHS       R229                          4500
    RHS       R230                          4500
    RHS       R231                          4500
    RHS       R232                          4500
    RHS       R233                          4500
    RHS       R234                          4500
    RHS       R235                          4500
    RHS       R236                          4500
    RHS       R237                          4500
    RHS       R238                          4500
    RHS       R239                          4500
    RHS       R240                          4500
    RHS       R241                          4500
    RHS       R242                          4500
    RHS       R243                          4500
    RHS       R244                          4500
    RHS       R245                          4500
    RHS       R246                          4500
    RHS       R247                          4500
    RHS       R248                          4500
    RHS       R249                          4500
    RHS       R250                          4500
    RHS       R251                          4500
    RHS       R252                          4500
    RHS       R253                          4500
    RHS       R254                          4500
    RHS       R255                          4500
    RHS       R256                          4500
    RHS       R257                          4500
    RHS       R258                          4500
    RHS       R259                          4500
    RHS       R260                          4500
    RHS       R261                          4500
    RHS       R262                          4500
    RHS       R263                          4500
    RHS       R264                          4500
    RHS       R265                          4500
    RHS       R266                          4500
    RHS       R267                          4500
    RHS       R268                          4500
    RHS       R269                          4500
    RHS       R270                          4500
    RHS       R271                          4500
    RHS       R272                          4500
    RHS       R273                          4500
    RHS       R274                          4500
    RHS       R275                          4500
    RHS       R276                          4500
    RHS       R277                          4500
    RHS       R278                          4500
    RHS       R279                          4500
    RHS       R280                          4500
    RHS       R281                          4500
    RHS       R282                          4500
    RHS       R283                          4500
    RHS       R284                          4500
    RHS       R285                          4500
    RHS       R286                          4500
    RHS       R287                          4500
    RHS       R288                          4500
    RHS       R289                          4500
    RHS       R290                          4500
    RHS       R291                          4500
    RHS       R292                          4500
    RHS       R293                          4500
    RHS       R294                          4500
    RHS       R295                          4500
    RHS       R296                          4500
    RHS       R297                          4500
    RHS       R298                          4500
    RHS       R299                          4500
    RHS       R300                          4500
    RHS       R301                          4500
    RHS       R302                          4500
    RHS       R303                          4500
    RHS       R304                          4500
    RHS       R305                          4500
    RHS       R306                          4500
    RHS       R307                          4500
    RHS       R308                          4500
    RHS       R309                          4500
    RHS       R310                          4500
    RHS       R311                          4500
    RHS       R312                          4500
    RHS       R313                          4500
    RHS       R314                          4500
    RHS       R315                          4500
    RHS       R316                          4500
    RHS       R317                          4500
    RHS       R318                          4500
    RHS       R319                          4500
    RHS       R320                          4500
    RHS       R321                          4500
    RHS       R322                          4500
    RHS       R323                          4500
    RHS       R324                          4500
    RHS       R325                          4500
    RHS       R326                          4500
    RHS       R327                          4500
    RHS       R328                          4500
    RHS       R329                          4500
    RHS       R330                          4500
    RHS       R331                          4500
    RHS       R332                          4500
    RHS       R333                          4500
    RHS       R334                          4500
    RHS       R335                          4500
    RHS       R336                          4500
    RHS       R337                          4500
    RHS       R338                          4500
    RHS       R339                          4500
    RHS       R340                          4500
    RHS       R341                          4500
    RHS       R342                          4500
    RHS       R343                          4500
    RHS       R344                          4500
    RHS       R345                          4500
    RHS       R346                          4500
    RHS       R347                          4500
    RHS       R348                          4500
    RHS       R349                          4500
    RHS       R350                          4500
    RHS       R351                          4500
    RHS       R352                          4500
    RHS       R353                          4500
    RHS       R354                          4500
    RHS       R355                          4500
    RHS       R356                          4500
    RHS       R357                          4500
    RHS       R358                          4500
    RHS       R359                          4500
    RHS       R360                          4500
    RHS       R361                          4500
    RHS       R362                          4500
    RHS       R363                          4500
    RHS       R364                          4500
    RHS       R365                          4500
    RHS       R366                          4500
    RHS       R367                          4500
    RHS       R368                          4500
    RHS       R369                          4500
    RHS       R370                          4500
    RHS       R371                          4500
    RHS       R372                          4500
    RHS       R373                          4500
    RHS       R374                          4500
    RHS       R375                          4500
    RHS       R376                          4500
    RHS       R377                          4500
    RHS       R378                          4500
    RHS       R379                          4500
    RHS       R380                          4500
    RHS       R381                          4500
    RHS       R382                          4500
    RHS       R383                          4500
    RHS       R384                          4500
    RHS       R385                          4500
    RHS       R386                          4500
    RHS       R387                          4500
    RHS       R388                          4500
    RHS       R389                          4500
    RHS       R390                          4500
    RHS       R391                          4500
    RHS       R392                          4500
    RHS       R393                          4500
    RHS       R394                          4500
    RHS       R395                          4500
    RHS       R396                          4500
    RHS       R397                          4500
    RHS       R398                          4500
    RHS       R399                          4500
    RHS       R400                          4500
    RHS       R401                          4500
    RHS       R402                          4500
    RHS       R403                          4500
    RHS       R404                          4500
    RHS       R405                          4500
    RHS       R406                          4500
    RHS       R407                          4500
    RHS       R408                          4500
    RHS       R409                          4500
    RHS       R410                          4500
    RHS       R411                          4500
    RHS       R412                          4500
    RHS       R413                          4500
    RHS       R414                          4500
    RHS       R415                          4500
    RHS       R416                          4500
    RHS       R417                          4500
    RHS       R418                          4500
    RHS       R419                          4500
    RHS       R420                          4500
    RHS       R421                          4500
    RHS       R422                          4500
    RHS       R423                          4500
    RHS       R424                          4500
    RHS       R425                          4500
    RHS       R426                          4500
    RHS       R427                          4500
    RHS       R428                          4500
    RHS       R429                          4500
    RHS       R430                          4500
    RHS       R431                          4500
    RHS       R432                          4500
    RHS       R433                          4500
    RHS       R434                          4500
    RHS       R435                          4500
    RHS       R436                          4500
    RHS       R437                          4500
    RHS       R438                          4500
    RHS       R439                          4500
    RHS       R440                          4500
    RHS       R441                          4500
    RHS       R442                          4500
    RHS       R443                          4500
    RHS       R444                          4500
    RHS       R445                          4500
    RHS       R446                          4500
    RHS       R447                          4500
    RHS       R448                          4500
    RHS       R449                          4500
    RHS       R450                          4500
    RHS       R451                          4500
    RHS       R452                          4500
    RHS       R453                          4500
    RHS       R454                          4500
    RHS       R455                          4500
    RHS       R456                          4500
    RHS       R457                          4500
    RHS       R458                          4500
    RHS       R459                          4500
    RHS       R460                          4500
    RHS       R461                          4500
    RHS       R462                          4500
    RHS       R463                          4500
    RHS       R464                          4500
    RHS       R465                          4500
    RHS       R466                          4500
    RHS       R467                          4500
    RHS       R468                          4500
    RHS       R469                          4500
    RHS       R470                          4500
    RHS       R471                          4500
    RHS       R472                          4500
    RHS       R473                          4500
    RHS       R474                          4500
    RHS       R475                          4500
    RHS       R476                          4500
    RHS       R477                          4500
    RHS       R478                          4500
    RHS       R479                          4500
    RHS       R480                          4500
    RHS       R481                          4500
    RHS       R482                          4500
    RHS       R483                          4500
    RHS       R484                          4500
    RHS       R485                          4500
    RHS       R486                          4500
    RHS       R487                          4500
    RHS       R488                          4500
    RHS       R489                          4500
    RHS       R490                          4500
    RHS       R491                          4500
    RHS       R492                          4500
    RHS       R493                          4500
    RHS       R494                          4500
    RHS       R495                          4500
    RHS       R496                          4500
    RHS       R497                          4500
    RHS       R498                          4500
    RHS       R499                          4500
    RHS       R500                          4500
    RHS       R501                          4500
    RHS       R502                          4500
    RHS       R503                          4500
    RHS       R504                          4500
    RHS       R505                          4500
    RHS       R506                          4500
    RHS       R507                          4500
    RHS       R508                          4500
    RHS       R509                          4500
    RHS       R510                          4500
    RHS       R511                          4500
    RHS       R512                          4500
    RHS       R513                          4500
    RHS       R514                          4500
    RHS       R515                          4500
    RHS       R516                          4500
    RHS       R517                          4500
    RHS       R518                          4500
    RHS       R519                          4500
    RHS       R520                          4500
    RHS       R521                          4500
    RHS       R522                          4500
    RHS       R523                          4500
    RHS       R524                          4500
    RHS       R525                          4500
    RHS       R526                          4500
    RHS       R527                          4500
    RHS       R528                          4500
    RHS       R529                          4500
    RHS       R530                          4500
    RHS       R531                          4500
    RHS       R532                          4500
    RHS       R533                          4500
    RHS       R534                          4500
    RHS       R1193                         -402.5
    RHS       R1194                         -402.5
    RHS       R1195                         -402.5
    RHS       R1196                         -402.5
    RHS       R1197                         -402.5
    RHS       R1198                         -402.5
    RHS       R1199                         -402.5
    RHS       R1200                         -402.5
    RHS       R1201                         -402.5
    RHS       R1202                         -402.5
    RHS       R1203                         -402.5
    RHS       R1204                         -402.5
    RHS       R1205                         -402.5
    RHS       R1206                         -402.5
    RHS       R1207                         -402.5
    RHS       R1208                         -402.5
    RHS       R1209                         -402.5
    RHS       R1210                         -402.5
    RHS       R1211                         -402.5
    RHS       R1212                         -402.5
    RHS       R1213                         -402.5
    RHS       R1214                         -402.5
    RHS       R1215                         -402.5
    RHS       R1216                         -402.5
    RHS       R1217                         -402.5
    RHS       R1218                         -402.5
    RHS       R1219                         -535.5
    RHS       R1220                         -535.5
    RHS       R1221                         -1050
    RHS       R1222                         -1050
    RHS       R1223                         -535.5
    RHS       R1224                         -535.5
    RHS       R1225                         -1050
    RHS       R1226                         -1050
    RHS       R1227                         -535.5
    RHS       R1228                         -535.5
    RHS       R1229                         -1050
    RHS       R1230                         -1050
    RHS       R1231                         -535.5
    RHS       R1232                         -535.5
    RHS       R1233                         -1050
    RHS       R1234                         -1050
    RHS       R1235                         -535.5
    RHS       R1236                         -535.5
    RHS       R1237                         -1050
    RHS       R1238                         -1050
    RHS       R1239                         -535.5
    RHS       R1240                         -535.5
    RHS       R1241                         -1050
    RHS       R1242                         -1050
    RHS       R1243                         -535.5
    RHS       R1244                         -535.5
    RHS       R1245                         -1050
    RHS       R1246                         -1050
    RHS       R1247                         -1050
    RHS       R1248                         -535.5
    RHS       R1249                         -535.5
    RHS       R1250                         -1050
    RHS       R1251                         -1050
    RHS       R1252                         -535.5
    RHS       R1253                         -535.5
    RHS       R1254                         -1050
    RHS       R1255                         -1050
    RHS       R1256                         -535.5
    RHS       R1257                         -535.5
    RHS       R1258                         -1050
    RHS       R1259                         -1050
    RHS       R1260                         -535.5
    RHS       R1261                         -535.5
    RHS       R1262                         -1050
    RHS       R1263                         -1050
    RHS       R1264                         -535.5
    RHS       R1265                         -535.5
    RHS       R1266                         -1050
    RHS       R1267                         -1050
    RHS       R1268                         -535.5
    RHS       R1269                         -535.5
    RHS       R1270                         -1050
    RHS       R1271                         -1050
    RHS       R1272                         -535.5
    RHS       R1273                         -318.5
    RHS       R1274                         -1050
    RHS       R1275                         -430.5
    RHS       R1276                         -539
    RHS       R1277                         -318.5
    RHS       R1278                         -1050
    RHS       R1279                         -430.5
    RHS       R1280                         -539
    RHS       R1281                         -318.5
    RHS       R1282                         -1050
    RHS       R1283                         -430.5
    RHS       R1284                         -539
    RHS       R1285                         -318.5
    RHS       R1286                         -1050
    RHS       R1287                         -430.5
    RHS       R1288                         -539
    RHS       R1289                         -318.5
    RHS       R1290                         -1050
    RHS       R1291                         -430.5
    RHS       R1292                         -539
    RHS       R1293                         -318.5
    RHS       R1294                         -1050
    RHS       R1295                         -430.5
    RHS       R1296                         -539
    RHS       R1297                         -318.5
    RHS       R1298                         -1050
    RHS       R1299                         -430.5
    RHS       R1300                         -1050
    RHS       R1301                         -430.5
    RHS       R1302                         -539
    RHS       R1303                         -318.5
    RHS       R1304                         -1050
    RHS       R1305                         -430.5
    RHS       R1306                         -539
    RHS       R1307                         -318.5
    RHS       R1308                         -1050
    RHS       R1309                         -430.5
    RHS       R1310                         -539
    RHS       R1311                         -318.5
    RHS       R1312                         -1050
    RHS       R1313                         -430.5
    RHS       R1314                         -539
    RHS       R1315                         -318.5
    RHS       R1316                         -1050
    RHS       R1317                         -430.5
    RHS       R1318                         -539
    RHS       R1319                         -318.5
    RHS       R1320                         -1050
    RHS       R1321                         -430.5
    RHS       R1322                         -539
    RHS       R1323                         -318.5
    RHS       R1324                         -1050
    RHS       R1325                         -430.5
    RHS       R1326                         -539
    RHS       R1327                         -1050
    RHS       R1328                         -308
    RHS       R1329                         -1039.5
    RHS       R1330                         -1050
    RHS       R1331                         -308
    RHS       R1332                         -1039.5
    RHS       R1333                         -1050
    RHS       R1334                         -308
    RHS       R1335                         -1039.5
    RHS       R1336                         -1050
    RHS       R1337                         -308
    RHS       R1338                         -1039.5
    RHS       R1339                         -1050
    RHS       R1340                         -308
    RHS       R1341                         -1039.5
    RHS       R1342                         -1050
    RHS       R1343                         -308
    RHS       R1344                         -1039.5
    RHS       R1345                         -1050
    RHS       R1346                         -308
    RHS       R1347                         -1039.5
    RHS       R1348                         -1050
    RHS       R1349                         -308
    RHS       R1350                         -1039.5
    RHS       R1351                         -1050
    RHS       R1352                         -308
    RHS       R1353                         -1039.5
    RHS       R1354                         -1050
    RHS       R1355                         -308
    RHS       R1356                         -1039.5
    RHS       R1357                         -1050
    RHS       R1358                         -308
    RHS       R1359                         -1039.5
    RHS       R1360                         -1050
    RHS       R1361                         -308
    RHS       R1362                         -1039.5
    RHS       R1363                         -1050
    RHS       R1364                         -308
    RHS       R1365                         -1039.5
    RHS       R1366                         -1050
    RHS       R1367                         -535.5
    RHS       R1368                         -535.5
    RHS       R1369                         -1050
    RHS       R1370                         -829.5
    RHS       R1371                         -829.5
    RHS       R1372                         -1050
    RHS       R1373                         -535.5
    RHS       R1374                         -535.5
    RHS       R1375                         -1050
    RHS       R1376                         -829.5
    RHS       R1377                         -829.5
    RHS       R1378                         -1050
    RHS       R1379                         -535.5
    RHS       R1380                         -535.5
    RHS       R1381                         -1050
    RHS       R1382                         -829.5
    RHS       R1383                         -829.5
    RHS       R1384                         -1050
    RHS       R1385                         -535.5
    RHS       R1386                         -535.5
    RHS       R1387                         -1050
    RHS       R1388                         -829.5
    RHS       R1389                         -829.5
    RHS       R1390                         -1050
    RHS       R1391                         -535.5
    RHS       R1392                         -535.5
    RHS       R1393                         -1050
    RHS       R1394                         -829.5
    RHS       R1395                         -829.5
    RHS       R1396                         -1050
    RHS       R1397                         -535.5
    RHS       R1398                         -535.5
    RHS       R1399                         -1050
    RHS       R1400                         -829.5
    RHS       R1401                         -829.5
    RHS       R1402                         -1050
    RHS       R1403                         -535.5
    RHS       R1404                         -535.5
    RHS       R1405                         -1050
    RHS       R1406                         -829.5
    RHS       R1407                         -829.5
    RHS       R1408                         -829.5
    RHS       R1409                         -829.5
    RHS       R1410                         -1050
    RHS       R1411                         -535.5
    RHS       R1412                         -535.5
    RHS       R1413                         -1050
    RHS       R1414                         -829.5
    RHS       R1415                         -829.5
    RHS       R1416                         -1050
    RHS       R1417                         -535.5
    RHS       R1418                         -535.5
    RHS       R1419                         -1050
    RHS       R1420                         -829.5
    RHS       R1421                         -829.5
    RHS       R1422                         -1050
    RHS       R1423                         -535.5
    RHS       R1424                         -535.5
    RHS       R1425                         -1050
    RHS       R1426                         -829.5
    RHS       R1427                         -829.5
    RHS       R1428                         -1050
    RHS       R1429                         -535.5
    RHS       R1430                         -535.5
    RHS       R1431                         -1050
    RHS       R1432                         -829.5
    RHS       R1433                         -829.5
    RHS       R1434                         -1050
    RHS       R1435                         -535.5
    RHS       R1436                         -535.5
    RHS       R1437                         -1050
    RHS       R1438                         -829.5
    RHS       R1439                         -829.5
    RHS       R1440                         -1050
    RHS       R1441                         -535.5
    RHS       R1442                         -535.5
    RHS       R1443                         -1050
    RHS       R1444                         -829.5
    RHS       R1445                         -829.5
    RHS       R1446                         -1050
    RHS       R1447                         -535.5
    RHS       R1448                         -535.5
    RHS       R1449                         -535.5
    RHS       R1450                         -535.5
    RHS       R1451                         -535.5
    RHS       R1452                         -535.5
    RHS       R1453                         -535.5
    RHS       R1454                         -535.5
    RHS       R1455                         -535.5
    RHS       R1456                         -535.5
    RHS       R1457                         -535.5
    RHS       R1458                         -535.5
    RHS       R1459                         -535.5
    RHS       R1460                         -535.5
    RHS       R1461                         -535.5
    RHS       R1462                         -535.5
    RHS       R1463                         -535.5
    RHS       R1464                         -535.5
    RHS       R1465                         -535.5
    RHS       R1466                         -535.5
    RHS       R1467                         -535.5
    RHS       R1468                         -535.5
    RHS       R1469                         -535.5
    RHS       R1470                         -535.5
    RHS       R1471                         -535.5
    RHS       R1472                         -535.5
    RHS       R1473                         -535.5
    RHS       R1474                         -535.5
    RHS       R1475                         -1050
    RHS       R1476                         -1050
    RHS       R1477                         -682.5
    RHS       R1478                         -609
    RHS       R1479                         -430.5
    RHS       R1480                         -861
    RHS       R1481                         -367.5
    RHS       R1482                         -1050
    RHS       R1483                         -430.5
    RHS       R1484                         -609
    RHS       R1485                         -1050
    RHS       R1486                         -1050
    RHS       R1487                         -682.5
    RHS       R1488                         -609
    RHS       R1489                         -430.5
    RHS       R1490                         -861
    RHS       R1491                         -367.5
    RHS       R1492                         -1050
    RHS       R1493                         -430.5
    RHS       R1494                         -609
    RHS       R1495                         -1050
    RHS       R1496                         -1050
    RHS       R1497                         -682.5
    RHS       R1498                         -609
    RHS       R1499                         -430.5
    RHS       R1500                         -861
    RHS       R1501                         -367.5
    RHS       R1502                         -1050
    RHS       R1503                         -430.5
    RHS       R1504                         -609
    RHS       R1505                         -1050
    RHS       R1506                         -1050
    RHS       R1507                         -682.5
    RHS       R1508                         -609
    RHS       R1509                         -430.5
    RHS       R1510                         -861
    RHS       R1511                         -367.5
    RHS       R1512                         -1050
    RHS       R1513                         -430.5
    RHS       R1514                         -609
    RHS       R1515                         -1050
    RHS       R1516                         -1050
    RHS       R1517                         -682.5
    RHS       R1518                         -609
    RHS       R1519                         -430.5
    RHS       R1520                         -861
    RHS       R1521                         -367.5
    RHS       R1522                         -1050
    RHS       R1523                         -430.5
    RHS       R1524                         -609
    RHS       R1525                         -1050
    RHS       R1526                         -1050
    RHS       R1527                         -682.5
    RHS       R1528                         -609
    RHS       R1529                         -430.5
    RHS       R1530                         -861
    RHS       R1531                         -367.5
    RHS       R1532                         -1050
    RHS       R1533                         -430.5
    RHS       R1534                         -609
    RHS       R1535                         -1050
    RHS       R1536                         -1050
    RHS       R1537                         -682.5
    RHS       R1538                         -609
    RHS       R1539                         -430.5
    RHS       R1540                         -861
    RHS       R1541                         -367.5
    RHS       R1542                         -1050
    RHS       R1543                         -430.5
    RHS       R1544                         -367.5
    RHS       R1545                         -1050
    RHS       R1546                         -430.5
    RHS       R1547                         -609
    RHS       R1548                         -1050
    RHS       R1549                         -1050
    RHS       R1550                         -682.5
    RHS       R1551                         -609
    RHS       R1552                         -430.5
    RHS       R1553                         -861
    RHS       R1554                         -367.5
    RHS       R1555                         -1050
    RHS       R1556                         -430.5
    RHS       R1557                         -609
    RHS       R1558                         -1050
    RHS       R1559                         -1050
    RHS       R1560                         -682.5
    RHS       R1561                         -609
    RHS       R1562                         -430.5
    RHS       R1563                         -861
    RHS       R1564                         -367.5
    RHS       R1565                         -1050
    RHS       R1566                         -430.5
    RHS       R1567                         -609
    RHS       R1568                         -1050
    RHS       R1569                         -1050
    RHS       R1570                         -682.5
    RHS       R1571                         -609
    RHS       R1572                         -430.5
    RHS       R1573                         -861
    RHS       R1574                         -367.5
    RHS       R1575                         -1050
    RHS       R1576                         -430.5
    RHS       R1577                         -609
    RHS       R1578                         -1050
    RHS       R1579                         -1050
    RHS       R1580                         -682.5
    RHS       R1581                         -609
    RHS       R1582                         -430.5
    RHS       R1583                         -861
    RHS       R1584                         -367.5
    RHS       R1585                         -1050
    RHS       R1586                         -430.5
    RHS       R1587                         -609
    RHS       R1588                         -1050
    RHS       R1589                         -1050
    RHS       R1590                         -682.5
    RHS       R1591                         -609
    RHS       R1592                         -430.5
    RHS       R1593                         -861
    RHS       R1594                         -367.5
    RHS       R1595                         -1050
    RHS       R1596                         -430.5
    RHS       R1597                         -609
    RHS       R1598                         -1050
    RHS       R1599                         -1050
    RHS       R1600                         -682.5
    RHS       R1601                         -609
    RHS       R1602                         -430.5
    RHS       R1603                         -861
    RHS       R1604                         -367.5
    RHS       R1605                         -1050
    RHS       R1606                         -430.5
    RHS       R1607                         -609
    RHS       R1608                         -1050
    RHS       R1609                         -1050
    RHS       R1610                         -682.5
    RHS       R1611                         -609
    RHS       R1612                         -430.5
    RHS       R1613                         -318.5
    RHS       R1614                         -318.5
    RHS       R1615                         -318.5
    RHS       R1616                         -318.5
    RHS       R1617                         -318.5
    RHS       R1618                         -318.5
    RHS       R1619                         -318.5
    RHS       R1620                         -318.5
    RHS       R1621                         -318.5
    RHS       R1622                         -318.5
    RHS       R1623                         -318.5
    RHS       R1624                         -318.5
    RHS       R1625                         -318.5
    RHS       R1626                         -318.5
    RHS       R1627                         -318.5
    RHS       R1628                         -318.5
    RHS       R1629                         -318.5
    RHS       R1630                         -318.5
    RHS       R1631                         -318.5
    RHS       R1632                         -318.5
    RHS       R1633                         -318.5
    RHS       R1634                         -318.5
    RHS       R1635                         -318.5
    RHS       R1636                         -318.5
    RHS       R1637                         -318.5
    RHS       R1638                         -318.5
    RHS       R1639                         -402.5
    RHS       R1640                         -402.5
    RHS       R1641                         -1050
    RHS       R1642                         -535.5
    RHS       R1643                         -539
    RHS       R1644                         -318.5
    RHS       R1645                         -1039.5
    RHS       R1646                         -308
    RHS       R1647                         -1050
    RHS       R1648                         -1050
    RHS       R1649                         -535.5
    RHS       R1650                         -535.5
    RHS       R1651                         -609
    RHS       R1652                         -861
    RHS       R1653                         -318.5
    RHS       R1654                         -318.5
BOUNDS
 FR BND       X924                          
 FR BND       X925                          
 FR BND       X926                          
 UP BND       X927                          1
 UP BND       X928                          1
 UP BND       X929                          1
 UP BND       X930                          1
 UP BND       X931                          1
 UP BND       X932                          1
 UP BND       X933                          1
 UP BND       X934                          1
 UP BND       X935                          1
 UP BND       X936                          1
 UP BND       X937                          1
 UP BND       X938                          1
 UP BND       X939                          1
 UP BND       X940                          1
 UP BND       X941                          1
 UP BND       X942                          1
 UP BND       X943                          1
 UP BND       X944                          1
 UP BND       X945                          1
 UP BND       X946                          1
 UP BND       X947                          1
 UP BND       X948                          1
 UP BND       X949                          1
 UP BND       X950                          1
 UP BND       X951                          1
 UP BND       X952                          1
 UP BND       X953                          1
 UP BND       X954                          1
 UP BND       X955                          1
 UP BND       X956                          1
 UP BND       X957                          1
 UP BND       X958                          1
 UP BND       X959                          1
 UP BND       X960                          1
 UP BND       X961                          1
 UP BND       X962                          1
 UP BND       X963                          1
 UP BND       X964                          1
 UP BND       X965                          1
 UP BND       X966                          1
 UP BND       X967                          1
 UP BND       X968                          1
 UP BND       X969                          1
 UP BND       X970                          1
 UP BND       X971                          1
 UP BND       X972                          1
 UP BND       X973                          1
 UP BND       X974                          1
 UP BND       X975                          1
 UP BND       X976                          1
 UP BND       X977                          1
 UP BND       X978                          1
 UP BND       X979                          1
 UP BND       X980                          1
 UP BND       X981                          1
 UP BND       X982                          1
 UP BND       X983                          1
 UP BND       X984                          1
 UP BND       X985                          1
 UP BND       X986                          1
 UP BND       X987                          1
 UP BND       X988                          1
 UP BND       X989                          1
 UP BND       X990                          1
 UP BND       X991                          1
 UP BND       X992                          1
 UP BND       X993                          1
 UP BND       X994                          1
 UP BND       X995                          1
 UP BND       X996                          1
 UP BND       X997                          1
 UP BND       X998                          1
 UP BND       X999                          1
 UP BND       X1000                         1
 UP BND       X1001                         1
 UP BND       X1002                         1
 UP BND       X1003                         1
 UP BND       X1004                         1
 UP BND       X1005                         1
 UP BND       X1006                         1
 UP BND       X1007                         1
 UP BND       X1008                         1
 UP BND       X1009                         1
 UP BND       X1010                         1
 UP BND       X1011                         1
 UP BND       X1012                         1
 UP BND       X1013                         1
 UP BND       X1014                         1
 UP BND       X1015                         1
 UP BND       X1016                         1
 UP BND       X1017                         1
 UP BND       X1018                         1
 UP BND       X1019                         1
 UP BND       X1020                         1
 UP BND       X1021                         1
 UP BND       X1022                         1
 UP BND       X1023                         1
 UP BND       X1024                         1
 UP BND       X1025                         1
 UP BND       X1026                         1
 UP BND       X1027                         1
 UP BND       X1028                         1
 UP BND       X1029                         1
 UP BND       X1030                         1
 UP BND       X1031                         1
 UP BND       X1032                         1
 UP BND       X1033                         1
 UP BND       X1034                         1
 UP BND       X1035                         1
 UP BND       X1036                         1
 UP BND       X1037                         1
 UP BND       X1038                         1
 UP BND       X1039                         1
 UP BND       X1040                         1
 UP BND       X1041                         1
 UP BND       X1042                         1
 UP BND       X1043                         1
 UP BND       X1044                         1
 UP BND       X1045                         1
 UP BND       X1046                         1
 UP BND       X1047                         1
 UP BND       X1048                         1
 UP BND       X1049                         1
 UP BND       X1050                         1
 UP BND       X1051                         1
 UP BND       X1052                         1
 UP BND       X1053                         1
 UP BND       X1054                         1
 UP BND       X1055                         1
 UP BND       X1056                         1
 UP BND       X1057                         1
 UP BND       X1058                         1
 UP BND       X1059                         1
 UP BND       X1060                         1
 UP BND       X1061                         1
 UP BND       X1062                         1
 UP BND       X1063                         1
 UP BND       X1064                         1
 UP BND       X1065                         1
 UP BND       X1066                         1
 UP BND       X1067                         1
 UP BND       X1068                         1
 UP BND       X1069                         1
 UP BND       X1070                         1
 UP BND       X1071                         1
 UP BND       X1072                         1
 UP BND       X1073                         1
 UP BND       X1074                         1
 UP BND       X1075                         1
 UP BND       X1076                         1
 UP BND       X1077                         1
 UP BND       X1078                         1
 UP BND       X1079                         1
 UP BND       X1080                         1
 UP BND       X1081                         1
 UP BND       X1082                         1
 UP BND       X1083                         1
 UP BND       X1084                         1
 UP BND       X1085                         1
 UP BND       X1086                         1
 UP BND       X1087                         1
 UP BND       X1088                         1
 UP BND       X1089                         1
 UP BND       X1090                         1
 UP BND       X1091                         1
 UP BND       X1092                         1
 UP BND       X1093                         1
 UP BND       X1094                         1
 UP BND       X1095                         1
 UP BND       X1096                         1
 UP BND       X1097                         1
 UP BND       X1098                         1
 UP BND       X1099                         1
 UP BND       X1100                         1
 UP BND       X1101                         1
 UP BND       X1102                         1
 UP BND       X1103                         1
 UP BND       X1104                         1
 UP BND       X1105                         1
 UP BND       X1106                         1
 UP BND       X1107                         1
 UP BND       X1108                         1
 UP BND       X1109                         1
 UP BND       X1110                         1
 UP BND       X1111                         1
 UP BND       X1112                         1
 UP BND       X1113                         1
 UP BND       X1114                         1
 UP BND       X1115                         1
 UP BND       X1116                         1
 UP BND       X1117                         1
 UP BND       X1118                         1
 UP BND       X1119                         1
 UP BND       X1120                         1
 UP BND       X1121                         1
 UP BND       X1122                         1
 UP BND       X1123                         1
 UP BND       X1124                         1
 UP BND       X1125                         1
 UP BND       X1126                         1
 UP BND       X1127                         1
 UP BND       X1128                         1
 UP BND       X1129                         1
 UP BND       X1130                         1
 UP BND       X1131                         1
 UP BND       X1132                         1
 UP BND       X1133                         1
 UP BND       X1134                         1
 UP BND       X1135                         1
 UP BND       X1136                         1
 UP BND       X1137                         1
 UP BND       X1138                         1
 UP BND       X1139                         1
 UP BND       X1140                         1
 UP BND       X1141                         1
 UP BND       X1142                         1
 UP BND       X1143                         1
 UP BND       X1144                         1
 UP BND       X1145                         1
 UP BND       X1146                         1
 UP BND       X1147                         1
 UP BND       X1148                         1
 UP BND       X1149                         1
 UP BND       X1150                         1
 UP BND       X1151                         1
 UP BND       X1152                         1
 UP BND       X1153                         1
 UP BND       X1154                         1
 UP BND       X1155                         1
 UP BND       X1156                         1
 UP BND       X1157                         1
 UP BND       X1158                         1
 UP BND       X1159                         1
 UP BND       X1160                         1
 UP BND       X1161                         1
 UP BND       X1162                         1
 UP BND       X1163                         1
 UP BND       X1164                         1
 UP BND       X1165                         1
 UP BND       X1166                         1
 UP BND       X1167                         1
 UP BND       X1168                         1
 UP BND       X1169                         1
 UP BND       X1170                         1
 UP BND       X1171                         1
 UP BND       X1172                         1
 UP BND       X1173                         1
 UP BND       X1174                         1
 UP BND       X1175                         1
 UP BND       X1176                         1
 UP BND       X1177                         1
 UP BND       X1178                         1
 UP BND       X1179                         1
 UP BND       X1180                         1
 UP BND       X1181                         1
 UP BND       X1182                         1
 UP BND       X1183                         1
 UP BND       X1184                         1
 UP BND       X1185                         1
 UP BND       X1186                         1
 UP BND       X1187                         1
 UP BND       X1188                         1
 UP BND       X1189                         1
 UP BND       X1190                         1
 UP BND       X1191                         1
 UP BND       X1192                         1
 UP BND       X1193                         1
 UP BND       X1194                         1
 UP BND       X1195                         1
 UP BND       X1196                         1
 UP BND       X1197                         1
 UP BND       X1198                         1
 UP BND       X1199                         1
 UP BND       X1200                         1
 UP BND       X1201                         1
 UP BND       X1202                         1
 UP BND       X1203                         1
 UP BND       X1204                         1
 UP BND       X1205                         1
 UP BND       X1206                         1
 UP BND       X1207                         1
 UP BND       X1208                         1
 UP BND       X1209                         1
 UP BND       X1210                         1
 UP BND       X1211                         1
 UP BND       X1212                         1
 UP BND       X1213                         1
 UP BND       X1214                         1
 UP BND       X1215                         1
 UP BND       X1216                         1
 UP BND       X1217                         1
 UP BND       X1218                         1
 UP BND       X1219                         1
 UP BND       X1220                         1
 UP BND       X1221                         1
 UP BND       X1222                         1
 UP BND       X1223                         1
 UP BND       X1224                         1
 UP BND       X1225                         1
 UP BND       X1226                         1
 UP BND       X1227                         1
 UP BND       X1228                         1
 UP BND       X1229                         1
 UP BND       X1230                         1
 UP BND       X1231                         1
 UP BND       X1232                         1
 UP BND       X1233                         1
 UP BND       X1234                         1
 UP BND       X1235                         1
 UP BND       X1236                         1
 UP BND       X1237                         1
 UP BND       X1238                         1
 UP BND       X1239                         1
 UP BND       X1240                         1
 UP BND       X1241                         1
 UP BND       X1242                         1
 UP BND       X1243                         1
 UP BND       X1244                         1
 UP BND       X1245                         1
 UP BND       X1246                         1
 UP BND       X1247                         1
 UP BND       X1248                         1
 UP BND       X1249                         1
 UP BND       X1250                         1
 UP BND       X1251                         1
 UP BND       X1252                         1
 UP BND       X1253                         1
 UP BND       X1254                         1
 UP BND       X1255                         1
 UP BND       X1256                         1
 UP BND       X1257                         1
 UP BND       X1258                         1
 UP BND       X1259                         1
 UP BND       X1260                         1
 UP BND       X1261                         1
 UP BND       X1262                         1
 UP BND       X1263                         1
 UP BND       X1264                         1
 UP BND       X1265                         1
 UP BND       X1266                         1
 UP BND       X1267                         1
 UP BND       X1268                         1
 UP BND       X1269                         1
 UP BND       X1270                         1
 UP BND       X1271                         1
 UP BND       X1272                         1
 UP BND       X1273                         1
 UP BND       X1274                         1
 UP BND       X1275                         1
 UP BND       X1276                         1
 UP BND       X1277                         1
 UP BND       X1278                         1
 UP BND       X1279                         1
 UP BND       X1280                         1
 UP BND       X1281                         1
 UP BND       X1282                         1
 UP BND       X1283                         1
 UP BND       X1284                         1
 UP BND       X1285                         1
 UP BND       X1286                         1
 UP BND       X1287                         1
 UP BND       X1288                         1
 UP BND       X1289                         1
 UP BND       X1290                         1
 UP BND       X1291                         1
 UP BND       X1292                         1
 UP BND       X1293                         1
 UP BND       X1294                         1
 UP BND       X1295                         1
 UP BND       X1296                         1
 UP BND       X1297                         1
 UP BND       X1298                         1
 UP BND       X1299                         1
 UP BND       X1300                         1
 UP BND       X1301                         1
 UP BND       X1302                         1
 UP BND       X1303                         1
 UP BND       X1304                         1
 UP BND       X1305                         1
 UP BND       X1306                         1
 UP BND       X1307                         1
 UP BND       X1308                         1
 UP BND       X1309                         1
 UP BND       X1310                         1
 UP BND       X1311                         1
 UP BND       X1312                         1
 UP BND       X1313                         1
 UP BND       X1314                         1
 UP BND       X1315                         1
 UP BND       X1316                         1
 UP BND       X1317                         1
 UP BND       X1318                         1
 UP BND       X1319                         1
 UP BND       X1320                         1
 UP BND       X1321                         1
 UP BND       X1322                         1
 UP BND       X1323                         1
 UP BND       X1324                         1
 UP BND       X1325                         1
 UP BND       X1326                         1
 UP BND       X1327                         1
 UP BND       X1328                         1
 UP BND       X1329                         1
 UP BND       X1330                         1
 UP BND       X1331                         1
 UP BND       X1332                         1
 UP BND       X1333                         1
 UP BND       X1334                         1
 UP BND       X1335                         1
 UP BND       X1336                         1
 UP BND       X1337                         1
 UP BND       X1338                         1
 UP BND       X1339                         1
 UP BND       X1340                         1
 UP BND       X1341                         1
 UP BND       X1342                         1
 UP BND       X1343                         1
 UP BND       X1344                         1
 UP BND       X1345                         1
 UP BND       X1346                         1
 UP BND       X1347                         1
 UP BND       X1348                         1
 UP BND       X1349                         1
 UP BND       X1350                         1
 UP BND       X1351                         1
 UP BND       X1352                         1
 UP BND       X1353                         1
 UP BND       X1354                         1
 UP BND       X1355                         1
 UP BND       X1356                         1
 UP BND       X1357                         1
 UP BND       X1358                         1
 UP BND       X1359                         1
 UP BND       X1360                         1
 UP BND       X1361                         1
 UP BND       X1362                         1
 UP BND       X1363                         1
 UP BND       X1364                         1
 UP BND       X1365                         1
 UP BND       X1366                         1
 UP BND       X1367                         1
 UP BND       X1368                         1
 UP BND       X1369                         1
 UP BND       X1370                         1
 UP BND       X1371                         1
 UP BND       X1372                         1
 UP BND       X1373                         1
 UP BND       X1374                         1
 UP BND       X1375                         1
 UP BND       X1376                         1
 UP BND       X1377                         1
 UP BND       X1378                         1
 UP BND       X1379                         1
 UP BND       X1380                         1
 UP BND       X1381                         1
 UP BND       X1382                         1
 UP BND       X1383                         1
 UP BND       X1384                         1
 UP BND       X1385                         1
 UP BND       X1386                         1
 UP BND       X1387                         1
 UP BND       X1388                         1
 UP BND       X1389                         1
 UP BND       X1390                         1
 UP BND       X1391                         1
 UP BND       X1392                         1
 UP BND       X1393                         1
 UP BND       X1394                         1
 UP BND       X1395                         1
 UP BND       X1396                         1
 UP BND       X1397                         1
 UP BND       X1398                         1
 UP BND       X1399                         1
 UP BND       X1400                         1
 UP BND       X1401                         1
 UP BND       X1402                         1
 UP BND       X1403                         1
 UP BND       X1404                         1
 UP BND       X1405                         1
 UP BND       X1406                         1
 UP BND       X1407                         1
 UP BND       X1408                         1
 UP BND       X1409                         1
 UP BND       X1410                         1
 UP BND       X1411                         1
 UP BND       X1412                         1
 UP BND       X1413                         1
 UP BND       X1414                         1
 UP BND       X1415                         1
 UP BND       X1416                         1
 UP BND       X1417                         1
 UP BND       X1418                         1
 UP BND       X1419                         1
 UP BND       X1420                         1
 UP BND       X1421                         1
 UP BND       X1422                         1
 UP BND       X1423                         1
 UP BND       X1424                         1
 UP BND       X1425                         1
 UP BND       X1426                         1
 UP BND       X1427                         1
 UP BND       X1428                         1
 UP BND       X1429                         1
 UP BND       X1430                         1
 UP BND       X1431                         1
 UP BND       X1432                         1
 UP BND       X1433                         1
 UP BND       X1434                         1
 UP BND       X1435                         1
 UP BND       X1436                         1
 UP BND       X1437                         1
 UP BND       X1438                         1
 UP BND       X1439                         1
 UP BND       X1440                         1
 UP BND       X1441                         1
 UP BND       X1442                         1
 UP BND       X1443                         1
 UP BND       X1444                         1
 UP BND       X1445                         1
 UP BND       X1446                         1
 UP BND       X1447                         1
 UP BND       X1448                         1
 UP BND       X1449                         1
 UP BND       X1450                         1
 UP BND       X1451                         1
 UP BND       X1452                         1
 UP BND       X1453                         1
 UP BND       X1454                         1
 UP BND       X1455                         1
 UP BND       X1456                         1
 UP BND       X1457                         1
 UP BND       X1458                         1
 UP BND       X1459                         1
 UP BND       X1460                         1
 UP BND       X1461                         1
ENDATA
