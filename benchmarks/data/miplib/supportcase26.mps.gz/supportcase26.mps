NAME supportcase26
ROWS
 N R0
 G R1
 G R2
 G R3
 G R4
 G R5
 G R6
 G R7
 G R8
 G R9
 G R10
 G R11
 G R12
 G R13
 G R14
 G R15
 G R16
 G R17
 G R18
 G R19
 G R20
 G R21
 G R22
 G R23
 G R24
 G R25
 G R26
 G R27
 G R28
 G R29
 G R30
 G R31
 G R32
 G R33
 G R34
 G R35
 G R36
 G R37
 G R38
 G R39
 G R40
 G R41
 G R42
 G R43
 G R44
 G R45
 G R46
 G R47
 G R48
 G R49
 G R50
 G R51
 G R52
 G R53
 G R54
 G R55
 G R56
 G R57
 G R58
 G R59
 G R60
 G R61
 G R62
 G R63
 G R64
 G R65
 G R66
 G R67
 G R68
 G R69
 G R70
 G R71
 G R72
 G R73
 G R74
 G R75
 G R76
 G R77
 G R78
 G R79
 G R80
 G R81
 G R82
 G R83
 G R84
 G R85
 G R86
 G R87
 G R88
 G R89
 G R90
 G R91
 G R92
 G R93
 G R94
 G R95
 G R96
 G R97
 G R98
 G R99
 G R100
 G R101
 G R102
 G R103
 G R104
 G R105
 G R106
 G R107
 G R108
 G R109
 G R110
 G R111
 G R112
 G R113
 G R114
 G R115
 G R116
 G R117
 G R118
 G R119
 G R120
 G R121
 G R122
 G R123
 G R124
 G R125
 G R126
 G R127
 G R128
 G R129
 G R130
 G R131
 G R132
 G R133
 G R134
 G R135
 G R136
 G R137
 G R138
 G R139
 G R140
 G R141
 G R142
 G R143
 G R144
 G R145
 G R146
 G R147
 G R148
 G R149
 G R150
 G R151
 G R152
 G R153
 G R154
 G R155
 G R156
 G R157
 G R158
 G R159
 G R160
 G R161
 G R162
 G R163
 G R164
 G R165
 G R166
 G R167
 G R168
 G R169
 G R170
 G R171
 G R172
 G R173
 G R174
 G R175
 G R176
 G R177
 G R178
 G R179
 G R180
 G R181
 G R182
 G R183
 G R184
 G R185
 G R186
 G R187
 G R188
 G R189
 G R190
 G R191
 G R192
 G R193
 G R194
 G R195
 G R196
 G R197
 G R198
 G R199
 G R200
 G R201
 G R202
 G R203
 G R204
 G R205
 G R206
 G R207
 G R208
 G R209
 G R210
 G R211
 G R212
 G R213
 G R214
 G R215
 G R216
 G R217
 G R218
 G R219
 G R220
 G R221
 G R222
 G R223
 G R224
 G R225
 G R226
 G R227
 G R228
 G R229
 G R230
 G R231
 G R232
 G R233
 G R234
 G R235
 G R236
 G R237
 G R238
 G R239
 G R240
 G R241
 G R242
 G R243
 G R244
 G R245
 G R246
 G R247
 G R248
 G R249
 G R250
 G R251
 G R252
 G R253
 G R254
 G R255
 G R256
 G R257
 G R258
 G R259
 G R260
 G R261
 G R262
 G R263
 G R264
 G R265
 G R266
 G R267
 G R268
 G R269
 G R270
 G R271
 G R272
 G R273
 G R274
 G R275
 G R276
 G R277
 G R278
 G R279
 G R280
 G R281
 G R282
 G R283
 G R284
 G R285
 G R286
 G R287
 G R288
 G R289
 G R290
 G R291
 G R292
 G R293
 G R294
 G R295
 G R296
 G R297
 G R298
 G R299
 G R300
 G R301
 G R302
 G R303
 G R304
 G R305
 G R306
 G R307
 G R308
 G R309
 G R310
 G R311
 G R312
 G R313
 G R314
 G R315
 G R316
 G R317
 G R318
 G R319
 G R320
 G R321
 G R322
 G R323
 G R324
 G R325
 G R326
 G R327
 G R328
 G R329
 G R330
 G R331
 G R332
 G R333
 G R334
 G R335
 G R336
 G R337
 G R338
 G R339
 G R340
 G R341
 G R342
 G R343
 G R344
 G R345
 G R346
 G R347
 G R348
 G R349
 G R350
 G R351
 G R352
 G R353
 G R354
 G R355
 G R356
 G R357
 G R358
 G R359
 G R360
 G R361
 G R362
 G R363
 G R364
 G R365
 G R366
 G R367
 G R368
 G R369
 G R370
 G R371
 G R372
 G R373
 G R374
 G R375
 G R376
 G R377
 G R378
 G R379
 G R380
 G R381
 G R382
 G R383
 G R384
 G R385
 G R386
 G R387
 G R388
 G R389
 G R390
 G R391
 G R392
 G R393
 G R394
 G R395
 G R396
 G R397
 G R398
 G R399
 G R400
 G R401
 G R402
 G R403
 G R404
 G R405
 G R406
 G R407
 G R408
 G R409
 G R410
 G R411
 G R412
 G R413
 G R414
 G R415
 G R416
 G R417
 G R418
 G R419
 G R420
 G R421
 G R422
 G R423
 G R424
 G R425
 G R426
 G R427
 G R428
 G R429
 G R430
 G R431
 G R432
 G R433
 G R434
 G R435
 G R436
 G R437
 G R438
 G R439
 G R440
 G R441
 G R442
 G R443
 G R444
 G R445
 G R446
 G R447
 G R448
 G R449
 G R450
 G R451
 G R452
 G R453
 G R454
 G R455
 G R456
 G R457
 G R458
 G R459
 G R460
 G R461
 G R462
 G R463
 G R464
 G R465
 G R466
 G R467
 G R468
 G R469
 G R470
 G R471
 G R472
 G R473
 G R474
 G R475
 G R476
 G R477
 G R478
 G R479
 G R480
 G R481
 G R482
 G R483
 G R484
 G R485
 G R486
 G R487
 G R488
 G R489
 G R490
 G R491
 G R492
 G R493
 G R494
 G R495
 G R496
 G R497
 G R498
 G R499
 G R500
 G R501
 G R502
 G R503
 G R504
 G R505
 G R506
 G R507
 G R508
 G R509
 G R510
 G R511
 G R512
 G R513
 G R514
 G R515
 G R516
 G R517
 G R518
 G R519
 G R520
 G R521
 G R522
 G R523
 G R524
 G R525
 G R526
 G R527
 G R528
 G R529
 G R530
 G R531
 G R532
 G R533
 G R534
 G R535
 G R536
 G R537
 G R538
 G R539
 G R540
 G R541
 G R542
 G R543
 G R544
 G R545
 G R546
 G R547
 G R548
 G R549
 G R550
 G R551
 G R552
 G R553
 G R554
 G R555
 G R556
 G R557
 G R558
 G R559
 G R560
 G R561
 G R562
 G R563
 G R564
 G R565
 G R566
 G R567
 G R568
 G R569
 G R570
 G R571
 G R572
 G R573
 G R574
 G R575
 G R576
 G R577
 G R578
 G R579
 G R580
 G R581
 G R582
 G R583
 G R584
 G R585
 G R586
 G R587
 G R588
 G R589
 G R590
 G R591
 G R592
 G R593
 G R594
 G R595
 G R596
 G R597
 G R598
 G R599
 G R600
 G R601
 G R602
 G R603
 G R604
 G R605
 G R606
 G R607
 G R608
 G R609
 G R610
 G R611
 G R612
 G R613
 G R614
 G R615
 G R616
 G R617
 G R618
 G R619
 G R620
 G R621
 G R622
 G R623
 G R624
 G R625
 G R626
 G R627
 G R628
 G R629
 G R630
 G R631
 G R632
 G R633
 G R634
 G R635
 G R636
 G R637
 G R638
 G R639
 G R640
 G R641
 G R642
 G R643
 G R644
 G R645
 G R646
 G R647
 G R648
 G R649
 G R650
 G R651
 G R652
 G R653
 G R654
 G R655
 G R656
 G R657
 G R658
 G R659
 G R660
 G R661
 G R662
 G R663
 G R664
 G R665
 G R666
 G R667
 G R668
 G R669
 G R670
 G R671
 G R672
 G R673
 G R674
 G R675
 G R676
 G R677
 G R678
 G R679
 G R680
 G R681
 G R682
 G R683
 G R684
 G R685
 G R686
 G R687
 G R688
 G R689
 G R690
 G R691
 G R692
 G R693
 G R694
 G R695
 G R696
 G R697
 G R698
 G R699
 G R700
 G R701
 G R702
 G R703
 G R704
 G R705
 G R706
 G R707
 G R708
 G R709
 G R710
 G R711
 G R712
 G R713
 G R714
 G R715
 G R716
 G R717
 G R718
 G R719
 G R720
 G R721
 G R722
 G R723
 G R724
 G R725
 G R726
 G R727
 G R728
 G R729
 G R730
 G R731
 G R732
 G R733
 G R734
 G R735
 G R736
 G R737
 G R738
 G R739
 G R740
 G R741
 G R742
 G R743
 G R744
 G R745
 G R746
 G R747
 G R748
 G R749
 G R750
 G R751
 G R752
 G R753
 G R754
 G R755
 G R756
 G R757
 G R758
 G R759
 G R760
 G R761
 G R762
 G R763
 G R764
 G R765
 G R766
 G R767
 G R768
 G R769
 G R770
 G R771
 G R772
 G R773
 G R774
 G R775
 G R776
 G R777
 G R778
 G R779
 G R780
 G R781
 G R782
 G R783
 G R784
 G R785
 G R786
 G R787
 G R788
 G R789
 G R790
 G R791
 G R792
 G R793
 G R794
 G R795
 G R796
 G R797
 G R798
 G R799
 G R800
 G R801
 G R802
 G R803
 G R804
 G R805
 G R806
 G R807
 G R808
 G R809
 G R810
 G R811
 G R812
 G R813
 G R814
 G R815
 G R816
 G R817
 G R818
 G R819
 G R820
 G R821
 G R822
 G R823
 G R824
 G R825
 G R826
 G R827
 G R828
 G R829
 G R830
 G R831
 G R832
 G R833
 G R834
 G R835
 G R836
 G R837
 G R838
 G R839
 G R840
 G R841
 G R842
 G R843
 G R844
 G R845
 G R846
 G R847
 G R848
 G R849
 G R850
 G R851
 G R852
 G R853
 G R854
 G R855
 G R856
 G R857
 G R858
 G R859
 G R860
 G R861
 G R862
 G R863
 G R864
 G R865
 G R866
 G R867
 G R868
 G R869
 G R870
COLUMNS
    X0        R0                            1
    X0        R1                            1
    X0        R41                           -1
    X0        R79                           -1
    X0        R80                           -1
    X0        R81                           -1
    X0        R82                           -1
    X0        R83                           -1
    X0        R84                           -1
    X0        R85                           -1
    X0        R86                           -1
    X0        R87                           -1
    X0        R88                           -1
    X0        R89                           -1
    X0        R90                           -1
    X0        R91                           -1
    X0        R92                           -1
    X0        R93                           -1
    X0        R94                           -1
    X0        R95                           -1
    X0        R96                           -1
    X0        R97                           -1
    X0        R98                           -1
    X0        R99                           -1
    X0        R100                          -1
    X0        R475                          1
    X0        R476                          1
    X0        R477                          1
    X0        R478                          1
    X0        R479                          1
    X0        R480                          1
    X0        R481                          1
    X0        R482                          1
    X0        R483                          1
    X0        R484                          1
    X0        R485                          1
    X0        R486                          1
    X0        R487                          1
    X0        R488                          1
    X0        R489                          1
    X0        R490                          1
    X0        R491                          1
    X0        R492                          1
    X0        R493                          1
    X0        R494                          1
    X0        R495                          1
    X0        R496                          1
    X1        R0                            1
    X1        R2                            1
    X1        R41                           1
    X1        R42                           -1
    X1        R101                          -1
    X1        R102                          -1
    X1        R103                          -1
    X1        R104                          -1
    X1        R105                          -1
    X1        R106                          -1
    X1        R107                          -1
    X1        R108                          -1
    X1        R109                          -1
    X1        R110                          -1
    X1        R111                          -1
    X1        R112                          -1
    X1        R113                          -1
    X1        R114                          -1
    X1        R115                          -1
    X1        R116                          -1
    X1        R117                          -1
    X1        R118                          -1
    X1        R119                          -1
    X1        R120                          -1
    X1        R121                          -1
    X1        R122                          -1
    X1        R497                          1
    X1        R498                          1
    X1        R499                          1
    X1        R500                          1
    X1        R501                          1
    X1        R502                          1
    X1        R503                          1
    X1        R504                          1
    X1        R505                          1
    X1        R506                          1
    X1        R507                          1
    X1        R508                          1
    X1        R509                          1
    X1        R510                          1
    X1        R511                          1
    X1        R512                          1
    X1        R513                          1
    X1        R514                          1
    X1        R515                          1
    X1        R516                          1
    X1        R517                          1
    X1        R518                          1
    X2        R0                            1
    X2        R3                            1
    X2        R42                           1
    X2        R43                           -1
    X2        R123                          -1
    X2        R124                          -1
    X2        R125                          -1
    X2        R126                          -1
    X2        R127                          -1
    X2        R128                          -1
    X2        R129                          -1
    X2        R130                          -1
    X2        R131                          -1
    X2        R132                          -1
    X2        R133                          -1
    X2        R134                          -1
    X2        R135                          -1
    X2        R136                          -1
    X2        R137                          -1
    X2        R138                          -1
    X2        R139                          -1
    X2        R140                          -1
    X2        R141                          -1
    X2        R142                          -1
    X2        R143                          -1
    X2        R144                          -1
    X2        R519                          1
    X2        R520                          1
    X2        R521                          1
    X2        R522                          1
    X2        R523                          1
    X2        R524                          1
    X2        R525                          1
    X2        R526                          1
    X2        R527                          1
    X2        R528                          1
    X2        R529                          1
    X2        R530                          1
    X2        R531                          1
    X2        R532                          1
    X2        R533                          1
    X2        R534                          1
    X2        R535                          1
    X2        R536                          1
    X2        R537                          1
    X2        R538                          1
    X2        R539                          1
    X2        R540                          1
    X3        R0                            1
    X3        R4                            1
    X3        R43                           1
    X3        R44                           -1
    X3        R145                          -1
    X3        R146                          -1
    X3        R147                          -1
    X3        R148                          -1
    X3        R149                          -1
    X3        R150                          -1
    X3        R151                          -1
    X3        R152                          -1
    X3        R153                          -1
    X3        R154                          -1
    X3        R155                          -1
    X3        R156                          -1
    X3        R157                          -1
    X3        R158                          -1
    X3        R159                          -1
    X3        R160                          -1
    X3        R161                          -1
    X3        R162                          -1
    X3        R163                          -1
    X3        R164                          -1
    X3        R165                          -1
    X3        R166                          -1
    X3        R541                          1
    X3        R542                          1
    X3        R543                          1
    X3        R544                          1
    X3        R545                          1
    X3        R546                          1
    X3        R547                          1
    X3        R548                          1
    X3        R549                          1
    X3        R550                          1
    X3        R551                          1
    X3        R552                          1
    X3        R553                          1
    X3        R554                          1
    X3        R555                          1
    X3        R556                          1
    X3        R557                          1
    X3        R558                          1
    X3        R559                          1
    X3        R560                          1
    X3        R561                          1
    X3        R562                          1
    X4        R0                            1
    X4        R5                            1
    X4        R44                           1
    X4        R45                           -1
    X4        R167                          -1
    X4        R168                          -1
    X4        R169                          -1
    X4        R170                          -1
    X4        R171                          -1
    X4        R172                          -1
    X4        R173                          -1
    X4        R174                          -1
    X4        R175                          -1
    X4        R176                          -1
    X4        R177                          -1
    X4        R178                          -1
    X4        R179                          -1
    X4        R180                          -1
    X4        R181                          -1
    X4        R182                          -1
    X4        R183                          -1
    X4        R184                          -1
    X4        R185                          -1
    X4        R186                          -1
    X4        R187                          -1
    X4        R188                          -1
    X4        R563                          1
    X4        R564                          1
    X4        R565                          1
    X4        R566                          1
    X4        R567                          1
    X4        R568                          1
    X4        R569                          1
    X4        R570                          1
    X4        R571                          1
    X4        R572                          1
    X4        R573                          1
    X4        R574                          1
    X4        R575                          1
    X4        R576                          1
    X4        R577                          1
    X4        R578                          1
    X4        R579                          1
    X4        R580                          1
    X4        R581                          1
    X4        R582                          1
    X4        R583                          1
    X4        R584                          1
    X5        R0                            1
    X5        R6                            1
    X5        R45                           1
    X5        R46                           -1
    X5        R189                          -1
    X5        R190                          -1
    X5        R191                          -1
    X5        R192                          -1
    X5        R193                          -1
    X5        R194                          -1
    X5        R195                          -1
    X5        R196                          -1
    X5        R197                          -1
    X5        R198                          -1
    X5        R199                          -1
    X5        R200                          -1
    X5        R201                          -1
    X5        R202                          -1
    X5        R203                          -1
    X5        R204                          -1
    X5        R205                          -1
    X5        R206                          -1
    X5        R207                          -1
    X5        R208                          -1
    X5        R209                          -1
    X5        R210                          -1
    X5        R585                          1
    X5        R586                          1
    X5        R587                          1
    X5        R588                          1
    X5        R589                          1
    X5        R590                          1
    X5        R591                          1
    X5        R592                          1
    X5        R593                          1
    X5        R594                          1
    X5        R595                          1
    X5        R596                          1
    X5        R597                          1
    X5        R598                          1
    X5        R599                          1
    X5        R600                          1
    X5        R601                          1
    X5        R602                          1
    X5        R603                          1
    X5        R604                          1
    X5        R605                          1
    X5        R606                          1
    X6        R0                            1
    X6        R7                            1
    X6        R46                           1
    X6        R47                           -1
    X6        R211                          -1
    X6        R212                          -1
    X6        R213                          -1
    X6        R214                          -1
    X6        R215                          -1
    X6        R216                          -1
    X6        R217                          -1
    X6        R218                          -1
    X6        R219                          -1
    X6        R220                          -1
    X6        R221                          -1
    X6        R222                          -1
    X6        R223                          -1
    X6        R224                          -1
    X6        R225                          -1
    X6        R226                          -1
    X6        R227                          -1
    X6        R228                          -1
    X6        R229                          -1
    X6        R230                          -1
    X6        R231                          -1
    X6        R232                          -1
    X6        R607                          1
    X6        R608                          1
    X6        R609                          1
    X6        R610                          1
    X6        R611                          1
    X6        R612                          1
    X6        R613                          1
    X6        R614                          1
    X6        R615                          1
    X6        R616                          1
    X6        R617                          1
    X6        R618                          1
    X6        R619                          1
    X6        R620                          1
    X6        R621                          1
    X6        R622                          1
    X6        R623                          1
    X6        R624                          1
    X6        R625                          1
    X6        R626                          1
    X6        R627                          1
    X6        R628                          1
    X7        R0                            1
    X7        R8                            1
    X7        R47                           1
    X7        R48                           -1
    X7        R233                          -1
    X7        R234                          -1
    X7        R235                          -1
    X7        R236                          -1
    X7        R237                          -1
    X7        R238                          -1
    X7        R239                          -1
    X7        R240                          -1
    X7        R241                          -1
    X7        R242                          -1
    X7        R243                          -1
    X7        R244                          -1
    X7        R245                          -1
    X7        R246                          -1
    X7        R247                          -1
    X7        R248                          -1
    X7        R249                          -1
    X7        R250                          -1
    X7        R251                          -1
    X7        R252                          -1
    X7        R253                          -1
    X7        R254                          -1
    X7        R629                          1
    X7        R630                          1
    X7        R631                          1
    X7        R632                          1
    X7        R633                          1
    X7        R634                          1
    X7        R635                          1
    X7        R636                          1
    X7        R637                          1
    X7        R638                          1
    X7        R639                          1
    X7        R640                          1
    X7        R641                          1
    X7        R642                          1
    X7        R643                          1
    X7        R644                          1
    X7        R645                          1
    X7        R646                          1
    X7        R647                          1
    X7        R648                          1
    X7        R649                          1
    X7        R650                          1
    X8        R0                            1
    X8        R9                            1
    X8        R48                           1
    X8        R49                           -1
    X8        R255                          -1
    X8        R256                          -1
    X8        R257                          -1
    X8        R258                          -1
    X8        R259                          -1
    X8        R260                          -1
    X8        R261                          -1
    X8        R262                          -1
    X8        R263                          -1
    X8        R264                          -1
    X8        R265                          -1
    X8        R266                          -1
    X8        R267                          -1
    X8        R268                          -1
    X8        R269                          -1
    X8        R270                          -1
    X8        R271                          -1
    X8        R272                          -1
    X8        R273                          -1
    X8        R274                          -1
    X8        R275                          -1
    X8        R276                          -1
    X8        R651                          1
    X8        R652                          1
    X8        R653                          1
    X8        R654                          1
    X8        R655                          1
    X8        R656                          1
    X8        R657                          1
    X8        R658                          1
    X8        R659                          1
    X8        R660                          1
    X8        R661                          1
    X8        R662                          1
    X8        R663                          1
    X8        R664                          1
    X8        R665                          1
    X8        R666                          1
    X8        R667                          1
    X8        R668                          1
    X8        R669                          1
    X8        R670                          1
    X8        R671                          1
    X8        R672                          1
    X9        R0                            1
    X9        R10                           1
    X9        R49                           1
    X9        R50                           -1
    X9        R277                          -1
    X9        R278                          -1
    X9        R279                          -1
    X9        R280                          -1
    X9        R281                          -1
    X9        R282                          -1
    X9        R283                          -1
    X9        R284                          -1
    X9        R285                          -1
    X9        R286                          -1
    X9        R287                          -1
    X9        R288                          -1
    X9        R289                          -1
    X9        R290                          -1
    X9        R291                          -1
    X9        R292                          -1
    X9        R293                          -1
    X9        R294                          -1
    X9        R295                          -1
    X9        R296                          -1
    X9        R297                          -1
    X9        R298                          -1
    X9        R673                          1
    X9        R674                          1
    X9        R675                          1
    X9        R676                          1
    X9        R677                          1
    X9        R678                          1
    X9        R679                          1
    X9        R680                          1
    X9        R681                          1
    X9        R682                          1
    X9        R683                          1
    X9        R684                          1
    X9        R685                          1
    X9        R686                          1
    X9        R687                          1
    X9        R688                          1
    X9        R689                          1
    X9        R690                          1
    X9        R691                          1
    X9        R692                          1
    X9        R693                          1
    X9        R694                          1
    X10       R0                            1
    X10       R11                           1
    X10       R50                           1
    X10       R51                           -1
    X10       R299                          -1
    X10       R300                          -1
    X10       R301                          -1
    X10       R302                          -1
    X10       R303                          -1
    X10       R304                          -1
    X10       R305                          -1
    X10       R306                          -1
    X10       R307                          -1
    X10       R308                          -1
    X10       R309                          -1
    X10       R310                          -1
    X10       R311                          -1
    X10       R312                          -1
    X10       R313                          -1
    X10       R314                          -1
    X10       R315                          -1
    X10       R316                          -1
    X10       R317                          -1
    X10       R318                          -1
    X10       R319                          -1
    X10       R320                          -1
    X10       R695                          1
    X10       R696                          1
    X10       R697                          1
    X10       R698                          1
    X10       R699                          1
    X10       R700                          1
    X10       R701                          1
    X10       R702                          1
    X10       R703                          1
    X10       R704                          1
    X10       R705                          1
    X10       R706                          1
    X10       R707                          1
    X10       R708                          1
    X10       R709                          1
    X10       R710                          1
    X10       R711                          1
    X10       R712                          1
    X10       R713                          1
    X10       R714                          1
    X10       R715                          1
    X10       R716                          1
    X11       R0                            1
    X11       R12                           1
    X11       R51                           1
    X11       R52                           -1
    X11       R321                          -1
    X11       R322                          -1
    X11       R323                          -1
    X11       R324                          -1
    X11       R325                          -1
    X11       R326                          -1
    X11       R327                          -1
    X11       R328                          -1
    X11       R329                          -1
    X11       R330                          -1
    X11       R331                          -1
    X11       R332                          -1
    X11       R333                          -1
    X11       R334                          -1
    X11       R335                          -1
    X11       R336                          -1
    X11       R337                          -1
    X11       R338                          -1
    X11       R339                          -1
    X11       R340                          -1
    X11       R341                          -1
    X11       R342                          -1
    X11       R717                          1
    X11       R718                          1
    X11       R719                          1
    X11       R720                          1
    X11       R721                          1
    X11       R722                          1
    X11       R723                          1
    X11       R724                          1
    X11       R725                          1
    X11       R726                          1
    X11       R727                          1
    X11       R728                          1
    X11       R729                          1
    X11       R730                          1
    X11       R731                          1
    X11       R732                          1
    X11       R733                          1
    X11       R734                          1
    X11       R735                          1
    X11       R736                          1
    X11       R737                          1
    X11       R738                          1
    X12       R0                            1
    X12       R13                           1
    X12       R52                           1
    X12       R53                           -1
    X12       R343                          -1
    X12       R344                          -1
    X12       R345                          -1
    X12       R346                          -1
    X12       R347                          -1
    X12       R348                          -1
    X12       R349                          -1
    X12       R350                          -1
    X12       R351                          -1
    X12       R352                          -1
    X12       R353                          -1
    X12       R354                          -1
    X12       R355                          -1
    X12       R356                          -1
    X12       R357                          -1
    X12       R358                          -1
    X12       R359                          -1
    X12       R360                          -1
    X12       R361                          -1
    X12       R362                          -1
    X12       R363                          -1
    X12       R364                          -1
    X12       R739                          1
    X12       R740                          1
    X12       R741                          1
    X12       R742                          1
    X12       R743                          1
    X12       R744                          1
    X12       R745                          1
    X12       R746                          1
    X12       R747                          1
    X12       R748                          1
    X12       R749                          1
    X12       R750                          1
    X12       R751                          1
    X12       R752                          1
    X12       R753                          1
    X12       R754                          1
    X12       R755                          1
    X12       R756                          1
    X12       R757                          1
    X12       R758                          1
    X12       R759                          1
    X12       R760                          1
    X13       R0                            1
    X13       R14                           1
    X13       R53                           1
    X13       R54                           -1
    X13       R365                          -1
    X13       R366                          -1
    X13       R367                          -1
    X13       R368                          -1
    X13       R369                          -1
    X13       R370                          -1
    X13       R371                          -1
    X13       R372                          -1
    X13       R373                          -1
    X13       R374                          -1
    X13       R375                          -1
    X13       R376                          -1
    X13       R377                          -1
    X13       R378                          -1
    X13       R379                          -1
    X13       R380                          -1
    X13       R381                          -1
    X13       R382                          -1
    X13       R383                          -1
    X13       R384                          -1
    X13       R385                          -1
    X13       R386                          -1
    X13       R761                          1
    X13       R762                          1
    X13       R763                          1
    X13       R764                          1
    X13       R765                          1
    X13       R766                          1
    X13       R767                          1
    X13       R768                          1
    X13       R769                          1
    X13       R770                          1
    X13       R771                          1
    X13       R772                          1
    X13       R773                          1
    X13       R774                          1
    X13       R775                          1
    X13       R776                          1
    X13       R777                          1
    X13       R778                          1
    X13       R779                          1
    X13       R780                          1
    X13       R781                          1
    X13       R782                          1
    X14       R0                            1
    X14       R15                           1
    X14       R54                           1
    X14       R55                           -1
    X14       R387                          -1
    X14       R388                          -1
    X14       R389                          -1
    X14       R390                          -1
    X14       R391                          -1
    X14       R392                          -1
    X14       R393                          -1
    X14       R394                          -1
    X14       R395                          -1
    X14       R396                          -1
    X14       R397                          -1
    X14       R398                          -1
    X14       R399                          -1
    X14       R400                          -1
    X14       R401                          -1
    X14       R402                          -1
    X14       R403                          -1
    X14       R404                          -1
    X14       R405                          -1
    X14       R406                          -1
    X14       R407                          -1
    X14       R408                          -1
    X14       R783                          1
    X14       R784                          1
    X14       R785                          1
    X14       R786                          1
    X14       R787                          1
    X14       R788                          1
    X14       R789                          1
    X14       R790                          1
    X14       R791                          1
    X14       R792                          1
    X14       R793                          1
    X14       R794                          1
    X14       R795                          1
    X14       R796                          1
    X14       R797                          1
    X14       R798                          1
    X14       R799                          1
    X14       R800                          1
    X14       R801                          1
    X14       R802                          1
    X14       R803                          1
    X14       R804                          1
    X15       R0                            1
    X15       R16                           1
    X15       R55                           1
    X15       R56                           -1
    X15       R409                          -1
    X15       R410                          -1
    X15       R411                          -1
    X15       R412                          -1
    X15       R413                          -1
    X15       R414                          -1
    X15       R415                          -1
    X15       R416                          -1
    X15       R417                          -1
    X15       R418                          -1
    X15       R419                          -1
    X15       R420                          -1
    X15       R421                          -1
    X15       R422                          -1
    X15       R423                          -1
    X15       R424                          -1
    X15       R425                          -1
    X15       R426                          -1
    X15       R427                          -1
    X15       R428                          -1
    X15       R429                          -1
    X15       R430                          -1
    X15       R805                          1
    X15       R806                          1
    X15       R807                          1
    X15       R808                          1
    X15       R809                          1
    X15       R810                          1
    X15       R811                          1
    X15       R812                          1
    X15       R813                          1
    X15       R814                          1
    X15       R815                          1
    X15       R816                          1
    X15       R817                          1
    X15       R818                          1
    X15       R819                          1
    X15       R820                          1
    X15       R821                          1
    X15       R822                          1
    X15       R823                          1
    X15       R824                          1
    X15       R825                          1
    X15       R826                          1
    X16       R0                            1
    X16       R17                           1
    X16       R56                           1
    X16       R57                           -1
    X16       R431                          -1
    X16       R432                          -1
    X16       R433                          -1
    X16       R434                          -1
    X16       R435                          -1
    X16       R436                          -1
    X16       R437                          -1
    X16       R438                          -1
    X16       R439                          -1
    X16       R440                          -1
    X16       R441                          -1
    X16       R442                          -1
    X16       R443                          -1
    X16       R444                          -1
    X16       R445                          -1
    X16       R446                          -1
    X16       R447                          -1
    X16       R448                          -1
    X16       R449                          -1
    X16       R450                          -1
    X16       R451                          -1
    X16       R452                          -1
    X16       R827                          1
    X16       R828                          1
    X16       R829                          1
    X16       R830                          1
    X16       R831                          1
    X16       R832                          1
    X16       R833                          1
    X16       R834                          1
    X16       R835                          1
    X16       R836                          1
    X16       R837                          1
    X16       R838                          1
    X16       R839                          1
    X16       R840                          1
    X16       R841                          1
    X16       R842                          1
    X16       R843                          1
    X16       R844                          1
    X16       R845                          1
    X16       R846                          1
    X16       R847                          1
    X16       R848                          1
    X17       R0                            1
    X17       R18                           1
    X17       R57                           1
    X17       R453                          -1
    X17       R454                          -1
    X17       R455                          -1
    X17       R456                          -1
    X17       R457                          -1
    X17       R458                          -1
    X17       R459                          -1
    X17       R460                          -1
    X17       R461                          -1
    X17       R462                          -1
    X17       R463                          -1
    X17       R464                          -1
    X17       R465                          -1
    X17       R466                          -1
    X17       R467                          -1
    X17       R468                          -1
    X17       R469                          -1
    X17       R470                          -1
    X17       R471                          -1
    X17       R472                          -1
    X17       R473                          -1
    X17       R474                          -1
    X17       R849                          1
    X17       R850                          1
    X17       R851                          1
    X17       R852                          1
    X17       R853                          1
    X17       R854                          1
    X17       R855                          1
    X17       R856                          1
    X17       R857                          1
    X17       R858                          1
    X17       R859                          1
    X17       R860                          1
    X17       R861                          1
    X17       R862                          1
    X17       R863                          1
    X17       R864                          1
    X17       R865                          1
    X17       R866                          1
    X17       R867                          1
    X17       R868                          1
    X17       R869                          1
    X17       R870                          1
    X18       R0                            1
    X18       R19                           1
    X18       R58                           -1
    X18       R79                           1
    X18       R101                          1
    X18       R123                          1
    X18       R145                          1
    X18       R167                          1
    X18       R189                          1
    X18       R211                          1
    X18       R233                          1
    X18       R255                          1
    X18       R277                          1
    X18       R299                          1
    X18       R321                          1
    X18       R343                          1
    X18       R365                          1
    X18       R387                          1
    X18       R409                          1
    X18       R431                          1
    X18       R453                          1
    X18       R475                          -1
    X18       R497                          -1
    X18       R519                          -1
    X18       R541                          -1
    X18       R563                          -1
    X18       R585                          -1
    X18       R607                          -1
    X18       R629                          -1
    X18       R651                          -1
    X18       R673                          -1
    X18       R695                          -1
    X18       R717                          -1
    X18       R739                          -1
    X18       R761                          -1
    X18       R783                          -1
    X18       R805                          -1
    X18       R827                          -1
    X18       R849                          -1
    X19       R0                            1
    X19       R20                           1
    X19       R58                           1
    X19       R59                           -1
    X19       R80                           1
    X19       R102                          1
    X19       R124                          1
    X19       R146                          1
    X19       R168                          1
    X19       R190                          1
    X19       R212                          1
    X19       R234                          1
    X19       R256                          1
    X19       R278                          1
    X19       R300                          1
    X19       R322                          1
    X19       R344                          1
    X19       R366                          1
    X19       R388                          1
    X19       R410                          1
    X19       R432                          1
    X19       R454                          1
    X19       R476                          -1
    X19       R498                          -1
    X19       R520                          -1
    X19       R542                          -1
    X19       R564                          -1
    X19       R586                          -1
    X19       R608                          -1
    X19       R630                          -1
    X19       R652                          -1
    X19       R674                          -1
    X19       R696                          -1
    X19       R718                          -1
    X19       R740                          -1
    X19       R762                          -1
    X19       R784                          -1
    X19       R806                          -1
    X19       R828                          -1
    X19       R850                          -1
    X20       R0                            1
    X20       R21                           1
    X20       R59                           1
    X20       R60                           -1
    X20       R81                           1
    X20       R103                          1
    X20       R125                          1
    X20       R147                          1
    X20       R169                          1
    X20       R191                          1
    X20       R213                          1
    X20       R235                          1
    X20       R257                          1
    X20       R279                          1
    X20       R301                          1
    X20       R323                          1
    X20       R345                          1
    X20       R367                          1
    X20       R389                          1
    X20       R411                          1
    X20       R433                          1
    X20       R455                          1
    X20       R477                          -1
    X20       R499                          -1
    X20       R521                          -1
    X20       R543                          -1
    X20       R565                          -1
    X20       R587                          -1
    X20       R609                          -1
    X20       R631                          -1
    X20       R653                          -1
    X20       R675                          -1
    X20       R697                          -1
    X20       R719                          -1
    X20       R741                          -1
    X20       R763                          -1
    X20       R785                          -1
    X20       R807                          -1
    X20       R829                          -1
    X20       R851                          -1
    X21       R0                            1
    X21       R22                           1
    X21       R60                           1
    X21       R61                           -1
    X21       R82                           1
    X21       R104                          1
    X21       R126                          1
    X21       R148                          1
    X21       R170                          1
    X21       R192                          1
    X21       R214                          1
    X21       R236                          1
    X21       R258                          1
    X21       R280                          1
    X21       R302                          1
    X21       R324                          1
    X21       R346                          1
    X21       R368                          1
    X21       R390                          1
    X21       R412                          1
    X21       R434                          1
    X21       R456                          1
    X21       R478                          -1
    X21       R500                          -1
    X21       R522                          -1
    X21       R544                          -1
    X21       R566                          -1
    X21       R588                          -1
    X21       R610                          -1
    X21       R632                          -1
    X21       R654                          -1
    X21       R676                          -1
    X21       R698                          -1
    X21       R720                          -1
    X21       R742                          -1
    X21       R764                          -1
    X21       R786                          -1
    X21       R808                          -1
    X21       R830                          -1
    X21       R852                          -1
    X22       R0                            1
    X22       R23                           1
    X22       R61                           1
    X22       R62                           -1
    X22       R83                           1
    X22       R105                          1
    X22       R127                          1
    X22       R149                          1
    X22       R171                          1
    X22       R193                          1
    X22       R215                          1
    X22       R237                          1
    X22       R259                          1
    X22       R281                          1
    X22       R303                          1
    X22       R325                          1
    X22       R347                          1
    X22       R369                          1
    X22       R391                          1
    X22       R413                          1
    X22       R435                          1
    X22       R457                          1
    X22       R479                          -1
    X22       R501                          -1
    X22       R523                          -1
    X22       R545                          -1
    X22       R567                          -1
    X22       R589                          -1
    X22       R611                          -1
    X22       R633                          -1
    X22       R655                          -1
    X22       R677                          -1
    X22       R699                          -1
    X22       R721                          -1
    X22       R743                          -1
    X22       R765                          -1
    X22       R787                          -1
    X22       R809                          -1
    X22       R831                          -1
    X22       R853                          -1
    X23       R0                            1
    X23       R24                           1
    X23       R62                           1
    X23       R63                           -1
    X23       R84                           1
    X23       R106                          1
    X23       R128                          1
    X23       R150                          1
    X23       R172                          1
    X23       R194                          1
    X23       R216                          1
    X23       R238                          1
    X23       R260                          1
    X23       R282                          1
    X23       R304                          1
    X23       R326                          1
    X23       R348                          1
    X23       R370                          1
    X23       R392                          1
    X23       R414                          1
    X23       R436                          1
    X23       R458                          1
    X23       R480                          -1
    X23       R502                          -1
    X23       R524                          -1
    X23       R546                          -1
    X23       R568                          -1
    X23       R590                          -1
    X23       R612                          -1
    X23       R634                          -1
    X23       R656                          -1
    X23       R678                          -1
    X23       R700                          -1
    X23       R722                          -1
    X23       R744                          -1
    X23       R766                          -1
    X23       R788                          -1
    X23       R810                          -1
    X23       R832                          -1
    X23       R854                          -1
    X24       R0                            1
    X24       R25                           1
    X24       R63                           1
    X24       R64                           -1
    X24       R85                           1
    X24       R107                          1
    X24       R129                          1
    X24       R151                          1
    X24       R173                          1
    X24       R195                          1
    X24       R217                          1
    X24       R239                          1
    X24       R261                          1
    X24       R283                          1
    X24       R305                          1
    X24       R327                          1
    X24       R349                          1
    X24       R371                          1
    X24       R393                          1
    X24       R415                          1
    X24       R437                          1
    X24       R459                          1
    X24       R481                          -1
    X24       R503                          -1
    X24       R525                          -1
    X24       R547                          -1
    X24       R569                          -1
    X24       R591                          -1
    X24       R613                          -1
    X24       R635                          -1
    X24       R657                          -1
    X24       R679                          -1
    X24       R701                          -1
    X24       R723                          -1
    X24       R745                          -1
    X24       R767                          -1
    X24       R789                          -1
    X24       R811                          -1
    X24       R833                          -1
    X24       R855                          -1
    X25       R0                            1
    X25       R26                           1
    X25       R64                           1
    X25       R65                           -1
    X25       R86                           1
    X25       R108                          1
    X25       R130                          1
    X25       R152                          1
    X25       R174                          1
    X25       R196                          1
    X25       R218                          1
    X25       R240                          1
    X25       R262                          1
    X25       R284                          1
    X25       R306                          1
    X25       R328                          1
    X25       R350                          1
    X25       R372                          1
    X25       R394                          1
    X25       R416                          1
    X25       R438                          1
    X25       R460                          1
    X25       R482                          -1
    X25       R504                          -1
    X25       R526                          -1
    X25       R548                          -1
    X25       R570                          -1
    X25       R592                          -1
    X25       R614                          -1
    X25       R636                          -1
    X25       R658                          -1
    X25       R680                          -1
    X25       R702                          -1
    X25       R724                          -1
    X25       R746                          -1
    X25       R768                          -1
    X25       R790                          -1
    X25       R812                          -1
    X25       R834                          -1
    X25       R856                          -1
    X26       R0                            1
    X26       R27                           1
    X26       R65                           1
    X26       R66                           -1
    X26       R87                           1
    X26       R109                          1
    X26       R131                          1
    X26       R153                          1
    X26       R175                          1
    X26       R197                          1
    X26       R219                          1
    X26       R241                          1
    X26       R263                          1
    X26       R285                          1
    X26       R307                          1
    X26       R329                          1
    X26       R351                          1
    X26       R373                          1
    X26       R395                          1
    X26       R417                          1
    X26       R439                          1
    X26       R461                          1
    X26       R483                          -1
    X26       R505                          -1
    X26       R527                          -1
    X26       R549                          -1
    X26       R571                          -1
    X26       R593                          -1
    X26       R615                          -1
    X26       R637                          -1
    X26       R659                          -1
    X26       R681                          -1
    X26       R703                          -1
    X26       R725                          -1
    X26       R747                          -1
    X26       R769                          -1
    X26       R791                          -1
    X26       R813                          -1
    X26       R835                          -1
    X26       R857                          -1
    X27       R0                            1
    X27       R28                           1
    X27       R66                           1
    X27       R67                           -1
    X27       R88                           1
    X27       R110                          1
    X27       R132                          1
    X27       R154                          1
    X27       R176                          1
    X27       R198                          1
    X27       R220                          1
    X27       R242                          1
    X27       R264                          1
    X27       R286                          1
    X27       R308                          1
    X27       R330                          1
    X27       R352                          1
    X27       R374                          1
    X27       R396                          1
    X27       R418                          1
    X27       R440                          1
    X27       R462                          1
    X27       R484                          -1
    X27       R506                          -1
    X27       R528                          -1
    X27       R550                          -1
    X27       R572                          -1
    X27       R594                          -1
    X27       R616                          -1
    X27       R638                          -1
    X27       R660                          -1
    X27       R682                          -1
    X27       R704                          -1
    X27       R726                          -1
    X27       R748                          -1
    X27       R770                          -1
    X27       R792                          -1
    X27       R814                          -1
    X27       R836                          -1
    X27       R858                          -1
    X28       R0                            1
    X28       R29                           1
    X28       R67                           1
    X28       R68                           -1
    X28       R89                           1
    X28       R111                          1
    X28       R133                          1
    X28       R155                          1
    X28       R177                          1
    X28       R199                          1
    X28       R221                          1
    X28       R243                          1
    X28       R265                          1
    X28       R287                          1
    X28       R309                          1
    X28       R331                          1
    X28       R353                          1
    X28       R375                          1
    X28       R397                          1
    X28       R419                          1
    X28       R441                          1
    X28       R463                          1
    X28       R485                          -1
    X28       R507                          -1
    X28       R529                          -1
    X28       R551                          -1
    X28       R573                          -1
    X28       R595                          -1
    X28       R617                          -1
    X28       R639                          -1
    X28       R661                          -1
    X28       R683                          -1
    X28       R705                          -1
    X28       R727                          -1
    X28       R749                          -1
    X28       R771                          -1
    X28       R793                          -1
    X28       R815                          -1
    X28       R837                          -1
    X28       R859                          -1
    X29       R0                            1
    X29       R30                           1
    X29       R68                           1
    X29       R69                           -1
    X29       R90                           1
    X29       R112                          1
    X29       R134                          1
    X29       R156                          1
    X29       R178                          1
    X29       R200                          1
    X29       R222                          1
    X29       R244                          1
    X29       R266                          1
    X29       R288                          1
    X29       R310                          1
    X29       R332                          1
    X29       R354                          1
    X29       R376                          1
    X29       R398                          1
    X29       R420                          1
    X29       R442                          1
    X29       R464                          1
    X29       R486                          -1
    X29       R508                          -1
    X29       R530                          -1
    X29       R552                          -1
    X29       R574                          -1
    X29       R596                          -1
    X29       R618                          -1
    X29       R640                          -1
    X29       R662                          -1
    X29       R684                          -1
    X29       R706                          -1
    X29       R728                          -1
    X29       R750                          -1
    X29       R772                          -1
    X29       R794                          -1
    X29       R816                          -1
    X29       R838                          -1
    X29       R860                          -1
    X30       R0                            1
    X30       R31                           1
    X30       R69                           1
    X30       R70                           -1
    X30       R91                           1
    X30       R113                          1
    X30       R135                          1
    X30       R157                          1
    X30       R179                          1
    X30       R201                          1
    X30       R223                          1
    X30       R245                          1
    X30       R267                          1
    X30       R289                          1
    X30       R311                          1
    X30       R333                          1
    X30       R355                          1
    X30       R377                          1
    X30       R399                          1
    X30       R421                          1
    X30       R443                          1
    X30       R465                          1
    X30       R487                          -1
    X30       R509                          -1
    X30       R531                          -1
    X30       R553                          -1
    X30       R575                          -1
    X30       R597                          -1
    X30       R619                          -1
    X30       R641                          -1
    X30       R663                          -1
    X30       R685                          -1
    X30       R707                          -1
    X30       R729                          -1
    X30       R751                          -1
    X30       R773                          -1
    X30       R795                          -1
    X30       R817                          -1
    X30       R839                          -1
    X30       R861                          -1
    X31       R0                            1
    X31       R32                           1
    X31       R70                           1
    X31       R71                           -1
    X31       R92                           1
    X31       R114                          1
    X31       R136                          1
    X31       R158                          1
    X31       R180                          1
    X31       R202                          1
    X31       R224                          1
    X31       R246                          1
    X31       R268                          1
    X31       R290                          1
    X31       R312                          1
    X31       R334                          1
    X31       R356                          1
    X31       R378                          1
    X31       R400                          1
    X31       R422                          1
    X31       R444                          1
    X31       R466                          1
    X31       R488                          -1
    X31       R510                          -1
    X31       R532                          -1
    X31       R554                          -1
    X31       R576                          -1
    X31       R598                          -1
    X31       R620                          -1
    X31       R642                          -1
    X31       R664                          -1
    X31       R686                          -1
    X31       R708                          -1
    X31       R730                          -1
    X31       R752                          -1
    X31       R774                          -1
    X31       R796                          -1
    X31       R818                          -1
    X31       R840                          -1
    X31       R862                          -1
    X32       R0                            1
    X32       R33                           1
    X32       R71                           1
    X32       R72                           -1
    X32       R93                           1
    X32       R115                          1
    X32       R137                          1
    X32       R159                          1
    X32       R181                          1
    X32       R203                          1
    X32       R225                          1
    X32       R247                          1
    X32       R269                          1
    X32       R291                          1
    X32       R313                          1
    X32       R335                          1
    X32       R357                          1
    X32       R379                          1
    X32       R401                          1
    X32       R423                          1
    X32       R445                          1
    X32       R467                          1
    X32       R489                          -1
    X32       R511                          -1
    X32       R533                          -1
    X32       R555                          -1
    X32       R577                          -1
    X32       R599                          -1
    X32       R621                          -1
    X32       R643                          -1
    X32       R665                          -1
    X32       R687                          -1
    X32       R709                          -1
    X32       R731                          -1
    X32       R753                          -1
    X32       R775                          -1
    X32       R797                          -1
    X32       R819                          -1
    X32       R841                          -1
    X32       R863                          -1
    X33       R0                            1
    X33       R34                           1
    X33       R72                           1
    X33       R73                           -1
    X33       R94                           1
    X33       R116                          1
    X33       R138                          1
    X33       R160                          1
    X33       R182                          1
    X33       R204                          1
    X33       R226                          1
    X33       R248                          1
    X33       R270                          1
    X33       R292                          1
    X33       R314                          1
    X33       R336                          1
    X33       R358                          1
    X33       R380                          1
    X33       R402                          1
    X33       R424                          1
    X33       R446                          1
    X33       R468                          1
    X33       R490                          -1
    X33       R512                          -1
    X33       R534                          -1
    X33       R556                          -1
    X33       R578                          -1
    X33       R600                          -1
    X33       R622                          -1
    X33       R644                          -1
    X33       R666                          -1
    X33       R688                          -1
    X33       R710                          -1
    X33       R732                          -1
    X33       R754                          -1
    X33       R776                          -1
    X33       R798                          -1
    X33       R820                          -1
    X33       R842                          -1
    X33       R864                          -1
    X34       R0                            1
    X34       R35                           1
    X34       R73                           1
    X34       R74                           -1
    X34       R95                           1
    X34       R117                          1
    X34       R139                          1
    X34       R161                          1
    X34       R183                          1
    X34       R205                          1
    X34       R227                          1
    X34       R249                          1
    X34       R271                          1
    X34       R293                          1
    X34       R315                          1
    X34       R337                          1
    X34       R359                          1
    X34       R381                          1
    X34       R403                          1
    X34       R425                          1
    X34       R447                          1
    X34       R469                          1
    X34       R491                          -1
    X34       R513                          -1
    X34       R535                          -1
    X34       R557                          -1
    X34       R579                          -1
    X34       R601                          -1
    X34       R623                          -1
    X34       R645                          -1
    X34       R667                          -1
    X34       R689                          -1
    X34       R711                          -1
    X34       R733                          -1
    X34       R755                          -1
    X34       R777                          -1
    X34       R799                          -1
    X34       R821                          -1
    X34       R843                          -1
    X34       R865                          -1
    X35       R0                            1
    X35       R36                           1
    X35       R74                           1
    X35       R75                           -1
    X35       R96                           1
    X35       R118                          1
    X35       R140                          1
    X35       R162                          1
    X35       R184                          1
    X35       R206                          1
    X35       R228                          1
    X35       R250                          1
    X35       R272                          1
    X35       R294                          1
    X35       R316                          1
    X35       R338                          1
    X35       R360                          1
    X35       R382                          1
    X35       R404                          1
    X35       R426                          1
    X35       R448                          1
    X35       R470                          1
    X35       R492                          -1
    X35       R514                          -1
    X35       R536                          -1
    X35       R558                          -1
    X35       R580                          -1
    X35       R602                          -1
    X35       R624                          -1
    X35       R646                          -1
    X35       R668                          -1
    X35       R690                          -1
    X35       R712                          -1
    X35       R734                          -1
    X35       R756                          -1
    X35       R778                          -1
    X35       R800                          -1
    X35       R822                          -1
    X35       R844                          -1
    X35       R866                          -1
    X36       R0                            1
    X36       R37                           1
    X36       R75                           1
    X36       R76                           -1
    X36       R97                           1
    X36       R119                          1
    X36       R141                          1
    X36       R163                          1
    X36       R185                          1
    X36       R207                          1
    X36       R229                          1
    X36       R251                          1
    X36       R273                          1
    X36       R295                          1
    X36       R317                          1
    X36       R339                          1
    X36       R361                          1
    X36       R383                          1
    X36       R405                          1
    X36       R427                          1
    X36       R449                          1
    X36       R471                          1
    X36       R493                          -1
    X36       R515                          -1
    X36       R537                          -1
    X36       R559                          -1
    X36       R581                          -1
    X36       R603                          -1
    X36       R625                          -1
    X36       R647                          -1
    X36       R669                          -1
    X36       R691                          -1
    X36       R713                          -1
    X36       R735                          -1
    X36       R757                          -1
    X36       R779                          -1
    X36       R801                          -1
    X36       R823                          -1
    X36       R845                          -1
    X36       R867                          -1
    X37       R0                            1
    X37       R38                           1
    X37       R76                           1
    X37       R77                           -1
    X37       R98                           1
    X37       R120                          1
    X37       R142                          1
    X37       R164                          1
    X37       R186                          1
    X37       R208                          1
    X37       R230                          1
    X37       R252                          1
    X37       R274                          1
    X37       R296                          1
    X37       R318                          1
    X37       R340                          1
    X37       R362                          1
    X37       R384                          1
    X37       R406                          1
    X37       R428                          1
    X37       R450                          1
    X37       R472                          1
    X37       R494                          -1
    X37       R516                          -1
    X37       R538                          -1
    X37       R560                          -1
    X37       R582                          -1
    X37       R604                          -1
    X37       R626                          -1
    X37       R648                          -1
    X37       R670                          -1
    X37       R692                          -1
    X37       R714                          -1
    X37       R736                          -1
    X37       R758                          -1
    X37       R780                          -1
    X37       R802                          -1
    X37       R824                          -1
    X37       R846                          -1
    X37       R868                          -1
    X38       R0                            1
    X38       R39                           1
    X38       R77                           1
    X38       R78                           -1
    X38       R99                           1
    X38       R121                          1
    X38       R143                          1
    X38       R165                          1
    X38       R187                          1
    X38       R209                          1
    X38       R231                          1
    X38       R253                          1
    X38       R275                          1
    X38       R297                          1
    X38       R319                          1
    X38       R341                          1
    X38       R363                          1
    X38       R385                          1
    X38       R407                          1
    X38       R429                          1
    X38       R451                          1
    X38       R473                          1
    X38       R495                          -1
    X38       R517                          -1
    X38       R539                          -1
    X38       R561                          -1
    X38       R583                          -1
    X38       R605                          -1
    X38       R627                          -1
    X38       R649                          -1
    X38       R671                          -1
    X38       R693                          -1
    X38       R715                          -1
    X38       R737                          -1
    X38       R759                          -1
    X38       R781                          -1
    X38       R803                          -1
    X38       R825                          -1
    X38       R847                          -1
    X38       R869                          -1
    X39       R0                            1
    X39       R40                           1
    X39       R78                           1
    X39       R100                          1
    X39       R122                          1
    X39       R144                          1
    X39       R166                          1
    X39       R188                          1
    X39       R210                          1
    X39       R232                          1
    X39       R254                          1
    X39       R276                          1
    X39       R298                          1
    X39       R320                          1
    X39       R342                          1
    X39       R364                          1
    X39       R386                          1
    X39       R408                          1
    X39       R430                          1
    X39       R452                          1
    X39       R474                          1
    X39       R496                          -1
    X39       R518                          -1
    X39       R540                          -1
    X39       R562                          -1
    X39       R584                          -1
    X39       R606                          -1
    X39       R628                          -1
    X39       R650                          -1
    X39       R672                          -1
    X39       R694                          -1
    X39       R716                          -1
    X39       R738                          -1
    X39       R760                          -1
    X39       R782                          -1
    X39       R804                          -1
    X39       R826                          -1
    X39       R848                          -1
    X39       R870                          -1
    X40       R79                           -10000
    X40       R475                          10000
    X41       R80                           -10000
    X41       R476                          10000
    X42       R81                           -10000
    X42       R477                          10000
    X43       R82                           -10000
    X43       R478                          10000
    X44       R83                           -10000
    X44       R479                          10000
    X45       R84                           -10000
    X45       R480                          10000
    X46       R85                           -10000
    X46       R481                          10000
    X47       R86                           -10000
    X47       R482                          10000
    X48       R87                           -10000
    X48       R483                          10000
    X49       R88                           -10000
    X49       R484                          10000
    X50       R89                           -10000
    X50       R485                          10000
    X51       R90                           -10000
    X51       R486                          10000
    X52       R91                           -10000
    X52       R487                          10000
    X53       R92                           -10000
    X53       R488                          10000
    X54       R93                           -10000
    X54       R489                          10000
    X55       R94                           -10000
    X55       R490                          10000
    X56       R95                           -10000
    X56       R491                          10000
    X57       R96                           -10000
    X57       R492                          10000
    X58       R97                           -10000
    X58       R493                          10000
    X59       R98                           -10000
    X59       R494                          10000
    X60       R99                           -10000
    X60       R495                          10000
    X61       R100                          -10000
    X61       R496                          10000
    X62       R101                          -10000
    X62       R497                          10000
    X63       R102                          -10000
    X63       R498                          10000
    X64       R103                          -10000
    X64       R499                          10000
    X65       R104                          -10000
    X65       R500                          10000
    X66       R105                          -10000
    X66       R501                          10000
    X67       R106                          -10000
    X67       R502                          10000
    X68       R107                          -10000
    X68       R503                          10000
    X69       R108                          -10000
    X69       R504                          10000
    X70       R109                          -10000
    X70       R505                          10000
    X71       R110                          -10000
    X71       R506                          10000
    X72       R111                          -10000
    X72       R507                          10000
    X73       R112                          -10000
    X73       R508                          10000
    X74       R113                          -10000
    X74       R509                          10000
    X75       R114                          -10000
    X75       R510                          10000
    X76       R115                          -10000
    X76       R511                          10000
    X77       R116                          -10000
    X77       R512                          10000
    X78       R117                          -10000
    X78       R513                          10000
    X79       R118                          -10000
    X79       R514                          10000
    X80       R119                          -10000
    X80       R515                          10000
    X81       R120                          -10000
    X81       R516                          10000
    X82       R121                          -10000
    X82       R517                          10000
    X83       R122                          -10000
    X83       R518                          10000
    X84       R123                          -10000
    X84       R519                          10000
    X85       R124                          -10000
    X85       R520                          10000
    X86       R125                          -10000
    X86       R521                          10000
    X87       R126                          -10000
    X87       R522                          10000
    X88       R127                          -10000
    X88       R523                          10000
    X89       R128                          -10000
    X89       R524                          10000
    X90       R129                          -10000
    X90       R525                          10000
    X91       R130                          -10000
    X91       R526                          10000
    X92       R131                          -10000
    X92       R527                          10000
    X93       R132                          -10000
    X93       R528                          10000
    X94       R133                          -10000
    X94       R529                          10000
    X95       R134                          -10000
    X95       R530                          10000
    X96       R135                          -10000
    X96       R531                          10000
    X97       R136                          -10000
    X97       R532                          10000
    X98       R137                          -10000
    X98       R533                          10000
    X99       R138                          -10000
    X99       R534                          10000
    X100      R139                          -10000
    X100      R535                          10000
    X101      R140                          -10000
    X101      R536                          10000
    X102      R141                          -10000
    X102      R537                          10000
    X103      R142                          -10000
    X103      R538                          10000
    X104      R143                          -10000
    X104      R539                          10000
    X105      R144                          -10000
    X105      R540                          10000
    X106      R145                          -10000
    X106      R541                          10000
    X107      R146                          -10000
    X107      R542                          10000
    X108      R147                          -10000
    X108      R543                          10000
    X109      R148                          -10000
    X109      R544                          10000
    X110      R149                          -10000
    X110      R545                          10000
    X111      R150                          -10000
    X111      R546                          10000
    X112      R151                          -10000
    X112      R547                          10000
    X113      R152                          -10000
    X113      R548                          10000
    X114      R153                          -10000
    X114      R549                          10000
    X115      R154                          -10000
    X115      R550                          10000
    X116      R155                          -10000
    X116      R551                          10000
    X117      R156                          -10000
    X117      R552                          10000
    X118      R157                          -10000
    X118      R553                          10000
    X119      R158                          -10000
    X119      R554                          10000
    X120      R159                          -10000
    X120      R555                          10000
    X121      R160                          -10000
    X121      R556                          10000
    X122      R161                          -10000
    X122      R557                          10000
    X123      R162                          -10000
    X123      R558                          10000
    X124      R163                          -10000
    X124      R559                          10000
    X125      R164                          -10000
    X125      R560                          10000
    X126      R165                          -10000
    X126      R561                          10000
    X127      R166                          -10000
    X127      R562                          10000
    X128      R167                          -10000
    X128      R563                          10000
    X129      R168                          -10000
    X129      R564                          10000
    X130      R169                          -10000
    X130      R565                          10000
    X131      R170                          -10000
    X131      R566                          10000
    X132      R171                          -10000
    X132      R567                          10000
    X133      R172                          -10000
    X133      R568                          10000
    X134      R173                          -10000
    X134      R569                          10000
    X135      R174                          -10000
    X135      R570                          10000
    X136      R175                          -10000
    X136      R571                          10000
    X137      R176                          -10000
    X137      R572                          10000
    X138      R177                          -10000
    X138      R573                          10000
    X139      R178                          -10000
    X139      R574                          10000
    X140      R179                          -10000
    X140      R575                          10000
    X141      R180                          -10000
    X141      R576                          10000
    X142      R181                          -10000
    X142      R577                          10000
    X143      R182                          -10000
    X143      R578                          10000
    X144      R183                          -10000
    X144      R579                          10000
    X145      R184                          -10000
    X145      R580                          10000
    X146      R185                          -10000
    X146      R581                          10000
    X147      R186                          -10000
    X147      R582                          10000
    X148      R187                          -10000
    X148      R583                          10000
    X149      R188                          -10000
    X149      R584                          10000
    X150      R189                          -10000
    X150      R585                          10000
    X151      R190                          -10000
    X151      R586                          10000
    X152      R191                          -10000
    X152      R587                          10000
    X153      R192                          -10000
    X153      R588                          10000
    X154      R193                          -10000
    X154      R589                          10000
    X155      R194                          -10000
    X155      R590                          10000
    X156      R195                          -10000
    X156      R591                          10000
    X157      R196                          -10000
    X157      R592                          10000
    X158      R197                          -10000
    X158      R593                          10000
    X159      R198                          -10000
    X159      R594                          10000
    X160      R199                          -10000
    X160      R595                          10000
    X161      R200                          -10000
    X161      R596                          10000
    X162      R201                          -10000
    X162      R597                          10000
    X163      R202                          -10000
    X163      R598                          10000
    X164      R203                          -10000
    X164      R599                          10000
    X165      R204                          -10000
    X165      R600                          10000
    X166      R205                          -10000
    X166      R601                          10000
    X167      R206                          -10000
    X167      R602                          10000
    X168      R207                          -10000
    X168      R603                          10000
    X169      R208                          -10000
    X169      R604                          10000
    X170      R209                          -10000
    X170      R605                          10000
    X171      R210                          -10000
    X171      R606                          10000
    X172      R211                          -10000
    X172      R607                          10000
    X173      R212                          -10000
    X173      R608                          10000
    X174      R213                          -10000
    X174      R609                          10000
    X175      R214                          -10000
    X175      R610                          10000
    X176      R215                          -10000
    X176      R611                          10000
    X177      R216                          -10000
    X177      R612                          10000
    X178      R217                          -10000
    X178      R613                          10000
    X179      R218                          -10000
    X179      R614                          10000
    X180      R219                          -10000
    X180      R615                          10000
    X181      R220                          -10000
    X181      R616                          10000
    X182      R221                          -10000
    X182      R617                          10000
    X183      R222                          -10000
    X183      R618                          10000
    X184      R223                          -10000
    X184      R619                          10000
    X185      R224                          -10000
    X185      R620                          10000
    X186      R225                          -10000
    X186      R621                          10000
    X187      R226                          -10000
    X187      R622                          10000
    X188      R227                          -10000
    X188      R623                          10000
    X189      R228                          -10000
    X189      R624                          10000
    X190      R229                          -10000
    X190      R625                          10000
    X191      R230                          -10000
    X191      R626                          10000
    X192      R231                          -10000
    X192      R627                          10000
    X193      R232                          -10000
    X193      R628                          10000
    X194      R233                          -10000
    X194      R629                          10000
    X195      R234                          -10000
    X195      R630                          10000
    X196      R235                          -10000
    X196      R631                          10000
    X197      R236                          -10000
    X197      R632                          10000
    X198      R237                          -10000
    X198      R633                          10000
    X199      R238                          -10000
    X199      R634                          10000
    X200      R239                          -10000
    X200      R635                          10000
    X201      R240                          -10000
    X201      R636                          10000
    X202      R241                          -10000
    X202      R637                          10000
    X203      R242                          -10000
    X203      R638                          10000
    X204      R243                          -10000
    X204      R639                          10000
    X205      R244                          -10000
    X205      R640                          10000
    X206      R245                          -10000
    X206      R641                          10000
    X207      R246                          -10000
    X207      R642                          10000
    X208      R247                          -10000
    X208      R643                          10000
    X209      R248                          -10000
    X209      R644                          10000
    X210      R249                          -10000
    X210      R645                          10000
    X211      R250                          -10000
    X211      R646                          10000
    X212      R251                          -10000
    X212      R647                          10000
    X213      R252                          -10000
    X213      R648                          10000
    X214      R253                          -10000
    X214      R649                          10000
    X215      R254                          -10000
    X215      R650                          10000
    X216      R255                          -10000
    X216      R651                          10000
    X217      R256                          -10000
    X217      R652                          10000
    X218      R257                          -10000
    X218      R653                          10000
    X219      R258                          -10000
    X219      R654                          10000
    X220      R259                          -10000
    X220      R655                          10000
    X221      R260                          -10000
    X221      R656                          10000
    X222      R261                          -10000
    X222      R657                          10000
    X223      R262                          -10000
    X223      R658                          10000
    X224      R263                          -10000
    X224      R659                          10000
    X225      R264                          -10000
    X225      R660                          10000
    X226      R265                          -10000
    X226      R661                          10000
    X227      R266                          -10000
    X227      R662                          10000
    X228      R267                          -10000
    X228      R663                          10000
    X229      R268                          -10000
    X229      R664                          10000
    X230      R269                          -10000
    X230      R665                          10000
    X231      R270                          -10000
    X231      R666                          10000
    X232      R271                          -10000
    X232      R667                          10000
    X233      R272                          -10000
    X233      R668                          10000
    X234      R273                          -10000
    X234      R669                          10000
    X235      R274                          -10000
    X235      R670                          10000
    X236      R275                          -10000
    X236      R671                          10000
    X237      R276                          -10000
    X237      R672                          10000
    X238      R277                          -10000
    X238      R673                          10000
    X239      R278                          -10000
    X239      R674                          10000
    X240      R279                          -10000
    X240      R675                          10000
    X241      R280                          -10000
    X241      R676                          10000
    X242      R281                          -10000
    X242      R677                          10000
    X243      R282                          -10000
    X243      R678                          10000
    X244      R283                          -10000
    X244      R679                          10000
    X245      R284                          -10000
    X245      R680                          10000
    X246      R285                          -10000
    X246      R681                          10000
    X247      R286                          -10000
    X247      R682                          10000
    X248      R287                          -10000
    X248      R683                          10000
    X249      R288                          -10000
    X249      R684                          10000
    X250      R289                          -10000
    X250      R685                          10000
    X251      R290                          -10000
    X251      R686                          10000
    X252      R291                          -10000
    X252      R687                          10000
    X253      R292                          -10000
    X253      R688                          10000
    X254      R293                          -10000
    X254      R689                          10000
    X255      R294                          -10000
    X255      R690                          10000
    X256      R295                          -10000
    X256      R691                          10000
    X257      R296                          -10000
    X257      R692                          10000
    X258      R297                          -10000
    X258      R693                          10000
    X259      R298                          -10000
    X259      R694                          10000
    X260      R299                          -10000
    X260      R695                          10000
    X261      R300                          -10000
    X261      R696                          10000
    X262      R301                          -10000
    X262      R697                          10000
    X263      R302                          -10000
    X263      R698                          10000
    X264      R303                          -10000
    X264      R699                          10000
    X265      R304                          -10000
    X265      R700                          10000
    X266      R305                          -10000
    X266      R701                          10000
    X267      R306                          -10000
    X267      R702                          10000
    X268      R307                          -10000
    X268      R703                          10000
    X269      R308                          -10000
    X269      R704                          10000
    X270      R309                          -10000
    X270      R705                          10000
    X271      R310                          -10000
    X271      R706                          10000
    X272      R311                          -10000
    X272      R707                          10000
    X273      R312                          -10000
    X273      R708                          10000
    X274      R313                          -10000
    X274      R709                          10000
    X275      R314                          -10000
    X275      R710                          10000
    X276      R315                          -10000
    X276      R711                          10000
    X277      R316                          -10000
    X277      R712                          10000
    X278      R317                          -10000
    X278      R713                          10000
    X279      R318                          -10000
    X279      R714                          10000
    X280      R319                          -10000
    X280      R715                          10000
    X281      R320                          -10000
    X281      R716                          10000
    X282      R321                          -10000
    X282      R717                          10000
    X283      R322                          -10000
    X283      R718                          10000
    X284      R323                          -10000
    X284      R719                          10000
    X285      R324                          -10000
    X285      R720                          10000
    X286      R325                          -10000
    X286      R721                          10000
    X287      R326                          -10000
    X287      R722                          10000
    X288      R327                          -10000
    X288      R723                          10000
    X289      R328                          -10000
    X289      R724                          10000
    X290      R329                          -10000
    X290      R725                          10000
    X291      R330                          -10000
    X291      R726                          10000
    X292      R331                          -10000
    X292      R727                          10000
    X293      R332                          -10000
    X293      R728                          10000
    X294      R333                          -10000
    X294      R729                          10000
    X295      R334                          -10000
    X295      R730                          10000
    X296      R335                          -10000
    X296      R731                          10000
    X297      R336                          -10000
    X297      R732                          10000
    X298      R337                          -10000
    X298      R733                          10000
    X299      R338                          -10000
    X299      R734                          10000
    X300      R339                          -10000
    X300      R735                          10000
    X301      R340                          -10000
    X301      R736                          10000
    X302      R341                          -10000
    X302      R737                          10000
    X303      R342                          -10000
    X303      R738                          10000
    X304      R343                          -10000
    X304      R739                          10000
    X305      R344                          -10000
    X305      R740                          10000
    X306      R345                          -10000
    X306      R741                          10000
    X307      R346                          -10000
    X307      R742                          10000
    X308      R347                          -10000
    X308      R743                          10000
    X309      R348                          -10000
    X309      R744                          10000
    X310      R349                          -10000
    X310      R745                          10000
    X311      R350                          -10000
    X311      R746                          10000
    X312      R351                          -10000
    X312      R747                          10000
    X313      R352                          -10000
    X313      R748                          10000
    X314      R353                          -10000
    X314      R749                          10000
    X315      R354                          -10000
    X315      R750                          10000
    X316      R355                          -10000
    X316      R751                          10000
    X317      R356                          -10000
    X317      R752                          10000
    X318      R357                          -10000
    X318      R753                          10000
    X319      R358                          -10000
    X319      R754                          10000
    X320      R359                          -10000
    X320      R755                          10000
    X321      R360                          -10000
    X321      R756                          10000
    X322      R361                          -10000
    X322      R757                          10000
    X323      R362                          -10000
    X323      R758                          10000
    X324      R363                          -10000
    X324      R759                          10000
    X325      R364                          -10000
    X325      R760                          10000
    X326      R365                          -10000
    X326      R761                          10000
    X327      R366                          -10000
    X327      R762                          10000
    X328      R367                          -10000
    X328      R763                          10000
    X329      R368                          -10000
    X329      R764                          10000
    X330      R369                          -10000
    X330      R765                          10000
    X331      R370                          -10000
    X331      R766                          10000
    X332      R371                          -10000
    X332      R767                          10000
    X333      R372                          -10000
    X333      R768                          10000
    X334      R373                          -10000
    X334      R769                          10000
    X335      R374                          -10000
    X335      R770                          10000
    X336      R375                          -10000
    X336      R771                          10000
    X337      R376                          -10000
    X337      R772                          10000
    X338      R377                          -10000
    X338      R773                          10000
    X339      R378                          -10000
    X339      R774                          10000
    X340      R379                          -10000
    X340      R775                          10000
    X341      R380                          -10000
    X341      R776                          10000
    X342      R381                          -10000
    X342      R777                          10000
    X343      R382                          -10000
    X343      R778                          10000
    X344      R383                          -10000
    X344      R779                          10000
    X345      R384                          -10000
    X345      R780                          10000
    X346      R385                          -10000
    X346      R781                          10000
    X347      R386                          -10000
    X347      R782                          10000
    X348      R387                          -10000
    X348      R783                          10000
    X349      R388                          -10000
    X349      R784                          10000
    X350      R389                          -10000
    X350      R785                          10000
    X351      R390                          -10000
    X351      R786                          10000
    X352      R391                          -10000
    X352      R787                          10000
    X353      R392                          -10000
    X353      R788                          10000
    X354      R393                          -10000
    X354      R789                          10000
    X355      R394                          -10000
    X355      R790                          10000
    X356      R395                          -10000
    X356      R791                          10000
    X357      R396                          -10000
    X357      R792                          10000
    X358      R397                          -10000
    X358      R793                          10000
    X359      R398                          -10000
    X359      R794                          10000
    X360      R399                          -10000
    X360      R795                          10000
    X361      R400                          -10000
    X361      R796                          10000
    X362      R401                          -10000
    X362      R797                          10000
    X363      R402                          -10000
    X363      R798                          10000
    X364      R403                          -10000
    X364      R799                          10000
    X365      R404                          -10000
    X365      R800                          10000
    X366      R405                          -10000
    X366      R801                          10000
    X367      R406                          -10000
    X367      R802                          10000
    X368      R407                          -10000
    X368      R803                          10000
    X369      R408                          -10000
    X369      R804                          10000
    X370      R409                          -10000
    X370      R805                          10000
    X371      R410                          -10000
    X371      R806                          10000
    X372      R411                          -10000
    X372      R807                          10000
    X373      R412                          -10000
    X373      R808                          10000
    X374      R413                          -10000
    X374      R809                          10000
    X375      R414                          -10000
    X375      R810                          10000
    X376      R415                          -10000
    X376      R811                          10000
    X377      R416                          -10000
    X377      R812                          10000
    X378      R417                          -10000
    X378      R813                          10000
    X379      R418                          -10000
    X379      R814                          10000
    X380      R419                          -10000
    X380      R815                          10000
    X381      R420                          -10000
    X381      R816                          10000
    X382      R421                          -10000
    X382      R817                          10000
    X383      R422                          -10000
    X383      R818                          10000
    X384      R423                          -10000
    X384      R819                          10000
    X385      R424                          -10000
    X385      R820                          10000
    X386      R425                          -10000
    X386      R821                          10000
    X387      R426                          -10000
    X387      R822                          10000
    X388      R427                          -10000
    X388      R823                          10000
    X389      R428                          -10000
    X389      R824                          10000
    X390      R429                          -10000
    X390      R825                          10000
    X391      R430                          -10000
    X391      R826                          10000
    X392      R431                          -10000
    X392      R827                          10000
    X393      R432                          -10000
    X393      R828                          10000
    X394      R433                          -10000
    X394      R829                          10000
    X395      R434                          -10000
    X395      R830                          10000
    X396      R435                          -10000
    X396      R831                          10000
    X397      R436                          -10000
    X397      R832                          10000
    X398      R437                          -10000
    X398      R833                          10000
    X399      R438                          -10000
    X399      R834                          10000
    X400      R439                          -10000
    X400      R835                          10000
    X401      R440                          -10000
    X401      R836                          10000
    X402      R441                          -10000
    X402      R837                          10000
    X403      R442                          -10000
    X403      R838                          10000
    X404      R443                          -10000
    X404      R839                          10000
    X405      R444                          -10000
    X405      R840                          10000
    X406      R445                          -10000
    X406      R841                          10000
    X407      R446                          -10000
    X407      R842                          10000
    X408      R447                          -10000
    X408      R843                          10000
    X409      R448                          -10000
    X409      R844                          10000
    X410      R449                          -10000
    X410      R845                          10000
    X411      R450                          -10000
    X411      R846                          10000
    X412      R451                          -10000
    X412      R847                          10000
    X413      R452                          -10000
    X413      R848                          10000
    X414      R453                          -10000
    X414      R849                          10000
    X415      R454                          -10000
    X415      R850                          10000
    X416      R455                          -10000
    X416      R851                          10000
    X417      R456                          -10000
    X417      R852                          10000
    X418      R457                          -10000
    X418      R853                          10000
    X419      R458                          -10000
    X419      R854                          10000
    X420      R459                          -10000
    X420      R855                          10000
    X421      R460                          -10000
    X421      R856                          10000
    X422      R461                          -10000
    X422      R857                          10000
    X423      R462                          -10000
    X423      R858                          10000
    X424      R463                          -10000
    X424      R859                          10000
    X425      R464                          -10000
    X425      R860                          10000
    X426      R465                          -10000
    X426      R861                          10000
    X427      R466                          -10000
    X427      R862                          10000
    X428      R467                          -10000
    X428      R863                          10000
    X429      R468                          -10000
    X429      R864                          10000
    X430      R469                          -10000
    X430      R865                          10000
    X431      R470                          -10000
    X431      R866                          10000
    X432      R471                          -10000
    X432      R867                          10000
    X433      R472                          -10000
    X433      R868                          10000
    X434      R473                          -10000
    X434      R869                          10000
    X435      R474                          -10000
    X435      R870                          10000
RHS
    RHS       R1                            4.4671401964674438e+00
    RHS       R2                            6.2128613386623890e+00
    RHS       R3                            7.9585755803420390e+00
    RHS       R4                            9.7042736497011504e+00
    RHS       R5                            1.1443118396869350e+01
    RHS       R6                            1.8070142649144010e+01
    RHS       R7                            2.1632285210455851e+01
    RHS       R8                            2.3429543901538949e+01
    RHS       R9                            3.0191503842725691e+01
    RHS       R10                           4.1000994560430073e+01
    RHS       R11                           4.3354118127685602e+01
    RHS       R12                           4.6964983926437462e+01
    RHS       R13                           5.0151058515918798e+01
    RHS       R14                           5.2519488213678969e+01
    RHS       R15                           5.5216457674844648e+01
    RHS       R16                           5.8003095311575997e+01
    RHS       R17                           6.0658786838152878e+01
    RHS       R18                           6.2488578094467478e+01
    RHS       R19                           5.3576976356001116e-01
    RHS       R20                           2.3206129814243468e+00
    RHS       R21                           4.1041481174214987e+00
    RHS       R22                           5.8961286087221971e+00
    RHS       R23                           1.0657675496785110e+01
    RHS       R24                           1.2449151189249701e+01
    RHS       R25                           1.4240626881714309e+01
    RHS       R26                           1.6032102574178960e+01
    RHS       R27                           1.8108808713448489e+01
    RHS       R28                           2.4023891394023639e+01
    RHS       R29                           3.2374917559452641e+01
    RHS       R30                           3.5269401037454443e+01
    RHS       R31                           3.7066786493253367e+01
    RHS       R32                           3.9522133144453669e+01
    RHS       R33                           4.2758990006681181e+01
    RHS       R34                           4.5750848180563871e+01
    RHS       R35                           4.8869081054279107e+01
    RHS       R36                           5.1608375221115182e+01
    RHS       R37                           5.5086376722907232e+01
    RHS       R38                           5.6905364415697157e+01
    RHS       R39                           6.1330612307121577e+01
    RHS       R40                           6.3242782354275732e+01
    RHS       R41                           2
    RHS       R42                           2
    RHS       R43                           2
    RHS       R44                           2
    RHS       R45                           2
    RHS       R46                           2
    RHS       R47                           2
    RHS       R48                           2
    RHS       R49                           2
    RHS       R50                           2
    RHS       R51                           2
    RHS       R52                           2
    RHS       R53                           2
    RHS       R54                           2
    RHS       R55                           2
    RHS       R56                           2
    RHS       R57                           2
    RHS       R58                           2
    RHS       R59                           2
    RHS       R60                           2
    RHS       R61                           2
    RHS       R62                           2
    RHS       R63                           2
    RHS       R64                           2
    RHS       R65                           2
    RHS       R66                           2
    RHS       R67                           2
    RHS       R68                           2
    RHS       R69                           2
    RHS       R70                           2
    RHS       R71                           2
    RHS       R72                           2
    RHS       R73                           2
    RHS       R74                           2
    RHS       R75                           2
    RHS       R76                           2
    RHS       R77                           2
    RHS       R78                           2
    RHS       R79                           -9.9958768943743817e+03
    RHS       R80                           -9.9958768943743817e+03
    RHS       R81                           -9.9958768943743817e+03
    RHS       R82                           -9.9958768943743817e+03
    RHS       R83                           -9.9958768943743817e+03
    RHS       R84                           -9.9958768943743817e+03
    RHS       R85                           -9.9958768943743817e+03
    RHS       R86                           -9.9958768943743817e+03
    RHS       R87                           -9.9958768943743817e+03
    RHS       R88                           -9.9958768943743817e+03
    RHS       R89                           -9.9958768943743817e+03
    RHS       R90                           -9.9958768943743817e+03
    RHS       R91                           -9.9958768943743817e+03
    RHS       R92                           -9.9958768943743817e+03
    RHS       R93                           -9.9958768943743817e+03
    RHS       R94                           -9.9958768943743817e+03
    RHS       R95                           -9.9958768943743817e+03
    RHS       R96                           -9.9958768943743817e+03
    RHS       R97                           -9.9958768943743817e+03
    RHS       R98                           -9.9958768943743817e+03
    RHS       R99                           -9.9958768943743817e+03
    RHS       R100                          -9.9958768943743817e+03
    RHS       R101                          -9.9958768943743817e+03
    RHS       R102                          -9.9958768943743817e+03
    RHS       R103                          -9.9958768943743817e+03
    RHS       R104                          -9.9958768943743817e+03
    RHS       R105                          -9.9958768943743817e+03
    RHS       R106                          -9.9958768943743817e+03
    RHS       R107                          -9.9958768943743817e+03
    RHS       R108                          -9.9958768943743817e+03
    RHS       R109                          -9.9958768943743817e+03
    RHS       R110                          -9.9958768943743817e+03
    RHS       R111                          -9.9958768943743817e+03
    RHS       R112                          -9.9958768943743817e+03
    RHS       R113                          -9.9958768943743817e+03
    RHS       R114                          -9.9958768943743817e+03
    RHS       R115                          -9.9958768943743817e+03
    RHS       R116                          -9.9958768943743817e+03
    RHS       R117                          -9.9958768943743817e+03
    RHS       R118                          -9.9958768943743817e+03
    RHS       R119                          -9.9958768943743817e+03
    RHS       R120                          -9.9958768943743817e+03
    RHS       R121                          -9.9958768943743817e+03
    RHS       R122                          -9.9958768943743817e+03
    RHS       R123                          -9.9958768943743817e+03
    RHS       R124                          -9.9958768943743817e+03
    RHS       R125                          -9.9958768943743817e+03
    RHS       R126                          -9.9958768943743817e+03
    RHS       R127                          -9.9958768943743817e+03
    RHS       R128                          -9.9958768943743817e+03
    RHS       R129                          -9.9958768943743817e+03
    RHS       R130                          -9.9958768943743817e+03
    RHS       R131                          -9.9958768943743817e+03
    RHS       R132                          -9.9958768943743817e+03
    RHS       R133                          -9.9958768943743817e+03
    RHS       R134                          -9.9958768943743817e+03
    RHS       R135                          -9.9958768943743817e+03
    RHS       R136                          -9.9958768943743817e+03
    RHS       R137                          -9.9958768943743817e+03
    RHS       R138                          -9.9958768943743817e+03
    RHS       R139                          -9.9958768943743817e+03
    RHS       R140                          -9.9958768943743817e+03
    RHS       R141                          -9.9958768943743817e+03
    RHS       R142                          -9.9958768943743817e+03
    RHS       R143                          -9.9958768943743817e+03
    RHS       R144                          -9.9958768943743817e+03
    RHS       R145                          -9.9958768943743817e+03
    RHS       R146                          -9.9958768943743817e+03
    RHS       R147                          -9.9958768943743817e+03
    RHS       R148                          -9.9958768943743817e+03
    RHS       R149                          -9.9958768943743817e+03
    RHS       R150                          -9.9958768943743817e+03
    RHS       R151                          -9.9958768943743817e+03
    RHS       R152                          -9.9958768943743817e+03
    RHS       R153                          -9.9958768943743817e+03
    RHS       R154                          -9.9958768943743817e+03
    RHS       R155                          -9.9958768943743817e+03
    RHS       R156                          -9.9958768943743817e+03
    RHS       R157                          -9.9958768943743817e+03
    RHS       R158                          -9.9958768943743817e+03
    RHS       R159                          -9.9958768943743817e+03
    RHS       R160                          -9.9958768943743817e+03
    RHS       R161                          -9.9958768943743817e+03
    RHS       R162                          -9.9958768943743817e+03
    RHS       R163                          -9.9958768943743817e+03
    RHS       R164                          -9.9958768943743817e+03
    RHS       R165                          -9.9958768943743817e+03
    RHS       R166                          -9.9958768943743817e+03
    RHS       R167                          -9.9958768943743817e+03
    RHS       R168                          -9.9958768943743817e+03
    RHS       R169                          -9.9958768943743817e+03
    RHS       R170                          -9.9958768943743817e+03
    RHS       R171                          -9.9958768943743817e+03
    RHS       R172                          -9.9958768943743817e+03
    RHS       R173                          -9.9958768943743817e+03
    RHS       R174                          -9.9958768943743817e+03
    RHS       R175                          -9.9958768943743817e+03
    RHS       R176                          -9.9958768943743817e+03
    RHS       R177                          -9.9958768943743817e+03
    RHS       R178                          -9.9958768943743817e+03
    RHS       R179                          -9.9958768943743817e+03
    RHS       R180                          -9.9958768943743817e+03
    RHS       R181                          -9.9958768943743817e+03
    RHS       R182                          -9.9958768943743817e+03
    RHS       R183                          -9.9958768943743817e+03
    RHS       R184                          -9.9958768943743817e+03
    RHS       R185                          -9.9958768943743817e+03
    RHS       R186                          -9.9958768943743817e+03
    RHS       R187                          -9.9958768943743817e+03
    RHS       R188                          -9.9958768943743817e+03
    RHS       R189                          -9.9958768943743817e+03
    RHS       R190                          -9.9958768943743817e+03
    RHS       R191                          -9.9958768943743817e+03
    RHS       R192                          -9.9958768943743817e+03
    RHS       R193                          -9.9958768943743817e+03
    RHS       R194                          -9.9958768943743817e+03
    RHS       R195                          -9.9958768943743817e+03
    RHS       R196                          -9.9958768943743817e+03
    RHS       R197                          -9.9958768943743817e+03
    RHS       R198                          -9.9958768943743817e+03
    RHS       R199                          -9.9958768943743817e+03
    RHS       R200                          -9.9958768943743817e+03
    RHS       R201                          -9.9958768943743817e+03
    RHS       R202                          -9.9958768943743817e+03
    RHS       R203                          -9.9958768943743817e+03
    RHS       R204                          -9.9958768943743817e+03
    RHS       R205                          -9.9958768943743817e+03
    RHS       R206                          -9.9958768943743817e+03
    RHS       R207                          -9.9958768943743817e+03
    RHS       R208                          -9.9958768943743817e+03
    RHS       R209                          -9.9958768943743817e+03
    RHS       R210                          -9.9958768943743817e+03
    RHS       R211                          -9.9958768943743817e+03
    RHS       R212                          -9.9958768943743817e+03
    RHS       R213                          -9.9958768943743817e+03
    RHS       R214                          -9.9958768943743817e+03
    RHS       R215                          -9.9958768943743817e+03
    RHS       R216                          -9.9958768943743817e+03
    RHS       R217                          -9.9958768943743817e+03
    RHS       R218                          -9.9958768943743817e+03
    RHS       R219                          -9.9958768943743817e+03
    RHS       R220                          -9.9958768943743817e+03
    RHS       R221                          -9.9958768943743817e+03
    RHS       R222                          -9.9958768943743817e+03
    RHS       R223                          -9.9958768943743817e+03
    RHS       R224                          -9.9958768943743817e+03
    RHS       R225                          -9.9958768943743817e+03
    RHS       R226                          -9.9958768943743817e+03
    RHS       R227                          -9.9958768943743817e+03
    RHS       R228                          -9.9958768943743817e+03
    RHS       R229                          -9.9958768943743817e+03
    RHS       R230                          -9.9958768943743817e+03
    RHS       R231                          -9.9958768943743817e+03
    RHS       R232                          -9.9958768943743817e+03
    RHS       R233                          -9.9958768943743817e+03
    RHS       R234                          -9.9958768943743817e+03
    RHS       R235                          -9.9958768943743817e+03
    RHS       R236                          -9.9958768943743817e+03
    RHS       R237                          -9.9958768943743817e+03
    RHS       R238                          -9.9958768943743817e+03
    RHS       R239                          -9.9958768943743817e+03
    RHS       R240                          -9.9958768943743817e+03
    RHS       R241                          -9.9958768943743817e+03
    RHS       R242                          -9.9958768943743817e+03
    RHS       R243                          -9.9958768943743817e+03
    RHS       R244                          -9.9958768943743817e+03
    RHS       R245                          -9.9958768943743817e+03
    RHS       R246                          -9.9958768943743817e+03
    RHS       R247                          -9.9958768943743817e+03
    RHS       R248                          -9.9958768943743817e+03
    RHS       R249                          -9.9958768943743817e+03
    RHS       R250                          -9.9958768943743817e+03
    RHS       R251                          -9.9958768943743817e+03
    RHS       R252                          -9.9958768943743817e+03
    RHS       R253                          -9.9958768943743817e+03
    RHS       R254                          -9.9958768943743817e+03
    RHS       R255                          -9.9958768943743817e+03
    RHS       R256                          -9.9958768943743817e+03
    RHS       R257                          -9.9958768943743817e+03
    RHS       R258                          -9.9958768943743817e+03
    RHS       R259                          -9.9958768943743817e+03
    RHS       R260                          -9.9958768943743817e+03
    RHS       R261                          -9.9958768943743817e+03
    RHS       R262                          -9.9958768943743817e+03
    RHS       R263                          -9.9958768943743817e+03
    RHS       R264                          -9.9958768943743817e+03
    RHS       R265                          -9.9958768943743817e+03
    RHS       R266                          -9.9958768943743817e+03
    RHS       R267                          -9.9958768943743817e+03
    RHS       R268                          -9.9958768943743817e+03
    RHS       R269                          -9.9958768943743817e+03
    RHS       R270                          -9.9958768943743817e+03
    RHS       R271                          -9.9958768943743817e+03
    RHS       R272                          -9.9958768943743817e+03
    RHS       R273                          -9.9958768943743817e+03
    RHS       R274                          -9.9958768943743817e+03
    RHS       R275                          -9.9958768943743817e+03
    RHS       R276                          -9.9958768943743817e+03
    RHS       R277                          -9.9958768943743817e+03
    RHS       R278                          -9.9958768943743817e+03
    RHS       R279                          -9.9958768943743817e+03
    RHS       R280                          -9.9958768943743817e+03
    RHS       R281                          -9.9958768943743817e+03
    RHS       R282                          -9.9958768943743817e+03
    RHS       R283                          -9.9958768943743817e+03
    RHS       R284                          -9.9958768943743817e+03
    RHS       R285                          -9.9958768943743817e+03
    RHS       R286                          -9.9958768943743817e+03
    RHS       R287                          -9.9958768943743817e+03
    RHS       R288                          -9.9958768943743817e+03
    RHS       R289                          -9.9958768943743817e+03
    RHS       R290                          -9.9958768943743817e+03
    RHS       R291                          -9.9958768943743817e+03
    RHS       R292                          -9.9958768943743817e+03
    RHS       R293                          -9.9958768943743817e+03
    RHS       R294                          -9.9958768943743817e+03
    RHS       R295                          -9.9958768943743817e+03
    RHS       R296                          -9.9958768943743817e+03
    RHS       R297                          -9.9958768943743817e+03
    RHS       R298                          -9.9958768943743817e+03
    RHS       R299                          -9.9958768943743817e+03
    RHS       R300                          -9.9958768943743817e+03
    RHS       R301                          -9.9958768943743817e+03
    RHS       R302                          -9.9958768943743817e+03
    RHS       R303                          -9.9958768943743817e+03
    RHS       R304                          -9.9958768943743817e+03
    RHS       R305                          -9.9958768943743817e+03
    RHS       R306                          -9.9958768943743817e+03
    RHS       R307                          -9.9958768943743817e+03
    RHS       R308                          -9.9958768943743817e+03
    RHS       R309                          -9.9958768943743817e+03
    RHS       R310                          -9.9958768943743817e+03
    RHS       R311                          -9.9958768943743817e+03
    RHS       R312                          -9.9958768943743817e+03
    RHS       R313                          -9.9958768943743817e+03
    RHS       R314                          -9.9958768943743817e+03
    RHS       R315                          -9.9958768943743817e+03
    RHS       R316                          -9.9958768943743817e+03
    RHS       R317                          -9.9958768943743817e+03
    RHS       R318                          -9.9958768943743817e+03
    RHS       R319                          -9.9958768943743817e+03
    RHS       R320                          -9.9958768943743817e+03
    RHS       R321                          -9.9958768943743817e+03
    RHS       R322                          -9.9958768943743817e+03
    RHS       R323                          -9.9958768943743817e+03
    RHS       R324                          -9.9958768943743817e+03
    RHS       R325                          -9.9958768943743817e+03
    RHS       R326                          -9.9958768943743817e+03
    RHS       R327                          -9.9958768943743817e+03
    RHS       R328                          -9.9958768943743817e+03
    RHS       R329                          -9.9958768943743817e+03
    RHS       R330                          -9.9958768943743817e+03
    RHS       R331                          -9.9958768943743817e+03
    RHS       R332                          -9.9958768943743817e+03
    RHS       R333                          -9.9958768943743817e+03
    RHS       R334                          -9.9958768943743817e+03
    RHS       R335                          -9.9958768943743817e+03
    RHS       R336                          -9.9958768943743817e+03
    RHS       R337                          -9.9958768943743817e+03
    RHS       R338                          -9.9958768943743817e+03
    RHS       R339                          -9.9958768943743817e+03
    RHS       R340                          -9.9958768943743817e+03
    RHS       R341                          -9.9958768943743817e+03
    RHS       R342                          -9.9958768943743817e+03
    RHS       R343                          -9.9958768943743817e+03
    RHS       R344                          -9.9958768943743817e+03
    RHS       R345                          -9.9958768943743817e+03
    RHS       R346                          -9.9958768943743817e+03
    RHS       R347                          -9.9958768943743817e+03
    RHS       R348                          -9.9958768943743817e+03
    RHS       R349                          -9.9958768943743817e+03
    RHS       R350                          -9.9958768943743817e+03
    RHS       R351                          -9.9958768943743817e+03
    RHS       R352                          -9.9958768943743817e+03
    RHS       R353                          -9.9958768943743817e+03
    RHS       R354                          -9.9958768943743817e+03
    RHS       R355                          -9.9958768943743817e+03
    RHS       R356                          -9.9958768943743817e+03
    RHS       R357                          -9.9958768943743817e+03
    RHS       R358                          -9.9958768943743817e+03
    RHS       R359                          -9.9958768943743817e+03
    RHS       R360                          -9.9958768943743817e+03
    RHS       R361                          -9.9958768943743817e+03
    RHS       R362                          -9.9958768943743817e+03
    RHS       R363                          -9.9958768943743817e+03
    RHS       R364                          -9.9958768943743817e+03
    RHS       R365                          -9.9958768943743817e+03
    RHS       R366                          -9.9958768943743817e+03
    RHS       R367                          -9.9958768943743817e+03
    RHS       R368                          -9.9958768943743817e+03
    RHS       R369                          -9.9958768943743817e+03
    RHS       R370                          -9.9958768943743817e+03
    RHS       R371                          -9.9958768943743817e+03
    RHS       R372                          -9.9958768943743817e+03
    RHS       R373                          -9.9958768943743817e+03
    RHS       R374                          -9.9958768943743817e+03
    RHS       R375                          -9.9958768943743817e+03
    RHS       R376                          -9.9958768943743817e+03
    RHS       R377                          -9.9958768943743817e+03
    RHS       R378                          -9.9958768943743817e+03
    RHS       R379                          -9.9958768943743817e+03
    RHS       R380                          -9.9958768943743817e+03
    RHS       R381                          -9.9958768943743817e+03
    RHS       R382                          -9.9958768943743817e+03
    RHS       R383                          -9.9958768943743817e+03
    RHS       R384                          -9.9958768943743817e+03
    RHS       R385                          -9.9958768943743817e+03
    RHS       R386                          -9.9958768943743817e+03
    RHS       R387                          -9.9958768943743817e+03
    RHS       R388                          -9.9958768943743817e+03
    RHS       R389                          -9.9958768943743817e+03
    RHS       R390                          -9.9958768943743817e+03
    RHS       R391                          -9.9958768943743817e+03
    RHS       R392                          -9.9958768943743817e+03
    RHS       R393                          -9.9958768943743817e+03
    RHS       R394                          -9.9958768943743817e+03
    RHS       R395                          -9.9958768943743817e+03
    RHS       R396                          -9.9958768943743817e+03
    RHS       R397                          -9.9958768943743817e+03
    RHS       R398                          -9.9958768943743817e+03
    RHS       R399                          -9.9958768943743817e+03
    RHS       R400                          -9.9958768943743817e+03
    RHS       R401                          -9.9958768943743817e+03
    RHS       R402                          -9.9958768943743817e+03
    RHS       R403                          -9.9958768943743817e+03
    RHS       R404                          -9.9958768943743817e+03
    RHS       R405                          -9.9958768943743817e+03
    RHS       R406                          -9.9958768943743817e+03
    RHS       R407                          -9.9958768943743817e+03
    RHS       R408                          -9.9958768943743817e+03
    RHS       R409                          -9.9958768943743817e+03
    RHS       R410                          -9.9958768943743817e+03
    RHS       R411                          -9.9958768943743817e+03
    RHS       R412                          -9.9958768943743817e+03
    RHS       R413                          -9.9958768943743817e+03
    RHS       R414                          -9.9958768943743817e+03
    RHS       R415                          -9.9958768943743817e+03
    RHS       R416                          -9.9958768943743817e+03
    RHS       R417                          -9.9958768943743817e+03
    RHS       R418                          -9.9958768943743817e+03
    RHS       R419                          -9.9958768943743817e+03
    RHS       R420                          -9.9958768943743817e+03
    RHS       R421                          -9.9958768943743817e+03
    RHS       R422                          -9.9958768943743817e+03
    RHS       R423                          -9.9958768943743817e+03
    RHS       R424                          -9.9958768943743817e+03
    RHS       R425                          -9.9958768943743817e+03
    RHS       R426                          -9.9958768943743817e+03
    RHS       R427                          -9.9958768943743817e+03
    RHS       R428                          -9.9958768943743817e+03
    RHS       R429                          -9.9958768943743817e+03
    RHS       R430                          -9.9958768943743817e+03
    RHS       R431                          -9.9958768943743817e+03
    RHS       R432                          -9.9958768943743817e+03
    RHS       R433                          -9.9958768943743817e+03
    RHS       R434                          -9.9958768943743817e+03
    RHS       R435                          -9.9958768943743817e+03
    RHS       R436                          -9.9958768943743817e+03
    RHS       R437                          -9.9958768943743817e+03
    RHS       R438                          -9.9958768943743817e+03
    RHS       R439                          -9.9958768943743817e+03
    RHS       R440                          -9.9958768943743817e+03
    RHS       R441                          -9.9958768943743817e+03
    RHS       R442                          -9.9958768943743817e+03
    RHS       R443                          -9.9958768943743817e+03
    RHS       R444                          -9.9958768943743817e+03
    RHS       R445                          -9.9958768943743817e+03
    RHS       R446                          -9.9958768943743817e+03
    RHS       R447                          -9.9958768943743817e+03
    RHS       R448                          -9.9958768943743817e+03
    RHS       R449                          -9.9958768943743817e+03
    RHS       R450                          -9.9958768943743817e+03
    RHS       R451                          -9.9958768943743817e+03
    RHS       R452                          -9.9958768943743817e+03
    RHS       R453                          -9.9958768943743817e+03
    RHS       R454                          -9.9958768943743817e+03
    RHS       R455                          -9.9958768943743817e+03
    RHS       R456                          -9.9958768943743817e+03
    RHS       R457                          -9.9958768943743817e+03
    RHS       R458                          -9.9958768943743817e+03
    RHS       R459                          -9.9958768943743817e+03
    RHS       R460                          -9.9958768943743817e+03
    RHS       R461                          -9.9958768943743817e+03
    RHS       R462                          -9.9958768943743817e+03
    RHS       R463                          -9.9958768943743817e+03
    RHS       R464                          -9.9958768943743817e+03
    RHS       R465                          -9.9958768943743817e+03
    RHS       R466                          -9.9958768943743817e+03
    RHS       R467                          -9.9958768943743817e+03
    RHS       R468                          -9.9958768943743817e+03
    RHS       R469                          -9.9958768943743817e+03
    RHS       R470                          -9.9958768943743817e+03
    RHS       R471                          -9.9958768943743817e+03
    RHS       R472                          -9.9958768943743817e+03
    RHS       R473                          -9.9958768943743817e+03
    RHS       R474                          -9.9958768943743817e+03
    RHS       R475                          4.1231056256176606e+00
    RHS       R476                          4.1231056256176606e+00
    RHS       R477                          4.1231056256176606e+00
    RHS       R478                          4.1231056256176606e+00
    RHS       R479                          4.1231056256176606e+00
    RHS       R480                          4.1231056256176606e+00
    RHS       R481                          4.1231056256176606e+00
    RHS       R482                          4.1231056256176606e+00
    RHS       R483                          4.1231056256176606e+00
    RHS       R484                          4.1231056256176606e+00
    RHS       R485                          4.1231056256176606e+00
    RHS       R486                          4.1231056256176606e+00
    RHS       R487                          4.1231056256176606e+00
    RHS       R488                          4.1231056256176606e+00
    RHS       R489                          4.1231056256176606e+00
    RHS       R490                          4.1231056256176606e+00
    RHS       R491                          4.1231056256176606e+00
    RHS       R492                          4.1231056256176606e+00
    RHS       R493                          4.1231056256176606e+00
    RHS       R494                          4.1231056256176606e+00
    RHS       R495                          4.1231056256176606e+00
    RHS       R496                          4.1231056256176606e+00
    RHS       R497                          4.1231056256176606e+00
    RHS       R498                          4.1231056256176606e+00
    RHS       R499                          4.1231056256176606e+00
    RHS       R500                          4.1231056256176606e+00
    RHS       R501                          4.1231056256176606e+00
    RHS       R502                          4.1231056256176606e+00
    RHS       R503                          4.1231056256176606e+00
    RHS       R504                          4.1231056256176606e+00
    RHS       R505                          4.1231056256176606e+00
    RHS       R506                          4.1231056256176606e+00
    RHS       R507                          4.1231056256176606e+00
    RHS       R508                          4.1231056256176606e+00
    RHS       R509                          4.1231056256176606e+00
    RHS       R510                          4.1231056256176606e+00
    RHS       R511                          4.1231056256176606e+00
    RHS       R512                          4.1231056256176606e+00
    RHS       R513                          4.1231056256176606e+00
    RHS       R514                          4.1231056256176606e+00
    RHS       R515                          4.1231056256176606e+00
    RHS       R516                          4.1231056256176606e+00
    RHS       R517                          4.1231056256176606e+00
    RHS       R518                          4.1231056256176606e+00
    RHS       R519                          4.1231056256176606e+00
    RHS       R520                          4.1231056256176606e+00
    RHS       R521                          4.1231056256176606e+00
    RHS       R522                          4.1231056256176606e+00
    RHS       R523                          4.1231056256176606e+00
    RHS       R524                          4.1231056256176606e+00
    RHS       R525                          4.1231056256176606e+00
    RHS       R526                          4.1231056256176606e+00
    RHS       R527                          4.1231056256176606e+00
    RHS       R528                          4.1231056256176606e+00
    RHS       R529                          4.1231056256176606e+00
    RHS       R530                          4.1231056256176606e+00
    RHS       R531                          4.1231056256176606e+00
    RHS       R532                          4.1231056256176606e+00
    RHS       R533                          4.1231056256176606e+00
    RHS       R534                          4.1231056256176606e+00
    RHS       R535                          4.1231056256176606e+00
    RHS       R536                          4.1231056256176606e+00
    RHS       R537                          4.1231056256176606e+00
    RHS       R538                          4.1231056256176606e+00
    RHS       R539                          4.1231056256176606e+00
    RHS       R540                          4.1231056256176606e+00
    RHS       R541                          4.1231056256176606e+00
    RHS       R542                          4.1231056256176606e+00
    RHS       R543                          4.1231056256176606e+00
    RHS       R544                          4.1231056256176606e+00
    RHS       R545                          4.1231056256176606e+00
    RHS       R546                          4.1231056256176606e+00
    RHS       R547                          4.1231056256176606e+00
    RHS       R548                          4.1231056256176606e+00
    RHS       R549                          4.1231056256176606e+00
    RHS       R550                          4.1231056256176606e+00
    RHS       R551                          4.1231056256176606e+00
    RHS       R552                          4.1231056256176606e+00
    RHS       R553                          4.1231056256176606e+00
    RHS       R554                          4.1231056256176606e+00
    RHS       R555                          4.1231056256176606e+00
    RHS       R556                          4.1231056256176606e+00
    RHS       R557                          4.1231056256176606e+00
    RHS       R558                          4.1231056256176606e+00
    RHS       R559                          4.1231056256176606e+00
    RHS       R560                          4.1231056256176606e+00
    RHS       R561                          4.1231056256176606e+00
    RHS       R562                          4.1231056256176606e+00
    RHS       R563                          4.1231056256176606e+00
    RHS       R564                          4.1231056256176606e+00
    RHS       R565                          4.1231056256176606e+00
    RHS       R566                          4.1231056256176606e+00
    RHS       R567                          4.1231056256176606e+00
    RHS       R568                          4.1231056256176606e+00
    RHS       R569                          4.1231056256176606e+00
    RHS       R570                          4.1231056256176606e+00
    RHS       R571                          4.1231056256176606e+00
    RHS       R572                          4.1231056256176606e+00
    RHS       R573                          4.1231056256176606e+00
    RHS       R574                          4.1231056256176606e+00
    RHS       R575                          4.1231056256176606e+00
    RHS       R576                          4.1231056256176606e+00
    RHS       R577                          4.1231056256176606e+00
    RHS       R578                          4.1231056256176606e+00
    RHS       R579                          4.1231056256176606e+00
    RHS       R580                          4.1231056256176606e+00
    RHS       R581                          4.1231056256176606e+00
    RHS       R582                          4.1231056256176606e+00
    RHS       R583                          4.1231056256176606e+00
    RHS       R584                          4.1231056256176606e+00
    RHS       R585                          4.1231056256176606e+00
    RHS       R586                          4.1231056256176606e+00
    RHS       R587                          4.1231056256176606e+00
    RHS       R588                          4.1231056256176606e+00
    RHS       R589                          4.1231056256176606e+00
    RHS       R590                          4.1231056256176606e+00
    RHS       R591                          4.1231056256176606e+00
    RHS       R592                          4.1231056256176606e+00
    RHS       R593                          4.1231056256176606e+00
    RHS       R594                          4.1231056256176606e+00
    RHS       R595                          4.1231056256176606e+00
    RHS       R596                          4.1231056256176606e+00
    RHS       R597                          4.1231056256176606e+00
    RHS       R598                          4.1231056256176606e+00
    RHS       R599                          4.1231056256176606e+00
    RHS       R600                          4.1231056256176606e+00
    RHS       R601                          4.1231056256176606e+00
    RHS       R602                          4.1231056256176606e+00
    RHS       R603                          4.1231056256176606e+00
    RHS       R604                          4.1231056256176606e+00
    RHS       R605                          4.1231056256176606e+00
    RHS       R606                          4.1231056256176606e+00
    RHS       R607                          4.1231056256176606e+00
    RHS       R608                          4.1231056256176606e+00
    RHS       R609                          4.1231056256176606e+00
    RHS       R610                          4.1231056256176606e+00
    RHS       R611                          4.1231056256176606e+00
    RHS       R612                          4.1231056256176606e+00
    RHS       R613                          4.1231056256176606e+00
    RHS       R614                          4.1231056256176606e+00
    RHS       R615                          4.1231056256176606e+00
    RHS       R616                          4.1231056256176606e+00
    RHS       R617                          4.1231056256176606e+00
    RHS       R618                          4.1231056256176606e+00
    RHS       R619                          4.1231056256176606e+00
    RHS       R620                          4.1231056256176606e+00
    RHS       R621                          4.1231056256176606e+00
    RHS       R622                          4.1231056256176606e+00
    RHS       R623                          4.1231056256176606e+00
    RHS       R624                          4.1231056256176606e+00
    RHS       R625                          4.1231056256176606e+00
    RHS       R626                          4.1231056256176606e+00
    RHS       R627                          4.1231056256176606e+00
    RHS       R628                          4.1231056256176606e+00
    RHS       R629                          4.1231056256176606e+00
    RHS       R630                          4.1231056256176606e+00
    RHS       R631                          4.1231056256176606e+00
    RHS       R632                          4.1231056256176606e+00
    RHS       R633                          4.1231056256176606e+00
    RHS       R634                          4.1231056256176606e+00
    RHS       R635                          4.1231056256176606e+00
    RHS       R636                          4.1231056256176606e+00
    RHS       R637                          4.1231056256176606e+00
    RHS       R638                          4.1231056256176606e+00
    RHS       R639                          4.1231056256176606e+00
    RHS       R640                          4.1231056256176606e+00
    RHS       R641                          4.1231056256176606e+00
    RHS       R642                          4.1231056256176606e+00
    RHS       R643                          4.1231056256176606e+00
    RHS       R644                          4.1231056256176606e+00
    RHS       R645                          4.1231056256176606e+00
    RHS       R646                          4.1231056256176606e+00
    RHS       R647                          4.1231056256176606e+00
    RHS       R648                          4.1231056256176606e+00
    RHS       R649                          4.1231056256176606e+00
    RHS       R650                          4.1231056256176606e+00
    RHS       R651                          4.1231056256176606e+00
    RHS       R652                          4.1231056256176606e+00
    RHS       R653                          4.1231056256176606e+00
    RHS       R654                          4.1231056256176606e+00
    RHS       R655                          4.1231056256176606e+00
    RHS       R656                          4.1231056256176606e+00
    RHS       R657                          4.1231056256176606e+00
    RHS       R658                          4.1231056256176606e+00
    RHS       R659                          4.1231056256176606e+00
    RHS       R660                          4.1231056256176606e+00
    RHS       R661                          4.1231056256176606e+00
    RHS       R662                          4.1231056256176606e+00
    RHS       R663                          4.1231056256176606e+00
    RHS       R664                          4.1231056256176606e+00
    RHS       R665                          4.1231056256176606e+00
    RHS       R666                          4.1231056256176606e+00
    RHS       R667                          4.1231056256176606e+00
    RHS       R668                          4.1231056256176606e+00
    RHS       R669                          4.1231056256176606e+00
    RHS       R670                          4.1231056256176606e+00
    RHS       R671                          4.1231056256176606e+00
    RHS       R672                          4.1231056256176606e+00
    RHS       R673                          4.1231056256176606e+00
    RHS       R674                          4.1231056256176606e+00
    RHS       R675                          4.1231056256176606e+00
    RHS       R676                          4.1231056256176606e+00
    RHS       R677                          4.1231056256176606e+00
    RHS       R678                          4.1231056256176606e+00
    RHS       R679                          4.1231056256176606e+00
    RHS       R680                          4.1231056256176606e+00
    RHS       R681                          4.1231056256176606e+00
    RHS       R682                          4.1231056256176606e+00
    RHS       R683                          4.1231056256176606e+00
    RHS       R684                          4.1231056256176606e+00
    RHS       R685                          4.1231056256176606e+00
    RHS       R686                          4.1231056256176606e+00
    RHS       R687                          4.1231056256176606e+00
    RHS       R688                          4.1231056256176606e+00
    RHS       R689                          4.1231056256176606e+00
    RHS       R690                          4.1231056256176606e+00
    RHS       R691                          4.1231056256176606e+00
    RHS       R692                          4.1231056256176606e+00
    RHS       R693                          4.1231056256176606e+00
    RHS       R694                          4.1231056256176606e+00
    RHS       R695                          4.1231056256176606e+00
    RHS       R696                          4.1231056256176606e+00
    RHS       R697                          4.1231056256176606e+00
    RHS       R698                          4.1231056256176606e+00
    RHS       R699                          4.1231056256176606e+00
    RHS       R700                          4.1231056256176606e+00
    RHS       R701                          4.1231056256176606e+00
    RHS       R702                          4.1231056256176606e+00
    RHS       R703                          4.1231056256176606e+00
    RHS       R704                          4.1231056256176606e+00
    RHS       R705                          4.1231056256176606e+00
    RHS       R706                          4.1231056256176606e+00
    RHS       R707                          4.1231056256176606e+00
    RHS       R708                          4.1231056256176606e+00
    RHS       R709                          4.1231056256176606e+00
    RHS       R710                          4.1231056256176606e+00
    RHS       R711                          4.1231056256176606e+00
    RHS       R712                          4.1231056256176606e+00
    RHS       R713                          4.1231056256176606e+00
    RHS       R714                          4.1231056256176606e+00
    RHS       R715                          4.1231056256176606e+00
    RHS       R716                          4.1231056256176606e+00
    RHS       R717                          4.1231056256176606e+00
    RHS       R718                          4.1231056256176606e+00
    RHS       R719                          4.1231056256176606e+00
    RHS       R720                          4.1231056256176606e+00
    RHS       R721                          4.1231056256176606e+00
    RHS       R722                          4.1231056256176606e+00
    RHS       R723                          4.1231056256176606e+00
    RHS       R724                          4.1231056256176606e+00
    RHS       R725                          4.1231056256176606e+00
    RHS       R726                          4.1231056256176606e+00
    RHS       R727                          4.1231056256176606e+00
    RHS       R728                          4.1231056256176606e+00
    RHS       R729                          4.1231056256176606e+00
    RHS       R730                          4.1231056256176606e+00
    RHS       R731                          4.1231056256176606e+00
    RHS       R732                          4.1231056256176606e+00
    RHS       R733                          4.1231056256176606e+00
    RHS       R734                          4.1231056256176606e+00
    RHS       R735                          4.1231056256176606e+00
    RHS       R736                          4.1231056256176606e+00
    RHS       R737                          4.1231056256176606e+00
    RHS       R738                          4.1231056256176606e+00
    RHS       R739                          4.1231056256176606e+00
    RHS       R740                          4.1231056256176606e+00
    RHS       R741                          4.1231056256176606e+00
    RHS       R742                          4.1231056256176606e+00
    RHS       R743                          4.1231056256176606e+00
    RHS       R744                          4.1231056256176606e+00
    RHS       R745                          4.1231056256176606e+00
    RHS       R746                          4.1231056256176606e+00
    RHS       R747                          4.1231056256176606e+00
    RHS       R748                          4.1231056256176606e+00
    RHS       R749                          4.1231056256176606e+00
    RHS       R750                          4.1231056256176606e+00
    RHS       R751                          4.1231056256176606e+00
    RHS       R752                          4.1231056256176606e+00
    RHS       R753                          4.1231056256176606e+00
    RHS       R754                          4.1231056256176606e+00
    RHS       R755                          4.1231056256176606e+00
    RHS       R756                          4.1231056256176606e+00
    RHS       R757                          4.1231056256176606e+00
    RHS       R758                          4.1231056256176606e+00
    RHS       R759                          4.1231056256176606e+00
    RHS       R760                          4.1231056256176606e+00
    RHS       R761                          4.1231056256176606e+00
    RHS       R762                          4.1231056256176606e+00
    RHS       R763                          4.1231056256176606e+00
    RHS       R764                          4.1231056256176606e+00
    RHS       R765                          4.1231056256176606e+00
    RHS       R766                          4.1231056256176606e+00
    RHS       R767                          4.1231056256176606e+00
    RHS       R768                          4.1231056256176606e+00
    RHS       R769                          4.1231056256176606e+00
    RHS       R770                          4.1231056256176606e+00
    RHS       R771                          4.1231056256176606e+00
    RHS       R772                          4.1231056256176606e+00
    RHS       R773                          4.1231056256176606e+00
    RHS       R774                          4.1231056256176606e+00
    RHS       R775                          4.1231056256176606e+00
    RHS       R776                          4.1231056256176606e+00
    RHS       R777                          4.1231056256176606e+00
    RHS       R778                          4.1231056256176606e+00
    RHS       R779                          4.1231056256176606e+00
    RHS       R780                          4.1231056256176606e+00
    RHS       R781                          4.1231056256176606e+00
    RHS       R782                          4.1231056256176606e+00
    RHS       R783                          4.1231056256176606e+00
    RHS       R784                          4.1231056256176606e+00
    RHS       R785                          4.1231056256176606e+00
    RHS       R786                          4.1231056256176606e+00
    RHS       R787                          4.1231056256176606e+00
    RHS       R788                          4.1231056256176606e+00
    RHS       R789                          4.1231056256176606e+00
    RHS       R790                          4.1231056256176606e+00
    RHS       R791                          4.1231056256176606e+00
    RHS       R792                          4.1231056256176606e+00
    RHS       R793                          4.1231056256176606e+00
    RHS       R794                          4.1231056256176606e+00
    RHS       R795                          4.1231056256176606e+00
    RHS       R796                          4.1231056256176606e+00
    RHS       R797                          4.1231056256176606e+00
    RHS       R798                          4.1231056256176606e+00
    RHS       R799                          4.1231056256176606e+00
    RHS       R800                          4.1231056256176606e+00
    RHS       R801                          4.1231056256176606e+00
    RHS       R802                          4.1231056256176606e+00
    RHS       R803                          4.1231056256176606e+00
    RHS       R804                          4.1231056256176606e+00
    RHS       R805                          4.1231056256176606e+00
    RHS       R806                          4.1231056256176606e+00
    RHS       R807                          4.1231056256176606e+00
    RHS       R808                          4.1231056256176606e+00
    RHS       R809                          4.1231056256176606e+00
    RHS       R810                          4.1231056256176606e+00
    RHS       R811                          4.1231056256176606e+00
    RHS       R812                          4.1231056256176606e+00
    RHS       R813                          4.1231056256176606e+00
    RHS       R814                          4.1231056256176606e+00
    RHS       R815                          4.1231056256176606e+00
    RHS       R816                          4.1231056256176606e+00
    RHS       R817                          4.1231056256176606e+00
    RHS       R818                          4.1231056256176606e+00
    RHS       R819                          4.1231056256176606e+00
    RHS       R820                          4.1231056256176606e+00
    RHS       R821                          4.1231056256176606e+00
    RHS       R822                          4.1231056256176606e+00
    RHS       R823                          4.1231056256176606e+00
    RHS       R824                          4.1231056256176606e+00
    RHS       R825                          4.1231056256176606e+00
    RHS       R826                          4.1231056256176606e+00
    RHS       R827                          4.1231056256176606e+00
    RHS       R828                          4.1231056256176606e+00
    RHS       R829                          4.1231056256176606e+00
    RHS       R830                          4.1231056256176606e+00
    RHS       R831                          4.1231056256176606e+00
    RHS       R832                          4.1231056256176606e+00
    RHS       R833                          4.1231056256176606e+00
    RHS       R834                          4.1231056256176606e+00
    RHS       R835                          4.1231056256176606e+00
    RHS       R836                          4.1231056256176606e+00
    RHS       R837                          4.1231056256176606e+00
    RHS       R838                          4.1231056256176606e+00
    RHS       R839                          4.1231056256176606e+00
    RHS       R840                          4.1231056256176606e+00
    RHS       R841                          4.1231056256176606e+00
    RHS       R842                          4.1231056256176606e+00
    RHS       R843                          4.1231056256176606e+00
    RHS       R844                          4.1231056256176606e+00
    RHS       R845                          4.1231056256176606e+00
    RHS       R846                          4.1231056256176606e+00
    RHS       R847                          4.1231056256176606e+00
    RHS       R848                          4.1231056256176606e+00
    RHS       R849                          4.1231056256176606e+00
    RHS       R850                          4.1231056256176606e+00
    RHS       R851                          4.1231056256176606e+00
    RHS       R852                          4.1231056256176606e+00
    RHS       R853                          4.1231056256176606e+00
    RHS       R854                          4.1231056256176606e+00
    RHS       R855                          4.1231056256176606e+00
    RHS       R856                          4.1231056256176606e+00
    RHS       R857                          4.1231056256176606e+00
    RHS       R858                          4.1231056256176606e+00
    RHS       R859                          4.1231056256176606e+00
    RHS       R860                          4.1231056256176606e+00
    RHS       R861                          4.1231056256176606e+00
    RHS       R862                          4.1231056256176606e+00
    RHS       R863                          4.1231056256176606e+00
    RHS       R864                          4.1231056256176606e+00
    RHS       R865                          4.1231056256176606e+00
    RHS       R866                          4.1231056256176606e+00
    RHS       R867                          4.1231056256176606e+00
    RHS       R868                          4.1231056256176606e+00
    RHS       R869                          4.1231056256176606e+00
    RHS       R870                          4.1231056256176606e+00
BOUNDS
 LO BND       X40                           0
 UP BND       X40                           1
 LO BND       X41                           0
 UP BND       X41                           1
 LO BND       X42                           0
 UP BND       X42                           1
 LO BND       X43                           0
 UP BND       X43                           1
 LO BND       X44                           0
 UP BND       X44                           1
 LO BND       X45                           0
 UP BND       X45                           1
 LO BND       X46                           0
 UP BND       X46                           1
 LO BND       X47                           0
 UP BND       X47                           1
 LO BND       X48                           0
 UP BND       X48                           1
 LO BND       X49                           0
 UP BND       X49                           1
 LO BND       X50                           0
 UP BND       X50                           1
 LO BND       X51                           0
 UP BND       X51                           1
 LO BND       X52                           0
 UP BND       X52                           1
 LO BND       X53                           0
 UP BND       X53                           1
 LO BND       X54                           0
 UP BND       X54                           1
 LO BND       X55                           0
 UP BND       X55                           1
 LO BND       X56                           0
 UP BND       X56                           1
 LO BND       X57                           0
 UP BND       X57                           1
 LO BND       X58                           0
 UP BND       X58                           1
 LO BND       X59                           0
 UP BND       X59                           1
 LO BND       X60                           0
 UP BND       X60                           1
 LO BND       X61                           0
 UP BND       X61                           1
 LO BND       X62                           0
 UP BND       X62                           1
 LO BND       X63                           0
 UP BND       X63                           1
 LO BND       X64                           0
 UP BND       X64                           1
 LO BND       X65                           0
 UP BND       X65                           1
 LO BND       X66                           0
 UP BND       X66                           1
 LO BND       X67                           0
 UP BND       X67                           1
 LO BND       X68                           0
 UP BND       X68                           1
 LO BND       X69                           0
 UP BND       X69                           1
 LO BND       X70                           0
 UP BND       X70                           1
 LO BND       X71                           0
 UP BND       X71                           1
 LO BND       X72                           0
 UP BND       X72                           1
 LO BND       X73                           0
 UP BND       X73                           1
 LO BND       X74                           0
 UP BND       X74                           1
 LO BND       X75                           0
 UP BND       X75                           1
 LO BND       X76                           0
 UP BND       X76                           1
 LO BND       X77                           0
 UP BND       X77                           1
 LO BND       X78                           0
 UP BND       X78                           1
 LO BND       X79                           0
 UP BND       X79                           1
 LO BND       X80                           0
 UP BND       X80                           1
 LO BND       X81                           0
 UP BND       X81                           1
 LO BND       X82                           0
 UP BND       X82                           1
 LO BND       X83                           0
 UP BND       X83                           1
 LO BND       X84                           0
 UP BND       X84                           1
 LO BND       X85                           0
 UP BND       X85                           1
 LO BND       X86                           0
 UP BND       X86                           1
 LO BND       X87                           0
 UP BND       X87                           1
 LO BND       X88                           0
 UP BND       X88                           1
 LO BND       X89                           0
 UP BND       X89                           1
 LO BND       X90                           0
 UP BND       X90                           1
 LO BND       X91                           0
 UP BND       X91                           1
 LO BND       X92                           0
 UP BND       X92                           1
 LO BND       X93                           0
 UP BND       X93                           1
 LO BND       X94                           0
 UP BND       X94                           1
 LO BND       X95                           0
 UP BND       X95                           1
 LO BND       X96                           0
 UP BND       X96                           1
 LO BND       X97                           0
 UP BND       X97                           1
 LO BND       X98                           0
 UP BND       X98                           1
 LO BND       X99                           0
 UP BND       X99                           1
 LO BND       X100                          0
 UP BND       X100                          1
 LO BND       X101                          0
 UP BND       X101                          1
 LO BND       X102                          0
 UP BND       X102                          1
 LO BND       X103                          0
 UP BND       X103                          1
 LO BND       X104                          0
 UP BND       X104                          1
 LO BND       X105                          0
 UP BND       X105                          1
 LO BND       X106                          0
 UP BND       X106                          1
 LO BND       X107                          0
 UP BND       X107                          1
 LO BND       X108                          0
 UP BND       X108                          1
 LO BND       X109                          0
 UP BND       X109                          1
 LO BND       X110                          0
 UP BND       X110                          1
 LO BND       X111                          0
 UP BND       X111                          1
 LO BND       X112                          0
 UP BND       X112                          1
 LO BND       X113                          0
 UP BND       X113                          1
 LO BND       X114                          0
 UP BND       X114                          1
 LO BND       X115                          0
 UP BND       X115                          1
 LO BND       X116                          0
 UP BND       X116                          1
 LO BND       X117                          0
 UP BND       X117                          1
 LO BND       X118                          0
 UP BND       X118                          1
 LO BND       X119                          0
 UP BND       X119                          1
 LO BND       X120                          0
 UP BND       X120                          1
 LO BND       X121                          0
 UP BND       X121                          1
 LO BND       X122                          0
 UP BND       X122                          1
 LO BND       X123                          0
 UP BND       X123                          1
 LO BND       X124                          0
 UP BND       X124                          1
 LO BND       X125                          0
 UP BND       X125                          1
 LO BND       X126                          0
 UP BND       X126                          1
 LO BND       X127                          0
 UP BND       X127                          1
 LO BND       X128                          0
 UP BND       X128                          1
 LO BND       X129                          0
 UP BND       X129                          1
 LO BND       X130                          0
 UP BND       X130                          1
 LO BND       X131                          0
 UP BND       X131                          1
 LO BND       X132                          0
 UP BND       X132                          1
 LO BND       X133                          0
 UP BND       X133                          1
 LO BND       X134                          0
 UP BND       X134                          1
 LO BND       X135                          0
 UP BND       X135                          1
 LO BND       X136                          0
 UP BND       X136                          1
 LO BND       X137                          0
 UP BND       X137                          1
 LO BND       X138                          0
 UP BND       X138                          1
 LO BND       X139                          0
 UP BND       X139                          1
 LO BND       X140                          0
 UP BND       X140                          1
 LO BND       X141                          0
 UP BND       X141                          1
 LO BND       X142                          0
 UP BND       X142                          1
 LO BND       X143                          0
 UP BND       X143                          1
 LO BND       X144                          0
 UP BND       X144                          1
 LO BND       X145                          0
 UP BND       X145                          1
 LO BND       X146                          0
 UP BND       X146                          1
 LO BND       X147                          0
 UP BND       X147                          1
 LO BND       X148                          0
 UP BND       X148                          1
 LO BND       X149                          0
 UP BND       X149                          1
 LO BND       X150                          0
 UP BND       X150                          1
 LO BND       X151                          0
 UP BND       X151                          1
 LO BND       X152                          0
 UP BND       X152                          1
 LO BND       X153                          0
 UP BND       X153                          1
 LO BND       X154                          0
 UP BND       X154                          1
 LO BND       X155                          0
 UP BND       X155                          1
 LO BND       X156                          0
 UP BND       X156                          1
 LO BND       X157                          0
 UP BND       X157                          1
 LO BND       X158                          0
 UP BND       X158                          1
 LO BND       X159                          0
 UP BND       X159                          1
 LO BND       X160                          0
 UP BND       X160                          1
 LO BND       X161                          0
 UP BND       X161                          1
 LO BND       X162                          0
 UP BND       X162                          1
 LO BND       X163                          0
 UP BND       X163                          1
 LO BND       X164                          0
 UP BND       X164                          1
 LO BND       X165                          0
 UP BND       X165                          1
 LO BND       X166                          0
 UP BND       X166                          1
 LO BND       X167                          0
 UP BND       X167                          1
 LO BND       X168                          0
 UP BND       X168                          1
 LO BND       X169                          0
 UP BND       X169                          1
 LO BND       X170                          0
 UP BND       X170                          1
 LO BND       X171                          0
 UP BND       X171                          1
 LO BND       X172                          0
 UP BND       X172                          1
 LO BND       X173                          0
 UP BND       X173                          1
 LO BND       X174                          0
 UP BND       X174                          1
 LO BND       X175                          0
 UP BND       X175                          1
 LO BND       X176                          0
 UP BND       X176                          1
 LO BND       X177                          0
 UP BND       X177                          1
 LO BND       X178                          0
 UP BND       X178                          1
 LO BND       X179                          0
 UP BND       X179                          1
 LO BND       X180                          0
 UP BND       X180                          1
 LO BND       X181                          0
 UP BND       X181                          1
 LO BND       X182                          0
 UP BND       X182                          1
 LO BND       X183                          0
 UP BND       X183                          1
 LO BND       X184                          0
 UP BND       X184                          1
 LO BND       X185                          0
 UP BND       X185                          1
 LO BND       X186                          0
 UP BND       X186                          1
 LO BND       X187                          0
 UP BND       X187                          1
 LO BND       X188                          0
 UP BND       X188                          1
 LO BND       X189                          0
 UP BND       X189                          1
 LO BND       X190                          0
 UP BND       X190                          1
 LO BND       X191                          0
 UP BND       X191                          1
 LO BND       X192                          0
 UP BND       X192                          1
 LO BND       X193                          0
 UP BND       X193                          1
 LO BND       X194                          0
 UP BND       X194                          1
 LO BND       X195                          0
 UP BND       X195                          1
 LO BND       X196                          0
 UP BND       X196                          1
 LO BND       X197                          0
 UP BND       X197                          1
 LO BND       X198                          0
 UP BND       X198                          1
 LO BND       X199                          0
 UP BND       X199                          1
 LO BND       X200                          0
 UP BND       X200                          1
 LO BND       X201                          0
 UP BND       X201                          1
 LO BND       X202                          0
 UP BND       X202                          1
 LO BND       X203                          0
 UP BND       X203                          1
 LO BND       X204                          0
 UP BND       X204                          1
 LO BND       X205                          0
 UP BND       X205                          1
 LO BND       X206                          0
 UP BND       X206                          1
 LO BND       X207                          0
 UP BND       X207                          1
 LO BND       X208                          0
 UP BND       X208                          1
 LO BND       X209                          0
 UP BND       X209                          1
 LO BND       X210                          0
 UP BND       X210                          1
 LO BND       X211                          0
 UP BND       X211                          1
 LO BND       X212                          0
 UP BND       X212                          1
 LO BND       X213                          0
 UP BND       X213                          1
 LO BND       X214                          0
 UP BND       X214                          1
 LO BND       X215                          0
 UP BND       X215                          1
 LO BND       X216                          0
 UP BND       X216                          1
 LO BND       X217                          0
 UP BND       X217                          1
 LO BND       X218                          0
 UP BND       X218                          1
 LO BND       X219                          0
 UP BND       X219                          1
 LO BND       X220                          0
 UP BND       X220                          1
 LO BND       X221                          0
 UP BND       X221                          1
 LO BND       X222                          0
 UP BND       X222                          1
 LO BND       X223                          0
 UP BND       X223                          1
 LO BND       X224                          0
 UP BND       X224                          1
 LO BND       X225                          0
 UP BND       X225                          1
 LO BND       X226                          0
 UP BND       X226                          1
 LO BND       X227                          0
 UP BND       X227                          1
 LO BND       X228                          0
 UP BND       X228                          1
 LO BND       X229                          0
 UP BND       X229                          1
 LO BND       X230                          0
 UP BND       X230                          1
 LO BND       X231                          0
 UP BND       X231                          1
 LO BND       X232                          0
 UP BND       X232                          1
 LO BND       X233                          0
 UP BND       X233                          1
 LO BND       X234                          0
 UP BND       X234                          1
 LO BND       X235                          0
 UP BND       X235                          1
 LO BND       X236                          0
 UP BND       X236                          1
 LO BND       X237                          0
 UP BND       X237                          1
 LO BND       X238                          0
 UP BND       X238                          1
 LO BND       X239                          0
 UP BND       X239                          1
 LO BND       X240                          0
 UP BND       X240                          1
 LO BND       X241                          0
 UP BND       X241                          1
 LO BND       X242                          0
 UP BND       X242                          1
 LO BND       X243                          0
 UP BND       X243                          1
 LO BND       X244                          0
 UP BND       X244                          1
 LO BND       X245                          0
 UP BND       X245                          1
 LO BND       X246                          0
 UP BND       X246                          1
 LO BND       X247                          0
 UP BND       X247                          1
 LO BND       X248                          0
 UP BND       X248                          1
 LO BND       X249                          0
 UP BND       X249                          1
 LO BND       X250                          0
 UP BND       X250                          1
 LO BND       X251                          0
 UP BND       X251                          1
 LO BND       X252                          0
 UP BND       X252                          1
 LO BND       X253                          0
 UP BND       X253                          1
 LO BND       X254                          0
 UP BND       X254                          1
 LO BND       X255                          0
 UP BND       X255                          1
 LO BND       X256                          0
 UP BND       X256                          1
 LO BND       X257                          0
 UP BND       X257                          1
 LO BND       X258                          0
 UP BND       X258                          1
 LO BND       X259                          0
 UP BND       X259                          1
 LO BND       X260                          0
 UP BND       X260                          1
 LO BND       X261                          0
 UP BND       X261                          1
 LO BND       X262                          0
 UP BND       X262                          1
 LO BND       X263                          0
 UP BND       X263                          1
 LO BND       X264                          0
 UP BND       X264                          1
 LO BND       X265                          0
 UP BND       X265                          1
 LO BND       X266                          0
 UP BND       X266                          1
 LO BND       X267                          0
 UP BND       X267                          1
 LO BND       X268                          0
 UP BND       X268                          1
 LO BND       X269                          0
 UP BND       X269                          1
 LO BND       X270                          0
 UP BND       X270                          1
 LO BND       X271                          0
 UP BND       X271                          1
 LO BND       X272                          0
 UP BND       X272                          1
 LO BND       X273                          0
 UP BND       X273                          1
 LO BND       X274                          0
 UP BND       X274                          1
 LO BND       X275                          0
 UP BND       X275                          1
 LO BND       X276                          0
 UP BND       X276                          1
 LO BND       X277                          0
 UP BND       X277                          1
 LO BND       X278                          0
 UP BND       X278                          1
 LO BND       X279                          0
 UP BND       X279                          1
 LO BND       X280                          0
 UP BND       X280                          1
 LO BND       X281                          0
 UP BND       X281                          1
 LO BND       X282                          0
 UP BND       X282                          1
 LO BND       X283                          0
 UP BND       X283                          1
 LO BND       X284                          0
 UP BND       X284                          1
 LO BND       X285                          0
 UP BND       X285                          1
 LO BND       X286                          0
 UP BND       X286                          1
 LO BND       X287                          0
 UP BND       X287                          1
 LO BND       X288                          0
 UP BND       X288                          1
 LO BND       X289                          0
 UP BND       X289                          1
 LO BND       X290                          0
 UP BND       X290                          1
 LO BND       X291                          0
 UP BND       X291                          1
 LO BND       X292                          0
 UP BND       X292                          1
 LO BND       X293                          0
 UP BND       X293                          1
 LO BND       X294                          0
 UP BND       X294                          1
 LO BND       X295                          0
 UP BND       X295                          1
 LO BND       X296                          0
 UP BND       X296                          1
 LO BND       X297                          0
 UP BND       X297                          1
 LO BND       X298                          0
 UP BND       X298                          1
 LO BND       X299                          0
 UP BND       X299                          1
 LO BND       X300                          0
 UP BND       X300                          1
 LO BND       X301                          0
 UP BND       X301                          1
 LO BND       X302                          0
 UP BND       X302                          1
 LO BND       X303                          0
 UP BND       X303                          1
 LO BND       X304                          0
 UP BND       X304                          1
 LO BND       X305                          0
 UP BND       X305                          1
 LO BND       X306                          0
 UP BND       X306                          1
 LO BND       X307                          0
 UP BND       X307                          1
 LO BND       X308                          0
 UP BND       X308                          1
 LO BND       X309                          0
 UP BND       X309                          1
 LO BND       X310                          0
 UP BND       X310                          1
 LO BND       X311                          0
 UP BND       X311                          1
 LO BND       X312                          0
 UP BND       X312                          1
 LO BND       X313                          0
 UP BND       X313                          1
 LO BND       X314                          0
 UP BND       X314                          1
 LO BND       X315                          0
 UP BND       X315                          1
 LO BND       X316                          0
 UP BND       X316                          1
 LO BND       X317                          0
 UP BND       X317                          1
 LO BND       X318                          0
 UP BND       X318                          1
 LO BND       X319                          0
 UP BND       X319                          1
 LO BND       X320                          0
 UP BND       X320                          1
 LO BND       X321                          0
 UP BND       X321                          1
 LO BND       X322                          0
 UP BND       X322                          1
 LO BND       X323                          0
 UP BND       X323                          1
 LO BND       X324                          0
 UP BND       X324                          1
 LO BND       X325                          0
 UP BND       X325                          1
 LO BND       X326                          0
 UP BND       X326                          1
 LO BND       X327                          0
 UP BND       X327                          1
 LO BND       X328                          0
 UP BND       X328                          1
 LO BND       X329                          0
 UP BND       X329                          1
 LO BND       X330                          0
 UP BND       X330                          1
 LO BND       X331                          0
 UP BND       X331                          1
 LO BND       X332                          0
 UP BND       X332                          1
 LO BND       X333                          0
 UP BND       X333                          1
 LO BND       X334                          0
 UP BND       X334                          1
 LO BND       X335                          0
 UP BND       X335                          1
 LO BND       X336                          0
 UP BND       X336                          1
 LO BND       X337                          0
 UP BND       X337                          1
 LO BND       X338                          0
 UP BND       X338                          1
 LO BND       X339                          0
 UP BND       X339                          1
 LO BND       X340                          0
 UP BND       X340                          1
 LO BND       X341                          0
 UP BND       X341                          1
 LO BND       X342                          0
 UP BND       X342                          1
 LO BND       X343                          0
 UP BND       X343                          1
 LO BND       X344                          0
 UP BND       X344                          1
 LO BND       X345                          0
 UP BND       X345                          1
 LO BND       X346                          0
 UP BND       X346                          1
 LO BND       X347                          0
 UP BND       X347                          1
 LO BND       X348                          0
 UP BND       X348                          1
 LO BND       X349                          0
 UP BND       X349                          1
 LO BND       X350                          0
 UP BND       X350                          1
 LO BND       X351                          0
 UP BND       X351                          1
 LO BND       X352                          0
 UP BND       X352                          1
 LO BND       X353                          0
 UP BND       X353                          1
 LO BND       X354                          0
 UP BND       X354                          1
 LO BND       X355                          0
 UP BND       X355                          1
 LO BND       X356                          0
 UP BND       X356                          1
 LO BND       X357                          0
 UP BND       X357                          1
 LO BND       X358                          0
 UP BND       X358                          1
 LO BND       X359                          0
 UP BND       X359                          1
 LO BND       X360                          0
 UP BND       X360                          1
 LO BND       X361                          0
 UP BND       X361                          1
 LO BND       X362                          0
 UP BND       X362                          1
 LO BND       X363                          0
 UP BND       X363                          1
 LO BND       X364                          0
 UP BND       X364                          1
 LO BND       X365                          0
 UP BND       X365                          1
 LO BND       X366                          0
 UP BND       X366                          1
 LO BND       X367                          0
 UP BND       X367                          1
 LO BND       X368                          0
 UP BND       X368                          1
 LO BND       X369                          0
 UP BND       X369                          1
 LO BND       X370                          0
 UP BND       X370                          1
 LO BND       X371                          0
 UP BND       X371                          1
 LO BND       X372                          0
 UP BND       X372                          1
 LO BND       X373                          0
 UP BND       X373                          1
 LO BND       X374                          0
 UP BND       X374                          1
 LO BND       X375                          0
 UP BND       X375                          1
 LO BND       X376                          0
 UP BND       X376                          1
 LO BND       X377                          0
 UP BND       X377                          1
 LO BND       X378                          0
 UP BND       X378                          1
 LO BND       X379                          0
 UP BND       X379                          1
 LO BND       X380                          0
 UP BND       X380                          1
 LO BND       X381                          0
 UP BND       X381                          1
 LO BND       X382                          0
 UP BND       X382                          1
 LO BND       X383                          0
 UP BND       X383                          1
 LO BND       X384                          0
 UP BND       X384                          1
 LO BND       X385                          0
 UP BND       X385                          1
 LO BND       X386                          0
 UP BND       X386                          1
 LO BND       X387                          0
 UP BND       X387                          1
 LO BND       X388                          0
 UP BND       X388                          1
 LO BND       X389                          0
 UP BND       X389                          1
 LO BND       X390                          0
 UP BND       X390                          1
 LO BND       X391                          0
 UP BND       X391                          1
 LO BND       X392                          0
 UP BND       X392                          1
 LO BND       X393                          0
 UP BND       X393                          1
 LO BND       X394                          0
 UP BND       X394                          1
 LO BND       X395                          0
 UP BND       X395                          1
 LO BND       X396                          0
 UP BND       X396                          1
 LO BND       X397                          0
 UP BND       X397                          1
 LO BND       X398                          0
 UP BND       X398                          1
 LO BND       X399                          0
 UP BND       X399                          1
 LO BND       X400                          0
 UP BND       X400                          1
 LO BND       X401                          0
 UP BND       X401                          1
 LO BND       X402                          0
 UP BND       X402                          1
 LO BND       X403                          0
 UP BND       X403                          1
 LO BND       X404                          0
 UP BND       X404                          1
 LO BND       X405                          0
 UP BND       X405                          1
 LO BND       X406                          0
 UP BND       X406                          1
 LO BND       X407                          0
 UP BND       X407                          1
 LO BND       X408                          0
 UP BND       X408                          1
 LO BND       X409                          0
 UP BND       X409                          1
 LO BND       X410                          0
 UP BND       X410                          1
 LO BND       X411                          0
 UP BND       X411                          1
 LO BND       X412                          0
 UP BND       X412                          1
 LO BND       X413                          0
 UP BND       X413                          1
 LO BND       X414                          0
 UP BND       X414                          1
 LO BND       X415                          0
 UP BND       X415                          1
 LO BND       X416                          0
 UP BND       X416                          1
 LO BND       X417                          0
 UP BND       X417                          1
 LO BND       X418                          0
 UP BND       X418                          1
 LO BND       X419                          0
 UP BND       X419                          1
 LO BND       X420                          0
 UP BND       X420                          1
 LO BND       X421                          0
 UP BND       X421                          1
 LO BND       X422                          0
 UP BND       X422                          1
 LO BND       X423                          0
 UP BND       X423                          1
 LO BND       X424                          0
 UP BND       X424                          1
 LO BND       X425                          0
 UP BND       X425                          1
 LO BND       X426                          0
 UP BND       X426                          1
 LO BND       X427                          0
 UP BND       X427                          1
 LO BND       X428                          0
 UP BND       X428                          1
 LO BND       X429                          0
 UP BND       X429                          1
 LO BND       X430                          0
 UP BND       X430                          1
 LO BND       X431                          0
 UP BND       X431                          1
 LO BND       X432                          0
 UP BND       X432                          1
 LO BND       X433                          0
 UP BND       X433                          1
 LO BND       X434                          0
 UP BND       X434                          1
 LO BND       X435                          0
 UP BND       X435                          1
ENDATA
