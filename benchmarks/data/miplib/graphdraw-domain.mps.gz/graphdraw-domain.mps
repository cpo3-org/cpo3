NAME graphdraw-domain
ROWS
 N R0
 E R1
 E R2
 E R3
 E R4
 E R5
 E R6
 E R7
 E R8
 E R9
 E R10
 E R11
 E R12
 E R13
 E R14
 E R15
 E R16
 E R17
 E R18
 E R19
 E R20
 E R21
 E R22
 E R23
 E R24
 E R25
 E R26
 E R27
 E R28
 E R29
 E R30
 E R31
 E R32
 E R33
 E R34
 E R35
 E R36
 E R37
 E R38
 E R39
 E R40
 E R41
 E R42
 E R43
 E R44
 E R45
 G R46
 G R47
 G R48
 G R49
 G R50
 G R51
 G R52
 G R53
 G R54
 G R55
 G R56
 G R57
 G R58
 G R59
 G R60
 G R61
 G R62
 G R63
 G R64
 G R65
 G R66
 G R67
 G R68
 G R69
 G R70
 G R71
 G R72
 G R73
 G R74
 G R75
 G R76
 G R77
 G R78
 G R79
 G R80
 G R81
 G R82
 G R83
 G R84
 G R85
 G R86
 G R87
 G R88
 G R89
 G R90
 G R91
 G R92
 G R93
 G R94
 G R95
 G R96
 G R97
 G R98
 G R99
 G R100
 G R101
 G R102
 G R103
 G R104
 G R105
 G R106
 G R107
 G R108
 G R109
 G R110
 G R111
 G R112
 G R113
 G R114
 G R115
 G R116
 G R117
 G R118
 G R119
 G R120
 G R121
 G R122
 G R123
 G R124
 G R125
 G R126
 G R127
 G R128
 G R129
 G R130
 G R131
 G R132
 G R133
 G R134
 G R135
 G R136
 G R137
 G R138
 G R139
 G R140
 G R141
 G R142
 G R143
 G R144
 G R145
 G R146
 G R147
 G R148
 G R149
 G R150
 G R151
 G R152
 G R153
 G R154
 G R155
 G R156
 G R157
 G R158
 G R159
 G R160
 G R161
 G R162
 G R163
 G R164
 G R165
 G R166
 G R167
 G R168
 G R169
 G R170
 G R171
 G R172
 G R173
 G R174
 G R175
 G R176
 G R177
 G R178
 G R179
 G R180
 G R181
 G R182
 G R183
 G R184
 G R185
 G R186
 G R187
 G R188
 G R189
 G R190
 G R191
 G R192
 G R193
 G R194
 G R195
 G R196
 G R197
 G R198
 G R199
 G R200
 G R201
 G R202
 G R203
 G R204
 G R205
 G R206
 G R207
 G R208
 G R209
 G R210
 G R211
 G R212
 G R213
 G R214
 G R215
 G R216
 G R217
 G R218
 G R219
 G R220
 G R221
 G R222
 G R223
 G R224
 G R225
 G R226
 G R227
 G R228
 G R229
 G R230
 G R231
 G R232
 G R233
 G R234
 G R235
 G R236
 G R237
 G R238
 G R239
 G R240
 G R241
 G R242
 G R243
 G R244
 G R245
 G R246
 G R247
 G R248
 G R249
 G R250
 G R251
 G R252
 G R253
 G R254
 G R255
 G R256
 G R257
 G R258
 G R259
 G R260
 G R261
 G R262
 G R263
 G R264
 G R265
 G R266
 G R267
 G R268
 G R269
 G R270
 G R271
 G R272
 G R273
 G R274
 G R275
 G R276
 G R277
 G R278
 G R279
 G R280
 G R281
 G R282
 G R283
 G R284
 G R285
 G R286
 G R287
 G R288
 G R289
 G R290
 G R291
 G R292
 G R293
 G R294
 G R295
 G R296
 G R297
 G R298
 G R299
 G R300
 G R301
 G R302
 G R303
 G R304
 G R305
 G R306
 G R307
 G R308
 G R309
 G R310
 G R311
 G R312
 G R313
 G R314
 G R315
 G R316
 G R317
 G R318
 G R319
 G R320
 G R321
 G R322
 G R323
 G R324
 G R325
 G R326
 G R327
 G R328
 G R329
 G R330
 G R331
 G R332
 G R333
 G R334
 G R335
 G R336
 G R337
 G R338
 G R339
 G R340
 G R341
 G R342
 G R343
 G R344
 G R345
 G R346
 G R347
 G R348
 G R349
 G R350
 G R351
 G R352
 G R353
 G R354
 G R355
 G R356
 G R357
 G R358
 G R359
 G R360
 G R361
 G R362
 G R363
 G R364
 G R365
 G R366
 G R367
 G R368
 G R369
 G R370
 G R371
 G R372
 G R373
 G R374
 G R375
 G R376
 G R377
 G R378
 G R379
 G R380
 G R381
 G R382
 G R383
 G R384
 G R385
 L R386
 L R387
 L R388
 L R389
 L R390
 L R391
 L R392
 L R393
 L R394
 L R395
 L R396
 L R397
 L R398
 L R399
 L R400
 L R401
 L R402
 L R403
 L R404
 L R405
 L R406
 L R407
 L R408
 L R409
 L R410
 L R411
 L R412
 L R413
 L R414
 L R415
 L R416
 L R417
 L R418
 L R419
 L R420
 L R421
 L R422
 L R423
 L R424
 L R425
 L R426
 L R427
 L R428
 L R429
 L R430
 L R431
 L R432
 L R433
 L R434
 L R435
 L R436
 L R437
 L R438
 L R439
 L R440
 L R441
 L R442
 L R443
 L R444
 L R445
 L R446
 L R447
 L R448
 L R449
 L R450
 L R451
 L R452
 L R453
 L R454
 L R455
 L R456
 L R457
 L R458
 L R459
 L R460
 L R461
 L R462
 L R463
 L R464
 L R465
 L R466
 L R467
 L R468
 L R469
 L R470
 L R471
 L R472
 L R473
 L R474
 L R475
 L R476
 L R477
 L R478
 L R479
 L R480
 L R481
 L R482
 L R483
 L R484
 L R485
 L R486
 L R487
 L R488
 L R489
 L R490
 L R491
 L R492
 L R493
 L R494
 L R495
 L R496
 L R497
 L R498
 L R499
 L R500
 L R501
 L R502
 L R503
 L R504
 L R505
 L R506
 L R507
 L R508
 L R509
 L R510
 L R511
 L R512
 L R513
 L R514
 L R515
 L R516
 L R517
 L R518
 L R519
 L R520
 L R521
 L R522
 L R523
 L R524
 L R525
 L R526
 L R527
 L R528
 L R529
 L R530
 L R531
 L R532
 L R533
 L R534
 L R535
 L R536
 L R537
 L R538
 L R539
 L R540
 L R541
 L R542
 L R543
 L R544
 L R545
 L R546
 L R547
 L R548
 L R549
 L R550
 L R551
 L R552
 L R553
 L R554
 L R555
 L R556
 L R557
 L R558
 L R559
 L R560
 L R561
 L R562
 L R563
 L R564
 L R565
 L R566
 L R567
 L R568
 L R569
 L R570
 L R571
 L R572
 L R573
 L R574
 L R575
 L R576
 L R577
 L R578
 L R579
 L R580
 L R581
 L R582
 L R583
 L R584
 L R585
 L R586
 L R587
 L R588
 L R589
 L R590
 L R591
 L R592
 L R593
 L R594
 L R595
 L R596
 L R597
 L R598
 L R599
 L R600
 L R601
 L R602
 L R603
 L R604
 L R605
 L R606
 L R607
 L R608
 L R609
 L R610
 L R611
 L R612
 L R613
 L R614
 L R615
 L R616
 L R617
 L R618
 L R619
 L R620
 L R621
 L R622
 L R623
 L R624
 L R625
 L R626
 L R627
 L R628
 L R629
 L R630
 L R631
 L R632
 L R633
 L R634
 L R635
 L R636
 L R637
 L R638
 L R639
 L R640
 L R641
 L R642
 L R643
 L R644
 L R645
 L R646
 L R647
 L R648
 L R649
 L R650
 L R651
 L R652
 L R653
 L R654
 L R655
 L R656
 L R657
 L R658
 L R659
 L R660
 L R661
 L R662
 L R663
 L R664
 L R665
 L R666
 L R667
 L R668
 L R669
 L R670
 L R671
 L R672
 L R673
 L R674
 L R675
 L R676
 L R677
 L R678
 L R679
 L R680
 L R681
 L R682
 L R683
 L R684
 L R685
 L R686
 L R687
 L R688
 L R689
 L R690
 L R691
 L R692
 L R693
 L R694
 L R695
 L R696
 L R697
 L R698
 L R699
 L R700
 L R701
 L R702
 L R703
 L R704
 L R705
 L R706
 L R707
 L R708
 L R709
 L R710
 L R711
 L R712
 L R713
 L R714
 L R715
 L R716
 L R717
 L R718
 L R719
 L R720
 L R721
 L R722
 L R723
 L R724
 L R725
 L R726
 L R727
 L R728
 L R729
 L R730
 L R731
 L R732
 L R733
 L R734
 L R735
 L R736
 L R737
 L R738
 L R739
 L R740
 L R741
 L R742
 L R743
 L R744
 L R745
 L R746
 L R747
 L R748
 L R749
 L R750
 L R751
 L R752
 L R753
 L R754
 L R755
 L R756
 L R757
 L R758
 L R759
 L R760
 L R761
 L R762
 L R763
 L R764
 L R765
 L R766
 L R767
 L R768
 L R769
 L R770
 L R771
 L R772
 L R773
 L R774
 L R775
 L R776
 L R777
 L R778
 L R779
 L R780
 L R781
 L R782
 L R783
 L R784
 L R785
 L R786
 L R787
 L R788
 L R789
 L R790
 L R791
 L R792
 L R793
 L R794
 L R795
 L R796
 L R797
 L R798
 L R799
 L R800
 L R801
 L R802
 L R803
 L R804
 L R805
 L R806
 L R807
 L R808
 L R809
 L R810
 L R811
 L R812
 L R813
 L R814
 L R815
 L R816
 L R817
 L R818
 L R819
 L R820
 L R821
 L R822
 L R823
 L R824
 L R825
 L R826
 L R827
 L R828
 L R829
 L R830
 L R831
 L R832
 L R833
 L R834
 L R835
 L R836
 L R837
 L R838
 L R839
 L R840
 L R841
 L R842
 L R843
 L R844
 L R845
 L R846
 L R847
 L R848
 L R849
 L R850
 L R851
 L R852
 L R853
 L R854
 L R855
 L R856
 L R857
 L R858
 L R859
 L R860
 L R861
 L R862
 L R863
 L R864
 L R865
COLUMNS
    X0        R46                           1
    X0        R66                           -1
    X0        R86                           -1
    X0        R87                           -1
    X0        R88                           -1
    X0        R89                           -1
    X0        R90                           -1
    X0        R91                           -1
    X0        R92                           -1
    X0        R93                           -1
    X0        R94                           -1
    X0        R176                          1
    X0        R177                          1
    X0        R178                          1
    X0        R179                          1
    X0        R180                          1
    X0        R181                          1
    X0        R182                          1
    X0        R183                          1
    X0        R184                          1
    X0        R266                          -1
    X0        R267                          -1
    X0        R268                          -1
    X0        R269                          -1
    X0        R270                          -1
    X0        R300                          1
    X0        R301                          1
    X0        R302                          1
    X0        R303                          1
    X0        R304                          1
    X1        R47                           1
    X1        R67                           -1
    X1        R86                           1
    X1        R95                           -1
    X1        R96                           -1
    X1        R97                           -1
    X1        R98                           -1
    X1        R99                           -1
    X1        R100                          -1
    X1        R101                          -1
    X1        R102                          -1
    X1        R176                          -1
    X1        R185                          1
    X1        R186                          1
    X1        R187                          1
    X1        R188                          1
    X1        R189                          1
    X1        R190                          1
    X1        R191                          1
    X1        R192                          1
    X1        R266                          1
    X1        R271                          -1
    X1        R300                          -1
    X1        R305                          1
    X2        R48                           1
    X2        R68                           -1
    X2        R87                           1
    X2        R95                           1
    X2        R103                          -1
    X2        R104                          -1
    X2        R105                          -1
    X2        R106                          -1
    X2        R107                          -1
    X2        R108                          -1
    X2        R109                          -1
    X2        R177                          -1
    X2        R185                          -1
    X2        R193                          1
    X2        R194                          1
    X2        R195                          1
    X2        R196                          1
    X2        R197                          1
    X2        R198                          1
    X2        R199                          1
    X2        R272                          -1
    X2        R306                          1
    X3        R49                           1
    X3        R69                           -1
    X3        R88                           1
    X3        R96                           1
    X3        R103                          1
    X3        R110                          -1
    X3        R111                          -1
    X3        R112                          -1
    X3        R113                          -1
    X3        R114                          -1
    X3        R115                          -1
    X3        R178                          -1
    X3        R186                          -1
    X3        R193                          -1
    X3        R200                          1
    X3        R201                          1
    X3        R202                          1
    X3        R203                          1
    X3        R204                          1
    X3        R205                          1
    X3        R280                          -1
    X3        R314                          1
    X4        R50                           1
    X4        R70                           -1
    X4        R89                           1
    X4        R97                           1
    X4        R104                          1
    X4        R110                          1
    X4        R116                          -1
    X4        R117                          -1
    X4        R118                          -1
    X4        R119                          -1
    X4        R120                          -1
    X4        R179                          -1
    X4        R187                          -1
    X4        R194                          -1
    X4        R200                          -1
    X4        R206                          1
    X4        R207                          1
    X4        R208                          1
    X4        R209                          1
    X4        R210                          1
    X4        R270                          1
    X4        R280                          1
    X4        R281                          -1
    X4        R282                          -1
    X4        R304                          -1
    X4        R314                          -1
    X4        R315                          1
    X4        R316                          1
    X5        R51                           1
    X5        R71                           -1
    X5        R90                           1
    X5        R98                           1
    X5        R105                          1
    X5        R111                          1
    X5        R116                          1
    X5        R121                          -1
    X5        R122                          -1
    X5        R123                          -1
    X5        R124                          -1
    X5        R180                          -1
    X5        R188                          -1
    X5        R195                          -1
    X5        R201                          -1
    X5        R206                          -1
    X5        R211                          1
    X5        R212                          1
    X5        R213                          1
    X5        R214                          1
    X5        R267                          1
    X5        R271                          1
    X5        R272                          1
    X5        R273                          -1
    X5        R278                          1
    X5        R279                          1
    X5        R301                          -1
    X5        R305                          -1
    X5        R306                          -1
    X5        R307                          1
    X5        R312                          -1
    X5        R313                          -1
    X6        R52                           1
    X6        R72                           -1
    X6        R91                           1
    X6        R99                           1
    X6        R106                          1
    X6        R112                          1
    X6        R117                          1
    X6        R121                          1
    X6        R125                          -1
    X6        R126                          -1
    X6        R127                          -1
    X6        R181                          -1
    X6        R189                          -1
    X6        R196                          -1
    X6        R202                          -1
    X6        R207                          -1
    X6        R211                          -1
    X6        R215                          1
    X6        R216                          1
    X6        R217                          1
    X6        R275                          -1
    X6        R276                          -1
    X6        R309                          1
    X6        R310                          1
    X7        R53                           1
    X7        R73                           -1
    X7        R92                           1
    X7        R100                          1
    X7        R107                          1
    X7        R113                          1
    X7        R118                          1
    X7        R122                          1
    X7        R125                          1
    X7        R128                          -1
    X7        R129                          -1
    X7        R182                          -1
    X7        R190                          -1
    X7        R197                          -1
    X7        R203                          -1
    X7        R208                          -1
    X7        R212                          -1
    X7        R215                          -1
    X7        R218                          1
    X7        R219                          1
    X7        R269                          1
    X7        R274                          1
    X7        R275                          1
    X7        R277                          -1
    X7        R278                          -1
    X7        R303                          -1
    X7        R308                          -1
    X7        R309                          -1
    X7        R311                          1
    X7        R312                          1
    X8        R54                           1
    X8        R74                           -1
    X8        R93                           1
    X8        R101                          1
    X8        R108                          1
    X8        R114                          1
    X8        R119                          1
    X8        R123                          1
    X8        R126                          1
    X8        R128                          1
    X8        R130                          -1
    X8        R183                          -1
    X8        R191                          -1
    X8        R198                          -1
    X8        R204                          -1
    X8        R209                          -1
    X8        R213                          -1
    X8        R216                          -1
    X8        R218                          -1
    X8        R220                          1
    X8        R276                          1
    X8        R277                          1
    X8        R279                          -1
    X8        R282                          1
    X8        R310                          -1
    X8        R311                          -1
    X8        R313                          1
    X8        R316                          -1
    X9        R55                           1
    X9        R75                           -1
    X9        R94                           1
    X9        R102                          1
    X9        R109                          1
    X9        R115                          1
    X9        R120                          1
    X9        R124                          1
    X9        R127                          1
    X9        R129                          1
    X9        R130                          1
    X9        R184                          -1
    X9        R192                          -1
    X9        R199                          -1
    X9        R205                          -1
    X9        R210                          -1
    X9        R214                          -1
    X9        R217                          -1
    X9        R219                          -1
    X9        R220                          -1
    X9        R268                          1
    X9        R273                          1
    X9        R274                          -1
    X9        R281                          1
    X9        R302                          -1
    X9        R307                          -1
    X9        R308                          1
    X9        R315                          -1
    X10       R56                           1
    X10       R76                           -1
    X10       R131                          -1
    X10       R132                          -1
    X10       R133                          -1
    X10       R134                          -1
    X10       R135                          -1
    X10       R136                          -1
    X10       R137                          -1
    X10       R138                          -1
    X10       R139                          -1
    X10       R221                          1
    X10       R222                          1
    X10       R223                          1
    X10       R224                          1
    X10       R225                          1
    X10       R226                          1
    X10       R227                          1
    X10       R228                          1
    X10       R229                          1
    X10       R283                          -1
    X10       R284                          -1
    X10       R285                          -1
    X10       R286                          -1
    X10       R287                          -1
    X10       R317                          1
    X10       R318                          1
    X10       R319                          1
    X10       R320                          1
    X10       R321                          1
    X11       R57                           1
    X11       R77                           -1
    X11       R131                          1
    X11       R140                          -1
    X11       R141                          -1
    X11       R142                          -1
    X11       R143                          -1
    X11       R144                          -1
    X11       R145                          -1
    X11       R146                          -1
    X11       R147                          -1
    X11       R221                          -1
    X11       R230                          1
    X11       R231                          1
    X11       R232                          1
    X11       R233                          1
    X11       R234                          1
    X11       R235                          1
    X11       R236                          1
    X11       R237                          1
    X11       R283                          1
    X11       R288                          -1
    X11       R317                          -1
    X11       R322                          1
    X12       R58                           1
    X12       R78                           -1
    X12       R132                          1
    X12       R140                          1
    X12       R148                          -1
    X12       R149                          -1
    X12       R150                          -1
    X12       R151                          -1
    X12       R152                          -1
    X12       R153                          -1
    X12       R154                          -1
    X12       R222                          -1
    X12       R230                          -1
    X12       R238                          1
    X12       R239                          1
    X12       R240                          1
    X12       R241                          1
    X12       R242                          1
    X12       R243                          1
    X12       R244                          1
    X12       R289                          -1
    X12       R323                          1
    X13       R59                           1
    X13       R79                           -1
    X13       R133                          1
    X13       R141                          1
    X13       R148                          1
    X13       R155                          -1
    X13       R156                          -1
    X13       R157                          -1
    X13       R158                          -1
    X13       R159                          -1
    X13       R160                          -1
    X13       R223                          -1
    X13       R231                          -1
    X13       R238                          -1
    X13       R245                          1
    X13       R246                          1
    X13       R247                          1
    X13       R248                          1
    X13       R249                          1
    X13       R250                          1
    X13       R297                          -1
    X13       R331                          1
    X14       R60                           1
    X14       R80                           -1
    X14       R134                          1
    X14       R142                          1
    X14       R149                          1
    X14       R155                          1
    X14       R161                          -1
    X14       R162                          -1
    X14       R163                          -1
    X14       R164                          -1
    X14       R165                          -1
    X14       R224                          -1
    X14       R232                          -1
    X14       R239                          -1
    X14       R245                          -1
    X14       R251                          1
    X14       R252                          1
    X14       R253                          1
    X14       R254                          1
    X14       R255                          1
    X14       R287                          1
    X14       R297                          1
    X14       R298                          -1
    X14       R299                          -1
    X14       R321                          -1
    X14       R331                          -1
    X14       R332                          1
    X14       R333                          1
    X15       R61                           1
    X15       R81                           -1
    X15       R135                          1
    X15       R143                          1
    X15       R150                          1
    X15       R156                          1
    X15       R161                          1
    X15       R166                          -1
    X15       R167                          -1
    X15       R168                          -1
    X15       R169                          -1
    X15       R225                          -1
    X15       R233                          -1
    X15       R240                          -1
    X15       R246                          -1
    X15       R251                          -1
    X15       R256                          1
    X15       R257                          1
    X15       R258                          1
    X15       R259                          1
    X15       R284                          1
    X15       R288                          1
    X15       R289                          1
    X15       R290                          -1
    X15       R295                          1
    X15       R296                          1
    X15       R318                          -1
    X15       R322                          -1
    X15       R323                          -1
    X15       R324                          1
    X15       R329                          -1
    X15       R330                          -1
    X16       R62                           1
    X16       R82                           -1
    X16       R136                          1
    X16       R144                          1
    X16       R151                          1
    X16       R157                          1
    X16       R162                          1
    X16       R166                          1
    X16       R170                          -1
    X16       R171                          -1
    X16       R172                          -1
    X16       R226                          -1
    X16       R234                          -1
    X16       R241                          -1
    X16       R247                          -1
    X16       R252                          -1
    X16       R256                          -1
    X16       R260                          1
    X16       R261                          1
    X16       R262                          1
    X16       R292                          -1
    X16       R293                          -1
    X16       R326                          1
    X16       R327                          1
    X17       R63                           1
    X17       R83                           -1
    X17       R137                          1
    X17       R145                          1
    X17       R152                          1
    X17       R158                          1
    X17       R163                          1
    X17       R167                          1
    X17       R170                          1
    X17       R173                          -1
    X17       R174                          -1
    X17       R227                          -1
    X17       R235                          -1
    X17       R242                          -1
    X17       R248                          -1
    X17       R253                          -1
    X17       R257                          -1
    X17       R260                          -1
    X17       R263                          1
    X17       R264                          1
    X17       R286                          1
    X17       R291                          1
    X17       R292                          1
    X17       R294                          -1
    X17       R295                          -1
    X17       R320                          -1
    X17       R325                          -1
    X17       R326                          -1
    X17       R328                          1
    X17       R329                          1
    X18       R64                           1
    X18       R84                           -1
    X18       R138                          1
    X18       R146                          1
    X18       R153                          1
    X18       R159                          1
    X18       R164                          1
    X18       R168                          1
    X18       R171                          1
    X18       R173                          1
    X18       R175                          -1
    X18       R228                          -1
    X18       R236                          -1
    X18       R243                          -1
    X18       R249                          -1
    X18       R254                          -1
    X18       R258                          -1
    X18       R261                          -1
    X18       R263                          -1
    X18       R265                          1
    X18       R293                          1
    X18       R294                          1
    X18       R296                          -1
    X18       R299                          1
    X18       R327                          -1
    X18       R328                          -1
    X18       R330                          1
    X18       R333                          -1
    X19       R65                           1
    X19       R85                           -1
    X19       R139                          1
    X19       R147                          1
    X19       R154                          1
    X19       R160                          1
    X19       R165                          1
    X19       R169                          1
    X19       R172                          1
    X19       R174                          1
    X19       R175                          1
    X19       R229                          -1
    X19       R237                          -1
    X19       R244                          -1
    X19       R250                          -1
    X19       R255                          -1
    X19       R259                          -1
    X19       R262                          -1
    X19       R264                          -1
    X19       R265                          -1
    X19       R285                          1
    X19       R290                          1
    X19       R291                          -1
    X19       R298                          1
    X19       R319                          -1
    X19       R324                          -1
    X19       R325                          1
    X19       R332                          -1
    X20       R0                            1
    X20       R46                           1
    X20       R66                           1
    X20       R351                          1
    X21       R0                            1
    X21       R47                           1
    X21       R67                           1
    X21       R351                          1
    X22       R0                            1
    X22       R48                           1
    X22       R68                           1
    X22       R351                          1
    X23       R0                            1
    X23       R49                           1
    X23       R69                           1
    X23       R351                          1
    X24       R0                            1
    X24       R50                           1
    X24       R70                           1
    X24       R351                          1
    X25       R0                            1
    X25       R51                           1
    X25       R71                           1
    X25       R351                          1
    X26       R0                            1
    X26       R52                           1
    X26       R72                           1
    X26       R351                          1
    X27       R0                            1
    X27       R53                           1
    X27       R73                           1
    X27       R351                          1
    X28       R0                            1
    X28       R54                           1
    X28       R74                           1
    X28       R351                          1
    X29       R0                            1
    X29       R55                           1
    X29       R75                           1
    X29       R351                          1
    X30       R0                            1
    X30       R56                           1
    X30       R76                           1
    X30       R351                          1
    X31       R0                            1
    X31       R57                           1
    X31       R77                           1
    X31       R351                          1
    X32       R0                            1
    X32       R58                           1
    X32       R78                           1
    X32       R351                          1
    X33       R0                            1
    X33       R59                           1
    X33       R79                           1
    X33       R351                          1
    X34       R0                            1
    X34       R60                           1
    X34       R80                           1
    X34       R351                          1
    X35       R0                            1
    X35       R61                           1
    X35       R81                           1
    X35       R351                          1
    X36       R0                            1
    X36       R62                           1
    X36       R82                           1
    X36       R351                          1
    X37       R0                            1
    X37       R63                           1
    X37       R83                           1
    X37       R351                          1
    X38       R0                            1
    X38       R64                           1
    X38       R84                           1
    X38       R351                          1
    X39       R0                            1
    X39       R65                           1
    X39       R85                           1
    X39       R351                          1
    X40       R0                            86
    X40       R266                          1
    X40       R300                          1
    X40       R334                          1
    X40       R352                          1
    X41       R0                            86
    X41       R267                          1
    X41       R301                          1
    X41       R335                          1
    X41       R353                          1
    X42       R0                            86
    X42       R268                          1
    X42       R302                          1
    X42       R336                          1
    X42       R354                          1
    X43       R0                            86
    X43       R269                          1
    X43       R303                          1
    X43       R337                          1
    X43       R355                          1
    X44       R0                            86
    X44       R270                          1
    X44       R304                          1
    X44       R338                          1
    X44       R356                          1
    X45       R0                            86
    X45       R271                          1
    X45       R305                          1
    X45       R339                          1
    X45       R357                          1
    X46       R0                            86
    X46       R272                          1
    X46       R306                          1
    X46       R340                          1
    X46       R358                          1
    X47       R0                            86
    X47       R273                          1
    X47       R307                          1
    X47       R341                          1
    X47       R359                          1
    X48       R0                            86
    X48       R274                          1
    X48       R308                          1
    X48       R342                          1
    X48       R360                          1
    X49       R0                            86
    X49       R275                          1
    X49       R309                          1
    X49       R343                          1
    X49       R361                          1
    X50       R0                            86
    X50       R276                          1
    X50       R310                          1
    X50       R344                          1
    X50       R362                          1
    X51       R0                            86
    X51       R277                          1
    X51       R311                          1
    X51       R345                          1
    X51       R363                          1
    X52       R0                            86
    X52       R278                          1
    X52       R312                          1
    X52       R346                          1
    X52       R364                          1
    X53       R0                            86
    X53       R279                          1
    X53       R313                          1
    X53       R347                          1
    X53       R365                          1
    X54       R0                            86
    X54       R280                          1
    X54       R314                          1
    X54       R348                          1
    X54       R366                          1
    X55       R0                            86
    X55       R281                          1
    X55       R315                          1
    X55       R349                          1
    X55       R367                          1
    X56       R0                            86
    X56       R282                          1
    X56       R316                          1
    X56       R350                          1
    X56       R368                          1
    X57       R0                            86
    X57       R283                          1
    X57       R317                          1
    X57       R334                          1
    X57       R369                          1
    X58       R0                            86
    X58       R284                          1
    X58       R318                          1
    X58       R335                          1
    X58       R370                          1
    X59       R0                            86
    X59       R285                          1
    X59       R319                          1
    X59       R336                          1
    X59       R371                          1
    X60       R0                            86
    X60       R286                          1
    X60       R320                          1
    X60       R337                          1
    X60       R372                          1
    X61       R0                            86
    X61       R287                          1
    X61       R321                          1
    X61       R338                          1
    X61       R373                          1
    X62       R0                            86
    X62       R288                          1
    X62       R322                          1
    X62       R339                          1
    X62       R374                          1
    X63       R0                            86
    X63       R289                          1
    X63       R323                          1
    X63       R340                          1
    X63       R375                          1
    X64       R0                            86
    X64       R290                          1
    X64       R324                          1
    X64       R341                          1
    X64       R376                          1
    X65       R0                            86
    X65       R291                          1
    X65       R325                          1
    X65       R342                          1
    X65       R377                          1
    X66       R0                            86
    X66       R292                          1
    X66       R326                          1
    X66       R343                          1
    X66       R378                          1
    X67       R0                            86
    X67       R293                          1
    X67       R327                          1
    X67       R344                          1
    X67       R379                          1
    X68       R0                            86
    X68       R294                          1
    X68       R328                          1
    X68       R345                          1
    X68       R380                          1
    X69       R0                            86
    X69       R295                          1
    X69       R329                          1
    X69       R346                          1
    X69       R381                          1
    X70       R0                            86
    X70       R296                          1
    X70       R330                          1
    X70       R347                          1
    X70       R382                          1
    X71       R0                            86
    X71       R297                          1
    X71       R331                          1
    X71       R348                          1
    X71       R383                          1
    X72       R0                            86
    X72       R298                          1
    X72       R332                          1
    X72       R349                          1
    X72       R384                          1
    X73       R0                            86
    X73       R299                          1
    X73       R333                          1
    X73       R350                          1
    X73       R385                          1
    X74       R1                            1
    X74       R176                          -49
    X74       R369                          11.5
    X74       R386                          1
    X74       R388                          1
    X74       R390                          1
    X74       R392                          1
    X74       R394                          1
    X74       R396                          1
    X74       R398                          1
    X74       R400                          1
    X75       R1                            1
    X75       R221                          -54
    X75       R352                          8
    X75       R387                          1
    X75       R389                          1
    X75       R391                          1
    X75       R393                          1
    X75       R395                          1
    X75       R397                          1
    X75       R399                          1
    X75       R401                          1
    X76       R1                            1
    X76       R86                           -51
    X76       R369                          11.5
    X76       R626                          1
    X76       R628                          1
    X76       R630                          1
    X76       R632                          1
    X76       R634                          1
    X76       R636                          1
    X76       R638                          1
    X76       R640                          1
    X77       R1                            1
    X77       R131                          -53
    X77       R352                          8
    X77       R627                          1
    X77       R629                          1
    X77       R631                          1
    X77       R633                          1
    X77       R635                          1
    X77       R637                          1
    X77       R639                          1
    X77       R641                          1
    X78       R2                            1
    X78       R177                          -48
    X78       R402                          1
    X78       R404                          1
    X78       R406                          1
    X78       R408                          1
    X78       R410                          1
    X78       R412                          1
    X78       R414                          1
    X78       R626                          1
    X79       R2                            1
    X79       R222                          -52
    X79       R403                          1
    X79       R405                          1
    X79       R407                          1
    X79       R409                          1
    X79       R411                          1
    X79       R413                          1
    X79       R415                          1
    X79       R627                          1
    X80       R2                            1
    X80       R87                           -51
    X80       R386                          1
    X80       R642                          1
    X80       R644                          1
    X80       R646                          1
    X80       R648                          1
    X80       R650                          1
    X80       R652                          1
    X80       R654                          1
    X81       R2                            1
    X81       R132                          -53
    X81       R387                          1
    X81       R643                          1
    X81       R645                          1
    X81       R647                          1
    X81       R649                          1
    X81       R651                          1
    X81       R653                          1
    X81       R655                          1
    X82       R3                            1
    X82       R178                          -48
    X82       R416                          1
    X82       R418                          1
    X82       R420                          1
    X82       R422                          1
    X82       R424                          1
    X82       R426                          1
    X82       R628                          1
    X82       R642                          1
    X83       R3                            1
    X83       R223                          -52
    X83       R417                          1
    X83       R419                          1
    X83       R421                          1
    X83       R423                          1
    X83       R425                          1
    X83       R427                          1
    X83       R629                          1
    X83       R643                          1
    X84       R3                            1
    X84       R88                           -51
    X84       R388                          1
    X84       R402                          1
    X84       R656                          1
    X84       R658                          1
    X84       R660                          1
    X84       R662                          1
    X84       R664                          1
    X84       R666                          1
    X85       R3                            1
    X85       R133                          -53
    X85       R389                          1
    X85       R403                          1
    X85       R657                          1
    X85       R659                          1
    X85       R661                          1
    X85       R663                          1
    X85       R665                          1
    X85       R667                          1
    X86       R4                            1
    X86       R179                          -49
    X86       R373                          11
    X86       R428                          1
    X86       R430                          1
    X86       R432                          1
    X86       R434                          1
    X86       R436                          1
    X86       R630                          1
    X86       R644                          1
    X86       R656                          1
    X87       R4                            1
    X87       R224                          -53
    X87       R356                          8
    X87       R429                          1
    X87       R431                          1
    X87       R433                          1
    X87       R435                          1
    X87       R437                          1
    X87       R631                          1
    X87       R645                          1
    X87       R657                          1
    X88       R4                            1
    X88       R89                           -51
    X88       R373                          11
    X88       R390                          1
    X88       R404                          1
    X88       R416                          1
    X88       R668                          1
    X88       R670                          1
    X88       R672                          1
    X88       R674                          1
    X88       R676                          1
    X89       R4                            1
    X89       R134                          -53
    X89       R356                          8
    X89       R391                          1
    X89       R405                          1
    X89       R417                          1
    X89       R669                          1
    X89       R671                          1
    X89       R673                          1
    X89       R675                          1
    X89       R677                          1
    X90       R5                            1
    X90       R180                          -51
    X90       R370                          12.5
    X90       R438                          1
    X90       R440                          1
    X90       R442                          1
    X90       R444                          1
    X90       R632                          1
    X90       R646                          1
    X90       R658                          1
    X90       R668                          1
    X91       R5                            1
    X91       R225                          -56
    X91       R353                          9
    X91       R439                          1
    X91       R441                          1
    X91       R443                          1
    X91       R445                          1
    X91       R633                          1
    X91       R647                          1
    X91       R659                          1
    X91       R669                          1
    X92       R5                            1
    X92       R90                           -51
    X92       R370                          12.5
    X92       R392                          1
    X92       R406                          1
    X92       R418                          1
    X92       R428                          1
    X92       R678                          1
    X92       R680                          1
    X92       R682                          1
    X92       R684                          1
    X93       R5                            1
    X93       R135                          -53
    X93       R353                          9
    X93       R393                          1
    X93       R407                          1
    X93       R419                          1
    X93       R429                          1
    X93       R679                          1
    X93       R681                          1
    X93       R683                          1
    X93       R685                          1
    X94       R6                            1
    X94       R181                          -50
    X94       R446                          1
    X94       R448                          1
    X94       R450                          1
    X94       R634                          1
    X94       R648                          1
    X94       R660                          1
    X94       R670                          1
    X94       R678                          1
    X95       R6                            1
    X95       R226                          -53
    X95       R447                          1
    X95       R449                          1
    X95       R451                          1
    X95       R635                          1
    X95       R649                          1
    X95       R661                          1
    X95       R671                          1
    X95       R679                          1
    X96       R6                            1
    X96       R91                           -51
    X96       R394                          1
    X96       R408                          1
    X96       R420                          1
    X96       R430                          1
    X96       R438                          1
    X96       R686                          1
    X96       R688                          1
    X96       R690                          1
    X97       R6                            1
    X97       R136                          -53
    X97       R395                          1
    X97       R409                          1
    X97       R421                          1
    X97       R431                          1
    X97       R439                          1
    X97       R687                          1
    X97       R689                          1
    X97       R691                          1
    X98       R7                            1
    X98       R182                          -51
    X98       R372                          11
    X98       R452                          1
    X98       R454                          1
    X98       R636                          1
    X98       R650                          1
    X98       R662                          1
    X98       R672                          1
    X98       R680                          1
    X98       R686                          1
    X99       R7                            1
    X99       R227                          -53
    X99       R355                          9
    X99       R453                          1
    X99       R455                          1
    X99       R637                          1
    X99       R651                          1
    X99       R663                          1
    X99       R673                          1
    X99       R681                          1
    X99       R687                          1
    X100      R7                            1
    X100      R92                           -51
    X100      R372                          11
    X100      R396                          1
    X100      R410                          1
    X100      R422                          1
    X100      R432                          1
    X100      R440                          1
    X100      R446                          1
    X100      R692                          1
    X100      R694                          1
    X101      R7                            1
    X101      R137                          -53
    X101      R355                          9
    X101      R397                          1
    X101      R411                          1
    X101      R423                          1
    X101      R433                          1
    X101      R441                          1
    X101      R447                          1
    X101      R693                          1
    X101      R695                          1
    X102      R8                            1
    X102      R183                          -52
    X102      R456                          1
    X102      R638                          1
    X102      R652                          1
    X102      R664                          1
    X102      R674                          1
    X102      R682                          1
    X102      R688                          1
    X102      R692                          1
    X103      R8                            1
    X103      R228                          -53
    X103      R457                          1
    X103      R639                          1
    X103      R653                          1
    X103      R665                          1
    X103      R675                          1
    X103      R683                          1
    X103      R689                          1
    X103      R693                          1
    X104      R8                            1
    X104      R93                           -51
    X104      R398                          1
    X104      R412                          1
    X104      R424                          1
    X104      R434                          1
    X104      R442                          1
    X104      R448                          1
    X104      R452                          1
    X104      R696                          1
    X105      R8                            1
    X105      R138                          -53
    X105      R399                          1
    X105      R413                          1
    X105      R425                          1
    X105      R435                          1
    X105      R443                          1
    X105      R449                          1
    X105      R453                          1
    X105      R697                          1
    X106      R9                            1
    X106      R184                          -52
    X106      R371                          11.5
    X106      R640                          1
    X106      R654                          1
    X106      R666                          1
    X106      R676                          1
    X106      R684                          1
    X106      R690                          1
    X106      R694                          1
    X106      R696                          1
    X107      R9                            1
    X107      R229                          -54
    X107      R354                          9.5
    X107      R641                          1
    X107      R655                          1
    X107      R667                          1
    X107      R677                          1
    X107      R685                          1
    X107      R691                          1
    X107      R695                          1
    X107      R697                          1
    X108      R9                            1
    X108      R94                           -51
    X108      R371                          11.5
    X108      R400                          1
    X108      R414                          1
    X108      R426                          1
    X108      R436                          1
    X108      R444                          1
    X108      R450                          1
    X108      R454                          1
    X108      R456                          1
    X109      R9                            1
    X109      R139                          -53
    X109      R354                          9.5
    X109      R401                          1
    X109      R415                          1
    X109      R427                          1
    X109      R437                          1
    X109      R445                          1
    X109      R451                          1
    X109      R455                          1
    X109      R457                          1
    X110      R10                           1
    X110      R185                          -48
    X110      R386                          1
    X110      R458                          1
    X110      R460                          1
    X110      R462                          1
    X110      R464                          1
    X110      R466                          1
    X110      R468                          1
    X110      R470                          1
    X111      R10                           1
    X111      R230                          -52
    X111      R387                          1
    X111      R459                          1
    X111      R461                          1
    X111      R463                          1
    X111      R465                          1
    X111      R467                          1
    X111      R469                          1
    X111      R471                          1
    X112      R10                           1
    X112      R95                           -49
    X112      R626                          1
    X112      R698                          1
    X112      R700                          1
    X112      R702                          1
    X112      R704                          1
    X112      R706                          1
    X112      R708                          1
    X112      R710                          1
    X113      R10                           1
    X113      R140                          -54
    X113      R627                          1
    X113      R699                          1
    X113      R701                          1
    X113      R703                          1
    X113      R705                          1
    X113      R707                          1
    X113      R709                          1
    X113      R711                          1
    X114      R11                           1
    X114      R186                          -48
    X114      R388                          1
    X114      R472                          1
    X114      R474                          1
    X114      R476                          1
    X114      R478                          1
    X114      R480                          1
    X114      R482                          1
    X114      R698                          1
    X115      R11                           1
    X115      R231                          -52
    X115      R389                          1
    X115      R473                          1
    X115      R475                          1
    X115      R477                          1
    X115      R479                          1
    X115      R481                          1
    X115      R483                          1
    X115      R699                          1
    X116      R11                           1
    X116      R96                           -49
    X116      R458                          1
    X116      R628                          1
    X116      R712                          1
    X116      R714                          1
    X116      R716                          1
    X116      R718                          1
    X116      R720                          1
    X116      R722                          1
    X117      R11                           1
    X117      R141                          -54
    X117      R459                          1
    X117      R629                          1
    X117      R713                          1
    X117      R715                          1
    X117      R717                          1
    X117      R719                          1
    X117      R721                          1
    X117      R723                          1
    X118      R12                           1
    X118      R187                          -49
    X118      R390                          1
    X118      R484                          1
    X118      R486                          1
    X118      R488                          1
    X118      R490                          1
    X118      R492                          1
    X118      R700                          1
    X118      R712                          1
    X119      R12                           1
    X119      R232                          -53
    X119      R391                          1
    X119      R485                          1
    X119      R487                          1
    X119      R489                          1
    X119      R491                          1
    X119      R493                          1
    X119      R701                          1
    X119      R713                          1
    X120      R12                           1
    X120      R97                           -49
    X120      R460                          1
    X120      R472                          1
    X120      R630                          1
    X120      R724                          1
    X120      R726                          1
    X120      R728                          1
    X120      R730                          1
    X120      R732                          1
    X121      R12                           1
    X121      R142                          -54
    X121      R461                          1
    X121      R473                          1
    X121      R631                          1
    X121      R725                          1
    X121      R727                          1
    X121      R729                          1
    X121      R731                          1
    X121      R733                          1
    X122      R13                           1
    X122      R188                          -51
    X122      R374                          13
    X122      R392                          1
    X122      R494                          1
    X122      R496                          1
    X122      R498                          1
    X122      R500                          1
    X122      R702                          1
    X122      R714                          1
    X122      R724                          1
    X123      R13                           1
    X123      R233                          -56
    X123      R357                          8
    X123      R393                          1
    X123      R495                          1
    X123      R497                          1
    X123      R499                          1
    X123      R501                          1
    X123      R703                          1
    X123      R715                          1
    X123      R725                          1
    X124      R13                           1
    X124      R98                           -49
    X124      R374                          13
    X124      R462                          1
    X124      R474                          1
    X124      R484                          1
    X124      R632                          1
    X124      R734                          1
    X124      R736                          1
    X124      R738                          1
    X124      R740                          1
    X125      R13                           1
    X125      R143                          -54
    X125      R357                          8
    X125      R463                          1
    X125      R475                          1
    X125      R485                          1
    X125      R633                          1
    X125      R735                          1
    X125      R737                          1
    X125      R739                          1
    X125      R741                          1
    X126      R14                           1
    X126      R189                          -50
    X126      R394                          1
    X126      R502                          1
    X126      R504                          1
    X126      R506                          1
    X126      R704                          1
    X126      R716                          1
    X126      R726                          1
    X126      R734                          1
    X127      R14                           1
    X127      R234                          -53
    X127      R395                          1
    X127      R503                          1
    X127      R505                          1
    X127      R507                          1
    X127      R705                          1
    X127      R717                          1
    X127      R727                          1
    X127      R735                          1
    X128      R14                           1
    X128      R99                           -49
    X128      R464                          1
    X128      R476                          1
    X128      R486                          1
    X128      R494                          1
    X128      R634                          1
    X128      R742                          1
    X128      R744                          1
    X128      R746                          1
    X129      R14                           1
    X129      R144                          -54
    X129      R465                          1
    X129      R477                          1
    X129      R487                          1
    X129      R495                          1
    X129      R635                          1
    X129      R743                          1
    X129      R745                          1
    X129      R747                          1
    X130      R15                           1
    X130      R190                          -51
    X130      R396                          1
    X130      R508                          1
    X130      R510                          1
    X130      R706                          1
    X130      R718                          1
    X130      R728                          1
    X130      R736                          1
    X130      R742                          1
    X131      R15                           1
    X131      R235                          -53
    X131      R397                          1
    X131      R509                          1
    X131      R511                          1
    X131      R707                          1
    X131      R719                          1
    X131      R729                          1
    X131      R737                          1
    X131      R743                          1
    X132      R15                           1
    X132      R100                          -49
    X132      R466                          1
    X132      R478                          1
    X132      R488                          1
    X132      R496                          1
    X132      R502                          1
    X132      R636                          1
    X132      R748                          1
    X132      R750                          1
    X133      R15                           1
    X133      R145                          -54
    X133      R467                          1
    X133      R479                          1
    X133      R489                          1
    X133      R497                          1
    X133      R503                          1
    X133      R637                          1
    X133      R749                          1
    X133      R751                          1
    X134      R16                           1
    X134      R191                          -52
    X134      R398                          1
    X134      R512                          1
    X134      R708                          1
    X134      R720                          1
    X134      R730                          1
    X134      R738                          1
    X134      R744                          1
    X134      R748                          1
    X135      R16                           1
    X135      R236                          -53
    X135      R399                          1
    X135      R513                          1
    X135      R709                          1
    X135      R721                          1
    X135      R731                          1
    X135      R739                          1
    X135      R745                          1
    X135      R749                          1
    X136      R16                           1
    X136      R101                          -49
    X136      R468                          1
    X136      R480                          1
    X136      R490                          1
    X136      R498                          1
    X136      R504                          1
    X136      R508                          1
    X136      R638                          1
    X136      R752                          1
    X137      R16                           1
    X137      R146                          -54
    X137      R469                          1
    X137      R481                          1
    X137      R491                          1
    X137      R499                          1
    X137      R505                          1
    X137      R509                          1
    X137      R639                          1
    X137      R753                          1
    X138      R17                           1
    X138      R192                          -52
    X138      R400                          1
    X138      R710                          1
    X138      R722                          1
    X138      R732                          1
    X138      R740                          1
    X138      R746                          1
    X138      R750                          1
    X138      R752                          1
    X139      R17                           1
    X139      R237                          -54
    X139      R401                          1
    X139      R711                          1
    X139      R723                          1
    X139      R733                          1
    X139      R741                          1
    X139      R747                          1
    X139      R751                          1
    X139      R753                          1
    X140      R17                           1
    X140      R102                          -49
    X140      R470                          1
    X140      R482                          1
    X140      R492                          1
    X140      R500                          1
    X140      R506                          1
    X140      R510                          1
    X140      R512                          1
    X140      R640                          1
    X141      R17                           1
    X141      R147                          -54
    X141      R471                          1
    X141      R483                          1
    X141      R493                          1
    X141      R501                          1
    X141      R507                          1
    X141      R511                          1
    X141      R513                          1
    X141      R641                          1
    X142      R18                           1
    X142      R193                          -48
    X142      R402                          1
    X142      R458                          1
    X142      R514                          1
    X142      R516                          1
    X142      R518                          1
    X142      R520                          1
    X142      R522                          1
    X142      R524                          1
    X143      R18                           1
    X143      R238                          -52
    X143      R403                          1
    X143      R459                          1
    X143      R515                          1
    X143      R517                          1
    X143      R519                          1
    X143      R521                          1
    X143      R523                          1
    X143      R525                          1
    X144      R18                           1
    X144      R103                          -48
    X144      R642                          1
    X144      R698                          1
    X144      R754                          1
    X144      R756                          1
    X144      R758                          1
    X144      R760                          1
    X144      R762                          1
    X144      R764                          1
    X145      R18                           1
    X145      R148                          -52
    X145      R643                          1
    X145      R699                          1
    X145      R755                          1
    X145      R757                          1
    X145      R759                          1
    X145      R761                          1
    X145      R763                          1
    X145      R765                          1
    X146      R19                           1
    X146      R194                          -49
    X146      R404                          1
    X146      R460                          1
    X146      R526                          1
    X146      R528                          1
    X146      R530                          1
    X146      R532                          1
    X146      R534                          1
    X146      R754                          1
    X147      R19                           1
    X147      R239                          -53
    X147      R405                          1
    X147      R461                          1
    X147      R527                          1
    X147      R529                          1
    X147      R531                          1
    X147      R533                          1
    X147      R535                          1
    X147      R755                          1
    X148      R19                           1
    X148      R104                          -48
    X148      R514                          1
    X148      R644                          1
    X148      R700                          1
    X148      R766                          1
    X148      R768                          1
    X148      R770                          1
    X148      R772                          1
    X148      R774                          1
    X149      R19                           1
    X149      R149                          -52
    X149      R515                          1
    X149      R645                          1
    X149      R701                          1
    X149      R767                          1
    X149      R769                          1
    X149      R771                          1
    X149      R773                          1
    X149      R775                          1
    X150      R20                           1
    X150      R195                          -51
    X150      R375                          12
    X150      R406                          1
    X150      R462                          1
    X150      R536                          1
    X150      R538                          1
    X150      R540                          1
    X150      R542                          1
    X150      R756                          1
    X150      R766                          1
    X151      R20                           1
    X151      R240                          -56
    X151      R358                          7.5
    X151      R407                          1
    X151      R463                          1
    X151      R537                          1
    X151      R539                          1
    X151      R541                          1
    X151      R543                          1
    X151      R757                          1
    X151      R767                          1
    X152      R20                           1
    X152      R105                          -48
    X152      R375                          12
    X152      R516                          1
    X152      R526                          1
    X152      R646                          1
    X152      R702                          1
    X152      R776                          1
    X152      R778                          1
    X152      R780                          1
    X152      R782                          1
    X153      R20                           1
    X153      R150                          -52
    X153      R358                          7.5
    X153      R517                          1
    X153      R527                          1
    X153      R647                          1
    X153      R703                          1
    X153      R777                          1
    X153      R779                          1
    X153      R781                          1
    X153      R783                          1
    X154      R21                           1
    X154      R196                          -50
    X154      R408                          1
    X154      R464                          1
    X154      R544                          1
    X154      R546                          1
    X154      R548                          1
    X154      R758                          1
    X154      R768                          1
    X154      R776                          1
    X155      R21                           1
    X155      R241                          -53
    X155      R409                          1
    X155      R465                          1
    X155      R545                          1
    X155      R547                          1
    X155      R549                          1
    X155      R759                          1
    X155      R769                          1
    X155      R777                          1
    X156      R21                           1
    X156      R106                          -48
    X156      R518                          1
    X156      R528                          1
    X156      R536                          1
    X156      R648                          1
    X156      R704                          1
    X156      R784                          1
    X156      R786                          1
    X156      R788                          1
    X157      R21                           1
    X157      R151                          -52
    X157      R519                          1
    X157      R529                          1
    X157      R537                          1
    X157      R649                          1
    X157      R705                          1
    X157      R785                          1
    X157      R787                          1
    X157      R789                          1
    X158      R22                           1
    X158      R197                          -51
    X158      R410                          1
    X158      R466                          1
    X158      R550                          1
    X158      R552                          1
    X158      R760                          1
    X158      R770                          1
    X158      R778                          1
    X158      R784                          1
    X159      R22                           1
    X159      R242                          -53
    X159      R411                          1
    X159      R467                          1
    X159      R551                          1
    X159      R553                          1
    X159      R761                          1
    X159      R771                          1
    X159      R779                          1
    X159      R785                          1
    X160      R22                           1
    X160      R107                          -48
    X160      R520                          1
    X160      R530                          1
    X160      R538                          1
    X160      R544                          1
    X160      R650                          1
    X160      R706                          1
    X160      R790                          1
    X160      R792                          1
    X161      R22                           1
    X161      R152                          -52
    X161      R521                          1
    X161      R531                          1
    X161      R539                          1
    X161      R545                          1
    X161      R651                          1
    X161      R707                          1
    X161      R791                          1
    X161      R793                          1
    X162      R23                           1
    X162      R198                          -52
    X162      R412                          1
    X162      R468                          1
    X162      R554                          1
    X162      R762                          1
    X162      R772                          1
    X162      R780                          1
    X162      R786                          1
    X162      R790                          1
    X163      R23                           1
    X163      R243                          -53
    X163      R413                          1
    X163      R469                          1
    X163      R555                          1
    X163      R763                          1
    X163      R773                          1
    X163      R781                          1
    X163      R787                          1
    X163      R791                          1
    X164      R23                           1
    X164      R108                          -48
    X164      R522                          1
    X164      R532                          1
    X164      R540                          1
    X164      R546                          1
    X164      R550                          1
    X164      R652                          1
    X164      R708                          1
    X164      R794                          1
    X165      R23                           1
    X165      R153                          -52
    X165      R523                          1
    X165      R533                          1
    X165      R541                          1
    X165      R547                          1
    X165      R551                          1
    X165      R653                          1
    X165      R709                          1
    X165      R795                          1
    X166      R24                           1
    X166      R199                          -52
    X166      R414                          1
    X166      R470                          1
    X166      R764                          1
    X166      R774                          1
    X166      R782                          1
    X166      R788                          1
    X166      R792                          1
    X166      R794                          1
    X167      R24                           1
    X167      R244                          -54
    X167      R415                          1
    X167      R471                          1
    X167      R765                          1
    X167      R775                          1
    X167      R783                          1
    X167      R789                          1
    X167      R793                          1
    X167      R795                          1
    X168      R24                           1
    X168      R109                          -48
    X168      R524                          1
    X168      R534                          1
    X168      R542                          1
    X168      R548                          1
    X168      R552                          1
    X168      R554                          1
    X168      R654                          1
    X168      R710                          1
    X169      R24                           1
    X169      R154                          -52
    X169      R525                          1
    X169      R535                          1
    X169      R543                          1
    X169      R549                          1
    X169      R553                          1
    X169      R555                          1
    X169      R655                          1
    X169      R711                          1
    X170      R25                           1
    X170      R200                          -49
    X170      R383                          10.5
    X170      R416                          1
    X170      R472                          1
    X170      R514                          1
    X170      R556                          1
    X170      R558                          1
    X170      R560                          1
    X170      R562                          1
    X170      R564                          1
    X171      R25                           1
    X171      R245                          -53
    X171      R366                          6.5
    X171      R417                          1
    X171      R473                          1
    X171      R515                          1
    X171      R557                          1
    X171      R559                          1
    X171      R561                          1
    X171      R563                          1
    X171      R565                          1
    X172      R25                           1
    X172      R110                          -48
    X172      R383                          10.5
    X172      R656                          1
    X172      R712                          1
    X172      R754                          1
    X172      R796                          1
    X172      R798                          1
    X172      R800                          1
    X172      R802                          1
    X172      R804                          1
    X173      R25                           1
    X173      R155                          -52
    X173      R366                          6.5
    X173      R657                          1
    X173      R713                          1
    X173      R755                          1
    X173      R797                          1
    X173      R799                          1
    X173      R801                          1
    X173      R803                          1
    X173      R805                          1
    X174      R26                           1
    X174      R201                          -51
    X174      R418                          1
    X174      R474                          1
    X174      R516                          1
    X174      R566                          1
    X174      R568                          1
    X174      R570                          1
    X174      R572                          1
    X174      R796                          1
    X175      R26                           1
    X175      R246                          -56
    X175      R419                          1
    X175      R475                          1
    X175      R517                          1
    X175      R567                          1
    X175      R569                          1
    X175      R571                          1
    X175      R573                          1
    X175      R797                          1
    X176      R26                           1
    X176      R111                          -48
    X176      R556                          1
    X176      R658                          1
    X176      R714                          1
    X176      R756                          1
    X176      R806                          1
    X176      R808                          1
    X176      R810                          1
    X176      R812                          1
    X177      R26                           1
    X177      R156                          -52
    X177      R557                          1
    X177      R659                          1
    X177      R715                          1
    X177      R757                          1
    X177      R807                          1
    X177      R809                          1
    X177      R811                          1
    X177      R813                          1
    X178      R27                           1
    X178      R202                          -50
    X178      R420                          1
    X178      R476                          1
    X178      R518                          1
    X178      R574                          1
    X178      R576                          1
    X178      R578                          1
    X178      R798                          1
    X178      R806                          1
    X179      R27                           1
    X179      R247                          -53
    X179      R421                          1
    X179      R477                          1
    X179      R519                          1
    X179      R575                          1
    X179      R577                          1
    X179      R579                          1
    X179      R799                          1
    X179      R807                          1
    X180      R27                           1
    X180      R112                          -48
    X180      R558                          1
    X180      R566                          1
    X180      R660                          1
    X180      R716                          1
    X180      R758                          1
    X180      R814                          1
    X180      R816                          1
    X180      R818                          1
    X181      R27                           1
    X181      R157                          -52
    X181      R559                          1
    X181      R567                          1
    X181      R661                          1
    X181      R717                          1
    X181      R759                          1
    X181      R815                          1
    X181      R817                          1
    X181      R819                          1
    X182      R28                           1
    X182      R203                          -51
    X182      R422                          1
    X182      R478                          1
    X182      R520                          1
    X182      R580                          1
    X182      R582                          1
    X182      R800                          1
    X182      R808                          1
    X182      R814                          1
    X183      R28                           1
    X183      R248                          -53
    X183      R423                          1
    X183      R479                          1
    X183      R521                          1
    X183      R581                          1
    X183      R583                          1
    X183      R801                          1
    X183      R809                          1
    X183      R815                          1
    X184      R28                           1
    X184      R113                          -48
    X184      R560                          1
    X184      R568                          1
    X184      R574                          1
    X184      R662                          1
    X184      R718                          1
    X184      R760                          1
    X184      R820                          1
    X184      R822                          1
    X185      R28                           1
    X185      R158                          -52
    X185      R561                          1
    X185      R569                          1
    X185      R575                          1
    X185      R663                          1
    X185      R719                          1
    X185      R761                          1
    X185      R821                          1
    X185      R823                          1
    X186      R29                           1
    X186      R204                          -52
    X186      R424                          1
    X186      R480                          1
    X186      R522                          1
    X186      R584                          1
    X186      R802                          1
    X186      R810                          1
    X186      R816                          1
    X186      R820                          1
    X187      R29                           1
    X187      R249                          -53
    X187      R425                          1
    X187      R481                          1
    X187      R523                          1
    X187      R585                          1
    X187      R803                          1
    X187      R811                          1
    X187      R817                          1
    X187      R821                          1
    X188      R29                           1
    X188      R114                          -48
    X188      R562                          1
    X188      R570                          1
    X188      R576                          1
    X188      R580                          1
    X188      R664                          1
    X188      R720                          1
    X188      R762                          1
    X188      R824                          1
    X189      R29                           1
    X189      R159                          -52
    X189      R563                          1
    X189      R571                          1
    X189      R577                          1
    X189      R581                          1
    X189      R665                          1
    X189      R721                          1
    X189      R763                          1
    X189      R825                          1
    X190      R30                           1
    X190      R205                          -52
    X190      R426                          1
    X190      R482                          1
    X190      R524                          1
    X190      R804                          1
    X190      R812                          1
    X190      R818                          1
    X190      R822                          1
    X190      R824                          1
    X191      R30                           1
    X191      R250                          -54
    X191      R427                          1
    X191      R483                          1
    X191      R525                          1
    X191      R805                          1
    X191      R813                          1
    X191      R819                          1
    X191      R823                          1
    X191      R825                          1
    X192      R30                           1
    X192      R115                          -48
    X192      R564                          1
    X192      R572                          1
    X192      R578                          1
    X192      R582                          1
    X192      R584                          1
    X192      R666                          1
    X192      R722                          1
    X192      R764                          1
    X193      R30                           1
    X193      R160                          -52
    X193      R565                          1
    X193      R573                          1
    X193      R579                          1
    X193      R583                          1
    X193      R585                          1
    X193      R667                          1
    X193      R723                          1
    X193      R765                          1
    X194      R31                           1
    X194      R206                          -51
    X194      R428                          1
    X194      R484                          1
    X194      R526                          1
    X194      R556                          1
    X194      R586                          1
    X194      R588                          1
    X194      R590                          1
    X194      R592                          1
    X195      R31                           1
    X195      R251                          -56
    X195      R429                          1
    X195      R485                          1
    X195      R527                          1
    X195      R557                          1
    X195      R587                          1
    X195      R589                          1
    X195      R591                          1
    X195      R593                          1
    X196      R31                           1
    X196      R116                          -49
    X196      R668                          1
    X196      R724                          1
    X196      R766                          1
    X196      R796                          1
    X196      R826                          1
    X196      R828                          1
    X196      R830                          1
    X196      R832                          1
    X197      R31                           1
    X197      R161                          -53
    X197      R669                          1
    X197      R725                          1
    X197      R767                          1
    X197      R797                          1
    X197      R827                          1
    X197      R829                          1
    X197      R831                          1
    X197      R833                          1
    X198      R32                           1
    X198      R207                          -50
    X198      R430                          1
    X198      R486                          1
    X198      R528                          1
    X198      R558                          1
    X198      R594                          1
    X198      R596                          1
    X198      R598                          1
    X198      R826                          1
    X199      R32                           1
    X199      R252                          -53
    X199      R431                          1
    X199      R487                          1
    X199      R529                          1
    X199      R559                          1
    X199      R595                          1
    X199      R597                          1
    X199      R599                          1
    X199      R827                          1
    X200      R32                           1
    X200      R117                          -49
    X200      R586                          1
    X200      R670                          1
    X200      R726                          1
    X200      R768                          1
    X200      R798                          1
    X200      R834                          1
    X200      R836                          1
    X200      R838                          1
    X201      R32                           1
    X201      R162                          -53
    X201      R587                          1
    X201      R671                          1
    X201      R727                          1
    X201      R769                          1
    X201      R799                          1
    X201      R835                          1
    X201      R837                          1
    X201      R839                          1
    X202      R33                           1
    X202      R208                          -51
    X202      R432                          1
    X202      R488                          1
    X202      R530                          1
    X202      R560                          1
    X202      R600                          1
    X202      R602                          1
    X202      R828                          1
    X202      R834                          1
    X203      R33                           1
    X203      R253                          -53
    X203      R433                          1
    X203      R489                          1
    X203      R531                          1
    X203      R561                          1
    X203      R601                          1
    X203      R603                          1
    X203      R829                          1
    X203      R835                          1
    X204      R33                           1
    X204      R118                          -49
    X204      R588                          1
    X204      R594                          1
    X204      R672                          1
    X204      R728                          1
    X204      R770                          1
    X204      R800                          1
    X204      R840                          1
    X204      R842                          1
    X205      R33                           1
    X205      R163                          -53
    X205      R589                          1
    X205      R595                          1
    X205      R673                          1
    X205      R729                          1
    X205      R771                          1
    X205      R801                          1
    X205      R841                          1
    X205      R843                          1
    X206      R34                           1
    X206      R209                          -52
    X206      R385                          11
    X206      R434                          1
    X206      R490                          1
    X206      R532                          1
    X206      R562                          1
    X206      R604                          1
    X206      R830                          1
    X206      R836                          1
    X206      R840                          1
    X207      R34                           1
    X207      R254                          -53
    X207      R368                          8.5
    X207      R435                          1
    X207      R491                          1
    X207      R533                          1
    X207      R563                          1
    X207      R605                          1
    X207      R831                          1
    X207      R837                          1
    X207      R841                          1
    X208      R34                           1
    X208      R119                          -49
    X208      R385                          11
    X208      R590                          1
    X208      R596                          1
    X208      R600                          1
    X208      R674                          1
    X208      R730                          1
    X208      R772                          1
    X208      R802                          1
    X208      R844                          1
    X209      R34                           1
    X209      R164                          -53
    X209      R368                          8.5
    X209      R591                          1
    X209      R597                          1
    X209      R601                          1
    X209      R675                          1
    X209      R731                          1
    X209      R773                          1
    X209      R803                          1
    X209      R845                          1
    X210      R35                           1
    X210      R210                          -52
    X210      R384                          11.5
    X210      R436                          1
    X210      R492                          1
    X210      R534                          1
    X210      R564                          1
    X210      R832                          1
    X210      R838                          1
    X210      R842                          1
    X210      R844                          1
    X211      R35                           1
    X211      R255                          -54
    X211      R367                          8.5
    X211      R437                          1
    X211      R493                          1
    X211      R535                          1
    X211      R565                          1
    X211      R833                          1
    X211      R839                          1
    X211      R843                          1
    X211      R845                          1
    X212      R35                           1
    X212      R120                          -49
    X212      R384                          11.5
    X212      R592                          1
    X212      R598                          1
    X212      R602                          1
    X212      R604                          1
    X212      R676                          1
    X212      R732                          1
    X212      R774                          1
    X212      R804                          1
    X213      R35                           1
    X213      R165                          -53
    X213      R367                          8.5
    X213      R593                          1
    X213      R599                          1
    X213      R603                          1
    X213      R605                          1
    X213      R677                          1
    X213      R733                          1
    X213      R775                          1
    X213      R805                          1
    X214      R36                           1
    X214      R211                          -50
    X214      R438                          1
    X214      R494                          1
    X214      R536                          1
    X214      R566                          1
    X214      R586                          1
    X214      R606                          1
    X214      R608                          1
    X214      R610                          1
    X215      R36                           1
    X215      R256                          -53
    X215      R439                          1
    X215      R495                          1
    X215      R537                          1
    X215      R567                          1
    X215      R587                          1
    X215      R607                          1
    X215      R609                          1
    X215      R611                          1
    X216      R36                           1
    X216      R121                          -51
    X216      R678                          1
    X216      R734                          1
    X216      R776                          1
    X216      R806                          1
    X216      R826                          1
    X216      R846                          1
    X216      R848                          1
    X216      R850                          1
    X217      R36                           1
    X217      R166                          -56
    X217      R679                          1
    X217      R735                          1
    X217      R777                          1
    X217      R807                          1
    X217      R827                          1
    X217      R847                          1
    X217      R849                          1
    X217      R851                          1
    X218      R37                           1
    X218      R212                          -51
    X218      R381                          12.5
    X218      R440                          1
    X218      R496                          1
    X218      R538                          1
    X218      R568                          1
    X218      R588                          1
    X218      R612                          1
    X218      R614                          1
    X218      R846                          1
    X219      R37                           1
    X219      R257                          -53
    X219      R364                          9
    X219      R441                          1
    X219      R497                          1
    X219      R539                          1
    X219      R569                          1
    X219      R589                          1
    X219      R613                          1
    X219      R615                          1
    X219      R847                          1
    X220      R37                           1
    X220      R122                          -51
    X220      R381                          12.5
    X220      R606                          1
    X220      R680                          1
    X220      R736                          1
    X220      R778                          1
    X220      R808                          1
    X220      R828                          1
    X220      R852                          1
    X220      R854                          1
    X221      R37                           1
    X221      R167                          -56
    X221      R364                          9
    X221      R607                          1
    X221      R681                          1
    X221      R737                          1
    X221      R779                          1
    X221      R809                          1
    X221      R829                          1
    X221      R853                          1
    X221      R855                          1
    X222      R38                           1
    X222      R213                          -52
    X222      R382                          12.5
    X222      R442                          1
    X222      R498                          1
    X222      R540                          1
    X222      R570                          1
    X222      R590                          1
    X222      R616                          1
    X222      R848                          1
    X222      R852                          1
    X223      R38                           1
    X223      R258                          -53
    X223      R365                          9.5
    X223      R443                          1
    X223      R499                          1
    X223      R541                          1
    X223      R571                          1
    X223      R591                          1
    X223      R617                          1
    X223      R849                          1
    X223      R853                          1
    X224      R38                           1
    X224      R123                          -51
    X224      R382                          12.5
    X224      R608                          1
    X224      R612                          1
    X224      R682                          1
    X224      R738                          1
    X224      R780                          1
    X224      R810                          1
    X224      R830                          1
    X224      R856                          1
    X225      R38                           1
    X225      R168                          -56
    X225      R365                          9.5
    X225      R609                          1
    X225      R613                          1
    X225      R683                          1
    X225      R739                          1
    X225      R781                          1
    X225      R811                          1
    X225      R831                          1
    X225      R857                          1
    X226      R39                           1
    X226      R214                          -52
    X226      R376                          13
    X226      R444                          1
    X226      R500                          1
    X226      R542                          1
    X226      R572                          1
    X226      R592                          1
    X226      R850                          1
    X226      R854                          1
    X226      R856                          1
    X227      R39                           1
    X227      R259                          -54
    X227      R359                          9.5
    X227      R445                          1
    X227      R501                          1
    X227      R543                          1
    X227      R573                          1
    X227      R593                          1
    X227      R851                          1
    X227      R855                          1
    X227      R857                          1
    X228      R39                           1
    X228      R124                          -51
    X228      R376                          13
    X228      R610                          1
    X228      R614                          1
    X228      R616                          1
    X228      R684                          1
    X228      R740                          1
    X228      R782                          1
    X228      R812                          1
    X228      R832                          1
    X229      R39                           1
    X229      R169                          -56
    X229      R359                          9.5
    X229      R611                          1
    X229      R615                          1
    X229      R617                          1
    X229      R685                          1
    X229      R741                          1
    X229      R783                          1
    X229      R813                          1
    X229      R833                          1
    X230      R40                           1
    X230      R215                          -51
    X230      R378                          11
    X230      R446                          1
    X230      R502                          1
    X230      R544                          1
    X230      R574                          1
    X230      R594                          1
    X230      R606                          1
    X230      R618                          1
    X230      R620                          1
    X231      R40                           1
    X231      R260                          -53
    X231      R361                          8.5
    X231      R447                          1
    X231      R503                          1
    X231      R545                          1
    X231      R575                          1
    X231      R595                          1
    X231      R607                          1
    X231      R619                          1
    X231      R621                          1
    X232      R40                           1
    X232      R125                          -50
    X232      R378                          11
    X232      R686                          1
    X232      R742                          1
    X232      R784                          1
    X232      R814                          1
    X232      R834                          1
    X232      R846                          1
    X232      R858                          1
    X232      R860                          1
    X233      R40                           1
    X233      R170                          -53
    X233      R361                          8.5
    X233      R687                          1
    X233      R743                          1
    X233      R785                          1
    X233      R815                          1
    X233      R835                          1
    X233      R847                          1
    X233      R859                          1
    X233      R861                          1
    X234      R41                           1
    X234      R216                          -52
    X234      R379                          11
    X234      R448                          1
    X234      R504                          1
    X234      R546                          1
    X234      R576                          1
    X234      R596                          1
    X234      R608                          1
    X234      R622                          1
    X234      R858                          1
    X235      R41                           1
    X235      R261                          -53
    X235      R362                          9
    X235      R449                          1
    X235      R505                          1
    X235      R547                          1
    X235      R577                          1
    X235      R597                          1
    X235      R609                          1
    X235      R623                          1
    X235      R859                          1
    X236      R41                           1
    X236      R126                          -50
    X236      R379                          11
    X236      R618                          1
    X236      R688                          1
    X236      R744                          1
    X236      R786                          1
    X236      R816                          1
    X236      R836                          1
    X236      R848                          1
    X236      R862                          1
    X237      R41                           1
    X237      R171                          -53
    X237      R362                          9
    X237      R619                          1
    X237      R689                          1
    X237      R745                          1
    X237      R787                          1
    X237      R817                          1
    X237      R837                          1
    X237      R849                          1
    X237      R863                          1
    X238      R42                           1
    X238      R217                          -52
    X238      R450                          1
    X238      R506                          1
    X238      R548                          1
    X238      R578                          1
    X238      R598                          1
    X238      R610                          1
    X238      R860                          1
    X238      R862                          1
    X239      R42                           1
    X239      R262                          -54
    X239      R451                          1
    X239      R507                          1
    X239      R549                          1
    X239      R579                          1
    X239      R599                          1
    X239      R611                          1
    X239      R861                          1
    X239      R863                          1
    X240      R42                           1
    X240      R127                          -50
    X240      R620                          1
    X240      R622                          1
    X240      R690                          1
    X240      R746                          1
    X240      R788                          1
    X240      R818                          1
    X240      R838                          1
    X240      R850                          1
    X241      R42                           1
    X241      R172                          -53
    X241      R621                          1
    X241      R623                          1
    X241      R691                          1
    X241      R747                          1
    X241      R789                          1
    X241      R819                          1
    X241      R839                          1
    X241      R851                          1
    X242      R43                           1
    X242      R218                          -52
    X242      R380                          11
    X242      R452                          1
    X242      R508                          1
    X242      R550                          1
    X242      R580                          1
    X242      R600                          1
    X242      R612                          1
    X242      R618                          1
    X242      R624                          1
    X243      R43                           1
    X243      R263                          -53
    X243      R363                          9.5
    X243      R453                          1
    X243      R509                          1
    X243      R551                          1
    X243      R581                          1
    X243      R601                          1
    X243      R613                          1
    X243      R619                          1
    X243      R625                          1
    X244      R43                           1
    X244      R128                          -51
    X244      R380                          11
    X244      R692                          1
    X244      R748                          1
    X244      R790                          1
    X244      R820                          1
    X244      R840                          1
    X244      R852                          1
    X244      R858                          1
    X244      R864                          1
    X245      R43                           1
    X245      R173                          -53
    X245      R363                          9.5
    X245      R693                          1
    X245      R749                          1
    X245      R791                          1
    X245      R821                          1
    X245      R841                          1
    X245      R853                          1
    X245      R859                          1
    X245      R865                          1
    X246      R44                           1
    X246      R219                          -52
    X246      R377                          11.5
    X246      R454                          1
    X246      R510                          1
    X246      R552                          1
    X246      R582                          1
    X246      R602                          1
    X246      R614                          1
    X246      R620                          1
    X246      R864                          1
    X247      R44                           1
    X247      R264                          -54
    X247      R360                          9.5
    X247      R455                          1
    X247      R511                          1
    X247      R553                          1
    X247      R583                          1
    X247      R603                          1
    X247      R615                          1
    X247      R621                          1
    X247      R865                          1
    X248      R44                           1
    X248      R129                          -51
    X248      R377                          11.5
    X248      R624                          1
    X248      R694                          1
    X248      R750                          1
    X248      R792                          1
    X248      R822                          1
    X248      R842                          1
    X248      R854                          1
    X248      R860                          1
    X249      R44                           1
    X249      R174                          -53
    X249      R360                          9.5
    X249      R625                          1
    X249      R695                          1
    X249      R751                          1
    X249      R793                          1
    X249      R823                          1
    X249      R843                          1
    X249      R855                          1
    X249      R861                          1
    X250      R45                           1
    X250      R220                          -52
    X250      R456                          1
    X250      R512                          1
    X250      R554                          1
    X250      R584                          1
    X250      R604                          1
    X250      R616                          1
    X250      R622                          1
    X250      R624                          1
    X251      R45                           1
    X251      R265                          -54
    X251      R457                          1
    X251      R513                          1
    X251      R555                          1
    X251      R585                          1
    X251      R605                          1
    X251      R617                          1
    X251      R623                          1
    X251      R625                          1
    X252      R45                           1
    X252      R130                          -52
    X252      R696                          1
    X252      R752                          1
    X252      R794                          1
    X252      R824                          1
    X252      R844                          1
    X252      R856                          1
    X252      R862                          1
    X252      R864                          1
    X253      R45                           1
    X253      R175                          -53
    X253      R697                          1
    X253      R753                          1
    X253      R795                          1
    X253      R825                          1
    X253      R845                          1
    X253      R857                          1
    X253      R863                          1
    X253      R865                          1
RHS
    RHS       R1                            1
    RHS       R2                            1
    RHS       R3                            1
    RHS       R4                            1
    RHS       R5                            1
    RHS       R6                            1
    RHS       R7                            1
    RHS       R8                            1
    RHS       R9                            1
    RHS       R10                           1
    RHS       R11                           1
    RHS       R12                           1
    RHS       R13                           1
    RHS       R14                           1
    RHS       R15                           1
    RHS       R16                           1
    RHS       R17                           1
    RHS       R18                           1
    RHS       R19                           1
    RHS       R20                           1
    RHS       R21                           1
    RHS       R22                           1
    RHS       R23                           1
    RHS       R24                           1
    RHS       R25                           1
    RHS       R26                           1
    RHS       R27                           1
    RHS       R28                           1
    RHS       R29                           1
    RHS       R30                           1
    RHS       R31                           1
    RHS       R32                           1
    RHS       R33                           1
    RHS       R34                           1
    RHS       R35                           1
    RHS       R36                           1
    RHS       R37                           1
    RHS       R38                           1
    RHS       R39                           1
    RHS       R40                           1
    RHS       R41                           1
    RHS       R42                           1
    RHS       R43                           1
    RHS       R44                           1
    RHS       R45                           1
    RHS       R46                           17.5
    RHS       R47                           18.5
    RHS       R48                           19
    RHS       R49                           19
    RHS       R50                           18.5
    RHS       R51                           17.5
    RHS       R52                           18
    RHS       R53                           17.5
    RHS       R54                           17
    RHS       R55                           17
    RHS       R56                           16.5
    RHS       R57                           16
    RHS       R58                           17
    RHS       R59                           17
    RHS       R60                           16.5
    RHS       R61                           15
    RHS       R62                           16.5
    RHS       R63                           16.5
    RHS       R64                           16.5
    RHS       R65                           16
    RHS       R66                           -17.5
    RHS       R67                           -18.5
    RHS       R68                           -19
    RHS       R69                           -19
    RHS       R70                           -18.5
    RHS       R71                           -17.5
    RHS       R72                           -18
    RHS       R73                           -17.5
    RHS       R74                           -17
    RHS       R75                           -17
    RHS       R76                           -16.5
    RHS       R77                           -16
    RHS       R78                           -17
    RHS       R79                           -17
    RHS       R80                           -16.5
    RHS       R81                           -15
    RHS       R82                           -16.5
    RHS       R83                           -16.5
    RHS       R84                           -16.5
    RHS       R85                           -16
    RHS       R86                           -42
    RHS       R87                           -42
    RHS       R88                           -42
    RHS       R89                           -42
    RHS       R90                           -42
    RHS       R91                           -42
    RHS       R92                           -42
    RHS       R93                           -42
    RHS       R94                           -42
    RHS       R95                           -42
    RHS       R96                           -42
    RHS       R97                           -42
    RHS       R98                           -42
    RHS       R99                           -42
    RHS       R100                          -42
    RHS       R101                          -42
    RHS       R102                          -42
    RHS       R103                          -42
    RHS       R104                          -42
    RHS       R105                          -42
    RHS       R106                          -42
    RHS       R107                          -42
    RHS       R108                          -42
    RHS       R109                          -42
    RHS       R110                          -42
    RHS       R111                          -42
    RHS       R112                          -42
    RHS       R113                          -42
    RHS       R114                          -42
    RHS       R115                          -42
    RHS       R116                          -42
    RHS       R117                          -42
    RHS       R118                          -42
    RHS       R119                          -42
    RHS       R120                          -42
    RHS       R121                          -42
    RHS       R122                          -42
    RHS       R123                          -42
    RHS       R124                          -42
    RHS       R125                          -42
    RHS       R126                          -42
    RHS       R127                          -42
    RHS       R128                          -42
    RHS       R129                          -42
    RHS       R130                          -42
    RHS       R131                          -42
    RHS       R132                          -42
    RHS       R133                          -42
    RHS       R134                          -42
    RHS       R135                          -42
    RHS       R136                          -42
    RHS       R137                          -42
    RHS       R138                          -42
    RHS       R139                          -42
    RHS       R140                          -42
    RHS       R141                          -42
    RHS       R142                          -42
    RHS       R143                          -42
    RHS       R144                          -42
    RHS       R145                          -42
    RHS       R146                          -42
    RHS       R147                          -42
    RHS       R148                          -42
    RHS       R149                          -42
    RHS       R150                          -42
    RHS       R151                          -42
    RHS       R152                          -42
    RHS       R153                          -42
    RHS       R154                          -42
    RHS       R155                          -42
    RHS       R156                          -42
    RHS       R157                          -42
    RHS       R158                          -42
    RHS       R159                          -42
    RHS       R160                          -42
    RHS       R161                          -42
    RHS       R162                          -42
    RHS       R163                          -42
    RHS       R164                          -42
    RHS       R165                          -42
    RHS       R166                          -42
    RHS       R167                          -42
    RHS       R168                          -42
    RHS       R169                          -42
    RHS       R170                          -42
    RHS       R171                          -42
    RHS       R172                          -42
    RHS       R173                          -42
    RHS       R174                          -42
    RHS       R175                          -42
    RHS       R176                          -42
    RHS       R177                          -42
    RHS       R178                          -42
    RHS       R179                          -42
    RHS       R180                          -42
    RHS       R181                          -42
    RHS       R182                          -42
    RHS       R183                          -42
    RHS       R184                          -42
    RHS       R185                          -42
    RHS       R186                          -42
    RHS       R187                          -42
    RHS       R188                          -42
    RHS       R189                          -42
    RHS       R190                          -42
    RHS       R191                          -42
    RHS       R192                          -42
    RHS       R193                          -42
    RHS       R194                          -42
    RHS       R195                          -42
    RHS       R196                          -42
    RHS       R197                          -42
    RHS       R198                          -42
    RHS       R199                          -42
    RHS       R200                          -42
    RHS       R201                          -42
    RHS       R202                          -42
    RHS       R203                          -42
    RHS       R204                          -42
    RHS       R205                          -42
    RHS       R206                          -42
    RHS       R207                          -42
    RHS       R208                          -42
    RHS       R209                          -42
    RHS       R210                          -42
    RHS       R211                          -42
    RHS       R212                          -42
    RHS       R213                          -42
    RHS       R214                          -42
    RHS       R215                          -42
    RHS       R216                          -42
    RHS       R217                          -42
    RHS       R218                          -42
    RHS       R219                          -42
    RHS       R220                          -42
    RHS       R221                          -42
    RHS       R222                          -42
    RHS       R223                          -42
    RHS       R224                          -42
    RHS       R225                          -42
    RHS       R226                          -42
    RHS       R227                          -42
    RHS       R228                          -42
    RHS       R229                          -42
    RHS       R230                          -42
    RHS       R231                          -42
    RHS       R232                          -42
    RHS       R233                          -42
    RHS       R234                          -42
    RHS       R235                          -42
    RHS       R236                          -42
    RHS       R237                          -42
    RHS       R238                          -42
    RHS       R239                          -42
    RHS       R240                          -42
    RHS       R241                          -42
    RHS       R242                          -42
    RHS       R243                          -42
    RHS       R244                          -42
    RHS       R245                          -42
    RHS       R246                          -42
    RHS       R247                          -42
    RHS       R248                          -42
    RHS       R249                          -42
    RHS       R250                          -42
    RHS       R251                          -42
    RHS       R252                          -42
    RHS       R253                          -42
    RHS       R254                          -42
    RHS       R255                          -42
    RHS       R256                          -42
    RHS       R257                          -42
    RHS       R258                          -42
    RHS       R259                          -42
    RHS       R260                          -42
    RHS       R261                          -42
    RHS       R262                          -42
    RHS       R263                          -42
    RHS       R264                          -42
    RHS       R265                          -42
    RHS       R266                          1
    RHS       R268                          -0.5
    RHS       R270                          1
    RHS       R271                          -1
    RHS       R272                          -1.5
    RHS       R273                          -0.5
    RHS       R274                          0.5
    RHS       R275                          -0.5
    RHS       R276                          -1
    RHS       R277                          -0.5
    RHS       R279                          0.5
    RHS       R280                          -0.5
    RHS       R281                          -1.5
    RHS       R282                          -1.5
    RHS       R283                          -0.5
    RHS       R284                          -1.5
    RHS       R285                          -0.5
    RHS       R288                          -1
    RHS       R289                          -2
    RHS       R290                          1
    RHS       R291                          0.5
    RHS       R295                          -1.5
    RHS       R296                          -1.5
    RHS       R297                          -0.5
    RHS       R298                          -0.5
    RHS       R300                          -1
    RHS       R302                          0.5
    RHS       R304                          -1
    RHS       R305                          1
    RHS       R306                          1.5
    RHS       R307                          0.5
    RHS       R308                          -0.5
    RHS       R309                          0.5
    RHS       R310                          1
    RHS       R311                          0.5
    RHS       R313                          -0.5
    RHS       R314                          0.5
    RHS       R315                          1.5
    RHS       R316                          1.5
    RHS       R317                          0.5
    RHS       R318                          1.5
    RHS       R319                          0.5
    RHS       R322                          1
    RHS       R323                          2
    RHS       R324                          -1
    RHS       R325                          -0.5
    RHS       R329                          1.5
    RHS       R330                          1.5
    RHS       R331                          0.5
    RHS       R332                          0.5
    RHS       R334                          8
    RHS       R335                          9
    RHS       R336                          9.5
    RHS       R337                          9
    RHS       R338                          8
    RHS       R339                          8
    RHS       R340                          7.5
    RHS       R341                          9.5
    RHS       R342                          9.5
    RHS       R343                          8.5
    RHS       R344                          9
    RHS       R345                          9.5
    RHS       R346                          9
    RHS       R347                          9.5
    RHS       R348                          6.5
    RHS       R349                          8.5
    RHS       R350                          8.5
    RHS       R351                          30
    RHS       R352                          8
    RHS       R353                          9
    RHS       R354                          9.5
    RHS       R355                          9
    RHS       R356                          8
    RHS       R357                          8
    RHS       R358                          7.5
    RHS       R359                          9.5
    RHS       R360                          9.5
    RHS       R361                          8.5
    RHS       R362                          9
    RHS       R363                          9.5
    RHS       R364                          9
    RHS       R365                          9.5
    RHS       R366                          6.5
    RHS       R367                          8.5
    RHS       R368                          8.5
    RHS       R369                          11.5
    RHS       R370                          12.5
    RHS       R371                          11.5
    RHS       R372                          11
    RHS       R373                          11
    RHS       R374                          13
    RHS       R375                          12
    RHS       R376                          13
    RHS       R377                          11.5
    RHS       R378                          11
    RHS       R379                          11
    RHS       R380                          11
    RHS       R381                          12.5
    RHS       R382                          12.5
    RHS       R383                          10.5
    RHS       R384                          11.5
    RHS       R385                          11
    RHS       R386                          2
    RHS       R387                          2
    RHS       R388                          2
    RHS       R389                          2
    RHS       R390                          2
    RHS       R391                          2
    RHS       R392                          2
    RHS       R393                          2
    RHS       R394                          2
    RHS       R395                          2
    RHS       R396                          2
    RHS       R397                          2
    RHS       R398                          2
    RHS       R399                          2
    RHS       R400                          2
    RHS       R401                          2
    RHS       R402                          2
    RHS       R403                          2
    RHS       R404                          2
    RHS       R405                          2
    RHS       R406                          2
    RHS       R407                          2
    RHS       R408                          2
    RHS       R409                          2
    RHS       R410                          2
    RHS       R411                          2
    RHS       R412                          2
    RHS       R413                          2
    RHS       R414                          2
    RHS       R415                          2
    RHS       R416                          2
    RHS       R417                          2
    RHS       R418                          2
    RHS       R419                          2
    RHS       R420                          2
    RHS       R421                          2
    RHS       R422                          2
    RHS       R423                          2
    RHS       R424                          2
    RHS       R425                          2
    RHS       R426                          2
    RHS       R427                          2
    RHS       R428                          2
    RHS       R429                          2
    RHS       R430                          2
    RHS       R431                          2
    RHS       R432                          2
    RHS       R433                          2
    RHS       R434                          2
    RHS       R435                          2
    RHS       R436                          2
    RHS       R437                          2
    RHS       R438                          2
    RHS       R439                          2
    RHS       R440                          2
    RHS       R441                          2
    RHS       R442                          2
    RHS       R443                          2
    RHS       R444                          2
    RHS       R445                          2
    RHS       R446                          2
    RHS       R447                          2
    RHS       R448                          2
    RHS       R449                          2
    RHS       R450                          2
    RHS       R451                          2
    RHS       R452                          2
    RHS       R453                          2
    RHS       R454                          2
    RHS       R455                          2
    RHS       R456                          2
    RHS       R457                          2
    RHS       R458                          2
    RHS       R459                          2
    RHS       R460                          2
    RHS       R461                          2
    RHS       R462                          2
    RHS       R463                          2
    RHS       R464                          2
    RHS       R465                          2
    RHS       R466                          2
    RHS       R467                          2
    RHS       R468                          2
    RHS       R469                          2
    RHS       R470                          2
    RHS       R471                          2
    RHS       R472                          2
    RHS       R473                          2
    RHS       R474                          2
    RHS       R475                          2
    RHS       R476                          2
    RHS       R477                          2
    RHS       R478                          2
    RHS       R479                          2
    RHS       R480                          2
    RHS       R481                          2
    RHS       R482                          2
    RHS       R483                          2
    RHS       R484                          2
    RHS       R485                          2
    RHS       R486                          2
    RHS       R487                          2
    RHS       R488                          2
    RHS       R489                          2
    RHS       R490                          2
    RHS       R491                          2
    RHS       R492                          2
    RHS       R493                          2
    RHS       R494                          2
    RHS       R495                          2
    RHS       R496                          2
    RHS       R497                          2
    RHS       R498                          2
    RHS       R499                          2
    RHS       R500                          2
    RHS       R501                          2
    RHS       R502                          2
    RHS       R503                          2
    RHS       R504                          2
    RHS       R505                          2
    RHS       R506                          2
    RHS       R507                          2
    RHS       R508                          2
    RHS       R509                          2
    RHS       R510                          2
    RHS       R511                          2
    RHS       R512                          2
    RHS       R513                          2
    RHS       R514                          2
    RHS       R515                          2
    RHS       R516                          2
    RHS       R517                          2
    RHS       R518                          2
    RHS       R519                          2
    RHS       R520                          2
    RHS       R521                          2
    RHS       R522                          2
    RHS       R523                          2
    RHS       R524                          2
    RHS       R525                          2
    RHS       R526                          2
    RHS       R527                          2
    RHS       R528                          2
    RHS       R529                          2
    RHS       R530                          2
    RHS       R531                          2
    RHS       R532                          2
    RHS       R533                          2
    RHS       R534                          2
    RHS       R535                          2
    RHS       R536                          2
    RHS       R537                          2
    RHS       R538                          2
    RHS       R539                          2
    RHS       R540                          2
    RHS       R541                          2
    RHS       R542                          2
    RHS       R543                          2
    RHS       R544                          2
    RHS       R545                          2
    RHS       R546                          2
    RHS       R547                          2
    RHS       R548                          2
    RHS       R549                          2
    RHS       R550                          2
    RHS       R551                          2
    RHS       R552                          2
    RHS       R553                          2
    RHS       R554                          2
    RHS       R555                          2
    RHS       R556                          2
    RHS       R557                          2
    RHS       R558                          2
    RHS       R559                          2
    RHS       R560                          2
    RHS       R561                          2
    RHS       R562                          2
    RHS       R563                          2
    RHS       R564                          2
    RHS       R565                          2
    RHS       R566                          2
    RHS       R567                          2
    RHS       R568                          2
    RHS       R569                          2
    RHS       R570                          2
    RHS       R571                          2
    RHS       R572                          2
    RHS       R573                          2
    RHS       R574                          2
    RHS       R575                          2
    RHS       R576                          2
    RHS       R577                          2
    RHS       R578                          2
    RHS       R579                          2
    RHS       R580                          2
    RHS       R581                          2
    RHS       R582                          2
    RHS       R583                          2
    RHS       R584                          2
    RHS       R585                          2
    RHS       R586                          2
    RHS       R587                          2
    RHS       R588                          2
    RHS       R589                          2
    RHS       R590                          2
    RHS       R591                          2
    RHS       R592                          2
    RHS       R593                          2
    RHS       R594                          2
    RHS       R595                          2
    RHS       R596                          2
    RHS       R597                          2
    RHS       R598                          2
    RHS       R599                          2
    RHS       R600                          2
    RHS       R601                          2
    RHS       R602                          2
    RHS       R603                          2
    RHS       R604                          2
    RHS       R605                          2
    RHS       R606                          2
    RHS       R607                          2
    RHS       R608                          2
    RHS       R609                          2
    RHS       R610                          2
    RHS       R611                          2
    RHS       R612                          2
    RHS       R613                          2
    RHS       R614                          2
    RHS       R615                          2
    RHS       R616                          2
    RHS       R617                          2
    RHS       R618                          2
    RHS       R619                          2
    RHS       R620                          2
    RHS       R621                          2
    RHS       R622                          2
    RHS       R623                          2
    RHS       R624                          2
    RHS       R625                          2
    RHS       R626                          2
    RHS       R627                          2
    RHS       R628                          2
    RHS       R629                          2
    RHS       R630                          2
    RHS       R631                          2
    RHS       R632                          2
    RHS       R633                          2
    RHS       R634                          2
    RHS       R635                          2
    RHS       R636                          2
    RHS       R637                          2
    RHS       R638                          2
    RHS       R639                          2
    RHS       R640                          2
    RHS       R641                          2
    RHS       R642                          2
    RHS       R643                          2
    RHS       R644                          2
    RHS       R645                          2
    RHS       R646                          2
    RHS       R647                          2
    RHS       R648                          2
    RHS       R649                          2
    RHS       R650                          2
    RHS       R651                          2
    RHS       R652                          2
    RHS       R653                          2
    RHS       R654                          2
    RHS       R655                          2
    RHS       R656                          2
    RHS       R657                          2
    RHS       R658                          2
    RHS       R659                          2
    RHS       R660                          2
    RHS       R661                          2
    RHS       R662                          2
    RHS       R663                          2
    RHS       R664                          2
    RHS       R665                          2
    RHS       R666                          2
    RHS       R667                          2
    RHS       R668                          2
    RHS       R669                          2
    RHS       R670                          2
    RHS       R671                          2
    RHS       R672                          2
    RHS       R673                          2
    RHS       R674                          2
    RHS       R675                          2
    RHS       R676                          2
    RHS       R677                          2
    RHS       R678                          2
    RHS       R679                          2
    RHS       R680                          2
    RHS       R681                          2
    RHS       R682                          2
    RHS       R683                          2
    RHS       R684                          2
    RHS       R685                          2
    RHS       R686                          2
    RHS       R687                          2
    RHS       R688                          2
    RHS       R689                          2
    RHS       R690                          2
    RHS       R691                          2
    RHS       R692                          2
    RHS       R693                          2
    RHS       R694                          2
    RHS       R695                          2
    RHS       R696                          2
    RHS       R697                          2
    RHS       R698                          2
    RHS       R699                          2
    RHS       R700                          2
    RHS       R701                          2
    RHS       R702                          2
    RHS       R703                          2
    RHS       R704                          2
    RHS       R705                          2
    RHS       R706                          2
    RHS       R707                          2
    RHS       R708                          2
    RHS       R709                          2
    RHS       R710                          2
    RHS       R711                          2
    RHS       R712                          2
    RHS       R713                          2
    RHS       R714                          2
    RHS       R715                          2
    RHS       R716                          2
    RHS       R717                          2
    RHS       R718                          2
    RHS       R719                          2
    RHS       R720                          2
    RHS       R721                          2
    RHS       R722                          2
    RHS       R723                          2
    RHS       R724                          2
    RHS       R725                          2
    RHS       R726                          2
    RHS       R727                          2
    RHS       R728                          2
    RHS       R729                          2
    RHS       R730                          2
    RHS       R731                          2
    RHS       R732                          2
    RHS       R733                          2
    RHS       R734                          2
    RHS       R735                          2
    RHS       R736                          2
    RHS       R737                          2
    RHS       R738                          2
    RHS       R739                          2
    RHS       R740                          2
    RHS       R741                          2
    RHS       R742                          2
    RHS       R743                          2
    RHS       R744                          2
    RHS       R745                          2
    RHS       R746                          2
    RHS       R747                          2
    RHS       R748                          2
    RHS       R749                          2
    RHS       R750                          2
    RHS       R751                          2
    RHS       R752                          2
    RHS       R753                          2
    RHS       R754                          2
    RHS       R755                          2
    RHS       R756                          2
    RHS       R757                          2
    RHS       R758                          2
    RHS       R759                          2
    RHS       R760                          2
    RHS       R761                          2
    RHS       R762                          2
    RHS       R763                          2
    RHS       R764                          2
    RHS       R765                          2
    RHS       R766                          2
    RHS       R767                          2
    RHS       R768                          2
    RHS       R769                          2
    RHS       R770                          2
    RHS       R771                          2
    RHS       R772                          2
    RHS       R773                          2
    RHS       R774                          2
    RHS       R775                          2
    RHS       R776                          2
    RHS       R777                          2
    RHS       R778                          2
    RHS       R779                          2
    RHS       R780                          2
    RHS       R781                          2
    RHS       R782                          2
    RHS       R783                          2
    RHS       R784                          2
    RHS       R785                          2
    RHS       R786                          2
    RHS       R787                          2
    RHS       R788                          2
    RHS       R789                          2
    RHS       R790                          2
    RHS       R791                          2
    RHS       R792                          2
    RHS       R793                          2
    RHS       R794                          2
    RHS       R795                          2
    RHS       R796                          2
    RHS       R797                          2
    RHS       R798                          2
    RHS       R799                          2
    RHS       R800                          2
    RHS       R801                          2
    RHS       R802                          2
    RHS       R803                          2
    RHS       R804                          2
    RHS       R805                          2
    RHS       R806                          2
    RHS       R807                          2
    RHS       R808                          2
    RHS       R809                          2
    RHS       R810                          2
    RHS       R811                          2
    RHS       R812                          2
    RHS       R813                          2
    RHS       R814                          2
    RHS       R815                          2
    RHS       R816                          2
    RHS       R817                          2
    RHS       R818                          2
    RHS       R819                          2
    RHS       R820                          2
    RHS       R821                          2
    RHS       R822                          2
    RHS       R823                          2
    RHS       R824                          2
    RHS       R825                          2
    RHS       R826                          2
    RHS       R827                          2
    RHS       R828                          2
    RHS       R829                          2
    RHS       R830                          2
    RHS       R831                          2
    RHS       R832                          2
    RHS       R833                          2
    RHS       R834                          2
    RHS       R835                          2
    RHS       R836                          2
    RHS       R837                          2
    RHS       R838                          2
    RHS       R839                          2
    RHS       R840                          2
    RHS       R841                          2
    RHS       R842                          2
    RHS       R843                          2
    RHS       R844                          2
    RHS       R845                          2
    RHS       R846                          2
    RHS       R847                          2
    RHS       R848                          2
    RHS       R849                          2
    RHS       R850                          2
    RHS       R851                          2
    RHS       R852                          2
    RHS       R853                          2
    RHS       R854                          2
    RHS       R855                          2
    RHS       R856                          2
    RHS       R857                          2
    RHS       R858                          2
    RHS       R859                          2
    RHS       R860                          2
    RHS       R861                          2
    RHS       R862                          2
    RHS       R863                          2
    RHS       R864                          2
    RHS       R865                          2
BOUNDS
 LO BND       X0                            1
 UP BND       X0                            34
 LO BND       X1                            1
 UP BND       X1                            36
 LO BND       X2                            1
 UP BND       X2                            37
 LO BND       X3                            1
 UP BND       X3                            37
 LO BND       X4                            1
 UP BND       X4                            36
 LO BND       X5                            1
 UP BND       X5                            34
 LO BND       X6                            1
 UP BND       X6                            35
 LO BND       X7                            1
 UP BND       X7                            34
 LO BND       X8                            1
 UP BND       X8                            33
 LO BND       X9                            1
 UP BND       X9                            33
 LO BND       X10                           1
 UP BND       X10                           32
 LO BND       X11                           1
 UP BND       X11                           31
 LO BND       X12                           1
 UP BND       X12                           33
 LO BND       X13                           1
 UP BND       X13                           33
 LO BND       X14                           1
 UP BND       X14                           32
 LO BND       X15                           1
 UP BND       X15                           29
 LO BND       X16                           1
 UP BND       X16                           32
 LO BND       X17                           1
 UP BND       X17                           32
 LO BND       X18                           1
 UP BND       X18                           32
 LO BND       X19                           1
 UP BND       X19                           31
 FR BND       X20                           
 FR BND       X21                           
 FR BND       X22                           
 FR BND       X23                           
 FR BND       X24                           
 FR BND       X25                           
 FR BND       X26                           
 FR BND       X27                           
 FR BND       X28                           
 FR BND       X29                           
 FR BND       X30                           
 FR BND       X31                           
 FR BND       X32                           
 FR BND       X33                           
 FR BND       X34                           
 FR BND       X35                           
 FR BND       X36                           
 FR BND       X37                           
 FR BND       X38                           
 FR BND       X39                           
 UP BND       X40                           43
 UP BND       X41                           42
 UP BND       X42                           42.5
 UP BND       X43                           42
 UP BND       X44                           43
 UP BND       X45                           43
 UP BND       X46                           43.5
 UP BND       X47                           42.5
 UP BND       X48                           42.5
 UP BND       X49                           42.5
 UP BND       X50                           43
 UP BND       X51                           42.5
 UP BND       X52                           42
 UP BND       X53                           42.5
 UP BND       X54                           42.5
 UP BND       X55                           43.5
 UP BND       X56                           43.5
 UP BND       X57                           42.5
 UP BND       X58                           43.5
 UP BND       X59                           42.5
 UP BND       X60                           42
 UP BND       X61                           42
 UP BND       X62                           43
 UP BND       X63                           44
 UP BND       X64                           43
 UP BND       X65                           42.5
 UP BND       X66                           42
 UP BND       X67                           42
 UP BND       X68                           42
 UP BND       X69                           43.5
 UP BND       X70                           43.5
 UP BND       X71                           42.5
 UP BND       X72                           42.5
 UP BND       X73                           42
 UP BND       X74                           1
 UP BND       X75                           1
 UP BND       X76                           1
 UP BND       X77                           1
 UP BND       X78                           1
 UP BND       X79                           1
 UP BND       X80                           1
 UP BND       X81                           1
 UP BND       X82                           1
 UP BND       X83                           1
 UP BND       X84                           1
 UP BND       X85                           1
 UP BND       X86                           1
 UP BND       X87                           1
 UP BND       X88                           1
 UP BND       X89                           1
 UP BND       X90                           1
 UP BND       X91                           1
 UP BND       X92                           1
 UP BND       X93                           1
 UP BND       X94                           1
 UP BND       X95                           1
 UP BND       X96                           1
 UP BND       X97                           1
 UP BND       X98                           1
 UP BND       X99                           1
 UP BND       X100                          1
 UP BND       X101                          1
 UP BND       X102                          1
 UP BND       X103                          1
 UP BND       X104                          1
 UP BND       X105                          1
 UP BND       X106                          1
 UP BND       X107                          1
 UP BND       X108                          1
 UP BND       X109                          1
 UP BND       X110                          1
 UP BND       X111                          1
 UP BND       X112                          1
 UP BND       X113                          1
 UP BND       X114                          1
 UP BND       X115                          1
 UP BND       X116                          1
 UP BND       X117                          1
 UP BND       X118                          1
 UP BND       X119                          1
 UP BND       X120                          1
 UP BND       X121                          1
 UP BND       X122                          1
 UP BND       X123                          1
 UP BND       X124                          1
 UP BND       X125                          1
 UP BND       X126                          1
 UP BND       X127                          1
 UP BND       X128                          1
 UP BND       X129                          1
 UP BND       X130                          1
 UP BND       X131                          1
 UP BND       X132                          1
 UP BND       X133                          1
 UP BND       X134                          1
 UP BND       X135                          1
 UP BND       X136                          1
 UP BND       X137                          1
 UP BND       X138                          1
 UP BND       X139                          1
 UP BND       X140                          1
 UP BND       X141                          1
 UP BND       X142                          1
 UP BND       X143                          1
 UP BND       X144                          1
 UP BND       X145                          1
 UP BND       X146                          1
 UP BND       X147                          1
 UP BND       X148                          1
 UP BND       X149                          1
 UP BND       X150                          1
 UP BND       X151                          1
 UP BND       X152                          1
 UP BND       X153                          1
 UP BND       X154                          1
 UP BND       X155                          1
 UP BND       X156                          1
 UP BND       X157                          1
 UP BND       X158                          1
 UP BND       X159                          1
 UP BND       X160                          1
 UP BND       X161                          1
 UP BND       X162                          1
 UP BND       X163                          1
 UP BND       X164                          1
 UP BND       X165                          1
 UP BND       X166                          1
 UP BND       X167                          1
 UP BND       X168                          1
 UP BND       X169                          1
 UP BND       X170                          1
 UP BND       X171                          1
 UP BND       X172                          1
 UP BND       X173                          1
 UP BND       X174                          1
 UP BND       X175                          1
 UP BND       X176                          1
 UP BND       X177                          1
 UP BND       X178                          1
 UP BND       X179                          1
 UP BND       X180                          1
 UP BND       X181                          1
 UP BND       X182                          1
 UP BND       X183                          1
 UP BND       X184                          1
 UP BND       X185                          1
 UP BND       X186                          1
 UP BND       X187                          1
 UP BND       X188                          1
 UP BND       X189                          1
 UP BND       X190                          1
 UP BND       X191                          1
 UP BND       X192                          1
 UP BND       X193                          1
 UP BND       X194                          1
 UP BND       X195                          1
 UP BND       X196                          1
 UP BND       X197                          1
 UP BND       X198                          1
 UP BND       X199                          1
 UP BND       X200                          1
 UP BND       X201                          1
 UP BND       X202                          1
 UP BND       X203                          1
 UP BND       X204                          1
 UP BND       X205                          1
 UP BND       X206                          1
 UP BND       X207                          1
 UP BND       X208                          1
 UP BND       X209                          1
 UP BND       X210                          1
 UP BND       X211                          1
 UP BND       X212                          1
 UP BND       X213                          1
 UP BND       X214                          1
 UP BND       X215                          1
 UP BND       X216                          1
 UP BND       X217                          1
 UP BND       X218                          1
 UP BND       X219                          1
 UP BND       X220                          1
 UP BND       X221                          1
 UP BND       X222                          1
 UP BND       X223                          1
 UP BND       X224                          1
 UP BND       X225                          1
 UP BND       X226                          1
 UP BND       X227                          1
 UP BND       X228                          1
 UP BND       X229                          1
 UP BND       X230                          1
 UP BND       X231                          1
 UP BND       X232                          1
 UP BND       X233                          1
 UP BND       X234                          1
 UP BND       X235                          1
 UP BND       X236                          1
 UP BND       X237                          1
 UP BND       X238                          1
 UP BND       X239                          1
 UP BND       X240                          1
 UP BND       X241                          1
 UP BND       X242                          1
 UP BND       X243                          1
 UP BND       X244                          1
 UP BND       X245                          1
 UP BND       X246                          1
 UP BND       X247                          1
 UP BND       X248                          1
 UP BND       X249                          1
 UP BND       X250                          1
 UP BND       X251                          1
 UP BND       X252                          1
 UP BND       X253                          1
ENDATA
