NAME          ic97_potential
ROWS
 N R0
 G R1
 L R2
 G R3
 L R4
 G R5
 L R6
 G R7
 L R8
 G R9
 L R10
 G R11
 L R12
 G R13
 L R14
 G R15
 L R16
 G R17
 L R18
 G R19
 L R20
 G R21
 L R22
 G R23
 L R24
 G R25
 L R26
 G R27
 L R28
 G R29
 L R30
 G R31
 L R32
 G R33
 L R34
 G R35
 L R36
 G R37
 L R38
 G R39
 L R40
 G R41
 L R42
 G R43
 L R44
 G R45
 L R46
 G R47
 L R48
 G R49
 L R50
 G R51
 L R52
 G R53
 L R54
 G R55
 L R56
 G R57
 L R58
 G R59
 L R60
 G R61
 L R62
 G R63
 L R64
 G R65
 L R66
 G R67
 L R68
 G R69
 L R70
 G R71
 L R72
 G R73
 L R74
 G R75
 L R76
 G R77
 L R78
 G R79
 L R80
 G R81
 L R82
 G R83
 L R84
 G R85
 L R86
 G R87
 L R88
 G R89
 L R90
 G R91
 L R92
 G R93
 L R94
 G R95
 L R96
 G R97
 L R98
 G R99
 L R100
 G R101
 L R102
 G R103
 L R104
 G R105
 L R106
 G R107
 L R108
 G R109
 L R110
 G R111
 L R112
 G R113
 L R114
 G R115
 L R116
 G R117
 L R118
 G R119
 L R120
 G R121
 L R122
 G R123
 L R124
 G R125
 L R126
 G R127
 L R128
 G R129
 L R130
 G R131
 L R132
 G R133
 L R134
 G R135
 L R136
 G R137
 L R138
 G R139
 L R140
 G R141
 L R142
 G R143
 L R144
 G R145
 L R146
 G R147
 L R148
 G R149
 L R150
 G R151
 L R152
 G R153
 L R154
 G R155
 L R156
 G R157
 L R158
 G R159
 L R160
 G R161
 L R162
 G R163
 L R164
 G R165
 L R166
 G R167
 L R168
 G R169
 L R170
 G R171
 L R172
 G R173
 L R174
 G R175
 L R176
 G R177
 L R178
 G R179
 L R180
 G R181
 L R182
 G R183
 L R184
 G R185
 L R186
 G R187
 L R188
 G R189
 L R190
 G R191
 L R192
 G R193
 L R194
 G R195
 L R196
 G R197
 L R198
 G R199
 L R200
 G R201
 L R202
 G R203
 L R204
 G R205
 L R206
 G R207
 L R208
 G R209
 L R210
 G R211
 L R212
 G R213
 L R214
 G R215
 L R216
 G R217
 L R218
 G R219
 L R220
 G R221
 L R222
 G R223
 L R224
 G R225
 L R226
 G R227
 L R228
 G R229
 L R230
 G R231
 L R232
 G R233
 L R234
 G R235
 L R236
 G R237
 L R238
 G R239
 L R240
 G R241
 L R242
 G R243
 L R244
 G R245
 L R246
 G R247
 L R248
 G R249
 L R250
 G R251
 L R252
 G R253
 L R254
 G R255
 L R256
 G R257
 L R258
 G R259
 L R260
 G R261
 L R262
 G R263
 L R264
 G R265
 L R266
 G R267
 L R268
 G R269
 L R270
 G R271
 L R272
 G R273
 L R274
 G R275
 L R276
 G R277
 L R278
 G R279
 L R280
 G R281
 L R282
 G R283
 L R284
 G R285
 L R286
 G R287
 L R288
 G R289
 L R290
 G R291
 L R292
 G R293
 L R294
 G R295
 L R296
 G R297
 L R298
 G R299
 L R300
 G R301
 L R302
 G R303
 L R304
 G R305
 L R306
 G R307
 L R308
 G R309
 L R310
 G R311
 L R312
 G R313
 L R314
 G R315
 L R316
 G R317
 L R318
 G R319
 L R320
 G R321
 L R322
 G R323
 L R324
 G R325
 L R326
 G R327
 L R328
 G R329
 L R330
 G R331
 L R332
 G R333
 L R334
 G R335
 L R336
 G R337
 L R338
 G R339
 L R340
 G R341
 L R342
 G R343
 L R344
 G R345
 L R346
 G R347
 L R348
 G R349
 L R350
 G R351
 L R352
 G R353
 L R354
 G R355
 L R356
 G R357
 L R358
 G R359
 L R360
 G R361
 L R362
 G R363
 L R364
 G R365
 L R366
 G R367
 L R368
 G R369
 L R370
 G R371
 L R372
 G R373
 L R374
 G R375
 L R376
 G R377
 L R378
 G R379
 L R380
 G R381
 L R382
 G R383
 L R384
 G R385
 L R386
 G R387
 L R388
 G R389
 L R390
 G R391
 L R392
 G R393
 L R394
 G R395
 L R396
 G R397
 L R398
 G R399
 L R400
 G R401
 L R402
 G R403
 L R404
 G R405
 L R406
 G R407
 L R408
 G R409
 L R410
 G R411
 L R412
 G R413
 L R414
 G R415
 L R416
 G R417
 L R418
 G R419
 L R420
 G R421
 L R422
 G R423
 L R424
 G R425
 L R426
 G R427
 L R428
 G R429
 L R430
 G R431
 L R432
 G R433
 L R434
 G R435
 L R436
 G R437
 L R438
 G R439
 L R440
 G R441
 L R442
 G R443
 L R444
 G R445
 L R446
 G R447
 L R448
 G R449
 L R450
 G R451
 L R452
 G R453
 L R454
 G R455
 L R456
 G R457
 L R458
 G R459
 L R460
 G R461
 L R462
 G R463
 L R464
 G R465
 L R466
 G R467
 L R468
 G R469
 L R470
 G R471
 L R472
 G R473
 L R474
 G R475
 L R476
 G R477
 L R478
 G R479
 L R480
 G R481
 L R482
 G R483
 L R484
 G R485
 L R486
 G R487
 L R488
 G R489
 L R490
 G R491
 L R492
 G R493
 L R494
 G R495
 L R496
 G R497
 L R498
 G R499
 L R500
 G R501
 L R502
 G R503
 L R504
 G R505
 L R506
 G R507
 L R508
 G R509
 L R510
 G R511
 L R512
 G R513
 L R514
 G R515
 L R516
 G R517
 L R518
 G R519
 L R520
 G R521
 L R522
 G R523
 L R524
 G R525
 L R526
 G R527
 L R528
 G R529
 L R530
 G R531
 L R532
 G R533
 L R534
 G R535
 L R536
 G R537
 L R538
 G R539
 L R540
 G R541
 L R542
 G R543
 L R544
 G R545
 L R546
 G R547
 L R548
 G R549
 L R550
 G R551
 L R552
 G R553
 L R554
 G R555
 L R556
 G R557
 L R558
 G R559
 L R560
 G R561
 L R562
 G R563
 L R564
 G R565
 L R566
 G R567
 L R568
 G R569
 L R570
 G R571
 L R572
 G R573
 L R574
 G R575
 L R576
 G R577
 L R578
 G R579
 L R580
 G R581
 L R582
 G R583
 L R584
 G R585
 L R586
 G R587
 L R588
 G R589
 L R590
 G R591
 L R592
 G R593
 L R594
 G R595
 L R596
 G R597
 L R598
 G R599
 L R600
 G R601
 L R602
 G R603
 L R604
 G R605
 L R606
 G R607
 L R608
 G R609
 L R610
 G R611
 L R612
 G R613
 L R614
 G R615
 L R616
 G R617
 L R618
 G R619
 L R620
 G R621
 L R622
 G R623
 L R624
 G R625
 L R626
 G R627
 L R628
 G R629
 L R630
 G R631
 L R632
 G R633
 L R634
 G R635
 L R636
 G R637
 L R638
 G R639
 L R640
 G R641
 L R642
 G R643
 L R644
 G R645
 L R646
 G R647
 L R648
 G R649
 L R650
 G R651
 L R652
 G R653
 L R654
 G R655
 L R656
 G R657
 L R658
 G R659
 L R660
 G R661
 L R662
 G R663
 L R664
 G R665
 L R666
 G R667
 L R668
 G R669
 L R670
 G R671
 L R672
 G R673
 L R674
 G R675
 L R676
 G R677
 L R678
 G R679
 L R680
 G R681
 L R682
 G R683
 L R684
 G R685
 L R686
 G R687
 L R688
 G R689
 L R690
 G R691
 L R692
 G R693
 L R694
 G R695
 L R696
 G R697
 L R698
 G R699
 L R700
 G R701
 L R702
 G R703
 L R704
 G R705
 L R706
 G R707
 L R708
 G R709
 L R710
 G R711
 L R712
 G R713
 L R714
 G R715
 L R716
 G R717
 L R718
 G R719
 L R720
 G R721
 L R722
 G R723
 L R724
 G R725
 L R726
 G R727
 L R728
 G R729
 L R730
 G R731
 L R732
 G R733
 L R734
 G R735
 L R736
 G R737
 L R738
 G R739
 L R740
 G R741
 L R742
 G R743
 L R744
 G R745
 L R746
 G R747
 L R748
 G R749
 L R750
 G R751
 L R752
 G R753
 L R754
 G R755
 L R756
 G R757
 L R758
 G R759
 L R760
 G R761
 L R762
 G R763
 L R764
 G R765
 L R766
 G R767
 L R768
 G R769
 L R770
 G R771
 L R772
 G R773
 L R774
 G R775
 L R776
 G R777
 L R778
 G R779
 L R780
 G R781
 L R782
 G R783
 L R784
 G R785
 L R786
 G R787
 L R788
 G R789
 L R790
 G R791
 L R792
 G R793
 L R794
 G R795
 L R796
 G R797
 L R798
 G R799
 L R800
 G R801
 L R802
 G R803
 L R804
 G R805
 L R806
 G R807
 L R808
 G R809
 L R810
 G R811
 L R812
 G R813
 L R814
 G R815
 L R816
 G R817
 L R818
 G R819
 L R820
 G R821
 L R822
 G R823
 L R824
 G R825
 L R826
 G R827
 L R828
 G R829
 L R830
 G R831
 L R832
 G R833
 L R834
 G R835
 L R836
 G R837
 L R838
 G R839
 L R840
 G R841
 L R842
 G R843
 L R844
 G R845
 L R846
 G R847
 L R848
 G R849
 L R850
 G R851
 L R852
 G R853
 L R854
 G R855
 L R856
 G R857
 L R858
 G R859
 L R860
 G R861
 L R862
 G R863
 L R864
 G R865
 L R866
 G R867
 L R868
 G R869
 L R870
 G R871
 L R872
 G R873
 L R874
 G R875
 L R876
 G R877
 L R878
 G R879
 L R880
 G R881
 L R882
 G R883
 L R884
 G R885
 L R886
 G R887
 L R888
 G R889
 L R890
 G R891
 L R892
 G R893
 L R894
 G R895
 L R896
 G R897
 L R898
 G R899
 L R900
 G R901
 L R902
 G R903
 L R904
 G R905
 L R906
 G R907
 L R908
 G R909
 L R910
 G R911
 L R912
 G R913
 L R914
 G R915
 L R916
 G R917
 L R918
 G R919
 L R920
 G R921
 L R922
 G R923
 L R924
 G R925
 L R926
 G R927
 L R928
 G R929
 L R930
 G R931
 L R932
 G R933
 L R934
 G R935
 L R936
 G R937
 L R938
 G R939
 L R940
 G R941
 L R942
 G R943
 L R944
 G R945
 L R946
 G R947
 L R948
 G R949
 L R950
 G R951
 L R952
 G R953
 L R954
 G R955
 L R956
 G R957
 L R958
 G R959
 L R960
 G R961
 L R962
 G R963
 L R964
 G R965
 L R966
 G R967
 L R968
 G R969
 L R970
 G R971
 L R972
 G R973
 L R974
 G R975
 L R976
 G R977
 L R978
 G R979
 L R980
 G R981
 L R982
 G R983
 L R984
 G R985
 L R986
 G R987
 L R988
 G R989
 L R990
 G R991
 L R992
 G R993
 L R994
 G R995
 L R996
 G R997
 L R998
 G R999
 L R1000
 G R1001
 L R1002
 G R1003
 L R1004
 G R1005
 L R1006
 G R1007
 L R1008
 G R1009
 L R1010
 G R1011
 L R1012
 G R1013
 L R1014
 G R1015
 L R1016
 G R1017
 L R1018
 G R1019
 L R1020
 G R1021
 L R1022
 G R1023
 L R1024
 G R1025
 L R1026
 G R1027
 L R1028
 G R1029
 L R1030
 G R1031
 L R1032
 G R1033
 L R1034
 G R1035
 L R1036
 G R1037
 L R1038
 G R1039
 L R1040
 G R1041
 L R1042
 G R1043
 L R1044
 G R1045
 L R1046
COLUMNS
    X0        R0                            2
    X0        R1                            1
    X0        R2                            1
    X0        R23                           1
    X0        R24                           1
    X0        R87                           1
    X0        R88                           1
    X0        R475                          -1
    X0        R476                          -1
    X0        R827                          1
    X0        R828                          1
    X0        R829                          -1
    X0        R830                          -1
    X0        R1031                         -1
    X0        R1032                         -1
    X1        R1                            -1
    X1        R2                            -1
    X1        R49                           1
    X1        R50                           1
    X1        R191                          -1
    X1        R192                          -1
    X1        R695                          1
    X1        R696                          1
    X1        R697                          -1
    X1        R698                          -1
    X2        R0                            60
    X2        R1                            60
    X2        R2                            60
    X3        R0                            2
    X3        R3                            1
    X3        R4                            1
    X3        R341                          1
    X3        R342                          1
    X3        R509                          -1
    X3        R510                          -1
    X3        R511                          -1
    X3        R512                          -1
    X3        R513                          -1
    X3        R514                          -1
    X3        R845                          1
    X3        R846                          1
    X4        R3                            -1
    X4        R4                            -1
    X4        R57                           1
    X4        R58                           1
    X4        R209                          -1
    X4        R210                          -1
    X4        R211                          -1
    X4        R212                          -1
    X4        R705                          1
    X4        R706                          1
    X4        R707                          -1
    X4        R708                          -1
    X5        R0                            60
    X5        R3                            60
    X5        R4                            60
    X6        R0                            1
    X6        R5                            1
    X6        R6                            1
    X6        R519                          -1
    X6        R520                          -1
    X6        R849                          1
    X6        R850                          1
    X6        R851                          -1
    X6        R852                          -1
    X6        R1031                         1
    X6        R1032                         1
    X7        R0                            -2
    X7        R5                            -1
    X7        R6                            -1
    X7        R95                           1
    X7        R96                           1
    X7        R113                          -1
    X7        R114                          -1
    X7        R321                          -1
    X7        R322                          -1
    X7        R323                          -1
    X7        R324                          -1
    X7        R325                          -1
    X7        R326                          -1
    X7        R327                          -1
    X7        R328                          -1
    X7        R735                          -1
    X7        R736                          -1
    X8        R0                            60
    X8        R5                            60
    X8        R6                            60
    X9        R7                            1
    X9        R8                            1
    X9        R47                           -1
    X9        R48                           -1
    X9        R113                          1
    X9        R114                          1
    X9        R131                          1
    X9        R132                          1
    X9        R137                          -1
    X9        R138                          -1
    X9        R213                          1
    X9        R214                          1
    X9        R867                          1
    X9        R868                          1
    X9        R869                          -1
    X9        R870                          -1
    X10       R0                            -1
    X10       R7                            -1
    X10       R8                            -1
    X10       R9                            -1
    X10       R10                           -1
    X10       R59                           1
    X10       R60                           1
    X10       R209                          1
    X10       R210                          1
    X10       R337                          -1
    X10       R338                          -1
    X10       R339                          -1
    X10       R340                          -1
    X10       R743                          1
    X10       R744                          1
    X10       R745                          -1
    X10       R746                          -1
    X11       R0                            60
    X11       R7                            60
    X11       R8                            60
    X12       R9                            1
    X12       R10                           1
    X12       R345                          1
    X12       R346                          1
    X12       R511                          1
    X12       R512                          1
    X12       R621                          1
    X12       R622                          1
    X12       R665                          -1
    X12       R666                          -1
    X12       R969                          -1
    X12       R970                          -1
    X13       R0                            60
    X13       R9                            60
    X13       R10                           60
    X14       R11                           1
    X14       R12                           1
    X14       R53                           -1
    X14       R54                           -1
    X14       R87                           -1
    X14       R88                           -1
    X14       R89                           -1
    X14       R90                           -1
    X14       R697                          1
    X14       R698                          1
    X14       R699                          -1
    X14       R700                          -1
    X14       R1009                         -1
    X14       R1010                         -1
    X15       R0                            -2
    X15       R11                           -1
    X15       R12                           -1
    X15       R97                           1
    X15       R98                           1
    X15       R131                          -1
    X15       R132                          -1
    X15       R321                          1
    X15       R322                          1
    X15       R469                          -1
    X15       R470                          -1
    X15       R471                          -1
    X15       R472                          -1
    X15       R473                          -1
    X15       R474                          -1
    X15       R827                          -1
    X15       R828                          -1
    X16       R0                            60
    X16       R11                           60
    X16       R12                           60
    X17       R13                           1
    X17       R14                           1
    X17       R45                           -1
    X17       R46                           -1
    X17       R95                           -1
    X17       R96                           -1
    X17       R97                           -1
    X17       R98                           -1
    X17       R99                           -1
    X17       R100                          -1
    X17       R213                          -1
    X17       R214                          -1
    X17       R707                          1
    X17       R708                          1
    X17       R709                          -1
    X17       R710                          -1
    X18       R0                            -2
    X18       R13                           -1
    X18       R14                           -1
    X18       R15                           -1
    X18       R16                           -1
    X18       R337                          1
    X18       R338                          1
    X18       R505                          -1
    X18       R506                          -1
    X18       R507                          -1
    X18       R508                          -1
    X18       R843                          1
    X18       R844                          1
    X18       R845                          -1
    X18       R846                          -1
    X19       R0                            60
    X19       R13                           60
    X19       R14                           60
    X20       R15                           1
    X20       R16                           1
    X20       R347                          1
    X20       R348                          1
    X20       R513                          1
    X20       R514                          1
    X20       R623                          1
    X20       R624                          1
    X20       R665                          1
    X20       R666                          1
    X20       R973                          -1
    X20       R974                          -1
    X21       R0                            60
    X21       R15                           60
    X21       R16                           60
    X22       R0                            1
    X22       R17                           1
    X22       R18                           1
    X22       R21                           1
    X22       R22                           1
    X22       R55                           -1
    X22       R56                           -1
    X22       R735                          1
    X22       R736                          1
    X22       R737                          -1
    X22       R738                          -1
    X22       R1009                         1
    X22       R1010                         1
    X23       R17                           -1
    X23       R18                           -1
    X23       R51                           1
    X23       R52                           1
    X23       R191                          1
    X23       R192                          1
    X23       R847                          1
    X23       R848                          1
    X23       R849                          -1
    X23       R850                          -1
    X24       R0                            60
    X24       R17                           60
    X24       R18                           60
    X25       R0                            2
    X25       R19                           1
    X25       R20                           1
    X25       R341                          -1
    X25       R342                          -1
    X25       R343                          -1
    X25       R344                          -1
    X25       R345                          -1
    X25       R346                          -1
    X25       R347                          -1
    X25       R348                          -1
    X25       R745                          1
    X25       R746                          1
    X26       R0                            -1
    X26       R19                           -1
    X26       R20                           -1
    X26       R211                          1
    X26       R212                          1
    X26       R505                          1
    X26       R506                          1
    X26       R533                          -1
    X26       R534                          -1
    X26       R865                          1
    X26       R866                          1
    X26       R867                          -1
    X26       R868                          -1
    X27       R0                            60
    X27       R19                           60
    X27       R20                           60
    X28       R21                           -1
    X28       R22                           -1
    X28       R325                          1
    X28       R326                          1
    X28       R471                          1
    X28       R472                          1
    X28       R617                          1
    X28       R618                          1
    X28       R663                          -1
    X28       R664                          -1
    X28       R967                          1
    X28       R968                          1
    X29       R0                            60
    X29       R21                           60
    X29       R22                           60
    X30       R23                           -1
    X30       R24                           -1
    X30       R327                          1
    X30       R328                          1
    X30       R473                          1
    X30       R474                          1
    X30       R619                          1
    X30       R620                          1
    X30       R663                          1
    X30       R664                          1
    X30       R971                          1
    X30       R972                          1
    X31       R0                            60
    X31       R23                           60
    X31       R24                           60
    X32       R0                            2
    X32       R25                           1
    X32       R26                           1
    X32       R121                          1
    X32       R122                          1
    X32       R123                          1
    X32       R124                          1
    X32       R881                          1
    X32       R882                          1
    X33       R0                            -1
    X33       R25                           -1
    X33       R26                           -1
    X33       R367                          -1
    X33       R368                          -1
    X33       R369                          -1
    X33       R370                          -1
    X33       R371                          -1
    X33       R372                          -1
    X33       R753                          1
    X33       R754                          1
    X33       R755                          -1
    X33       R756                          -1
    X34       R0                            60
    X34       R25                           60
    X34       R26                           60
    X35       R0                            1
    X35       R27                           1
    X35       R28                           1
    X35       R387                          1
    X35       R388                          1
    X35       R417                          1
    X35       R418                          1
    X35       R443                          1
    X35       R444                          1
    X35       R883                          1
    X35       R884                          1
    X35       R885                          -1
    X35       R886                          -1
    X36       R0                            -1
    X36       R27                           -1
    X36       R28                           -1
    X36       R121                          -1
    X36       R122                          -1
    X36       R381                          -1
    X36       R382                          -1
    X36       R765                          1
    X36       R766                          1
    X36       R767                          -1
    X36       R768                          -1
    X37       R0                            60
    X37       R27                           60
    X37       R28                           60
    X38       R0                            1
    X38       R29                           1
    X38       R30                           1
    X38       R803                          1
    X38       R804                          1
    X38       R805                          -1
    X38       R806                          -1
    X38       R1023                         1
    X38       R1024                         1
    X39       R29                           -1
    X39       R30                           -1
    X39       R367                          1
    X39       R368                          1
    X39       R411                          -1
    X39       R412                          -1
    X39       R413                          -1
    X39       R414                          -1
    X39       R783                          1
    X39       R784                          1
    X40       R0                            60
    X40       R29                           60
    X40       R30                           60
    X41       R31                           1
    X41       R32                           1
    X41       R383                          1
    X41       R384                          1
    X41       R415                          -1
    X41       R416                          -1
    X41       R417                          -1
    X41       R418                          -1
    X41       R785                          -1
    X41       R786                          -1
    X42       R0                            -1
    X42       R31                           -1
    X42       R32                           -1
    X42       R123                          -1
    X42       R124                          -1
    X42       R381                          1
    X42       R382                          1
    X42       R813                          1
    X42       R814                          1
    X42       R815                          -1
    X42       R816                          -1
    X43       R0                            60
    X43       R31                           60
    X43       R32                           60
    X44       R0                            1
    X44       R33                           1
    X44       R34                           1
    X44       R755                          1
    X44       R756                          1
    X44       R757                          -1
    X44       R758                          -1
    X44       R1023                         -1
    X44       R1024                         -1
    X45       R0                            -1
    X45       R33                           -1
    X45       R34                           -1
    X45       R371                          1
    X45       R372                          1
    X45       R413                          1
    X45       R414                          1
    X45       R441                          1
    X45       R442                          1
    X45       R879                          1
    X45       R880                          1
    X45       R881                          -1
    X45       R882                          -1
    X46       R0                            60
    X46       R33                           60
    X46       R34                           60
    X47       R0                            1
    X47       R35                           1
    X47       R36                           1
    X47       R383                          -1
    X47       R384                          -1
    X47       R385                          -1
    X47       R386                          -1
    X47       R387                          -1
    X47       R388                          -1
    X47       R767                          1
    X47       R768                          1
    X47       R769                          -1
    X47       R770                          -1
    X48       R0                            -2
    X48       R35                           -1
    X48       R36                           -1
    X48       R883                          -1
    X48       R884                          -1
    X49       R0                            60
    X49       R35                           60
    X49       R36                           60
    X50       R37                           1
    X50       R38                           1
    X50       R653                          1
    X50       R654                          1
    X50       R963                          -1
    X50       R964                          -1
    X51       R0                            -1
    X51       R37                           -1
    X51       R38                           -1
    X51       R279                          -1
    X51       R280                          -1
    X51       R281                          -1
    X51       R282                          -1
    X51       R283                          -1
    X51       R284                          -1
    X51       R285                          -1
    X51       R286                          -1
    X51       R287                          -1
    X51       R288                          -1
    X51       R725                          1
    X51       R726                          1
    X51       R727                          -1
    X51       R728                          -1
    X52       R0                            60
    X52       R37                           60
    X52       R38                           60
    X53       R0                            2
    X53       R39                           1
    X53       R40                           1
    X53       R77                           1
    X53       R78                           1
    X53       R111                          1
    X53       R112                          1
    X53       R145                          1
    X53       R146                          1
    X53       R147                          -1
    X53       R148                          -1
    X53       R257                          1
    X53       R258                          1
    X53       R265                          1
    X53       R266                          1
    X53       R267                          1
    X53       R268                          1
    X53       R431                          1
    X53       R432                          1
    X53       R437                          1
    X53       R438                          1
    X53       R545                          1
    X53       R546                          1
    X53       R549                          1
    X53       R550                          1
    X53       R587                          1
    X53       R588                          1
    X53       R589                          1
    X53       R590                          1
    X53       R637                          1
    X53       R638                          1
    X53       R997                          1
    X53       R998                          1
    X54       R39                           -1
    X54       R40                           -1
    X54       R657                          -1
    X54       R658                          -1
    X54       R961                          1
    X54       R962                          1
    X55       R0                            60
    X55       R39                           60
    X55       R40                           60
    X56       R0                            1
    X56       R41                           1
    X56       R42                           1
    X56       R249                          -1
    X56       R250                          -1
    X56       R251                          -1
    X56       R252                          -1
    X56       R253                          -1
    X56       R254                          -1
    X56       R255                          -1
    X56       R256                          -1
    X56       R257                          -1
    X56       R258                          -1
    X56       R717                          1
    X56       R718                          1
    X56       R719                          -1
    X56       R720                          -1
    X57       R41                           -1
    X57       R42                           -1
    X57       R657                          1
    X57       R658                          1
    X57       R965                          1
    X57       R966                          1
    X58       R0                            60
    X58       R41                           60
    X58       R42                           60
    X59       R43                           1
    X59       R44                           1
    X59       R653                          -1
    X59       R654                          -1
    X59       R959                          -1
    X59       R960                          -1
    X60       R0                            -2
    X60       R43                           -1
    X60       R44                           -1
    X60       R109                          1
    X60       R110                          1
    X60       R147                          1
    X60       R148                          1
    X60       R269                          1
    X60       R270                          1
    X60       R273                          1
    X60       R274                          1
    X60       R287                          1
    X60       R288                          1
    X60       R451                          1
    X60       R452                          1
    X60       R459                          1
    X60       R460                          1
    X60       R553                          1
    X60       R554                          1
    X60       R559                          1
    X60       R560                          1
    X60       R591                          1
    X60       R592                          1
    X60       R595                          1
    X60       R596                          1
    X60       R639                          1
    X60       R640                          1
    X60       R999                          -1
    X60       R1000                         -1
    X61       R0                            60
    X61       R43                           60
    X61       R44                           60
    X62       R45                           1
    X62       R46                           1
    X62       R215                          1
    X62       R216                          1
    X62       R535                          1
    X62       R536                          1
    X62       R961                          -1
    X62       R962                          -1
    X62       R1025                         -1
    X62       R1026                         -1
    X63       R0                            60
    X63       R45                           60
    X63       R46                           60
    X64       R47                           1
    X64       R48                           1
    X64       R217                          1
    X64       R218                          1
    X64       R537                          1
    X64       R538                          1
    X64       R965                          -1
    X64       R966                          -1
    X64       R1025                         1
    X64       R1026                         1
    X65       R0                            60
    X65       R47                           60
    X65       R48                           60
    X66       R49                           -1
    X66       R50                           -1
    X66       R187                          1
    X66       R188                          1
    X66       R515                          1
    X66       R516                          1
    X66       R655                          -1
    X66       R656                          -1
    X66       R959                          1
    X66       R960                          1
    X67       R0                            60
    X67       R49                           60
    X67       R50                           60
    X68       R51                           -1
    X68       R52                           -1
    X68       R189                          1
    X68       R190                          1
    X68       R517                          1
    X68       R518                          1
    X68       R655                          1
    X68       R656                          1
    X68       R963                          1
    X68       R964                          1
    X69       R0                            60
    X69       R51                           60
    X69       R52                           60
    X70       R53                           1
    X70       R54                           1
    X70       R91                           1
    X70       R92                           1
    X70       R115                          1
    X70       R116                          1
    X70       R195                          1
    X70       R196                          1
    X70       R329                          1
    X70       R330                          1
    X70       R675                          -1
    X70       R676                          -1
    X70       R975                          -1
    X70       R976                          -1
    X71       R0                            60
    X71       R53                           60
    X71       R54                           60
    X72       R55                           1
    X72       R56                           1
    X72       R93                           1
    X72       R94                           1
    X72       R117                          1
    X72       R118                          1
    X72       R197                          1
    X72       R198                          1
    X72       R331                          1
    X72       R332                          1
    X72       R675                          1
    X72       R676                          1
    X72       R983                          -1
    X72       R984                          -1
    X73       R0                            60
    X73       R55                           60
    X73       R56                           60
    X74       R57                           -1
    X74       R58                           -1
    X74       R205                          1
    X74       R206                          1
    X74       R333                          1
    X74       R334                          1
    X74       R685                          -1
    X74       R686                          -1
    X74       R981                          1
    X74       R982                          1
    X75       R0                            60
    X75       R57                           60
    X75       R58                           60
    X76       R59                           -1
    X76       R60                           -1
    X76       R207                          1
    X76       R208                          1
    X76       R335                          1
    X76       R336                          1
    X76       R685                          1
    X76       R686                          1
    X76       R989                          1
    X76       R990                          1
    X77       R0                            60
    X77       R59                           60
    X77       R60                           60
    X78       R0                            2
    X78       R61                           1
    X78       R62                           1
    X78       R81                           -1
    X78       R82                           -1
    X78       R165                          1
    X78       R166                          1
    X78       R363                          1
    X78       R364                          1
    X78       R407                          1
    X78       R408                          1
    X78       R951                          1
    X78       R952                          1
    X79       R0                            -2
    X79       R61                           -1
    X79       R62                           -1
    X79       R185                          -1
    X79       R186                          -1
    X79       R187                          -1
    X79       R188                          -1
    X79       R189                          -1
    X79       R190                          -1
    X79       R695                          -1
    X79       R696                          -1
    X80       R0                            60
    X80       R61                           60
    X80       R62                           60
    X81       R0                            2
    X81       R63                           1
    X81       R64                           1
    X81       R81                           1
    X81       R82                           1
    X81       R167                          1
    X81       R168                          1
    X81       R365                          1
    X81       R366                          1
    X81       R409                          1
    X81       R410                          1
    X81       R953                          1
    X81       R954                          1
    X82       R0                            -2
    X82       R63                           -1
    X82       R64                           -1
    X82       R185                          1
    X82       R186                          1
    X82       R515                          -1
    X82       R516                          -1
    X82       R517                          -1
    X82       R518                          -1
    X82       R847                          -1
    X82       R848                          -1
    X83       R0                            60
    X83       R63                           60
    X83       R64                           60
    X84       R0                            2
    X84       R65                           1
    X84       R66                           1
    X84       R215                          -1
    X84       R216                          -1
    X84       R217                          -1
    X84       R218                          -1
    X84       R709                          1
    X84       R710                          1
    X84       R1033                         -1
    X84       R1034                         -1
    X85       R0                            -2
    X85       R65                           -1
    X85       R66                           -1
    X85       R83                           -1
    X85       R84                           -1
    X85       R169                          1
    X85       R170                          1
    X85       R955                          -1
    X85       R956                          -1
    X86       R0                            60
    X86       R65                           60
    X86       R66                           60
    X87       R0                            2
    X87       R67                           1
    X87       R68                           1
    X87       R535                          -1
    X87       R536                          -1
    X87       R537                          -1
    X87       R538                          -1
    X87       R869                          1
    X87       R870                          1
    X87       R1033                         1
    X87       R1034                         1
    X88       R0                            -2
    X88       R67                           -1
    X88       R68                           -1
    X88       R83                           1
    X88       R84                           1
    X88       R171                          1
    X88       R172                          1
    X88       R957                          -1
    X88       R958                          -1
    X89       R0                            60
    X89       R67                           60
    X89       R68                           60
    X90       R161                          -1
    X90       R162                          -1
    X90       R163                          -1
    X90       R164                          -1
    X90       R165                          -1
    X90       R166                          -1
    X90       R167                          -1
    X90       R168                          -1
    X90       R687                          1
    X90       R688                          1
    X90       R689                          -1
    X90       R690                          -1
    X91       R0                            -1
    X91       R149                          -1
    X91       R150                          -1
    X91       R151                          -1
    X91       R152                          -1
    X91       R153                          -1
    X91       R154                          -1
    X91       R155                          -1
    X91       R156                          -1
    X91       R157                          -1
    X91       R158                          -1
    X91       R159                          -1
    X91       R160                          -1
    X91       R687                          -1
    X91       R688                          -1
    X92       R0                            60
    X92       R687                          60
    X92       R688                          60
    X93       R0                            1
    X93       R69                           1
    X93       R70                           1
    X93       R689                          1
    X93       R690                          1
    X94       R0                            60
    X94       R689                          60
    X94       R690                          60
    X95       R169                          -1
    X95       R170                          -1
    X95       R171                          -1
    X95       R172                          -1
    X95       R691                          1
    X95       R692                          1
    X95       R693                          -1
    X95       R694                          -1
    X96       R0                            -1
    X96       R71                           1
    X96       R72                           1
    X96       R691                          -1
    X96       R692                          -1
    X97       R0                            60
    X97       R691                          60
    X97       R692                          60
    X98       R0                            1
    X98       R173                          -1
    X98       R174                          -1
    X98       R175                          -1
    X98       R176                          -1
    X98       R177                          -1
    X98       R178                          -1
    X98       R179                          -1
    X98       R180                          -1
    X98       R181                          -1
    X98       R182                          -1
    X98       R183                          -1
    X98       R184                          -1
    X98       R693                          1
    X98       R694                          1
    X99       R0                            60
    X99       R693                          60
    X99       R694                          60
    X100      R0                            60
    X100      R695                          60
    X100      R696                          60
    X101      R0                            60
    X101      R697                          60
    X101      R698                          60
    X102      R193                          -1
    X102      R194                          -1
    X102      R195                          -1
    X102      R196                          -1
    X102      R197                          -1
    X102      R198                          -1
    X102      R699                          1
    X102      R700                          1
    X102      R701                          -1
    X102      R702                          -1
    X103      R0                            60
    X103      R699                          60
    X103      R700                          60
    X104      R0                            1
    X104      R199                          -1
    X104      R200                          -1
    X104      R701                          1
    X104      R702                          1
    X105      R0                            60
    X105      R701                          60
    X105      R702                          60
    X106      R91                           -1
    X106      R92                           -1
    X106      R93                           -1
    X106      R94                           -1
    X106      R203                          -1
    X106      R204                          -1
    X106      R205                          -1
    X106      R206                          -1
    X106      R207                          -1
    X106      R208                          -1
    X106      R703                          1
    X106      R704                          1
    X106      R705                          -1
    X106      R706                          -1
    X107      R0                            -1
    X107      R201                          -1
    X107      R202                          -1
    X107      R703                          -1
    X107      R704                          -1
    X108      R0                            60
    X108      R703                          60
    X108      R704                          60
    X109      R0                            60
    X109      R705                          60
    X109      R706                          60
    X110      R0                            60
    X110      R707                          60
    X110      R708                          60
    X111      R0                            60
    X111      R709                          60
    X111      R710                          60
    X112      R227                          -1
    X112      R228                          -1
    X112      R229                          -1
    X112      R230                          -1
    X112      R231                          -1
    X112      R232                          -1
    X112      R711                          1
    X112      R712                          1
    X112      R713                          -1
    X112      R714                          -1
    X113      R0                            -1
    X113      R219                          -1
    X113      R220                          -1
    X113      R221                          -1
    X113      R222                          -1
    X113      R223                          -1
    X113      R224                          -1
    X113      R225                          -1
    X113      R226                          -1
    X113      R711                          -1
    X113      R712                          -1
    X113      R1007                         -1
    X113      R1008                         -1
    X114      R0                            60
    X114      R711                          60
    X114      R712                          60
    X115      R101                          -1
    X115      R102                          -1
    X115      R103                          -1
    X115      R104                          -1
    X115      R233                          -1
    X115      R234                          -1
    X115      R235                          -1
    X115      R236                          -1
    X115      R237                          -1
    X115      R238                          -1
    X115      R713                          1
    X115      R714                          1
    X115      R715                          -1
    X115      R716                          -1
    X116      R0                            60
    X116      R713                          60
    X116      R714                          60
    X117      R239                          -1
    X117      R240                          -1
    X117      R241                          -1
    X117      R242                          -1
    X117      R243                          -1
    X117      R244                          -1
    X117      R245                          -1
    X117      R246                          -1
    X117      R247                          -1
    X117      R248                          -1
    X117      R715                          1
    X117      R716                          1
    X117      R717                          -1
    X117      R718                          -1
    X118      R0                            60
    X118      R715                          60
    X118      R716                          60
    X119      R0                            60
    X119      R717                          60
    X119      R718                          60
    X120      R105                          -1
    X120      R106                          -1
    X120      R107                          -1
    X120      R108                          -1
    X120      R109                          -1
    X120      R110                          -1
    X120      R259                          -1
    X120      R260                          -1
    X120      R261                          -1
    X120      R262                          -1
    X120      R263                          -1
    X120      R264                          -1
    X120      R265                          -1
    X120      R266                          -1
    X120      R719                          1
    X120      R720                          1
    X120      R721                          -1
    X120      R722                          -1
    X121      R0                            60
    X121      R719                          60
    X121      R720                          60
    X122      R0                            1
    X122      R267                          -1
    X122      R268                          -1
    X122      R721                          1
    X122      R722                          1
    X123      R0                            60
    X123      R721                          60
    X123      R722                          60
    X124      R105                          1
    X124      R106                          1
    X124      R111                          -1
    X124      R112                          -1
    X124      R271                          -1
    X124      R272                          -1
    X124      R273                          -1
    X124      R274                          -1
    X124      R275                          -1
    X124      R276                          -1
    X124      R277                          -1
    X124      R278                          -1
    X124      R723                          1
    X124      R724                          1
    X124      R725                          -1
    X124      R726                          -1
    X125      R0                            -1
    X125      R269                          -1
    X125      R270                          -1
    X125      R723                          -1
    X125      R724                          -1
    X126      R0                            60
    X126      R723                          60
    X126      R724                          60
    X127      R0                            60
    X127      R725                          60
    X127      R726                          60
    X128      R289                          -1
    X128      R290                          -1
    X128      R291                          -1
    X128      R292                          -1
    X128      R293                          -1
    X128      R294                          -1
    X128      R295                          -1
    X128      R296                          -1
    X128      R297                          -1
    X128      R298                          -1
    X128      R727                          1
    X128      R728                          1
    X128      R729                          -1
    X128      R730                          -1
    X129      R0                            60
    X129      R727                          60
    X129      R728                          60
    X130      R299                          -1
    X130      R300                          -1
    X130      R301                          -1
    X130      R302                          -1
    X130      R303                          -1
    X130      R304                          -1
    X130      R729                          1
    X130      R730                          1
    X130      R731                          -1
    X130      R732                          -1
    X131      R0                            60
    X131      R729                          60
    X131      R730                          60
    X132      R305                          -1
    X132      R306                          -1
    X132      R307                          -1
    X132      R308                          -1
    X132      R309                          -1
    X132      R310                          -1
    X132      R731                          1
    X132      R732                          1
    X132      R733                          -1
    X132      R734                          -1
    X133      R0                            60
    X133      R731                          60
    X133      R732                          60
    X134      R0                            1
    X134      R311                          -1
    X134      R312                          -1
    X134      R313                          -1
    X134      R314                          -1
    X134      R315                          -1
    X134      R316                          -1
    X134      R317                          -1
    X134      R318                          -1
    X134      R319                          -1
    X134      R320                          -1
    X134      R733                          1
    X134      R734                          1
    X135      R0                            60
    X135      R733                          60
    X135      R734                          60
    X136      R0                            60
    X136      R735                          60
    X136      R736                          60
    X137      R193                          1
    X137      R194                          1
    X137      R329                          -1
    X137      R330                          -1
    X137      R331                          -1
    X137      R332                          -1
    X137      R737                          1
    X137      R738                          1
    X137      R739                          -1
    X137      R740                          -1
    X138      R0                            60
    X138      R737                          60
    X138      R738                          60
    X139      R0                            1
    X139      R199                          1
    X139      R200                          1
    X139      R739                          1
    X139      R740                          1
    X140      R0                            60
    X140      R739                          60
    X140      R740                          60
    X141      R115                          -1
    X141      R116                          -1
    X141      R117                          -1
    X141      R118                          -1
    X141      R203                          1
    X141      R204                          1
    X141      R333                          -1
    X141      R334                          -1
    X141      R335                          -1
    X141      R336                          -1
    X141      R741                          1
    X141      R742                          1
    X141      R743                          -1
    X141      R744                          -1
    X142      R0                            -1
    X142      R201                          1
    X142      R202                          1
    X142      R741                          -1
    X142      R742                          -1
    X143      R0                            60
    X143      R741                          60
    X143      R742                          60
    X144      R0                            60
    X144      R743                          60
    X144      R744                          60
    X145      R0                            60
    X145      R745                          60
    X145      R746                          60
    X146      R149                          1
    X146      R150                          1
    X146      R351                          -1
    X146      R352                          -1
    X146      R353                          -1
    X146      R354                          -1
    X146      R747                          1
    X146      R748                          1
    X146      R749                          -1
    X146      R750                          -1
    X146      R1021                         -1
    X146      R1022                         -1
    X147      R0                            -1
    X147      R349                          -1
    X147      R350                          -1
    X147      R747                          -1
    X147      R748                          -1
    X148      R0                            60
    X148      R747                          60
    X148      R748                          60
    X149      R157                          1
    X149      R158                          1
    X149      R355                          -1
    X149      R356                          -1
    X149      R357                          -1
    X149      R358                          -1
    X149      R359                          -1
    X149      R360                          -1
    X149      R749                          1
    X149      R750                          1
    X149      R751                          -1
    X149      R752                          -1
    X150      R0                            60
    X150      R749                          60
    X150      R750                          60
    X151      R161                          1
    X151      R162                          1
    X151      R361                          -1
    X151      R362                          -1
    X151      R363                          -1
    X151      R364                          -1
    X151      R365                          -1
    X151      R366                          -1
    X151      R751                          1
    X151      R752                          1
    X151      R753                          -1
    X151      R754                          -1
    X152      R0                            60
    X152      R751                          60
    X152      R752                          60
    X153      R0                            60
    X153      R753                          60
    X153      R754                          60
    X154      R0                            60
    X154      R755                          60
    X154      R756                          60
    X155      R373                          -1
    X155      R374                          -1
    X155      R757                          1
    X155      R758                          1
    X155      R759                          -1
    X155      R760                          -1
    X156      R0                            60
    X156      R757                          60
    X156      R758                          60
    X157      R0                            1
    X157      R375                          -1
    X157      R376                          -1
    X157      R759                          1
    X157      R760                          1
    X158      R0                            60
    X158      R759                          60
    X158      R760                          60
    X159      R377                          -1
    X159      R378                          -1
    X159      R761                          1
    X159      R762                          1
    X159      R763                          -1
    X159      R764                          -1
    X160      R0                            -1
    X160      R119                          -1
    X160      R120                          -1
    X160      R761                          -1
    X160      R762                          -1
    X161      R0                            60
    X161      R761                          60
    X161      R762                          60
    X162      R379                          -1
    X162      R380                          -1
    X162      R763                          1
    X162      R764                          1
    X162      R765                          -1
    X162      R766                          -1
    X163      R0                            60
    X163      R763                          60
    X163      R764                          60
    X164      R0                            60
    X164      R765                          60
    X164      R766                          60
    X165      R0                            60
    X165      R767                          60
    X165      R768                          60
    X166      R389                          -1
    X166      R390                          -1
    X166      R769                          1
    X166      R770                          1
    X166      R771                          -1
    X166      R772                          -1
    X167      R0                            60
    X167      R769                          60
    X167      R770                          60
    X168      R173                          1
    X168      R174                          1
    X168      R771                          1
    X168      R772                          1
    X168      R773                          -1
    X168      R774                          -1
    X168      R1011                         -1
    X168      R1012                         -1
    X168      R1015                         -1
    X168      R1016                         -1
    X168      R1019                         -1
    X168      R1020                         -1
    X169      R0                            60
    X169      R771                          60
    X169      R772                          60
    X170      R181                          1
    X170      R182                          1
    X170      R391                          -1
    X170      R392                          -1
    X170      R393                          -1
    X170      R394                          -1
    X170      R395                          -1
    X170      R396                          -1
    X170      R773                          1
    X170      R774                          1
    X170      R775                          -1
    X170      R776                          -1
    X171      R0                            60
    X171      R773                          60
    X171      R774                          60
    X172      R0                            1
    X172      R397                          -1
    X172      R398                          -1
    X172      R775                          1
    X172      R776                          1
    X173      R0                            60
    X173      R775                          60
    X173      R776                          60
    X174      R151                          1
    X174      R152                          1
    X174      R399                          -1
    X174      R400                          -1
    X174      R401                          -1
    X174      R402                          -1
    X174      R777                          1
    X174      R778                          1
    X174      R779                          -1
    X174      R780                          -1
    X174      R1021                         1
    X174      R1022                         1
    X175      R0                            -1
    X175      R349                          1
    X175      R350                          1
    X175      R777                          -1
    X175      R778                          -1
    X176      R0                            60
    X176      R777                          60
    X176      R778                          60
    X177      R159                          1
    X177      R160                          1
    X177      R355                          1
    X177      R356                          1
    X177      R403                          -1
    X177      R404                          -1
    X177      R405                          -1
    X177      R406                          -1
    X177      R779                          1
    X177      R780                          1
    X177      R781                          -1
    X177      R782                          -1
    X178      R0                            60
    X178      R779                          60
    X178      R780                          60
    X179      R163                          1
    X179      R164                          1
    X179      R361                          1
    X179      R362                          1
    X179      R407                          -1
    X179      R408                          -1
    X179      R409                          -1
    X179      R410                          -1
    X179      R781                          1
    X179      R782                          1
    X179      R783                          -1
    X179      R784                          -1
    X180      R0                            60
    X180      R781                          60
    X180      R782                          60
    X181      R0                            60
    X181      R783                          60
    X181      R784                          60
    X182      R389                          1
    X182      R390                          1
    X182      R785                          1
    X182      R786                          1
    X182      R787                          -1
    X182      R788                          -1
    X183      R0                            60
    X183      R785                          60
    X183      R786                          60
    X184      R175                          1
    X184      R176                          1
    X184      R787                          1
    X184      R788                          1
    X184      R789                          -1
    X184      R790                          -1
    X184      R1013                         -1
    X184      R1014                         -1
    X184      R1017                         -1
    X184      R1018                         -1
    X184      R1019                         1
    X184      R1020                         1
    X185      R0                            60
    X185      R787                          60
    X185      R788                          60
    X186      R183                          1
    X186      R184                          1
    X186      R391                          1
    X186      R392                          1
    X186      R419                          -1
    X186      R420                          -1
    X186      R421                          -1
    X186      R422                          -1
    X186      R789                          1
    X186      R790                          1
    X186      R791                          -1
    X186      R792                          -1
    X187      R0                            60
    X187      R789                          60
    X187      R790                          60
    X188      R0                            1
    X188      R397                          1
    X188      R398                          1
    X188      R791                          1
    X188      R792                          1
    X189      R0                            60
    X189      R791                          60
    X189      R792                          60
    X190      R239                          1
    X190      R240                          1
    X190      R423                          -1
    X190      R424                          -1
    X190      R793                          1
    X190      R794                          1
    X190      R795                          -1
    X190      R796                          -1
    X190      R1035                         -1
    X190      R1036                         -1
    X190      R1037                         -1
    X190      R1038                         -1
    X190      R1039                         -1
    X190      R1040                         -1
    X191      R0                            -1
    X191      R793                          -1
    X191      R794                          -1
    X191      R1027                         -1
    X191      R1028                         -1
    X192      R0                            60
    X192      R793                          60
    X192      R794                          60
    X193      R249                          1
    X193      R250                          1
    X193      R425                          -1
    X193      R426                          -1
    X193      R427                          -1
    X193      R428                          -1
    X193      R429                          -1
    X193      R430                          -1
    X193      R431                          -1
    X193      R432                          -1
    X193      R795                          1
    X193      R796                          1
    X193      R797                          -1
    X193      R798                          -1
    X194      R0                            60
    X194      R795                          60
    X194      R796                          60
    X195      R259                          1
    X195      R260                          1
    X195      R433                          -1
    X195      R434                          -1
    X195      R435                          -1
    X195      R436                          -1
    X195      R437                          -1
    X195      R438                          -1
    X195      R797                          1
    X195      R798                          1
    X195      R799                          -1
    X195      R800                          -1
    X196      R0                            60
    X196      R797                          60
    X196      R798                          60
    X197      R439                          -1
    X197      R440                          -1
    X197      R799                          1
    X197      R800                          1
    X197      R801                          -1
    X197      R802                          -1
    X198      R0                            60
    X198      R799                          60
    X198      R800                          60
    X199      R369                          1
    X199      R370                          1
    X199      R411                          1
    X199      R412                          1
    X199      R441                          -1
    X199      R442                          -1
    X199      R801                          1
    X199      R802                          1
    X199      R803                          -1
    X199      R804                          -1
    X200      R0                            60
    X200      R801                          60
    X200      R802                          60
    X201      R0                            60
    X201      R803                          60
    X201      R804                          60
    X202      R373                          1
    X202      R374                          1
    X202      R805                          1
    X202      R806                          1
    X202      R807                          -1
    X202      R808                          -1
    X203      R0                            60
    X203      R805                          60
    X203      R806                          60
    X204      R375                          1
    X204      R376                          1
    X204      R807                          1
    X204      R808                          1
    X204      R809                          -1
    X204      R810                          -1
    X205      R0                            60
    X205      R807                          60
    X205      R808                          60
    X206      R0                            1
    X206      R119                          1
    X206      R120                          1
    X206      R809                          1
    X206      R810                          1
    X207      R0                            60
    X207      R809                          60
    X207      R810                          60
    X208      R379                          1
    X208      R380                          1
    X208      R811                          1
    X208      R812                          1
    X208      R813                          -1
    X208      R814                          -1
    X209      R0                            -1
    X209      R377                          1
    X209      R378                          1
    X209      R811                          -1
    X209      R812                          -1
    X210      R0                            60
    X210      R811                          60
    X210      R812                          60
    X211      R0                            60
    X211      R813                          60
    X211      R814                          60
    X212      R385                          1
    X212      R386                          1
    X212      R415                          1
    X212      R416                          1
    X212      R443                          -1
    X212      R444                          -1
    X212      R815                          1
    X212      R816                          1
    X212      R817                          -1
    X212      R818                          -1
    X213      R0                            60
    X213      R815                          60
    X213      R816                          60
    X214      R445                          -1
    X214      R446                          -1
    X214      R817                          1
    X214      R818                          1
    X214      R819                          -1
    X214      R820                          -1
    X215      R0                            60
    X215      R817                          60
    X215      R818                          60
    X216      R275                          1
    X216      R276                          1
    X216      R447                          -1
    X216      R448                          -1
    X216      R449                          -1
    X216      R450                          -1
    X216      R451                          -1
    X216      R452                          -1
    X216      R819                          1
    X216      R820                          1
    X216      R821                          -1
    X216      R822                          -1
    X217      R0                            60
    X217      R819                          60
    X217      R820                          60
    X218      R279                          1
    X218      R280                          1
    X218      R453                          -1
    X218      R454                          -1
    X218      R455                          -1
    X218      R456                          -1
    X218      R457                          -1
    X218      R458                          -1
    X218      R459                          -1
    X218      R460                          -1
    X218      R821                          1
    X218      R822                          1
    X218      R823                          -1
    X218      R824                          -1
    X219      R0                            60
    X219      R821                          60
    X219      R822                          60
    X220      R289                          1
    X220      R290                          1
    X220      R461                          -1
    X220      R462                          -1
    X220      R463                          -1
    X220      R464                          -1
    X220      R465                          -1
    X220      R466                          -1
    X220      R467                          -1
    X220      R468                          -1
    X220      R823                          1
    X220      R824                          1
    X220      R825                          -1
    X220      R826                          -1
    X221      R0                            60
    X221      R823                          60
    X221      R824                          60
    X222      R0                            1
    X222      R101                          1
    X222      R102                          1
    X222      R125                          -1
    X222      R126                          -1
    X222      R127                          -1
    X222      R128                          -1
    X222      R129                          -1
    X222      R130                          -1
    X222      R825                          1
    X222      R826                          1
    X222      R1029                         -1
    X222      R1030                         -1
    X223      R0                            60
    X223      R825                          60
    X223      R826                          60
    X224      R0                            60
    X224      R827                          60
    X224      R828                          60
    X225      R477                          -1
    X225      R478                          -1
    X225      R479                          -1
    X225      R480                          -1
    X225      R829                          1
    X225      R830                          1
    X225      R831                          -1
    X225      R832                          -1
    X226      R0                            60
    X226      R829                          60
    X226      R830                          60
    X227      R481                          -1
    X227      R482                          -1
    X227      R483                          -1
    X227      R484                          -1
    X227      R831                          1
    X227      R832                          1
    X227      R833                          -1
    X227      R834                          -1
    X228      R0                            60
    X228      R831                          60
    X228      R832                          60
    X229      R485                          -1
    X229      R486                          -1
    X229      R487                          -1
    X229      R488                          -1
    X229      R833                          1
    X229      R834                          1
    X229      R835                          -1
    X229      R836                          -1
    X230      R0                            60
    X230      R833                          60
    X230      R834                          60
    X231      R0                            1
    X231      R489                          -1
    X231      R490                          -1
    X231      R835                          1
    X231      R836                          1
    X232      R0                            60
    X232      R835                          60
    X232      R836                          60
    X233      R493                          -1
    X233      R494                          -1
    X233      R495                          -1
    X233      R496                          -1
    X233      R837                          1
    X233      R838                          1
    X233      R839                          -1
    X233      R840                          -1
    X234      R0                            -1
    X234      R133                          -1
    X234      R134                          -1
    X234      R491                          -1
    X234      R492                          -1
    X234      R837                          -1
    X234      R838                          -1
    X235      R0                            60
    X235      R837                          60
    X235      R838                          60
    X236      R497                          -1
    X236      R498                          -1
    X236      R499                          -1
    X236      R500                          -1
    X236      R839                          1
    X236      R840                          1
    X236      R841                          -1
    X236      R842                          -1
    X237      R0                            60
    X237      R839                          60
    X237      R840                          60
    X238      R501                          -1
    X238      R502                          -1
    X238      R503                          -1
    X238      R504                          -1
    X238      R841                          1
    X238      R842                          1
    X238      R843                          -1
    X238      R844                          -1
    X239      R0                            60
    X239      R841                          60
    X239      R842                          60
    X240      R0                            60
    X240      R843                          60
    X240      R844                          60
    X241      R0                            60
    X241      R845                          60
    X241      R846                          60
    X242      R0                            60
    X242      R847                          60
    X242      R848                          60
    X243      R0                            60
    X243      R849                          60
    X243      R850                          60
    X244      R477                          1
    X244      R478                          1
    X244      R521                          -1
    X244      R522                          -1
    X244      R851                          1
    X244      R852                          1
    X244      R853                          -1
    X244      R854                          -1
    X245      R0                            60
    X245      R851                          60
    X245      R852                          60
    X246      R481                          1
    X246      R482                          1
    X246      R523                          -1
    X246      R524                          -1
    X246      R853                          1
    X246      R854                          1
    X246      R855                          -1
    X246      R856                          -1
    X247      R0                            60
    X247      R853                          60
    X247      R854                          60
    X248      R485                          1
    X248      R486                          1
    X248      R525                          -1
    X248      R526                          -1
    X248      R855                          1
    X248      R856                          1
    X248      R857                          -1
    X248      R858                          -1
    X249      R0                            60
    X249      R855                          60
    X249      R856                          60
    X250      R0                            1
    X250      R489                          1
    X250      R490                          1
    X250      R857                          1
    X250      R858                          1
    X251      R0                            60
    X251      R857                          60
    X251      R858                          60
    X252      R493                          1
    X252      R494                          1
    X252      R527                          -1
    X252      R528                          -1
    X252      R859                          1
    X252      R860                          1
    X252      R861                          -1
    X252      R862                          -1
    X253      R0                            -1
    X253      R135                          -1
    X253      R136                          -1
    X253      R491                          1
    X253      R492                          1
    X253      R859                          -1
    X253      R860                          -1
    X254      R0                            60
    X254      R859                          60
    X254      R860                          60
    X255      R497                          1
    X255      R498                          1
    X255      R529                          -1
    X255      R530                          -1
    X255      R861                          1
    X255      R862                          1
    X255      R863                          -1
    X255      R864                          -1
    X256      R0                            60
    X256      R861                          60
    X256      R862                          60
    X257      R501                          1
    X257      R502                          1
    X257      R531                          -1
    X257      R532                          -1
    X257      R863                          1
    X257      R864                          1
    X257      R865                          -1
    X257      R866                          -1
    X258      R0                            60
    X258      R863                          60
    X258      R864                          60
    X259      R0                            60
    X259      R865                          60
    X259      R866                          60
    X260      R0                            60
    X260      R867                          60
    X260      R868                          60
    X261      R0                            60
    X261      R869                          60
    X261      R870                          60
    X262      R241                          1
    X262      R242                          1
    X262      R539                          -1
    X262      R540                          -1
    X262      R871                          1
    X262      R872                          1
    X262      R873                          -1
    X262      R874                          -1
    X262      R1035                         1
    X262      R1036                         1
    X262      R1041                         -1
    X262      R1042                         -1
    X262      R1043                         -1
    X262      R1044                         -1
    X263      R0                            -1
    X263      R871                          -1
    X263      R872                          -1
    X263      R1027                         1
    X263      R1028                         1
    X264      R0                            60
    X264      R871                          60
    X264      R872                          60
    X265      R251                          1
    X265      R252                          1
    X265      R425                          1
    X265      R426                          1
    X265      R541                          -1
    X265      R542                          -1
    X265      R543                          -1
    X265      R544                          -1
    X265      R545                          -1
    X265      R546                          -1
    X265      R873                          1
    X265      R874                          1
    X265      R875                          -1
    X265      R876                          -1
    X266      R0                            60
    X266      R873                          60
    X266      R874                          60
    X267      R261                          1
    X267      R262                          1
    X267      R433                          1
    X267      R434                          1
    X267      R547                          -1
    X267      R548                          -1
    X267      R549                          -1
    X267      R550                          -1
    X267      R875                          1
    X267      R876                          1
    X267      R877                          -1
    X267      R878                          -1
    X268      R0                            60
    X268      R875                          60
    X268      R876                          60
    X269      R439                          1
    X269      R440                          1
    X269      R877                          1
    X269      R878                          1
    X269      R879                          -1
    X269      R880                          -1
    X270      R0                            60
    X270      R877                          60
    X270      R878                          60
    X271      R0                            60
    X271      R879                          60
    X271      R880                          60
    X272      R0                            60
    X272      R881                          60
    X272      R882                          60
    X273      R0                            60
    X273      R883                          60
    X273      R884                          60
    X274      R445                          1
    X274      R446                          1
    X274      R885                          1
    X274      R886                          1
    X274      R887                          -1
    X274      R888                          -1
    X275      R0                            60
    X275      R885                          60
    X275      R886                          60
    X276      R277                          1
    X276      R278                          1
    X276      R447                          1
    X276      R448                          1
    X276      R551                          -1
    X276      R552                          -1
    X276      R553                          -1
    X276      R554                          -1
    X276      R887                          1
    X276      R888                          1
    X276      R889                          -1
    X276      R890                          -1
    X277      R0                            60
    X277      R887                          60
    X277      R888                          60
    X278      R281                          1
    X278      R282                          1
    X278      R453                          1
    X278      R454                          1
    X278      R555                          -1
    X278      R556                          -1
    X278      R557                          -1
    X278      R558                          -1
    X278      R559                          -1
    X278      R560                          -1
    X278      R889                          1
    X278      R890                          1
    X278      R891                          -1
    X278      R892                          -1
    X279      R0                            60
    X279      R889                          60
    X279      R890                          60
    X280      R291                          1
    X280      R292                          1
    X280      R461                          1
    X280      R462                          1
    X280      R561                          -1
    X280      R562                          -1
    X280      R563                          -1
    X280      R564                          -1
    X280      R565                          -1
    X280      R566                          -1
    X280      R891                          1
    X280      R892                          1
    X280      R893                          -1
    X280      R894                          -1
    X281      R0                            60
    X281      R891                          60
    X281      R892                          60
    X282      R0                            1
    X282      R103                          1
    X282      R104                          1
    X282      R139                          -1
    X282      R140                          -1
    X282      R141                          -1
    X282      R142                          -1
    X282      R143                          -1
    X282      R144                          -1
    X282      R893                          1
    X282      R894                          1
    X282      R1029                         1
    X282      R1030                         1
    X283      R0                            60
    X283      R893                          60
    X283      R894                          60
    X284      R227                          1
    X284      R228                          1
    X284      R575                          -1
    X284      R576                          -1
    X284      R577                          -1
    X284      R578                          -1
    X284      R895                          1
    X284      R896                          1
    X284      R897                          -1
    X284      R898                          -1
    X285      R0                            -1
    X285      R219                          1
    X285      R220                          1
    X285      R567                          -1
    X285      R568                          -1
    X285      R569                          -1
    X285      R570                          -1
    X285      R571                          -1
    X285      R572                          -1
    X285      R573                          -1
    X285      R574                          -1
    X285      R895                          -1
    X285      R896                          -1
    X286      R0                            60
    X286      R895                          60
    X286      R896                          60
    X287      R125                          1
    X287      R126                          1
    X287      R139                          1
    X287      R140                          1
    X287      R233                          1
    X287      R234                          1
    X287      R579                          -1
    X287      R580                          -1
    X287      R581                          -1
    X287      R582                          -1
    X287      R897                          1
    X287      R898                          1
    X287      R899                          -1
    X287      R900                          -1
    X288      R0                            60
    X288      R897                          60
    X288      R898                          60
    X289      R243                          1
    X289      R244                          1
    X289      R583                          -1
    X289      R584                          -1
    X289      R899                          1
    X289      R900                          1
    X289      R901                          -1
    X289      R902                          -1
    X289      R1037                         1
    X289      R1038                         1
    X289      R1041                         1
    X289      R1042                         1
    X289      R1045                         -1
    X289      R1046                         -1
    X290      R0                            60
    X290      R899                          60
    X290      R900                          60
    X291      R253                          1
    X291      R254                          1
    X291      R427                          1
    X291      R428                          1
    X291      R541                          1
    X291      R542                          1
    X291      R585                          -1
    X291      R586                          -1
    X291      R587                          -1
    X291      R588                          -1
    X291      R901                          1
    X291      R902                          1
    X291      R903                          -1
    X291      R904                          -1
    X292      R0                            60
    X292      R901                          60
    X292      R902                          60
    X293      R0                            1
    X293      R263                          1
    X293      R264                          1
    X293      R435                          1
    X293      R436                          1
    X293      R547                          1
    X293      R548                          1
    X293      R589                          -1
    X293      R590                          -1
    X293      R903                          1
    X293      R904                          1
    X294      R0                            60
    X294      R903                          60
    X294      R904                          60
    X295      R283                          1
    X295      R284                          1
    X295      R455                          1
    X295      R456                          1
    X295      R555                          1
    X295      R556                          1
    X295      R593                          -1
    X295      R594                          -1
    X295      R595                          -1
    X295      R596                          -1
    X295      R905                          1
    X295      R906                          1
    X295      R907                          -1
    X295      R908                          -1
    X296      R0                            -1
    X296      R107                          1
    X296      R108                          1
    X296      R145                          -1
    X296      R146                          -1
    X296      R271                          1
    X296      R272                          1
    X296      R449                          1
    X296      R450                          1
    X296      R551                          1
    X296      R552                          1
    X296      R591                          -1
    X296      R592                          -1
    X296      R905                          -1
    X296      R906                          -1
    X297      R0                            60
    X297      R905                          60
    X297      R906                          60
    X298      R293                          1
    X298      R294                          1
    X298      R463                          1
    X298      R464                          1
    X298      R561                          1
    X298      R562                          1
    X298      R597                          -1
    X298      R598                          -1
    X298      R599                          -1
    X298      R600                          -1
    X298      R907                          1
    X298      R908                          1
    X298      R909                          -1
    X298      R910                          -1
    X299      R0                            60
    X299      R907                          60
    X299      R908                          60
    X300      R299                          1
    X300      R300                          1
    X300      R601                          -1
    X300      R602                          -1
    X300      R603                          -1
    X300      R604                          -1
    X300      R909                          1
    X300      R910                          1
    X300      R911                          -1
    X300      R912                          -1
    X301      R0                            60
    X301      R909                          60
    X301      R910                          60
    X302      R305                          1
    X302      R306                          1
    X302      R605                          -1
    X302      R606                          -1
    X302      R607                          -1
    X302      R608                          -1
    X302      R911                          1
    X302      R912                          1
    X302      R913                          -1
    X302      R914                          -1
    X303      R0                            60
    X303      R911                          60
    X303      R912                          60
    X304      R0                            1
    X304      R311                          1
    X304      R312                          1
    X304      R609                          -1
    X304      R610                          -1
    X304      R611                          -1
    X304      R612                          -1
    X304      R613                          -1
    X304      R614                          -1
    X304      R615                          -1
    X304      R616                          -1
    X304      R913                          1
    X304      R914                          1
    X305      R0                            60
    X305      R913                          60
    X305      R914                          60
    X306      R89                           1
    X306      R90                           1
    X306      R475                          1
    X306      R476                          1
    X306      R519                          1
    X306      R520                          1
    X306      R915                          1
    X306      R916                          1
    X306      R917                          -1
    X306      R918                          -1
    X307      R0                            -1
    X307      R99                           1
    X307      R100                          1
    X307      R137                          1
    X307      R138                          1
    X307      R323                          1
    X307      R324                          1
    X307      R469                          1
    X307      R470                          1
    X307      R617                          -1
    X307      R618                          -1
    X307      R619                          -1
    X307      R620                          -1
    X307      R915                          -1
    X307      R916                          -1
    X308      R0                            60
    X308      R915                          60
    X308      R916                          60
    X309      R479                          1
    X309      R480                          1
    X309      R521                          1
    X309      R522                          1
    X309      R917                          1
    X309      R918                          1
    X309      R919                          -1
    X309      R920                          -1
    X310      R0                            60
    X310      R917                          60
    X310      R918                          60
    X311      R483                          1
    X311      R484                          1
    X311      R523                          1
    X311      R524                          1
    X311      R919                          1
    X311      R920                          1
    X311      R921                          -1
    X311      R922                          -1
    X312      R0                            60
    X312      R919                          60
    X312      R920                          60
    X313      R487                          1
    X313      R488                          1
    X313      R525                          1
    X313      R526                          1
    X313      R921                          1
    X313      R922                          1
    X313      R923                          -1
    X313      R924                          -1
    X314      R0                            60
    X314      R921                          60
    X314      R922                          60
    X315      R0                            1
    X315      R73                           1
    X315      R74                           1
    X315      R133                          1
    X315      R134                          1
    X315      R135                          1
    X315      R136                          1
    X315      R923                          1
    X315      R924                          1
    X316      R0                            60
    X316      R923                          60
    X316      R924                          60
    X317      R495                          1
    X317      R496                          1
    X317      R527                          1
    X317      R528                          1
    X317      R925                          1
    X317      R926                          1
    X317      R927                          -1
    X317      R928                          -1
    X318      R0                            -1
    X318      R75                           1
    X318      R76                           1
    X318      R925                          -1
    X318      R926                          -1
    X319      R0                            60
    X319      R925                          60
    X319      R926                          60
    X320      R499                          1
    X320      R500                          1
    X320      R529                          1
    X320      R530                          1
    X320      R927                          1
    X320      R928                          1
    X320      R929                          -1
    X320      R930                          -1
    X321      R0                            60
    X321      R927                          60
    X321      R928                          60
    X322      R503                          1
    X322      R504                          1
    X322      R531                          1
    X322      R532                          1
    X322      R929                          1
    X322      R930                          1
    X322      R931                          -1
    X322      R932                          -1
    X323      R0                            60
    X323      R929                          60
    X323      R930                          60
    X324      R339                          1
    X324      R340                          1
    X324      R507                          1
    X324      R508                          1
    X324      R533                          1
    X324      R534                          1
    X324      R931                          1
    X324      R932                          1
    X324      R933                          -1
    X324      R934                          -1
    X325      R0                            60
    X325      R931                          60
    X325      R932                          60
    X326      R0                            1
    X326      R343                          1
    X326      R344                          1
    X326      R509                          1
    X326      R510                          1
    X326      R621                          -1
    X326      R622                          -1
    X326      R623                          -1
    X326      R624                          -1
    X326      R933                          1
    X326      R934                          1
    X327      R0                            60
    X327      R933                          60
    X327      R934                          60
    X328      R229                          1
    X328      R230                          1
    X328      R575                          1
    X328      R576                          1
    X328      R631                          -1
    X328      R632                          -1
    X328      R935                          1
    X328      R936                          1
    X328      R937                          -1
    X328      R938                          -1
    X329      R0                            -1
    X329      R221                          1
    X329      R222                          1
    X329      R567                          1
    X329      R568                          1
    X329      R625                          -1
    X329      R626                          -1
    X329      R627                          -1
    X329      R628                          -1
    X329      R629                          -1
    X329      R630                          -1
    X329      R935                          -1
    X329      R936                          -1
    X330      R0                            60
    X330      R935                          60
    X330      R936                          60
    X331      R127                          1
    X331      R128                          1
    X331      R141                          1
    X331      R142                          1
    X331      R235                          1
    X331      R236                          1
    X331      R579                          1
    X331      R580                          1
    X331      R633                          -1
    X331      R634                          -1
    X331      R937                          1
    X331      R938                          1
    X331      R939                          -1
    X331      R940                          -1
    X332      R0                            60
    X332      R937                          60
    X332      R938                          60
    X333      R245                          1
    X333      R246                          1
    X333      R635                          -1
    X333      R636                          -1
    X333      R939                          1
    X333      R940                          1
    X333      R941                          -1
    X333      R942                          -1
    X333      R1039                         1
    X333      R1040                         1
    X333      R1043                         1
    X333      R1044                         1
    X333      R1045                         1
    X333      R1046                         1
    X334      R0                            60
    X334      R939                          60
    X334      R940                          60
    X335      R0                            1
    X335      R255                          1
    X335      R256                          1
    X335      R429                          1
    X335      R430                          1
    X335      R543                          1
    X335      R544                          1
    X335      R585                          1
    X335      R586                          1
    X335      R637                          -1
    X335      R638                          -1
    X335      R941                          1
    X335      R942                          1
    X336      R0                            60
    X336      R941                          60
    X336      R942                          60
    X337      R295                          1
    X337      R296                          1
    X337      R465                          1
    X337      R466                          1
    X337      R563                          1
    X337      R564                          1
    X337      R597                          1
    X337      R598                          1
    X337      R641                          -1
    X337      R642                          -1
    X337      R943                          1
    X337      R944                          1
    X337      R945                          -1
    X337      R946                          -1
    X338      R0                            -1
    X338      R285                          1
    X338      R286                          1
    X338      R457                          1
    X338      R458                          1
    X338      R557                          1
    X338      R558                          1
    X338      R593                          1
    X338      R594                          1
    X338      R639                          -1
    X338      R640                          -1
    X338      R943                          -1
    X338      R944                          -1
    X339      R0                            60
    X339      R943                          60
    X339      R944                          60
    X340      R301                          1
    X340      R302                          1
    X340      R601                          1
    X340      R602                          1
    X340      R643                          -1
    X340      R644                          -1
    X340      R945                          1
    X340      R946                          1
    X340      R947                          -1
    X340      R948                          -1
    X341      R0                            60
    X341      R945                          60
    X341      R946                          60
    X342      R307                          1
    X342      R308                          1
    X342      R605                          1
    X342      R606                          1
    X342      R645                          -1
    X342      R646                          -1
    X342      R947                          1
    X342      R948                          1
    X342      R949                          -1
    X342      R950                          -1
    X343      R0                            60
    X343      R947                          60
    X343      R948                          60
    X344      R0                            1
    X344      R313                          1
    X344      R314                          1
    X344      R609                          1
    X344      R610                          1
    X344      R647                          -1
    X344      R648                          -1
    X344      R649                          -1
    X344      R650                          -1
    X344      R651                          -1
    X344      R652                          -1
    X344      R949                          1
    X344      R950                          1
    X345      R0                            60
    X345      R949                          60
    X345      R950                          60
    X346      R0                            -1
    X346      R79                           -1
    X346      R80                           -1
    X346      R153                          1
    X346      R154                          1
    X346      R351                          1
    X346      R352                          1
    X346      R357                          1
    X346      R358                          1
    X346      R399                          1
    X346      R400                          1
    X346      R403                          1
    X346      R404                          1
    X346      R951                          -1
    X346      R952                          -1
    X347      R0                            60
    X347      R951                          60
    X347      R952                          60
    X348      R0                            -1
    X348      R79                           1
    X348      R80                           1
    X348      R155                          1
    X348      R156                          1
    X348      R353                          1
    X348      R354                          1
    X348      R359                          1
    X348      R360                          1
    X348      R401                          1
    X348      R402                          1
    X348      R405                          1
    X348      R406                          1
    X348      R953                          -1
    X348      R954                          -1
    X349      R0                            60
    X349      R953                          60
    X349      R954                          60
    X350      R0                            1
    X350      R85                           -1
    X350      R86                           -1
    X350      R177                          1
    X350      R178                          1
    X350      R393                          1
    X350      R394                          1
    X350      R419                          1
    X350      R420                          1
    X350      R955                          1
    X350      R956                          1
    X350      R1011                         1
    X350      R1012                         1
    X350      R1013                         1
    X350      R1014                         1
    X351      R0                            60
    X351      R955                          60
    X351      R956                          60
    X352      R0                            1
    X352      R85                           1
    X352      R86                           1
    X352      R179                          1
    X352      R180                          1
    X352      R395                          1
    X352      R396                          1
    X352      R421                          1
    X352      R422                          1
    X352      R957                          1
    X352      R958                          1
    X352      R1015                         1
    X352      R1016                         1
    X352      R1017                         1
    X352      R1018                         1
    X353      R0                            60
    X353      R957                          60
    X353      R958                          60
    X354      R0                            60
    X354      R959                          60
    X354      R960                          60
    X355      R0                            60
    X355      R961                          60
    X355      R962                          60
    X356      R0                            60
    X356      R963                          60
    X356      R964                          60
    X357      R0                            60
    X357      R965                          60
    X357      R966                          60
    X358      R0                            -1
    X358      R315                          1
    X358      R316                          1
    X358      R611                          1
    X358      R612                          1
    X358      R647                          1
    X358      R648                          1
    X358      R659                          -1
    X358      R660                          -1
    X358      R661                          -1
    X358      R662                          -1
    X358      R967                          -1
    X358      R968                          -1
    X359      R0                            60
    X359      R967                          60
    X359      R968                          60
    X360      R0                            1
    X360      R223                          1
    X360      R224                          1
    X360      R571                          1
    X360      R572                          1
    X360      R627                          1
    X360      R628                          1
    X360      R667                          -1
    X360      R668                          -1
    X360      R669                          -1
    X360      R670                          -1
    X360      R969                          1
    X360      R970                          1
    X361      R0                            60
    X361      R969                          60
    X361      R970                          60
    X362      R0                            -1
    X362      R317                          1
    X362      R318                          1
    X362      R613                          1
    X362      R614                          1
    X362      R649                          1
    X362      R650                          1
    X362      R659                          1
    X362      R660                          1
    X362      R671                          -1
    X362      R672                          -1
    X362      R971                          -1
    X362      R972                          -1
    X363      R0                            60
    X363      R971                          60
    X363      R972                          60
    X364      R0                            1
    X364      R225                          1
    X364      R226                          1
    X364      R573                          1
    X364      R574                          1
    X364      R629                          1
    X364      R630                          1
    X364      R667                          1
    X364      R668                          1
    X364      R673                          -1
    X364      R674                          -1
    X364      R973                          1
    X364      R974                          1
    X365      R0                            60
    X365      R973                          60
    X365      R974                          60
    X366      R677                          -1
    X366      R678                          -1
    X366      R975                          1
    X366      R976                          1
    X366      R977                          -1
    X366      R978                          -1
    X367      R0                            60
    X367      R975                          60
    X367      R976                          60
    X368      R0                            1
    X368      R679                          -1
    X368      R680                          -1
    X368      R977                          1
    X368      R978                          1
    X369      R0                            60
    X369      R977                          60
    X369      R978                          60
    X370      R683                          -1
    X370      R684                          -1
    X370      R979                          1
    X370      R980                          1
    X370      R981                          -1
    X370      R982                          -1
    X371      R0                            -1
    X371      R681                          -1
    X371      R682                          -1
    X371      R979                          -1
    X371      R980                          -1
    X372      R0                            60
    X372      R979                          60
    X372      R980                          60
    X373      R0                            60
    X373      R981                          60
    X373      R982                          60
    X374      R677                          1
    X374      R678                          1
    X374      R983                          1
    X374      R984                          1
    X374      R985                          -1
    X374      R986                          -1
    X375      R0                            60
    X375      R983                          60
    X375      R984                          60
    X376      R0                            1
    X376      R679                          1
    X376      R680                          1
    X376      R985                          1
    X376      R986                          1
    X377      R0                            60
    X377      R985                          60
    X377      R986                          60
    X378      R683                          1
    X378      R684                          1
    X378      R987                          1
    X378      R988                          1
    X378      R989                          -1
    X378      R990                          -1
    X379      R0                            -1
    X379      R681                          1
    X379      R682                          1
    X379      R987                          -1
    X379      R988                          -1
    X380      R0                            60
    X380      R987                          60
    X380      R988                          60
    X381      R0                            60
    X381      R989                          60
    X381      R990                          60
    X382      R231                          1
    X382      R232                          1
    X382      R577                          1
    X382      R578                          1
    X382      R631                          1
    X382      R632                          1
    X382      R991                          1
    X382      R992                          1
    X382      R993                          -1
    X382      R994                          -1
    X383      R0                            -1
    X383      R569                          1
    X383      R570                          1
    X383      R625                          1
    X383      R626                          1
    X383      R669                          1
    X383      R670                          1
    X383      R673                          1
    X383      R674                          1
    X383      R991                          -1
    X383      R992                          -1
    X383      R1007                         1
    X383      R1008                         1
    X384      R0                            60
    X384      R991                          60
    X384      R992                          60
    X385      R129                          1
    X385      R130                          1
    X385      R143                          1
    X385      R144                          1
    X385      R237                          1
    X385      R238                          1
    X385      R581                          1
    X385      R582                          1
    X385      R633                          1
    X385      R634                          1
    X385      R993                          1
    X385      R994                          1
    X385      R995                          -1
    X385      R996                          -1
    X386      R0                            60
    X386      R993                          60
    X386      R994                          60
    X387      R247                          1
    X387      R248                          1
    X387      R423                          1
    X387      R424                          1
    X387      R539                          1
    X387      R540                          1
    X387      R583                          1
    X387      R584                          1
    X387      R635                          1
    X387      R636                          1
    X387      R995                          1
    X387      R996                          1
    X387      R997                          -1
    X387      R998                          -1
    X388      R0                            60
    X388      R995                          60
    X388      R996                          60
    X389      R0                            60
    X389      R997                          60
    X389      R998                          60
    X390      R297                          1
    X390      R298                          1
    X390      R467                          1
    X390      R468                          1
    X390      R565                          1
    X390      R566                          1
    X390      R599                          1
    X390      R600                          1
    X390      R641                          1
    X390      R642                          1
    X390      R999                          1
    X390      R1000                         1
    X390      R1001                         -1
    X390      R1002                         -1
    X391      R0                            60
    X391      R999                          60
    X391      R1000                         60
    X392      R303                          1
    X392      R304                          1
    X392      R603                          1
    X392      R604                          1
    X392      R643                          1
    X392      R644                          1
    X392      R1001                         1
    X392      R1002                         1
    X392      R1003                         -1
    X392      R1004                         -1
    X393      R0                            60
    X393      R1001                         60
    X393      R1002                         60
    X394      R309                          1
    X394      R310                          1
    X394      R607                          1
    X394      R608                          1
    X394      R645                          1
    X394      R646                          1
    X394      R1003                         1
    X394      R1004                         1
    X394      R1005                         -1
    X394      R1006                         -1
    X395      R0                            60
    X395      R1003                         60
    X395      R1004                         60
    X396      R0                            1
    X396      R319                          1
    X396      R320                          1
    X396      R615                          1
    X396      R616                          1
    X396      R651                          1
    X396      R652                          1
    X396      R661                          1
    X396      R662                          1
    X396      R671                          1
    X396      R672                          1
    X396      R1005                         1
    X396      R1006                         1
    X397      R0                            60
    X397      R1005                         60
    X397      R1006                         60
    X398      R69                           -1
    X398      R70                           -1
    X398      R71                           -1
    X398      R72                           -1
    X398      R73                           -1
    X398      R74                           -1
    X398      R75                           -1
    X398      R76                           -1
    X398      R77                           -1
    X398      R78                           -1
    X399      R69                           60
    X399      R70                           60
    X400      R71                           60
    X400      R72                           60
    X401      R73                           60
    X401      R74                           60
    X402      R75                           60
    X402      R76                           60
    X403      R77                           60
    X403      R78                           60
    X404      R79                           60
    X404      R80                           60
    X405      R81                           60
    X405      R82                           60
    X406      R83                           60
    X406      R84                           60
    X407      R85                           60
    X407      R86                           60
    X408      R87                           60
    X408      R88                           60
    X409      R89                           60
    X409      R90                           60
    X410      R91                           60
    X410      R92                           60
    X411      R93                           60
    X411      R94                           60
    X412      R95                           60
    X412      R96                           60
    X413      R97                           60
    X413      R98                           60
    X414      R99                           60
    X414      R100                          60
    X415      R101                          60
    X415      R102                          60
    X416      R103                          60
    X416      R104                          60
    X417      R105                          60
    X417      R106                          60
    X418      R107                          60
    X418      R108                          60
    X419      R109                          60
    X419      R110                          60
    X420      R111                          60
    X420      R112                          60
    X421      R113                          60
    X421      R114                          60
    X422      R115                          60
    X422      R116                          60
    X423      R117                          60
    X423      R118                          60
    X424      R119                          60
    X424      R120                          60
    X425      R121                          60
    X425      R122                          60
    X426      R123                          60
    X426      R124                          60
    X427      R125                          60
    X427      R126                          60
    X428      R127                          60
    X428      R128                          60
    X429      R129                          60
    X429      R130                          60
    X430      R131                          60
    X430      R132                          60
    X431      R133                          60
    X431      R134                          60
    X432      R135                          60
    X432      R136                          60
    X433      R137                          60
    X433      R138                          60
    X434      R139                          60
    X434      R140                          60
    X435      R141                          60
    X435      R142                          60
    X436      R143                          60
    X436      R144                          60
    X437      R145                          60
    X437      R146                          60
    X438      R147                          60
    X438      R148                          60
    X439      R149                          60
    X439      R150                          60
    X440      R151                          60
    X440      R152                          60
    X441      R153                          60
    X441      R154                          60
    X442      R155                          60
    X442      R156                          60
    X443      R157                          60
    X443      R158                          60
    X444      R159                          60
    X444      R160                          60
    X445      R161                          60
    X445      R162                          60
    X446      R163                          60
    X446      R164                          60
    X447      R165                          60
    X447      R166                          60
    X448      R167                          60
    X448      R168                          60
    X449      R169                          60
    X449      R170                          60
    X450      R171                          60
    X450      R172                          60
    X451      R173                          60
    X451      R174                          60
    X452      R175                          60
    X452      R176                          60
    X453      R177                          60
    X453      R178                          60
    X454      R179                          60
    X454      R180                          60
    X455      R181                          60
    X455      R182                          60
    X456      R183                          60
    X456      R184                          60
    X457      R185                          60
    X457      R186                          60
    X458      R187                          60
    X458      R188                          60
    X459      R189                          60
    X459      R190                          60
    X460      R191                          60
    X460      R192                          60
    X461      R193                          60
    X461      R194                          60
    X462      R195                          60
    X462      R196                          60
    X463      R197                          60
    X463      R198                          60
    X464      R199                          60
    X464      R200                          60
    X465      R201                          60
    X465      R202                          60
    X466      R203                          60
    X466      R204                          60
    X467      R205                          60
    X467      R206                          60
    X468      R207                          60
    X468      R208                          60
    X469      R209                          60
    X469      R210                          60
    X470      R211                          60
    X470      R212                          60
    X471      R213                          60
    X471      R214                          60
    X472      R215                          60
    X472      R216                          60
    X473      R217                          60
    X473      R218                          60
    X474      R219                          60
    X474      R220                          60
    X475      R221                          60
    X475      R222                          60
    X476      R223                          60
    X476      R224                          60
    X477      R225                          60
    X477      R226                          60
    X478      R227                          60
    X478      R228                          60
    X479      R229                          60
    X479      R230                          60
    X480      R231                          60
    X480      R232                          60
    X481      R233                          60
    X481      R234                          60
    X482      R235                          60
    X482      R236                          60
    X483      R237                          60
    X483      R238                          60
    X484      R239                          60
    X484      R240                          60
    X485      R241                          60
    X485      R242                          60
    X486      R243                          60
    X486      R244                          60
    X487      R245                          60
    X487      R246                          60
    X488      R247                          60
    X488      R248                          60
    X489      R249                          60
    X489      R250                          60
    X490      R251                          60
    X490      R252                          60
    X491      R253                          60
    X491      R254                          60
    X492      R255                          60
    X492      R256                          60
    X493      R257                          60
    X493      R258                          60
    X494      R259                          60
    X494      R260                          60
    X495      R261                          60
    X495      R262                          60
    X496      R263                          60
    X496      R264                          60
    X497      R265                          60
    X497      R266                          60
    X498      R267                          60
    X498      R268                          60
    X499      R269                          60
    X499      R270                          60
    X500      R271                          60
    X500      R272                          60
    X501      R273                          60
    X501      R274                          60
    X502      R275                          60
    X502      R276                          60
    X503      R277                          60
    X503      R278                          60
    X504      R279                          60
    X504      R280                          60
    X505      R281                          60
    X505      R282                          60
    X506      R283                          60
    X506      R284                          60
    X507      R285                          60
    X507      R286                          60
    X508      R287                          60
    X508      R288                          60
    X509      R289                          60
    X509      R290                          60
    X510      R291                          60
    X510      R292                          60
    X511      R293                          60
    X511      R294                          60
    X512      R295                          60
    X512      R296                          60
    X513      R297                          60
    X513      R298                          60
    X514      R299                          60
    X514      R300                          60
    X515      R301                          60
    X515      R302                          60
    X516      R303                          60
    X516      R304                          60
    X517      R305                          60
    X517      R306                          60
    X518      R307                          60
    X518      R308                          60
    X519      R309                          60
    X519      R310                          60
    X520      R311                          60
    X520      R312                          60
    X521      R313                          60
    X521      R314                          60
    X522      R315                          60
    X522      R316                          60
    X523      R317                          60
    X523      R318                          60
    X524      R319                          60
    X524      R320                          60
    X525      R321                          60
    X525      R322                          60
    X526      R323                          60
    X526      R324                          60
    X527      R325                          60
    X527      R326                          60
    X528      R327                          60
    X528      R328                          60
    X529      R329                          60
    X529      R330                          60
    X530      R331                          60
    X530      R332                          60
    X531      R333                          60
    X531      R334                          60
    X532      R335                          60
    X532      R336                          60
    X533      R337                          60
    X533      R338                          60
    X534      R339                          60
    X534      R340                          60
    X535      R341                          60
    X535      R342                          60
    X536      R343                          60
    X536      R344                          60
    X537      R345                          60
    X537      R346                          60
    X538      R347                          60
    X538      R348                          60
    X539      R349                          60
    X539      R350                          60
    X540      R351                          60
    X540      R352                          60
    X541      R353                          60
    X541      R354                          60
    X542      R355                          60
    X542      R356                          60
    X543      R357                          60
    X543      R358                          60
    X544      R359                          60
    X544      R360                          60
    X545      R361                          60
    X545      R362                          60
    X546      R363                          60
    X546      R364                          60
    X547      R365                          60
    X547      R366                          60
    X548      R367                          60
    X548      R368                          60
    X549      R369                          60
    X549      R370                          60
    X550      R371                          60
    X550      R372                          60
    X551      R373                          60
    X551      R374                          60
    X552      R375                          60
    X552      R376                          60
    X553      R377                          60
    X553      R378                          60
    X554      R379                          60
    X554      R380                          60
    X555      R381                          60
    X555      R382                          60
    X556      R383                          60
    X556      R384                          60
    X557      R385                          60
    X557      R386                          60
    X558      R387                          60
    X558      R388                          60
    X559      R389                          60
    X559      R390                          60
    X560      R391                          60
    X560      R392                          60
    X561      R393                          60
    X561      R394                          60
    X562      R395                          60
    X562      R396                          60
    X563      R397                          60
    X563      R398                          60
    X564      R399                          60
    X564      R400                          60
    X565      R401                          60
    X565      R402                          60
    X566      R403                          60
    X566      R404                          60
    X567      R405                          60
    X567      R406                          60
    X568      R407                          60
    X568      R408                          60
    X569      R409                          60
    X569      R410                          60
    X570      R411                          60
    X570      R412                          60
    X571      R413                          60
    X571      R414                          60
    X572      R415                          60
    X572      R416                          60
    X573      R417                          60
    X573      R418                          60
    X574      R419                          60
    X574      R420                          60
    X575      R421                          60
    X575      R422                          60
    X576      R423                          60
    X576      R424                          60
    X577      R425                          60
    X577      R426                          60
    X578      R427                          60
    X578      R428                          60
    X579      R429                          60
    X579      R430                          60
    X580      R431                          60
    X580      R432                          60
    X581      R433                          60
    X581      R434                          60
    X582      R435                          60
    X582      R436                          60
    X583      R437                          60
    X583      R438                          60
    X584      R439                          60
    X584      R440                          60
    X585      R441                          60
    X585      R442                          60
    X586      R443                          60
    X586      R444                          60
    X587      R445                          60
    X587      R446                          60
    X588      R447                          60
    X588      R448                          60
    X589      R449                          60
    X589      R450                          60
    X590      R451                          60
    X590      R452                          60
    X591      R453                          60
    X591      R454                          60
    X592      R455                          60
    X592      R456                          60
    X593      R457                          60
    X593      R458                          60
    X594      R459                          60
    X594      R460                          60
    X595      R461                          60
    X595      R462                          60
    X596      R463                          60
    X596      R464                          60
    X597      R465                          60
    X597      R466                          60
    X598      R467                          60
    X598      R468                          60
    X599      R469                          60
    X599      R470                          60
    X600      R471                          60
    X600      R472                          60
    X601      R473                          60
    X601      R474                          60
    X602      R475                          60
    X602      R476                          60
    X603      R477                          60
    X603      R478                          60
    X604      R479                          60
    X604      R480                          60
    X605      R481                          60
    X605      R482                          60
    X606      R483                          60
    X606      R484                          60
    X607      R485                          60
    X607      R486                          60
    X608      R487                          60
    X608      R488                          60
    X609      R489                          60
    X609      R490                          60
    X610      R491                          60
    X610      R492                          60
    X611      R493                          60
    X611      R494                          60
    X612      R495                          60
    X612      R496                          60
    X613      R497                          60
    X613      R498                          60
    X614      R499                          60
    X614      R500                          60
    X615      R501                          60
    X615      R502                          60
    X616      R503                          60
    X616      R504                          60
    X617      R505                          60
    X617      R506                          60
    X618      R507                          60
    X618      R508                          60
    X619      R509                          60
    X619      R510                          60
    X620      R511                          60
    X620      R512                          60
    X621      R513                          60
    X621      R514                          60
    X622      R515                          60
    X622      R516                          60
    X623      R517                          60
    X623      R518                          60
    X624      R519                          60
    X624      R520                          60
    X625      R521                          60
    X625      R522                          60
    X626      R523                          60
    X626      R524                          60
    X627      R525                          60
    X627      R526                          60
    X628      R527                          60
    X628      R528                          60
    X629      R529                          60
    X629      R530                          60
    X630      R531                          60
    X630      R532                          60
    X631      R533                          60
    X631      R534                          60
    X632      R535                          60
    X632      R536                          60
    X633      R537                          60
    X633      R538                          60
    X634      R539                          60
    X634      R540                          60
    X635      R541                          60
    X635      R542                          60
    X636      R543                          60
    X636      R544                          60
    X637      R545                          60
    X637      R546                          60
    X638      R547                          60
    X638      R548                          60
    X639      R549                          60
    X639      R550                          60
    X640      R551                          60
    X640      R552                          60
    X641      R553                          60
    X641      R554                          60
    X642      R555                          60
    X642      R556                          60
    X643      R557                          60
    X643      R558                          60
    X644      R559                          60
    X644      R560                          60
    X645      R561                          60
    X645      R562                          60
    X646      R563                          60
    X646      R564                          60
    X647      R565                          60
    X647      R566                          60
    X648      R567                          60
    X648      R568                          60
    X649      R569                          60
    X649      R570                          60
    X650      R571                          60
    X650      R572                          60
    X651      R573                          60
    X651      R574                          60
    X652      R575                          60
    X652      R576                          60
    X653      R577                          60
    X653      R578                          60
    X654      R579                          60
    X654      R580                          60
    X655      R581                          60
    X655      R582                          60
    X656      R583                          60
    X656      R584                          60
    X657      R585                          60
    X657      R586                          60
    X658      R587                          60
    X658      R588                          60
    X659      R589                          60
    X659      R590                          60
    X660      R591                          60
    X660      R592                          60
    X661      R593                          60
    X661      R594                          60
    X662      R595                          60
    X662      R596                          60
    X663      R597                          60
    X663      R598                          60
    X664      R599                          60
    X664      R600                          60
    X665      R601                          60
    X665      R602                          60
    X666      R603                          60
    X666      R604                          60
    X667      R605                          60
    X667      R606                          60
    X668      R607                          60
    X668      R608                          60
    X669      R609                          60
    X669      R610                          60
    X670      R611                          60
    X670      R612                          60
    X671      R613                          60
    X671      R614                          60
    X672      R615                          60
    X672      R616                          60
    X673      R617                          60
    X673      R618                          60
    X674      R619                          60
    X674      R620                          60
    X675      R621                          60
    X675      R622                          60
    X676      R623                          60
    X676      R624                          60
    X677      R625                          60
    X677      R626                          60
    X678      R627                          60
    X678      R628                          60
    X679      R629                          60
    X679      R630                          60
    X680      R631                          60
    X680      R632                          60
    X681      R633                          60
    X681      R634                          60
    X682      R635                          60
    X682      R636                          60
    X683      R637                          60
    X683      R638                          60
    X684      R639                          60
    X684      R640                          60
    X685      R641                          60
    X685      R642                          60
    X686      R643                          60
    X686      R644                          60
    X687      R645                          60
    X687      R646                          60
    X688      R647                          60
    X688      R648                          60
    X689      R649                          60
    X689      R650                          60
    X690      R651                          60
    X690      R652                          60
    X691      R653                          60
    X691      R654                          60
    X692      R655                          60
    X692      R656                          60
    X693      R657                          60
    X693      R658                          60
    X694      R659                          60
    X694      R660                          60
    X695      R661                          60
    X695      R662                          60
    X696      R663                          60
    X696      R664                          60
    X697      R665                          60
    X697      R666                          60
    X698      R667                          60
    X698      R668                          60
    X699      R669                          60
    X699      R670                          60
    X700      R671                          60
    X700      R672                          60
    X701      R673                          60
    X701      R674                          60
    X702      R675                          60
    X702      R676                          60
    X703      R677                          60
    X703      R678                          60
    X704      R679                          60
    X704      R680                          60
    X705      R681                          60
    X705      R682                          60
    X706      R683                          60
    X706      R684                          60
    X707      R685                          60
    X707      R686                          60
    X708      R1007                         60
    X708      R1008                         60
    X709      R1009                         60
    X709      R1010                         60
    X710      R1011                         60
    X710      R1012                         60
    X711      R1013                         60
    X711      R1014                         60
    X712      R1015                         60
    X712      R1016                         60
    X713      R1017                         60
    X713      R1018                         60
    X714      R1019                         60
    X714      R1020                         60
    X715      R1021                         60
    X715      R1022                         60
    X716      R1023                         60
    X716      R1024                         60
    X717      R1025                         60
    X717      R1026                         60
    X718      R1027                         60
    X718      R1028                         60
    X719      R1029                         60
    X719      R1030                         60
    X720      R1031                         60
    X720      R1032                         60
    X721      R1033                         60
    X721      R1034                         60
    X722      R1035                         60
    X722      R1036                         60
    X723      R1037                         60
    X723      R1038                         60
    X724      R1039                         60
    X724      R1040                         60
    X725      R1041                         60
    X725      R1042                         60
    X726      R1043                         60
    X726      R1044                         60
    X727      R1045                         60
    X727      R1046                         60
RHS
    RHS       R1                            16
    RHS       R2                            21
    RHS       R3                            37
    RHS       R4                            42
    RHS       R5                            33
    RHS       R6                            38
    RHS       R7                            37
    RHS       R8                            42
    RHS       R9                            40
    RHS       R10                           47
    RHS       R11                           33
    RHS       R12                           38
    RHS       R13                           27
    RHS       R14                           32
    RHS       R15                           30
    RHS       R16                           37
    RHS       R17                           16
    RHS       R18                           21
    RHS       R19                           27
    RHS       R20                           32
    RHS       R21                           35
    RHS       R22                           42
    RHS       R23                           34
    RHS       R24                           41
    RHS       R25                           22
    RHS       R26                           27
    RHS       R27                           18
    RHS       R28                           23
    RHS       R29                           22
    RHS       R30                           27
    RHS       R31                           18
    RHS       R32                           23
    RHS       R33                           24
    RHS       R34                           29
    RHS       R35                           4
    RHS       R36                           9
    RHS       R37                           14
    RHS       R38                           19
    RHS       R39                           10
    RHS       R40                           15
    RHS       R41                           10
    RHS       R42                           15
    RHS       R43                           39
    RHS       R44                           44
    RHS       R45                           19
    RHS       R46                           26
    RHS       R47                           19
    RHS       R48                           26
    RHS       R49                           29
    RHS       R50                           36
    RHS       R51                           29
    RHS       R52                           36
    RHS       R53                           40
    RHS       R54                           47
    RHS       R55                           40
    RHS       R56                           47
    RHS       R57                           28
    RHS       R58                           35
    RHS       R59                           28
    RHS       R60                           35
    RHS       R61                           36
    RHS       R62                           41
    RHS       R63                           36
    RHS       R64                           41
    RHS       R65                           32
    RHS       R66                           37
    RHS       R67                           32
    RHS       R68                           37
    RHS       R69                           7
    RHS       R70                           7
    RHS       R71                           51
    RHS       R72                           51
    RHS       R75                           53
    RHS       R76                           53
    RHS       R77                           57
    RHS       R78                           57
    RHS       R79                           30
    RHS       R80                           30
    RHS       R81                           30
    RHS       R82                           30
    RHS       R83                           30
    RHS       R84                           30
    RHS       R85                           30
    RHS       R86                           30
    RHS       R87                           1
    RHS       R88                           59
    RHS       R89                           1
    RHS       R90                           59
    RHS       R91                           14
    RHS       R92                           68
    RHS       R93                           14
    RHS       R94                           68
    RHS       R95                           33
    RHS       R96                           89
    RHS       R97                           33
    RHS       R98                           89
    RHS       R99                           34
    RHS       R100                          90
    RHS       R101                          10
    RHS       R102                          66
    RHS       R103                          10
    RHS       R104                          66
    RHS       R105                          21
    RHS       R106                          77
    RHS       R107                          21
    RHS       R108                          77
    RHS       R109                          17
    RHS       R110                          71
    RHS       R111                          32
    RHS       R112                          86
    RHS       R113                          31
    RHS       R114                          87
    RHS       R115                          14
    RHS       R116                          68
    RHS       R117                          14
    RHS       R118                          68
    RHS       R119                          3
    RHS       R120                          59
    RHS       R121                          15
    RHS       R122                          69
    RHS       R123                          15
    RHS       R124                          69
    RHS       R125                          53
    RHS       R126                          109
    RHS       R127                          53
    RHS       R128                          109
    RHS       R129                          53
    RHS       R130                          110
    RHS       R131                          31
    RHS       R132                          87
    RHS       R133                          8
    RHS       R134                          64
    RHS       R135                          8
    RHS       R136                          64
    RHS       R137                          34
    RHS       R138                          90
    RHS       R139                          53
    RHS       R140                          109
    RHS       R141                          53
    RHS       R142                          109
    RHS       R143                          53
    RHS       R144                          110
    RHS       R145                          32
    RHS       R146                          86
    RHS       R147                          27
    RHS       R148                          81
    RHS       R149                          3
    RHS       R150                          56
    RHS       R151                          3
    RHS       R152                          56
    RHS       R153                          3
    RHS       R154                          56
    RHS       R155                          3
    RHS       R156                          56
    RHS       R157                          9
    RHS       R158                          62
    RHS       R159                          9
    RHS       R160                          62
    RHS       R161                          3
    RHS       R162                          57
    RHS       R163                          3
    RHS       R164                          57
    RHS       R165                          3
    RHS       R166                          56
    RHS       R167                          3
    RHS       R168                          56
    RHS       R169                          3
    RHS       R170                          56
    RHS       R171                          3
    RHS       R172                          56
    RHS       R173                          3
    RHS       R174                          56
    RHS       R175                          3
    RHS       R176                          56
    RHS       R177                          3
    RHS       R178                          56
    RHS       R179                          3
    RHS       R180                          56
    RHS       R181                          20
    RHS       R182                          74
    RHS       R183                          21
    RHS       R184                          75
    RHS       R185                          30
    RHS       R186                          30
    RHS       R187                          13
    RHS       R188                          66
    RHS       R189                          13
    RHS       R190                          66
    RHS       R191                          3
    RHS       R192                          57
    RHS       R193                          3
    RHS       R194                          57
    RHS       R195                          4
    RHS       R196                          57
    RHS       R197                          4
    RHS       R198                          57
    RHS       R199                          3
    RHS       R200                          57
    RHS       R201                          4
    RHS       R202                          57
    RHS       R203                          4
    RHS       R204                          57
    RHS       R205                          22
    RHS       R206                          75
    RHS       R207                          22
    RHS       R208                          75
    RHS       R209                          30
    RHS       R210                          30
    RHS       R211                          13
    RHS       R212                          67
    RHS       R213                          3
    RHS       R214                          57
    RHS       R215                          4
    RHS       R216                          57
    RHS       R217                          4
    RHS       R218                          57
    RHS       R219                          3
    RHS       R220                          56
    RHS       R221                          3
    RHS       R222                          56
    RHS       R223                          10
    RHS       R224                          64
    RHS       R225                          10
    RHS       R226                          64
    RHS       R227                          3
    RHS       R228                          56
    RHS       R229                          3
    RHS       R230                          56
    RHS       R231                          4
    RHS       R232                          57
    RHS       R233                          3
    RHS       R234                          56
    RHS       R235                          3
    RHS       R236                          56
    RHS       R237                          3
    RHS       R238                          57
    RHS       R239                          3
    RHS       R240                          56
    RHS       R241                          3
    RHS       R242                          57
    RHS       R243                          3
    RHS       R244                          56
    RHS       R245                          3
    RHS       R246                          56
    RHS       R247                          3
    RHS       R248                          57
    RHS       R249                          3
    RHS       R250                          57
    RHS       R251                          4
    RHS       R252                          57
    RHS       R253                          3
    RHS       R254                          56
    RHS       R255                          3
    RHS       R256                          56
    RHS       R257                          4
    RHS       R258                          57
    RHS       R259                          3
    RHS       R260                          57
    RHS       R261                          3
    RHS       R262                          57
    RHS       R263                          3
    RHS       R264                          57
    RHS       R265                          53
    RHS       R266                          106
    RHS       R267                          32
    RHS       R268                          86
    RHS       R269                          3
    RHS       R270                          57
    RHS       R271                          3
    RHS       R272                          56
    RHS       R273                          57
    RHS       R274                          110
    RHS       R275                          8
    RHS       R276                          61
    RHS       R277                          8
    RHS       R278                          61
    RHS       R279                          3
    RHS       R280                          56
    RHS       R281                          3
    RHS       R282                          57
    RHS       R283                          3
    RHS       R284                          56
    RHS       R285                          3
    RHS       R286                          56
    RHS       R287                          38
    RHS       R288                          91
    RHS       R289                          3
    RHS       R290                          57
    RHS       R291                          3
    RHS       R292                          57
    RHS       R293                          3
    RHS       R294                          56
    RHS       R295                          3
    RHS       R296                          56
    RHS       R297                          4
    RHS       R298                          57
    RHS       R299                          3
    RHS       R300                          56
    RHS       R301                          3
    RHS       R302                          56
    RHS       R303                          4
    RHS       R304                          57
    RHS       R305                          3
    RHS       R306                          56
    RHS       R307                          3
    RHS       R308                          56
    RHS       R309                          4
    RHS       R310                          57
    RHS       R311                          3
    RHS       R312                          56
    RHS       R313                          3
    RHS       R314                          56
    RHS       R315                          3
    RHS       R316                          57
    RHS       R317                          3
    RHS       R318                          57
    RHS       R319                          30
    RHS       R320                          30
    RHS       R321                          3
    RHS       R322                          57
    RHS       R323                          5
    RHS       R324                          57
    RHS       R325                          5
    RHS       R326                          57
    RHS       R327                          5
    RHS       R328                          57
    RHS       R329                          4
    RHS       R330                          57
    RHS       R331                          4
    RHS       R332                          57
    RHS       R333                          22
    RHS       R334                          75
    RHS       R335                          22
    RHS       R336                          75
    RHS       R337                          13
    RHS       R338                          67
    RHS       R339                          14
    RHS       R340                          68
    RHS       R341                          3
    RHS       R342                          57
    RHS       R343                          5
    RHS       R344                          57
    RHS       R345                          4
    RHS       R346                          57
    RHS       R347                          5
    RHS       R348                          57
    RHS       R349                          4
    RHS       R350                          57
    RHS       R351                          4
    RHS       R352                          57
    RHS       R353                          4
    RHS       R354                          57
    RHS       R355                          31
    RHS       R356                          31
    RHS       R357                          40
    RHS       R358                          40
    RHS       R359                          10
    RHS       R360                          10
    RHS       R361                          4
    RHS       R362                          57
    RHS       R363                          3
    RHS       R364                          57
    RHS       R365                          3
    RHS       R366                          57
    RHS       R367                          3
    RHS       R368                          57
    RHS       R369                          1
    RHS       R370                          55
    RHS       R371                          1
    RHS       R372                          55
    RHS       R373                          4
    RHS       R374                          57
    RHS       R375                          4
    RHS       R376                          57
    RHS       R377                          4
    RHS       R378                          57
    RHS       R379                          4
    RHS       R380                          57
    RHS       R381                          30
    RHS       R382                          30
    RHS       R383                          4
    RHS       R384                          57
    RHS       R385                          4
    RHS       R386                          57
    RHS       R387                          4
    RHS       R388                          57
    RHS       R389                          4
    RHS       R390                          57
    RHS       R391                          31
    RHS       R392                          31
    RHS       R393                          46
    RHS       R394                          100
    RHS       R395                          46
    RHS       R396                          100
    RHS       R397                          4
    RHS       R398                          57
    RHS       R399                          4
    RHS       R400                          57
    RHS       R401                          4
    RHS       R402                          57
    RHS       R403                          9
    RHS       R404                          9
    RHS       R405                          39
    RHS       R406                          39
    RHS       R407                          3
    RHS       R408                          57
    RHS       R409                          3
    RHS       R410                          57
    RHS       R411                          1
    RHS       R412                          55
    RHS       R413                          1
    RHS       R414                          55
    RHS       R415                          4
    RHS       R416                          57
    RHS       R417                          4
    RHS       R418                          57
    RHS       R419                          45
    RHS       R420                          99
    RHS       R421                          45
    RHS       R422                          99
    RHS       R423                          4
    RHS       R424                          57
    RHS       R425                          4
    RHS       R426                          57
    RHS       R427                          3
    RHS       R428                          56
    RHS       R429                          3
    RHS       R430                          56
    RHS       R431                          4
    RHS       R432                          57
    RHS       R433                          4
    RHS       R434                          57
    RHS       R435                          3
    RHS       R436                          57
    RHS       R437                          53
    RHS       R438                          106
    RHS       R439                          3
    RHS       R440                          57
    RHS       R441                          3
    RHS       R442                          57
    RHS       R443                          3
    RHS       R444                          57
    RHS       R445                          3
    RHS       R446                          57
    RHS       R447                          4
    RHS       R448                          57
    RHS       R449                          59
    RHS       R450                          112
    RHS       R451                          52
    RHS       R452                          105
    RHS       R453                          4
    RHS       R454                          57
    RHS       R455                          3
    RHS       R456                          56
    RHS       R457                          3
    RHS       R458                          56
    RHS       R459                          38
    RHS       R460                          91
    RHS       R461                          30
    RHS       R462                          30
    RHS       R463                          15
    RHS       R464                          15
    RHS       R465                          45
    RHS       R466                          45
    RHS       R467                          4
    RHS       R468                          57
    RHS       R469                          5
    RHS       R470                          57
    RHS       R471                          5
    RHS       R472                          57
    RHS       R473                          5
    RHS       R474                          57
    RHS       R475                          4
    RHS       R476                          57
    RHS       R477                          3
    RHS       R478                          57
    RHS       R479                          3
    RHS       R480                          57
    RHS       R481                          3
    RHS       R482                          57
    RHS       R483                          4
    RHS       R484                          57
    RHS       R485                          3
    RHS       R486                          57
    RHS       R487                          3
    RHS       R488                          57
    RHS       R489                          3
    RHS       R490                          56
    RHS       R491                          3
    RHS       R492                          57
    RHS       R493                          3
    RHS       R494                          57
    RHS       R495                          4
    RHS       R496                          57
    RHS       R497                          3
    RHS       R498                          57
    RHS       R499                          4
    RHS       R500                          57
    RHS       R501                          3
    RHS       R502                          57
    RHS       R503                          4
    RHS       R504                          57
    RHS       R505                          30
    RHS       R506                          30
    RHS       R507                          4
    RHS       R508                          57
    RHS       R509                          5
    RHS       R510                          57
    RHS       R511                          4
    RHS       R512                          57
    RHS       R513                          5
    RHS       R514                          57
    RHS       R515                          13
    RHS       R516                          66
    RHS       R517                          13
    RHS       R518                          66
    RHS       R519                          4
    RHS       R520                          57
    RHS       R521                          3
    RHS       R522                          57
    RHS       R523                          4
    RHS       R524                          57
    RHS       R525                          3
    RHS       R526                          57
    RHS       R527                          4
    RHS       R528                          57
    RHS       R529                          4
    RHS       R530                          57
    RHS       R531                          4
    RHS       R532                          57
    RHS       R533                          4
    RHS       R534                          57
    RHS       R535                          4
    RHS       R536                          57
    RHS       R537                          4
    RHS       R538                          57
    RHS       R539                          3
    RHS       R540                          57
    RHS       R541                          3
    RHS       R542                          56
    RHS       R543                          3
    RHS       R544                          56
    RHS       R545                          3
    RHS       R546                          57
    RHS       R547                          3
    RHS       R548                          57
    RHS       R549                          53
    RHS       R550                          106
    RHS       R551                          59
    RHS       R552                          112
    RHS       R553                          52
    RHS       R554                          105
    RHS       R555                          3
    RHS       R556                          56
    RHS       R557                          3
    RHS       R558                          56
    RHS       R559                          38
    RHS       R560                          91
    RHS       R561                          45
    RHS       R562                          45
    RHS       R563                          15
    RHS       R564                          15
    RHS       R565                          4
    RHS       R566                          57
    RHS       R567                          3
    RHS       R568                          57
    RHS       R569                          4
    RHS       R570                          57
    RHS       R571                          11
    RHS       R572                          64
    RHS       R573                          11
    RHS       R574                          64
    RHS       R575                          3
    RHS       R576                          57
    RHS       R577                          5
    RHS       R578                          57
    RHS       R579                          3
    RHS       R580                          57
    RHS       R581                          4
    RHS       R582                          57
    RHS       R583                          4
    RHS       R584                          57
    RHS       R585                          3
    RHS       R586                          57
    RHS       R587                          4
    RHS       R588                          57
    RHS       R589                          53
    RHS       R590                          106
    RHS       R591                          57
    RHS       R592                          110
    RHS       R593                          3
    RHS       R594                          57
    RHS       R595                          38
    RHS       R596                          91
    RHS       R597                          30
    RHS       R598                          30
    RHS       R599                          4
    RHS       R600                          57
    RHS       R601                          3
    RHS       R602                          57
    RHS       R603                          4
    RHS       R604                          57
    RHS       R605                          3
    RHS       R606                          57
    RHS       R607                          5
    RHS       R608                          57
    RHS       R609                          3
    RHS       R610                          57
    RHS       R611                          4
    RHS       R612                          57
    RHS       R613                          4
    RHS       R614                          57
    RHS       R615                          4
    RHS       R616                          57
    RHS       R617                          4
    RHS       R618                          57
    RHS       R619                          4
    RHS       R620                          57
    RHS       R621                          3
    RHS       R622                          56
    RHS       R623                          3
    RHS       R624                          56
    RHS       R625                          4
    RHS       R626                          57
    RHS       R627                          11
    RHS       R628                          64
    RHS       R629                          11
    RHS       R630                          64
    RHS       R631                          5
    RHS       R632                          57
    RHS       R633                          4
    RHS       R634                          57
    RHS       R635                          4
    RHS       R636                          57
    RHS       R637                          4
    RHS       R638                          57
    RHS       R639                          38
    RHS       R640                          91
    RHS       R641                          4
    RHS       R642                          57
    RHS       R643                          4
    RHS       R644                          57
    RHS       R645                          5
    RHS       R646                          57
    RHS       R647                          4
    RHS       R648                          57
    RHS       R649                          4
    RHS       R650                          57
    RHS       R651                          4
    RHS       R652                          57
    RHS       R653                          3
    RHS       R654                          57
    RHS       R655                          30
    RHS       R656                          30
    RHS       R657                          3
    RHS       R658                          57
    RHS       R659                          3
    RHS       R660                          57
    RHS       R661                          3
    RHS       R662                          57
    RHS       R663                          4
    RHS       R664                          57
    RHS       R665                          4
    RHS       R666                          57
    RHS       R667                          3
    RHS       R668                          57
    RHS       R669                          56
    RHS       R670                          110
    RHS       R671                          3
    RHS       R672                          57
    RHS       R673                          56
    RHS       R674                          110
    RHS       R675                          3
    RHS       R676                          57
    RHS       R677                          3
    RHS       R678                          57
    RHS       R679                          3
    RHS       R680                          57
    RHS       R681                          3
    RHS       R682                          57
    RHS       R683                          3
    RHS       R684                          57
    RHS       R685                          3
    RHS       R686                          57
    RHS       R687                          25
    RHS       R688                          32
    RHS       R689                          30
    RHS       R690                          37
    RHS       R691                          3
    RHS       R692                          10
    RHS       R693                          31
    RHS       R694                          38
    RHS       R695                          37
    RHS       R696                          44
    RHS       R697                          15
    RHS       R698                          22
    RHS       R699                          38
    RHS       R700                          45
    RHS       R701                          42
    RHS       R702                          49
    RHS       R703                          17
    RHS       R704                          24
    RHS       R705                          45
    RHS       R706                          52
    RHS       R707                          36
    RHS       R708                          43
    RHS       R709                          17
    RHS       R710                          24
    RHS       R711                          16
    RHS       R712                          23
    RHS       R713                          15
    RHS       R714                          22
    RHS       R715                          11
    RHS       R716                          18
    RHS       R717                          15
    RHS       R718                          22
    RHS       R719                          13
    RHS       R720                          20
    RHS       R721                          22
    RHS       R722                          29
    RHS       R723                          8
    RHS       R724                          15
    RHS       R725                          21
    RHS       R726                          28
    RHS       R727                          13
    RHS       R728                          20
    RHS       R729                          16
    RHS       R730                          23
    RHS       R731                          11
    RHS       R732                          18
    RHS       R733                          17
    RHS       R734                          24
    RHS       R735                          34
    RHS       R736                          41
    RHS       R737                          38
    RHS       R738                          45
    RHS       R739                          42
    RHS       R740                          49
    RHS       R741                          17
    RHS       R742                          24
    RHS       R743                          45
    RHS       R744                          52
    RHS       R745                          38
    RHS       R746                          45
    RHS       R747                          14
    RHS       R748                          21
    RHS       R749                          8
    RHS       R750                          18
    RHS       R751                          22
    RHS       R752                          29
    RHS       R753                          28
    RHS       R754                          35
    RHS       R755                          21
    RHS       R756                          28
    RHS       R757                          18
    RHS       R758                          25
    RHS       R759                          15
    RHS       R760                          22
    RHS       R761                          4
    RHS       R762                          11
    RHS       R763                          15
    RHS       R764                          22
    RHS       R765                          15
    RHS       R766                          22
    RHS       R767                          17
    RHS       R768                          24
    RHS       R769                          20
    RHS       R770                          27
    RHS       R771                          31
    RHS       R772                          38
    RHS       R773                          19
    RHS       R774                          29
    RHS       R775                          9
    RHS       R776                          16
    RHS       R777                          14
    RHS       R778                          21
    RHS       R779                          8
    RHS       R780                          18
    RHS       R781                          21
    RHS       R782                          28
    RHS       R783                          28
    RHS       R784                          35
    RHS       R785                          19
    RHS       R786                          26
    RHS       R787                          31
    RHS       R788                          38
    RHS       R789                          19
    RHS       R790                          29
    RHS       R791                          8
    RHS       R792                          15
    RHS       R793                          5
    RHS       R794                          12
    RHS       R795                          15
    RHS       R796                          22
    RHS       R797                          13
    RHS       R798                          20
    RHS       R799                          17
    RHS       R800                          24
    RHS       R801                          13
    RHS       R802                          20
    RHS       R803                          23
    RHS       R804                          30
    RHS       R805                          17
    RHS       R806                          24
    RHS       R807                          14
    RHS       R808                          21
    RHS       R809                          15
    RHS       R810                          22
    RHS       R811                          15
    RHS       R812                          22
    RHS       R813                          14
    RHS       R814                          21
    RHS       R815                          17
    RHS       R816                          24
    RHS       R817                          22
    RHS       R818                          29
    RHS       R819                          13
    RHS       R820                          20
    RHS       R821                          16
    RHS       R822                          23
    RHS       R823                          13
    RHS       R824                          20
    RHS       R825                          16
    RHS       R826                          23
    RHS       R827                          34
    RHS       R828                          41
    RHS       R829                          25
    RHS       R830                          32
    RHS       R831                          11
    RHS       R832                          18
    RHS       R833                          24
    RHS       R834                          31
    RHS       R835                          11
    RHS       R836                          18
    RHS       R837                          9
    RHS       R838                          16
    RHS       R839                          11
    RHS       R840                          18
    RHS       R841                          25
    RHS       R842                          32
    RHS       R843                          12
    RHS       R844                          19
    RHS       R845                          28
    RHS       R846                          35
    RHS       R847                          37
    RHS       R848                          44
    RHS       R849                          15
    RHS       R850                          22
    RHS       R851                          25
    RHS       R852                          32
    RHS       R853                          11
    RHS       R854                          18
    RHS       R855                          24
    RHS       R856                          31
    RHS       R857                          11
    RHS       R858                          18
    RHS       R859                          9
    RHS       R860                          16
    RHS       R861                          11
    RHS       R862                          18
    RHS       R863                          25
    RHS       R864                          32
    RHS       R865                          12
    RHS       R866                          19
    RHS       R867                          26
    RHS       R868                          33
    RHS       R869                          17
    RHS       R870                          24
    RHS       R871                          4
    RHS       R872                          11
    RHS       R873                          15
    RHS       R874                          22
    RHS       R875                          13
    RHS       R876                          20
    RHS       R877                          17
    RHS       R878                          24
    RHS       R879                          13
    RHS       R880                          20
    RHS       R881                          23
    RHS       R882                          30
    RHS       R883                          3
    RHS       R884                          10
    RHS       R885                          22
    RHS       R886                          29
    RHS       R887                          13
    RHS       R888                          20
    RHS       R889                          16
    RHS       R890                          23
    RHS       R891                          13
    RHS       R892                          20
    RHS       R893                          16
    RHS       R894                          23
    RHS       R895                          17
    RHS       R896                          24
    RHS       R897                          16
    RHS       R898                          23
    RHS       R899                          12
    RHS       R900                          19
    RHS       R901                          16
    RHS       R902                          23
    RHS       R903                          13
    RHS       R904                          20
    RHS       R905                          21
    RHS       R906                          28
    RHS       R907                          13
    RHS       R908                          20
    RHS       R909                          16
    RHS       R910                          23
    RHS       R911                          11
    RHS       R912                          18
    RHS       R913                          18
    RHS       R914                          25
    RHS       R915                          31
    RHS       R916                          38
    RHS       R917                          24
    RHS       R918                          31
    RHS       R919                          11
    RHS       R920                          18
    RHS       R921                          24
    RHS       R922                          31
    RHS       R923                          11
    RHS       R924                          18
    RHS       R925                          8
    RHS       R926                          15
    RHS       R927                          11
    RHS       R928                          18
    RHS       R929                          24
    RHS       R930                          31
    RHS       R931                          11
    RHS       R932                          18
    RHS       R933                          25
    RHS       R934                          32
    RHS       R935                          17
    RHS       R936                          24
    RHS       R937                          16
    RHS       R938                          23
    RHS       R939                          12
    RHS       R940                          19
    RHS       R941                          16
    RHS       R942                          23
    RHS       R943                          13
    RHS       R944                          20
    RHS       R945                          16
    RHS       R946                          23
    RHS       R947                          11
    RHS       R948                          18
    RHS       R949                          18
    RHS       R950                          25
    RHS       R951                          27
    RHS       R952                          34
    RHS       R953                          27
    RHS       R954                          34
    RHS       R955                          33
    RHS       R956                          40
    RHS       R957                          33
    RHS       R958                          40
    RHS       R959                          8
    RHS       R960                          15
    RHS       R961                          26
    RHS       R962                          33
    RHS       R963                          8
    RHS       R964                          15
    RHS       R965                          26
    RHS       R966                          33
    RHS       R967                          7
    RHS       R968                          14
    RHS       R969                          30
    RHS       R970                          37
    RHS       R971                          7
    RHS       R972                          14
    RHS       R973                          30
    RHS       R974                          37
    RHS       R975                          24
    RHS       R976                          31
    RHS       R977                          14
    RHS       R978                          21
    RHS       R979                          17
    RHS       R980                          24
    RHS       R981                          14
    RHS       R982                          21
    RHS       R983                          24
    RHS       R984                          31
    RHS       R985                          14
    RHS       R986                          21
    RHS       R987                          17
    RHS       R988                          24
    RHS       R989                          14
    RHS       R990                          21
    RHS       R991                          14
    RHS       R992                          21
    RHS       R993                          14
    RHS       R994                          21
    RHS       R995                          11
    RHS       R996                          18
    RHS       R997                          15
    RHS       R998                          22
    RHS       R999                          38
    RHS       R1000                         45
    RHS       R1001                         15
    RHS       R1002                         22
    RHS       R1003                         10
    RHS       R1004                         17
    RHS       R1005                         14
    RHS       R1006                         21
    RHS       R1007                         30
    RHS       R1008                         30
    RHS       R1009                         30
    RHS       R1010                         30
    RHS       R1011                         45
    RHS       R1012                         45
    RHS       R1013                         15
    RHS       R1014                         15
    RHS       R1015                         15
    RHS       R1016                         15
    RHS       R1017                         45
    RHS       R1018                         45
    RHS       R1019                         30
    RHS       R1020                         30
    RHS       R1021                         30
    RHS       R1022                         30
    RHS       R1023                         30
    RHS       R1024                         30
    RHS       R1025                         30
    RHS       R1026                         30
    RHS       R1027                         30
    RHS       R1028                         30
    RHS       R1029                         30
    RHS       R1030                         30
    RHS       R1031                         30
    RHS       R1032                         30
    RHS       R1033                         30
    RHS       R1034                         30
    RHS       R1035                         30
    RHS       R1036                         30
    RHS       R1037                         15
    RHS       R1038                         15
    RHS       R1039                         45
    RHS       R1040                         45
    RHS       R1041                         45
    RHS       R1042                         45
    RHS       R1043                         15
    RHS       R1044                         15
    RHS       R1045                         30
    RHS       R1046                         30
BOUNDS
 UP BND       X0                            59
 UP BND       X1                            59
 UP BND       X2                            1
 UP BND       X3                            59
 UP BND       X4                            59
 UP BND       X5                            1
 UP BND       X6                            59
 UP BND       X7                            59
 UP BND       X8                            1
 UP BND       X9                            59
 UP BND       X10                           59
 UP BND       X11                           1
 UP BND       X12                           59
 UP BND       X13                           1
 UP BND       X14                           59
 UP BND       X15                           59
 UP BND       X16                           1
 UP BND       X17                           59
 UP BND       X18                           59
 UP BND       X19                           1
 UP BND       X20                           59
 UP BND       X21                           1
 UP BND       X22                           59
 UP BND       X23                           59
 UP BND       X24                           1
 UP BND       X25                           59
 UP BND       X26                           59
 UP BND       X27                           1
 UP BND       X28                           59
 UP BND       X29                           1
 UP BND       X30                           59
 UP BND       X31                           1
 UP BND       X32                           59
 UP BND       X33                           59
 UP BND       X34                           1
 UP BND       X35                           59
 UP BND       X36                           59
 UP BND       X37                           1
 UP BND       X38                           59
 UP BND       X39                           59
 UP BND       X40                           1
 UP BND       X41                           59
 UP BND       X42                           59
 UP BND       X43                           1
 UP BND       X44                           59
 UP BND       X45                           59
 UP BND       X46                           1
 UP BND       X47                           59
 UP BND       X48                           59
 UP BND       X49                           1
 UP BND       X50                           59
 UP BND       X51                           59
 UP BND       X52                           1
 UP BND       X53                           59
 UP BND       X54                           59
 UP BND       X55                           1
 UP BND       X56                           59
 UP BND       X57                           59
 UP BND       X58                           1
 UP BND       X59                           59
 UP BND       X60                           59
 UP BND       X61                           1
 UP BND       X62                           59
 UP BND       X63                           1
 UP BND       X64                           59
 UP BND       X65                           1
 UP BND       X66                           59
 UP BND       X67                           1
 UP BND       X68                           59
 UP BND       X69                           1
 UP BND       X70                           59
 UP BND       X71                           1
 UP BND       X72                           59
 UP BND       X73                           1
 UP BND       X74                           59
 UP BND       X75                           1
 UP BND       X76                           59
 UP BND       X77                           1
 UP BND       X78                           59
 UP BND       X79                           59
 UP BND       X80                           1
 UP BND       X81                           59
 UP BND       X82                           59
 UP BND       X83                           1
 UP BND       X84                           59
 UP BND       X85                           59
 UP BND       X86                           1
 UP BND       X87                           59
 UP BND       X88                           59
 UP BND       X89                           1
 UP BND       X90                           59
 UP BND       X91                           59
 UP BND       X92                           1
 UP BND       X93                           59
 UP BND       X94                           1
 UP BND       X95                           59
 UP BND       X96                           59
 UP BND       X97                           1
 UP BND       X98                           59
 UP BND       X99                           1
 UP BND       X100                          1
 UP BND       X101                          1
 UP BND       X102                          59
 UP BND       X103                          1
 UP BND       X104                          59
 UP BND       X105                          1
 UP BND       X106                          59
 UP BND       X107                          59
 UP BND       X108                          1
 UP BND       X109                          1
 UP BND       X110                          1
 UP BND       X111                          1
 UP BND       X112                          59
 UP BND       X113                          59
 UP BND       X114                          1
 UP BND       X115                          59
 UP BND       X116                          1
 UP BND       X117                          59
 UP BND       X118                          1
 UP BND       X119                          1
 UP BND       X120                          59
 UP BND       X121                          1
 UP BND       X122                          59
 UP BND       X123                          1
 UP BND       X124                          59
 UP BND       X125                          59
 UP BND       X126                          1
 UP BND       X127                          1
 UP BND       X128                          59
 UP BND       X129                          1
 UP BND       X130                          59
 UP BND       X131                          1
 UP BND       X132                          59
 UP BND       X133                          1
 UP BND       X134                          59
 UP BND       X135                          1
 UP BND       X136                          1
 UP BND       X137                          59
 UP BND       X138                          1
 UP BND       X139                          59
 UP BND       X140                          1
 UP BND       X141                          59
 UP BND       X142                          59
 UP BND       X143                          1
 UP BND       X144                          1
 UP BND       X145                          1
 UP BND       X146                          59
 UP BND       X147                          59
 UP BND       X148                          1
 UP BND       X149                          59
 UP BND       X150                          1
 UP BND       X151                          59
 UP BND       X152                          1
 UP BND       X153                          1
 UP BND       X154                          1
 UP BND       X155                          59
 UP BND       X156                          1
 UP BND       X157                          59
 UP BND       X158                          1
 UP BND       X159                          59
 UP BND       X160                          59
 UP BND       X161                          1
 UP BND       X162                          59
 UP BND       X163                          1
 UP BND       X164                          1
 UP BND       X165                          1
 UP BND       X166                          59
 UP BND       X167                          1
 UP BND       X168                          59
 UP BND       X169                          1
 UP BND       X170                          59
 UP BND       X171                          1
 UP BND       X172                          59
 UP BND       X173                          1
 UP BND       X174                          59
 UP BND       X175                          59
 UP BND       X176                          1
 UP BND       X177                          59
 UP BND       X178                          1
 UP BND       X179                          59
 UP BND       X180                          1
 UP BND       X181                          1
 UP BND       X182                          59
 UP BND       X183                          1
 UP BND       X184                          59
 UP BND       X185                          1
 UP BND       X186                          59
 UP BND       X187                          1
 UP BND       X188                          59
 UP BND       X189                          1
 UP BND       X190                          59
 UP BND       X191                          59
 UP BND       X192                          1
 UP BND       X193                          59
 UP BND       X194                          1
 UP BND       X195                          59
 UP BND       X196                          1
 UP BND       X197                          59
 UP BND       X198                          1
 UP BND       X199                          59
 UP BND       X200                          1
 UP BND       X201                          1
 UP BND       X202                          59
 UP BND       X203                          1
 UP BND       X204                          59
 UP BND       X205                          1
 UP BND       X206                          59
 UP BND       X207                          1
 UP BND       X208                          59
 UP BND       X209                          59
 UP BND       X210                          1
 UP BND       X211                          1
 UP BND       X212                          59
 UP BND       X213                          1
 UP BND       X214                          59
 UP BND       X215                          1
 UP BND       X216                          59
 UP BND       X217                          1
 UP BND       X218                          59
 UP BND       X219                          1
 UP BND       X220                          59
 UP BND       X221                          1
 UP BND       X222                          59
 UP BND       X223                          1
 UP BND       X224                          1
 UP BND       X225                          59
 UP BND       X226                          1
 UP BND       X227                          59
 UP BND       X228                          1
 UP BND       X229                          59
 UP BND       X230                          1
 UP BND       X231                          59
 UP BND       X232                          1
 UP BND       X233                          59
 UP BND       X234                          59
 UP BND       X235                          1
 UP BND       X236                          59
 UP BND       X237                          1
 UP BND       X238                          59
 UP BND       X239                          1
 UP BND       X240                          1
 UP BND       X241                          1
 UP BND       X242                          1
 UP BND       X243                          1
 UP BND       X244                          59
 UP BND       X245                          1
 UP BND       X246                          59
 UP BND       X247                          1
 UP BND       X248                          59
 UP BND       X249                          1
 UP BND       X250                          59
 UP BND       X251                          1
 UP BND       X252                          59
 UP BND       X253                          59
 UP BND       X254                          1
 UP BND       X255                          59
 UP BND       X256                          1
 UP BND       X257                          59
 UP BND       X258                          1
 UP BND       X259                          1
 UP BND       X260                          1
 UP BND       X261                          1
 UP BND       X262                          59
 UP BND       X263                          59
 UP BND       X264                          1
 UP BND       X265                          59
 UP BND       X266                          1
 UP BND       X267                          59
 UP BND       X268                          1
 UP BND       X269                          59
 UP BND       X270                          1
 UP BND       X271                          1
 UP BND       X272                          1
 UP BND       X273                          1
 UP BND       X274                          59
 UP BND       X275                          1
 UP BND       X276                          59
 UP BND       X277                          1
 UP BND       X278                          59
 UP BND       X279                          1
 UP BND       X280                          59
 UP BND       X281                          1
 UP BND       X282                          59
 UP BND       X283                          1
 UP BND       X284                          59
 UP BND       X285                          59
 UP BND       X286                          1
 UP BND       X287                          59
 UP BND       X288                          1
 UP BND       X289                          59
 UP BND       X290                          1
 UP BND       X291                          59
 UP BND       X292                          1
 UP BND       X293                          59
 UP BND       X294                          1
 UP BND       X295                          59
 UP BND       X296                          59
 UP BND       X297                          1
 UP BND       X298                          59
 UP BND       X299                          1
 UP BND       X300                          59
 UP BND       X301                          1
 UP BND       X302                          59
 UP BND       X303                          1
 UP BND       X304                          59
 UP BND       X305                          1
 UP BND       X306                          59
 UP BND       X307                          59
 UP BND       X308                          1
 UP BND       X309                          59
 UP BND       X310                          1
 UP BND       X311                          59
 UP BND       X312                          1
 UP BND       X313                          59
 UP BND       X314                          1
 UP BND       X315                          59
 UP BND       X316                          1
 UP BND       X317                          59
 UP BND       X318                          59
 UP BND       X319                          1
 UP BND       X320                          59
 UP BND       X321                          1
 UP BND       X322                          59
 UP BND       X323                          1
 UP BND       X324                          59
 UP BND       X325                          1
 UP BND       X326                          59
 UP BND       X327                          1
 UP BND       X328                          59
 UP BND       X329                          59
 UP BND       X330                          1
 UP BND       X331                          59
 UP BND       X332                          1
 UP BND       X333                          59
 UP BND       X334                          1
 UP BND       X335                          59
 UP BND       X336                          1
 UP BND       X337                          59
 UP BND       X338                          59
 UP BND       X339                          1
 UP BND       X340                          59
 UP BND       X341                          1
 UP BND       X342                          59
 UP BND       X343                          1
 UP BND       X344                          59
 UP BND       X345                          1
 UP BND       X346                          59
 UP BND       X347                          1
 UP BND       X348                          59
 UP BND       X349                          1
 UP BND       X350                          59
 UP BND       X351                          1
 UP BND       X352                          59
 UP BND       X353                          1
 UP BND       X354                          1
 UP BND       X355                          1
 UP BND       X356                          1
 UP BND       X357                          1
 UP BND       X358                          59
 UP BND       X359                          1
 UP BND       X360                          59
 UP BND       X361                          1
 UP BND       X362                          59
 UP BND       X363                          1
 UP BND       X364                          59
 UP BND       X365                          1
 UP BND       X366                          59
 UP BND       X367                          1
 UP BND       X368                          59
 UP BND       X369                          1
 UP BND       X370                          59
 UP BND       X371                          59
 UP BND       X372                          1
 UP BND       X373                          1
 UP BND       X374                          59
 UP BND       X375                          1
 UP BND       X376                          59
 UP BND       X377                          1
 UP BND       X378                          59
 UP BND       X379                          59
 UP BND       X380                          1
 UP BND       X381                          1
 UP BND       X382                          59
 UP BND       X383                          59
 UP BND       X384                          1
 UP BND       X385                          59
 UP BND       X386                          1
 UP BND       X387                          59
 UP BND       X388                          1
 UP BND       X389                          1
 UP BND       X390                          59
 UP BND       X391                          1
 UP BND       X392                          59
 UP BND       X393                          1
 UP BND       X394                          59
 UP BND       X395                          1
 UP BND       X396                          59
 UP BND       X397                          1
 UP BND       X398                          59
 UP BND       X399                          1
 UP BND       X400                          1
 UP BND       X401                          1
 UP BND       X402                          1
 UP BND       X403                          1
 UP BND       X404                          1
 UP BND       X405                          1
 UP BND       X406                          1
 UP BND       X407                          1
 UP BND       X408                          1
 UP BND       X409                          1
 UP BND       X410                          2
 UP BND       X411                          2
 UP BND       X412                          2
 UP BND       X413                          2
 UP BND       X414                          2
 UP BND       X415                          2
 UP BND       X416                          2
 UP BND       X417                          2
 UP BND       X418                          2
 UP BND       X419                          2
 UP BND       X420                          2
 UP BND       X421                          2
 UP BND       X422                          2
 UP BND       X423                          2
 UP BND       X424                          1
 UP BND       X425                          2
 UP BND       X426                          2
 UP BND       X427                          2
 UP BND       X428                          2
 UP BND       X429                          2
 UP BND       X430                          2
 UP BND       X431                          2
 UP BND       X432                          2
 UP BND       X433                          2
 UP BND       X434                          2
 UP BND       X435                          2
 UP BND       X436                          2
 UP BND       X437                          2
 UP BND       X438                          2
 UP BND       X439                          1
 UP BND       X440                          1
 UP BND       X441                          1
 UP BND       X442                          1
 UP BND       X443                          2
 UP BND       X444                          2
 UP BND       X445                          1
 UP BND       X446                          1
 UP BND       X447                          1
 UP BND       X448                          1
 UP BND       X449                          1
 UP BND       X450                          1
 UP BND       X451                          1
 UP BND       X452                          1
 UP BND       X453                          1
 UP BND       X454                          1
 UP BND       X455                          2
 UP BND       X456                          2
 UP BND       X457                          1
 UP BND       X458                          2
 UP BND       X459                          2
 UP BND       X460                          1
 UP BND       X461                          1
 UP BND       X462                          1
 UP BND       X463                          1
 UP BND       X464                          1
 UP BND       X465                          1
 UP BND       X466                          1
 UP BND       X467                          2
 UP BND       X468                          2
 UP BND       X469                          1
 UP BND       X470                          2
 UP BND       X471                          1
 UP BND       X472                          1
 UP BND       X473                          1
 UP BND       X474                          1
 UP BND       X475                          1
 UP BND       X476                          2
 UP BND       X477                          2
 UP BND       X478                          1
 UP BND       X479                          1
 UP BND       X480                          1
 UP BND       X481                          1
 UP BND       X482                          1
 UP BND       X483                          1
 UP BND       X484                          1
 UP BND       X485                          1
 UP BND       X486                          1
 UP BND       X487                          1
 UP BND       X488                          1
 UP BND       X489                          1
 UP BND       X490                          1
 UP BND       X491                          1
 UP BND       X492                          1
 UP BND       X493                          1
 UP BND       X494                          1
 UP BND       X495                          1
 UP BND       X496                          1
 UP BND       X497                          2
 UP BND       X498                          2
 UP BND       X499                          1
 UP BND       X500                          1
 UP BND       X501                          2
 UP BND       X502                          2
 UP BND       X503                          2
 UP BND       X504                          1
 UP BND       X505                          1
 UP BND       X506                          1
 UP BND       X507                          1
 UP BND       X508                          2
 UP BND       X509                          1
 UP BND       X510                          1
 UP BND       X511                          1
 UP BND       X512                          1
 UP BND       X513                          1
 UP BND       X514                          1
 UP BND       X515                          1
 UP BND       X516                          1
 UP BND       X517                          1
 UP BND       X518                          1
 UP BND       X519                          1
 UP BND       X520                          1
 UP BND       X521                          1
 UP BND       X522                          1
 UP BND       X523                          1
 UP BND       X524                          1
 UP BND       X525                          1
 UP BND       X526                          1
 UP BND       X527                          1
 UP BND       X528                          1
 UP BND       X529                          1
 UP BND       X530                          1
 UP BND       X531                          2
 UP BND       X532                          2
 UP BND       X533                          2
 UP BND       X534                          2
 UP BND       X535                          1
 UP BND       X536                          1
 UP BND       X537                          1
 UP BND       X538                          1
 UP BND       X539                          1
 UP BND       X540                          1
 UP BND       X541                          1
 UP BND       X542                          1
 UP BND       X543                          1
 UP BND       X544                          1
 UP BND       X545                          1
 UP BND       X546                          1
 UP BND       X547                          1
 UP BND       X548                          1
 UP BND       X549                          1
 UP BND       X550                          1
 UP BND       X551                          1
 UP BND       X552                          1
 UP BND       X553                          1
 UP BND       X554                          1
 UP BND       X555                          1
 UP BND       X556                          1
 UP BND       X557                          1
 UP BND       X558                          1
 UP BND       X559                          1
 UP BND       X560                          1
 UP BND       X561                          2
 UP BND       X562                          2
 UP BND       X563                          1
 UP BND       X564                          1
 UP BND       X565                          1
 UP BND       X566                          1
 UP BND       X567                          1
 UP BND       X568                          1
 UP BND       X569                          1
 UP BND       X570                          1
 UP BND       X571                          1
 UP BND       X572                          1
 UP BND       X573                          1
 UP BND       X574                          2
 UP BND       X575                          2
 UP BND       X576                          1
 UP BND       X577                          1
 UP BND       X578                          1
 UP BND       X579                          1
 UP BND       X580                          1
 UP BND       X581                          1
 UP BND       X582                          1
 UP BND       X583                          2
 UP BND       X584                          1
 UP BND       X585                          1
 UP BND       X586                          1
 UP BND       X587                          1
 UP BND       X588                          1
 UP BND       X589                          2
 UP BND       X590                          2
 UP BND       X591                          1
 UP BND       X592                          1
 UP BND       X593                          1
 UP BND       X594                          2
 UP BND       X595                          1
 UP BND       X596                          1
 UP BND       X597                          1
 UP BND       X598                          1
 UP BND       X599                          1
 UP BND       X600                          1
 UP BND       X601                          1
 UP BND       X602                          1
 UP BND       X603                          1
 UP BND       X604                          1
 UP BND       X605                          1
 UP BND       X606                          1
 UP BND       X607                          1
 UP BND       X608                          1
 UP BND       X609                          1
 UP BND       X610                          1
 UP BND       X611                          1
 UP BND       X612                          1
 UP BND       X613                          1
 UP BND       X614                          1
 UP BND       X615                          1
 UP BND       X616                          1
 UP BND       X617                          1
 UP BND       X618                          1
 UP BND       X619                          1
 UP BND       X620                          1
 UP BND       X621                          1
 UP BND       X622                          2
 UP BND       X623                          2
 UP BND       X624                          1
 UP BND       X625                          1
 UP BND       X626                          1
 UP BND       X627                          1
 UP BND       X628                          1
 UP BND       X629                          1
 UP BND       X630                          1
 UP BND       X631                          1
 UP BND       X632                          1
 UP BND       X633                          1
 UP BND       X634                          1
 UP BND       X635                          1
 UP BND       X636                          1
 UP BND       X637                          1
 UP BND       X638                          1
 UP BND       X639                          2
 UP BND       X640                          2
 UP BND       X641                          2
 UP BND       X642                          1
 UP BND       X643                          1
 UP BND       X644                          2
 UP BND       X645                          1
 UP BND       X646                          1
 UP BND       X647                          1
 UP BND       X648                          1
 UP BND       X649                          1
 UP BND       X650                          2
 UP BND       X651                          2
 UP BND       X652                          1
 UP BND       X653                          1
 UP BND       X654                          1
 UP BND       X655                          1
 UP BND       X656                          1
 UP BND       X657                          1
 UP BND       X658                          1
 UP BND       X659                          2
 UP BND       X660                          2
 UP BND       X661                          1
 UP BND       X662                          2
 UP BND       X663                          1
 UP BND       X664                          1
 UP BND       X665                          1
 UP BND       X666                          1
 UP BND       X667                          1
 UP BND       X668                          1
 UP BND       X669                          1
 UP BND       X670                          1
 UP BND       X671                          1
 UP BND       X672                          1
 UP BND       X673                          1
 UP BND       X674                          1
 UP BND       X675                          1
 UP BND       X676                          1
 UP BND       X677                          1
 UP BND       X678                          2
 UP BND       X679                          2
 UP BND       X680                          1
 UP BND       X681                          1
 UP BND       X682                          1
 UP BND       X683                          1
 UP BND       X684                          2
 UP BND       X685                          1
 UP BND       X686                          1
 UP BND       X687                          1
 UP BND       X688                          1
 UP BND       X689                          1
 UP BND       X690                          1
 UP BND       X691                          1
 UP BND       X692                          1
 UP BND       X693                          1
 UP BND       X694                          1
 UP BND       X695                          1
 UP BND       X696                          1
 UP BND       X697                          1
 UP BND       X698                          1
 UP BND       X699                          2
 UP BND       X700                          1
 UP BND       X701                          2
 UP BND       X702                          1
 UP BND       X703                          1
 UP BND       X704                          1
 UP BND       X705                          1
 UP BND       X706                          1
 UP BND       X707                          1
 UP BND       X708                          1
 UP BND       X709                          1
 UP BND       X710                          1
 UP BND       X711                          1
 UP BND       X712                          1
 UP BND       X713                          1
 UP BND       X714                          1
 UP BND       X715                          1
 UP BND       X716                          1
 UP BND       X717                          1
 UP BND       X718                          1
 UP BND       X719                          1
 UP BND       X720                          1
 UP BND       X721                          1
 UP BND       X722                          1
 UP BND       X723                          1
 UP BND       X724                          1
 UP BND       X725                          1
 UP BND       X726                          1
 UP BND       X727                          1
ENDATA
